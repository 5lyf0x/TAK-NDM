# TAK Rig Navigation Data Manager v0.2.0-r16-r26

## West-of-Mississippi state expansion

This release adds first-class state transportation pipelines for the 21 requested states not already covered by the working CA/AZ/UT profiles:

- Alaska, Arkansas, Colorado, Hawaii, Idaho, Iowa, Kansas, Louisiana
- Minnesota, Missouri, Montana, Nebraska, Nevada, New Mexico, North Dakota
- Oklahoma, Oregon, South Dakota, Texas, Washington, Wyoming

Each state retains Core OpenStreetMap/Geofabrik plus applicable Federal sources, with one or more authoritative state DOT/GIS public-road sources added through a declarative profile. Colorado and Idaho gain newly profiled recreation/trail feeds under strict full-size-vehicle gating; the existing Nevada and New Mexico recreation adapters remain in place.

## Scale and reliability

- Large state ArcGIS datasets can stream directly to `.geojsonl` and are read incrementally during enrichment.
- ArcGIS services without offset pagination use object-ID batching.
- Layer metadata is checked for polyline geometry and Query capability; schema mismatches are surfaced separately from ordinary endpoint failures.
- Alaska queries are split around the antimeridian and then clipped to the exact state polygon.
- Expansion-state public-road normalization rejects explicit private/closed/prohibited/planned/abandoned/unconstructed geometry when those attributes are present.

## Compatibility

- California, Arizona, and Utah definitions are intentionally unchanged.
- `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`.
- Per-profile revisions affect only the owning state's source fingerprint.
- Existing configuration, state, caches, credentials, and ready Navigation/Terrain/Environment/Cellular packages are preserved by the normal upgrade installer.
- r25 consolidated Cellular UI and r24 provider-specific parallel FCC acquisition remain unchanged.
