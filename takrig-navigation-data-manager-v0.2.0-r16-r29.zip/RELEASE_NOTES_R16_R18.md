# TAK Rig Navigation Data Manager v0.2.0-r16-r18

## Cinematic Environment vegetation/tuning update

- Increases WorldCover tree-cover density from 220 to 245/255 and mangrove/tree density from 235 to 250/255 so TAK Rig can render thicker forest stands.
- Adds Cinematic Environment v1.1 tuning metadata: `tree_height_scale=1.50`, `forest_density_scale=1.50`, `material_transition_feather_m=60`, and `tree_min_projected_px=0.60`.
- Keeps the static atlas asset set `cinematic-environment-v1`, `takrig.environment.sqlite.v1`, and strict Environment ZIP membership unchanged.
- Keeps `ROUTING_PIPELINE_REVISION = 0.2.0-r16`; no Navigation graph rebuild is intentionally triggered.

After installing r16-r18, rebuild the desired state 3D Environment package so the denser WorldCover classification is written into its `environment.sqlite`.
