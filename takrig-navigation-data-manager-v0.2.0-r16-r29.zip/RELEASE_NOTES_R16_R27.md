# TAK Rig Navigation Data Manager v0.2.0-r16-r27

## Executive Slate WebUI, phase 1–2 state imagery

- Replaces the default state detail presentation with the approved Executive Slate layout: full-bleed state hero with live status overlaid; independent Current Activity and Packages/Storage panels that fit responsive widths.
- Same-origin local geographic/sunset state artwork for all 50 states, resolved by actual state abbreviation. Twenty state assets have the detailed scenic style (AL through MD alphabetically, with the approved California artwork preserved); remaining 30 retain the earlier illustrative art until future phases.
- Restyles live Navigation, Elevation, Cellular, and Maintenance controls without changing API paths, permission behavior, source data, operation states, download URLs, or error reporting. Existing Source, FCC credentials, state selection, and settings interfaces remain available from left navigation.
- Real app status values are fetched from the existing `/api/v1/status` endpoint on the original refresh interval. No sample data from theme previews is shipped as live state data.
- Adds a small, allowlisted WebP static route; no third-party images or network artwork dependency.
- Installer deploys local assets under `/usr/local/lib/takrig-routing/web/assets`, preserving all existing config, caches, secrets, and ready data; systemd upgrade behavior unchanged.
- `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16` (no planned graph rebuild due to the display-only version bump).

Rollback: reinstall the unchanged r26 source ZIP using its original installer. State/artwork changes in r27 have no data migrations.
