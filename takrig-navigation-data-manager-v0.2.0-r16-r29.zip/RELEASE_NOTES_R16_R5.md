# TAK Rig Navigation Data Manager v0.2.0-r16-r5

## Scope

r16-r5 builds on the validated r16-r4 Outdoors polygon-completion release and keeps `ROUTING_PIPELINE_REVISION = "0.2.0-r16"`. It adds the requested Outdoors map-management/drawing workflow improvements, weighted progress/ETA, automatic download acceleration, and a defensive geometry pipeline for the field-observed GEOS error `TopologyException: Ring edge missing ...`.

## Outdoors map management

- READY maps can be renamed without rebuilding their map components. The NDM job/catalog display name and downloadable filename are updated while the stable `package_id` is retained.
- Active/queued maps expose **CANCEL BUILD**. Cancellation is persisted in the job record and the verified builder process group is terminated. Build loops and external command stages also check cancellation cooperatively.
- Canceled maps remain available as definitions and expose **RETRY BUILD**.
- READY, FAILED, and CANCELED maps expose **DELETE**. Deleting removes the map job and its finished package/work artifacts while preserving reusable NDM source caches.

## Polygon drawing/editing

- Added an icon-only Undo control. It removes the most recently committed polygon vertex and recalculates geometry/estimates.
- Closed polygons now expose draggable red vertex handles. Dragging a handle updates the shaded polygon continuously and refreshes the estimate.
- Clicking the map after a polygon is complete no longer silently discards the completed polygon; use Clear Drawing or Undo when intentionally changing it.
- Existing r16-r4 completion paths remain: click first vertex, NDM-owned double-click, or **FINISH POLYGON**.

## Build progress and ETA

- Outdoors jobs now maintain weighted overall build progress rather than reporting only the current stage.
- Active job rows show a compact beveled percentage bar.
- ETA is calculated from observed progress and is blended with retained local build-history data when available.
- Build history is retained under the Outdoors status directory and is limited to the most recent 20 successful builds.

## Automatic download workers

- Outdoors hillshade acquisition now uses automatic adaptive concurrency.
- Starts at 2 active requests.
- Measures real aggregate bytes/second from the actual USGS 3DEP requests.
- Ramps up only while parallelism improves throughput and backs off when throughput materially declines.
- Hard maximum is **6 workers**, per operator requirement.
- Worker count is not exposed as a normal user setting.

## TopologyException / malformed source geometry hardening

The field error occurred with both rectangle and polygon selections and landed exactly on Web-Mercator tile-edge coordinates. r16-r5 therefore treats it as a source-vector overlay/encoding robustness issue rather than a polygon-selection-only issue.

The vector pipeline now:

- repairs invalid Shapely/GEOS geometry before repeated overlay work;
- applies fixed precision before tile clipping;
- retries intersection/difference at a coarser precision when the first overlay fails;
- uses safe intersection checks throughout selection and tile clipping;
- protects water-union/hydro-line difference operations;
- wraps MVT encoding so a malformed individual feature fragment is isolated and skipped instead of aborting the entire regional map build;
- records skipped geometry-fragment counts in component/package metadata and the READY detail when non-zero.

This applies equally to rectangle and polygon Outdoors selections.

## Compatibility

- Display/service version: `0.2.0-r16-r5`
- Routing pipeline revision: `0.2.0-r16` (unchanged)
- Valhalla: `3.6.3`
- Outdoors package format: `takrig.outdoors.region.v1`
- PMTiles: v3
- Leaflet: local verified 1.9.4 runtime as introduced in r16-r2
