# TAK Rig Navigation Data Manager v0.2.0-r16-r26 Validation

Date: 2026-10-08

## Identity

- Version: `0.2.0-r16-r26`
- Routing pipeline revision: `0.2.0-r16` (unchanged)
- Release type: West-of-Mississippi state-source expansion
- Upgrade policy: preserve existing configuration, state, caches, credentials, and ready Navigation/Terrain/Environment/Cellular packages.

## Release scope validated

- First-class state transportation profiles exist for all 21 requested expansion states: AK, AR, CO, HI, ID, IA, KS, LA, MN, MO, MT, NE, NV, NM, ND, OK, OR, SD, TX, WA, WY.
- California, Arizona, and Utah continue to use their existing source definitions; their global routing pipeline fingerprint is not bumped.
- Expansion profiles use per-source `profile_revision` values that participate in only the owning state's source fingerprint.
- Large ArcGIS state sources support streamed GeoJSONL acquisition and incremental enrichment.
- ArcGIS services without offset pagination support object-ID batch acquisition.
- ArcGIS metadata probing identifies polyline/query schema mismatches.
- Alaska uses antimeridian-safe split query envelopes plus exact state-boundary clipping.
- New state public-road normalization rejects explicit non-public/closed/planned/unconstructed records when upstream attributes expose them.
- Newly profiled recreation data requires explicit full-size-vehicle evidence before routing.
- r25 Cellular Package Status consolidation and r24 provider-specific parallel FCC downloader are retained.
- r25→r26 fingerprint comparison for California, Arizona, and Utah: **byte-for-byte unchanged** (`CA 971f2d…`, `AZ 181ee1…`, `UT 79e3c0…`).
- Installer regression confirms `state_profiles.py` is deployed with the runtime.

## Source-tree validation

- `python3 -m py_compile src/*.py tests/*.py`: PASS
- `python3 -m unittest discover -s tests -p 'test_*.py'`: **121 / 121 PASS**
- `bash -n install.sh uninstall.sh takrig-routing takrig-nav-manager`: PASS
- Inline Web JavaScript `node --check`: PASS

## Fresh-extraction validation

- ZIP CRC/integrity: PASS
- Root-flat package layout: PASS
- Missing/extra/byte-different files before generated test caches: **0 / 0 / 0**
- Forbidden `__pycache__`, `.pyc`, `.pyo` content: NONE
- Executable modes for `install.sh`, `uninstall.sh`, `takrig-routing`, and `takrig-nav-manager`: `0755` PASS
- Fresh extraction Python compile: PASS
- Fresh extraction unit/regression suite: **121 / 121 PASS**
- Fresh extraction shell syntax: PASS
- Fresh extraction inline Web JavaScript `node --check`: PASS
- Packaged files: **70**
