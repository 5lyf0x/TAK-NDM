# TAK Rig Navigation Data Manager v0.2.0-r16-r23

## Release scope

- Fixes Package Status summary-column overlap when long state statuses such as **WAITING FOR MAINTENANCE** are displayed.
- Replaces the narrow percentage-only Status column with minimum-width responsive grid tracks so status text cannot intrude into Current Activity.
- Long summary status pills may wrap cleanly inside their own column while compact statuses such as READY and QUEUED remain compact.
- Adds wider inter-column spacing and equivalent protections at the 1180 px and 900 px responsive breakpoints.
- Preserves the r22 gateway-wide FCC API credential model and the r21 Navigation/Elevation/Cellular data-card formatting.
- `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`.

## Upgrade behavior

Normal in-place install. Existing NDM configuration, state, caches, ready packages, FCC source inventory, and saved FCC credentials are preserved.
