# TAK Rig Navigation Data Manager v0.2.0-r16-r1

Focused Outdoors Map Creator preview-map correction built from v0.2.0-r16.

## Fixed

- The large Outdoors selection map and both min/max zoom preview maps no longer contact the public basemap tile endpoint directly from the browser.
- All preview tiles are fetched through the NDM API and shared through a persistent server-side disk cache.
- Added retry/backoff and bounded upstream concurrency to prevent three Leaflet maps from creating bursts of duplicate/competing requests.
- Added stale-cache fallback so previously viewed areas continue to render when the upstream preview source is temporarily unavailable.
- Added browser tile-error retry handling so a transient failure does not remain a permanent dark tile until the whole page is refreshed.
- Min/max preview updates are debounced and their tile layers are started after the main selection map, reducing initial contention.

## Operator configuration

The following keys are supported in `/etc/takrig-routing/config.json` and are populated by the r16-r1 installer when missing:

- `outdoors_preview_tile_url`
- `outdoors_preview_tile_timeout_seconds`
- `outdoors_preview_tile_retry_count`
- `outdoors_preview_tile_max_upstream_concurrency`
- `outdoors_preview_tile_cache_days`

Defaults use the same OpenStreetMap preview basemap as r16, but the browser now sees only the local NDM proxy endpoint.

## Compatibility

- Outdoors PMTiles/MVT package format: unchanged from r16.
- Routing/Valhalla package format: unchanged.
- 3D terrain/elevation format: unchanged.
- TAK Rig v0.19.1-r12: unchanged and remains the paired Android package.
- Routing pipeline revision remains pinned to r16 for this correction, preventing a display-only update from forcing state graph rebuilds.
- No SHA-256 sidecar is produced for this NDM source release.
