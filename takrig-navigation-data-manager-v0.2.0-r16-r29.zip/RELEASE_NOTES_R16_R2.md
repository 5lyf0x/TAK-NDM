# TAK Rig Navigation Data Manager v0.2.0-r16-r2

Focused Outdoors Map Creator Leaflet/runtime-layout correction built from v0.2.0-r16-r1.

## Fixed

- Leaflet is no longer loaded by the browser from `unpkg.com` or another CDN. The Web UI references only local NDM `/vendor/leaflet/` assets.
- The exact Leaflet 1.9.4 stylesheet is packaged locally. During installation, the exact pinned Leaflet 1.9.4 npm archive is downloaded once and verified by SHA-512; the extracted `leaflet.js` is independently verified by SHA-256 before being installed under the NDM Web root.
- The NDM Web server serves only an explicit whitelist of Leaflet files and images.
- The main Outdoors selection map and both min/max preview maps call Leaflet `invalidateSize()` after initial page layout.
- A `ResizeObserver` invalidates all three maps whenever their map containers change size.

## Preserved behavior

- The r16-r1 server-side preview-tile proxy/cache remains unchanged.
- Preview source URL, timeout, retries, upstream concurrency, and cache age remain operator-editable in `/etc/takrig-routing/config.json`.
- Outdoors PMTiles/MVT package format, routing/Valhalla packages, and 3D terrain/elevation packages are unchanged.
- `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`, so this display/runtime correction does not intentionally trigger state routing rebuilds.

## Installation note

The installer already requires Internet access for Ubuntu packages and Python dependencies. r16-r2 also uses that installation-time access to obtain the pinned official Leaflet archive. Once installed, the browser loads Leaflet from the NDM server itself rather than a public CDN.
