# TAK Rig Navigation Data Manager v0.2.0-r16-r19

## Per-state source persistence and Utah source-default repair

- Makes per-state source configuration authoritative. Newly configured states no longer inherit old global r9 source-group disable flags, which could make most Federal and State Sources appear disabled even though the current per-state Standard preset should enable them.
- Standard preset now enables every routable source registered for the state; Maximum Coverage enables every registered source; Custom preserves the operator's exact per-source enable choices.
- Serializes all `settings.json` read/modify/write transactions with a cross-thread/cross-process `settings.lock`, preventing a simultaneous state-selection/operations save from overwriting a per-state **SAVE SOURCES** update.
- Keeps endpoint health independent from source enablement. `HEALTHY`, `ERROR`, and `NOT_CHECKED` are probe states; the checkbox alone controls whether a source participates in the next build.
- Fixes the state-source **CHECK** action so checking an endpoint updates only that row's health display and no longer reloads the modal, which previously discarded unsaved checkbox/URL edits elsewhere in the same state.
- Adds Web save verification: after **SAVE SOURCES**, the UI compares the submitted checkbox states with the server's persisted state before closing the editor.
- Restarts `takrig-nav-manager.service` explicitly during an in-place upgrade so the new Python/Web runtime is active immediately; `systemctl enable --now` alone does not restart an already-running service.
- Utah's built-in Standard source set now resolves independently of legacy global switches and includes Core OSM plus all routable Federal sources, Utah Roads / UDOT / UGRC, and Utah Trails and Pathways. The reference-only USGS Trails layer remains off in Standard and is available in Maximum Coverage.
- Keeps `ROUTING_PIPELINE_REVISION = 0.2.0-r16`; this is a source-policy/persistence/UI release and does not change route feature normalization or Valhalla graph semantics.
