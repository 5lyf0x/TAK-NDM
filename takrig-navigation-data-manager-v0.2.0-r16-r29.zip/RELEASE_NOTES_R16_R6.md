# TAK Rig Navigation Data Manager v0.2.0-r16-r6

## Scope
This is an Outdoors hillshade-resilience release built on r16-r5. It does not change the routing pipeline revision.

## USGS 3DEP hillshade resilience
- Transient HTTP statuses `408`, `425`, `429`, `500`, `502`, `503`, and `504` are retried.
- Timeouts, URL/network errors, connection resets, and invalid transient image responses are retried.
- Initial retry delays are 1, 2, and 4 seconds plus positive randomized jitter.
- `Retry-After` is honored when supplied.
- Tiles still unavailable after normal retries are deferred until the main queue completes and retried after 8, 16, and 30 second windows.
- Adaptive concurrency starts at 2 workers, ramps only while aggregate throughput benefits, backs off on failures, and is hard capped at 6.

## Persistent hillshade cache
Verified PNG source tiles are cached under the NDM Outdoors cache using a versioned namespace. The cache survives failed/canceled map builds and can be reused by retries and overlapping map definitions. The finished PMTiles archive is assembled from cache in deterministic tile order after acquisition.

## Partial availability policy
NDM does not immediately throw away a large build for one stubborn USGS tile. After all extended retries, a residual gap may be accepted only when it is at most 0.1% of requested hillshade tiles, with an absolute ceiling of 25 missing tiles. For selections below 1,000 hillshade tiles, the allowed gap is zero. Accepted gaps publish as `READY WITH WARNINGS` and are recorded in manifest/package metadata. Anything above the threshold fails.

## Preserved r16-r5 functionality
Map rename/delete/cancel, icon-only polygon undo, draggable closed-polygon vertices, compact weighted progress/ETA, topology repair/isolation, and the six-worker automatic concurrency ceiling are retained.

## Routing fingerprint
`ROUTING_PIPELINE_REVISION = "0.2.0-r16"` remains unchanged.
