# TAK Rig Navigation Data Manager v0.2.0-r14

R14 is the terrain-pipeline reliability correction for the first r13 3D Terrain release. It preserves the `takrig.terrain.region.v1` package contract used by TAK Rig r23 while correcting acquisition, georeferencing, resume, validation, and status behavior.

## Terrain acquisition and raster correctness

- Removes the r13 `<1024 bytes` response-size failure. Every USGS 3DEP response is validated as a raster with GDAL regardless of byte size.
- Invalid responses report the 0.5° cell bbox, HTTP status, content type, response size, and GDAL/server detail.
- Valid all-NODATA edge/coastal cells are skipped rather than failing the state.
- Uses source raster validity/NODATA during GDAL warping and writes invalid samples as TAK Rig `-32768` Int16 NODATA.
- Requests a bbox expanded by half of one 3-arc-second sample around each stored 0.5° cell and uses `adjustAspectRatio=false`. The 601 output pixel centers therefore align with the 601 sample nodes TAK Rig interpolates from the stored west/east/south/north bounds.

## Reliability and resume

- USGS network timeouts, 429s, and transient 5xx responses retry with bounded exponential backoff.
- Terrain builds persist each completed tile into a WAL/FULL SQLite work database and resume committed cells after a later failure.
- A failed late-state cell no longer forces already-completed valid cells to be downloaded again.
- Terrain builds obey the NDM free-space reserve before and during work and enter `WAITING FOR SPACE` with detailed estimates instead of exhausting disk.
- Rapid repeated Build/Rebuild clicks are deduplicated. The terrain builder also re-checks ready state after acquiring the global terrain-build lock.

## Packaging / validation

- `tile_count` now means actual stored valid terrain tiles; candidate and skipped-NODATA counts are reported separately.
- Fixes decimal tile-ID scratch filename collisions and removes ENVI scratch files after every cell.
- Preserves a legitimate `0 m` maximum elevation instead of treating zero as missing.
- Before publication, the SQLite database passes quick/integrity checks, schema/encoding/shape validation, decompression/payload checks, min/max consistency, and contains at least one valid elevation tile. ZIP CRC/member validation remains mandatory.
- Adds antimeridian-safe `coverage_boxes`. For wrapped states such as Alaska, legacy `bounds` is constrained to one safe box so the existing r23 client cannot mistake a world-spanning rectangle for installed terrain.

## Web GUI

- Package Status now shows 3D Terrain stage, cell progress, exact failure detail, and disk-space waiting detail inline.
- Failed or waiting terrain exposes an explicit **RETRY 3D TERRAIN** action.

## Validation

- Python/unit/integration suite: 57 passed, 0 failed.
- Web inline JavaScript: syntax PASS.
- Shell scripts: syntax PASS.
- Release ZIP CRC/integrity and extracted-release rerun required before handoff.
