# TAK Rig Navigation Data Manager v0.2.0-r16-r29

TAK Rig Navigation Data Manager (NDM) is the TAK Gateway-side acquisition, enrichment, build, and delivery service for TAK Rig offline Navigation, Elevation/3D Terrain, 3D Environment, and Cellular Coverage data. It installs on Ubuntu/Debian and keeps selected U.S. state data ready without generating expensive routing graphs inside an Android download request.

The routing pipeline revision remains pinned to `0.2.0-r16`; installing r16-r29 does not intentionally rebuild already-current Navigation graphs.

## r16-r28 highlights

Executive Slate v28: centered real NDM state page, fixed card heights and sharp full-scene imagery, text-only sidebar with no sidebar wordmark, 50 locally bundled state artworks (see `RELEASE_NOTES_R16_R28.md`).

## r16-r27 highlights

- Approved responsive Executive Slate State WebUI with 50 locally bundled state images (20 detailed, 30 earlier illustration).
- Existing Navigation, Terrain, Cellular, Sources, and Maintenance API actions remain live and unchanged.
- Added safe same-origin static WebP routing; no routing pipeline changes.

## r16-r26 highlights

- Adds first-class state transportation pipelines for the 21 requested west-of-Mississippi expansion states: Alaska, Arkansas, Colorado, Hawaii, Idaho, Iowa, Kansas, Louisiana, Minnesota, Missouri, Montana, Nebraska, Nevada, New Mexico, North Dakota, Oklahoma, Oregon, South Dakota, Texas, Washington, and Wyoming.
- Preserves the existing California, Arizona, and Utah source definitions and routing behavior.
- Moves expansion-state definitions into declarative per-state profiles with independent `profile_revision` values, so an adapter change invalidates only the affected state rather than bumping the global routing pipeline.
- Adds streamed GeoJSONL acquisition/enrichment for large statewide ArcGIS inventories so large road networks such as Texas do not have to be accumulated as one in-memory FeatureCollection.
- Adds ArcGIS object-ID batch fallback for authoritative services that do not support offset pagination.
- Adds Alaska antimeridian-safe split query envelopes before exact state-boundary clipping.
- Adds conservative public-road normalization for the new profiles, rejecting explicit private/closed/prohibited/planned/abandoned/unconstructed records and retaining road class, surface, and high-clearance evidence where supplied.
- Adds strict full-size-vehicle gating for newly profiled state recreation/trail data; ATV/UTV/motorcycle-only or ambiguous trails are not promoted into normal vehicle routing.
- Source probing now distinguishes upstream schema changes (non-polyline or non-queryable ArcGIS layers) from ordinary endpoint failures.
- Keeps the r25 consolidated Cellular interface and r24 provider-specific parallel FCC acquisition unchanged.

## r16-r25 highlights

- Consolidates the full Cellular Coverage workflow into every state **CELL** card in Package Status and removes the old standalone Cellular Coverage section.
- Keeps the gateway-wide **FCC API status/settings** control in the Package Status header while keeping carrier selection, FCC source inventory, acquisition, and package lifecycle state-specific.
- Shows AT&T / Verizon / T-Mobile selectors and readiness, FCC vintage/source/H3 metadata, live parallel-download progress/rate, import/acquire controls, collapsible source details, and Cellular package actions in one state-local workspace.
- Preserves the r24 provider-specific FCC discovery and parallel resumable downloader (default 4 workers, configurable 1-6) with server 429/Retry-After backoff.

- Makes FCC API credentials gateway-wide in the WebUI: configure the account/token once and reuse it automatically for every state.
- Adds global FCC API status/test/save/clear/release endpoints while keeping state-specific carrier selection, source inventory, availability-vintage choice, acquisition, and package lifecycle.
- Replaces per-state FCC credential entry with per-state **ACQUIRE FCC DATA** using the saved gateway credentials.
- Makes each state name more prominent in Package Status with a larger 20 px state label and a separate state-code badge.
- Preserves the r16-r21 Package Status data-card geometry and all existing package/download behavior.

- Refined Package Status formatting: larger NAV / DEM / CELL identifiers, more card breathing room, larger action labels, stable equal-height cards, and wider desktop use.
- Navigation, Elevation, and Cell Coverage lifecycle/download behavior remains unchanged from r16-r20.

- Replaces the vertical Package Status action stack with the approved **Data Cards + Actions** layout.
- Adds independent horizontal **Navigation Data**, **Elevation Data**, and **Cell Coverage** cards for every shown state.
- Adds direct WebUI download actions for all three ready package types:
  - `/api/v1/packages/<STATE>/download`
  - `/api/v1/terrain/<STATE>/download`
  - `/api/v1/cellular/<STATE>/download`
- Keeps a previously verified package downloadable while source checking, rebuilding/updating, or after a failed replacement. Download is disabled only when no usable retained package exists.
- Presents package lifecycle states independently: Not Built, Queued, Building/Updating, Ready, Checking, Update Available, Failed, Waiting for Space, No Sources, and Sources Incomplete as applicable.
- Keeps source-cache cleanup and 3D Environment controls in a compact maintenance row beneath the three primary data cards.
- Removes the **Outdoors Map Creator** product, Outdoors WebUI/API/catalog lifecycle, Outdoors package generation, and the Leaflet runtime that existed solely for the creator.
- Upgrade does **not** delete existing `/var/lib/takrig-routing/outdoors` files. Legacy Outdoors data is left untouched on disk but is no longer surfaced or maintained by NDM.
- Preserves the r16-r19 per-state source persistence correction, including authoritative Standard/Maximum Coverage/Custom state source presets and Utah defaults.

## Per-state source configuration

Each state has an independent source registry grouped as Core, Federal, and State Sources:

```text
GET  /api/v1/states/<STATE>/sources
POST /api/v1/states/<STATE>/sources
POST /api/v1/states/<STATE>/sources/<SOURCE_ID>/check
```

Per-state source selection is authoritative. Legacy global source-group flags do not disable sources selected in a state preset. Health (`HEALTHY`, `NOT CHECKED`, `SCHEMA CHANGED`, `ERROR`) is independent from whether the source is enabled.

Utah Standard includes Core OSM, all routable Federal sources, Utah Roads / UDOT / UGRC, and Utah Trails and Pathways. Reference-only USGS Trails remains available through Maximum Coverage.

## West-of-Mississippi state profiles (r16-r26)

The 21 expansion states now have built-in authoritative state transportation profiles in addition to Core OSM and applicable Federal sources:

```text
AK AR CO HI ID IA KS LA MN MO MT NE NV NM ND OK OR SD TX WA WY
```

The profiles use state DOT/GIS public-road services and state-sponsored transportation inventories. Colorado and Idaho also include newly profiled recreation/trail feeds under strict full-size-vehicle filtering; the existing Nevada and New Mexico recreation adapters remain available. State recreation geometry is not assumed routable merely because it is motorized: explicit full-size/street-legal/high-clearance evidence is required for the new profiled trail feeds.

New expansion-state ArcGIS sources are schema-checked at runtime for polyline geometry and Query capability. Large layers stream to GeoJSONL and enrichment reads them incrementally. Services without offset pagination use object-ID batching. Alaska uses split antimeridian query envelopes followed by exact state-boundary clipping.

Per-profile revision values participate in only that state's source fingerprint. The global `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`, and CA/AZ/UT retain their previous source definitions.

## Navigation package

The manager downloads/enriches state road data and hands completed work atomically to the Valhalla 3.6.3 processor. The previous verified ZIP remains published until a replacement fully builds and validates.

Ready package format:

```text
manifest.json
valhalla.json
valhalla_tiles.tar
routing_coverage/index.json
routing_coverage/11/<x>/<y>.geojson.gz
```

Format/schema:

```text
takrig.valhalla.region.v1
takrig.routing.coverage.v2
```

Download:

```text
GET /api/v1/packages/<STATE>/download
```

## Elevation / 3D Terrain

New Terrain builds default to approximately 30 m (1 arc-second) sampling and produce aligned 60/120/240 m overview levels in the existing `terrain.sqlite` contract. Existing ready packages remain valid.

Download:

```text
GET /api/v1/terrain/<STATE>/download
```

## 3D Environment

3D Environment remains an independent per-state lifecycle. NDM preprocesses ESA WorldCover into `takrig.environment.region.v1` packages containing `manifest.json` and `environment.sqlite`. Cinematic Environment v1 may add cached photographic terrain/tree-impostor atlas metadata while failing soft to classification-only output if optional asset acquisition is unavailable.

Environment is maintained separately from the three downloadable Package Status data cards and retains its Build/Rebuild/Remove controls.

## Cellular Coverage

Cellular Coverage remains an independent FCC H3 dataset. For each selected carrier, NDM normalizes FCC in-vehicle coverage into one best-available class per H3 resolution-9 cell using:

```text
5G > LTE > Voice/3G
```

Ready ZIP members:

```text
manifest.json
coverage.h3
```

Contracts:

```text
takrig.cellular.region.v2
takrig.cellular.manifest.v2
takrig.cellular.h3.v1
```

Download:

```text
GET /api/v1/cellular/<STATE>/download
```

## Catalog and HTTP delivery

TAK Rig discovers ready data through:

```text
GET /api/v1/catalog
```

NDM serves validated packages with HTTP/1.1 exact framing, Range/Content-Range support, and ETag/If-Range handling. Package generation never runs synchronously inside a download request.

## Installation

```bash
cd ~/Downloads
unzip -q takrig-navigation-data-manager-v0.2.0-r16-r29.zip -d takrig-navigation-data-manager-v0.2.0-r16-r29
cd takrig-navigation-data-manager-v0.2.0-r16-r29
sudo ./install.sh
```

The normal upgrade installer preserves existing NDM configuration, state, caches, and previously built package data. r16-r21 retains the r16-r20 Outdoors removal and removes stale installed Outdoors runtime/UI assets but deliberately leaves legacy `/var/lib/takrig-routing/outdoors` data untouched.

## Useful commands

```bash
takrig-nav-manager status
takrig-nav-manager select CA NV AZ UT NM CO
takrig-nav-manager select --preset southwest
takrig-nav-manager reconcile --force-refresh
takrig-routing status
journalctl -u takrig-nav-manager.service -f
```

Server state remains under `/var/lib/takrig-routing`; logs remain under `/var/log/takrig-routing`.


## r29 elevation reliability and Pause / Resume

- Four independent USGS terrain cell requests run in parallel by default.
  Terrain SQLite writes and commit checkpoints stay single-threaded.
- After repeated USGS 502/503/504 errors, full-size raster requests
  automatically split into four aligned raster subrequests; exhausted transient
  errors trigger bounded retries at reduced concurrency (four → two → one).
- A previously completed 90 m package remains downloadable while an unfinished
  30 m work database resumes. The old package is replaced only after the 30 m
  package validates successfully.
- Navigation, Elevation and Cellular cards have independent Pause/Resume
  controls. Pause is cooperative and waits for a safe checkpoint, so an in-flight
  request or native Valhalla build stage may take time to finish. PAUSING and
  PAUSED are distinct states. Paused controls persist across NDM restarts.
- Navigation source downloads are cached and processing input is retained.
  Native Valhalla tile compilation itself is not incrementally resumable and
  may restart its current phase when resumed; completed ready packages remain.
- Cellular download batches and normalized H3 source records reuse completed
  cached work after resume. An interrupted encoding step may restart.
- A direct SSH recovery process must finish/stop before installing the new
  package. The installer will reject an active legacy background worker.
- The release preserves existing state files, ready packages, user settings,
  secrets, 50 local state image assets, and the r28 Executive Slate layout.

API (HTTP POST): `/api/v1/states/CA/{navigation|terrain|cellular}/{pause|resume}`.
Use the dashboard controls rather than manually editing pause markers.
