# TAK Rig Navigation Data Manager v0.2.0-r16-r22

## Release scope

- FCC API credentials are now configured once per TAK Gateway and reused automatically for every state.
- New gateway-wide FCC API status/release/test/save/clear endpoints mirror the actual credential scope.
- State Cellular cards now use **ACQUIRE FCC DATA** with the shared gateway credentials; carrier selection, source inventory, availability vintage, acquisition, and package state remain per-state.
- Legacy state-scoped FCC credential endpoints remain compatibility aliases and still operate on the same shared credential file.
- Package Status state names are more prominent: 20 px bold state name plus a separate state-code badge.
- Existing Navigation, Elevation, 3D Environment, and Cellular package schemas/lifecycles remain unchanged.
- `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`.

## Upgrade behavior

Normal in-place install. Existing NDM configuration, state, caches, ready packages, FCC source inventory, and saved FCC credentials are preserved.
