# TAK Rig Navigation Data integration contract — v0.2.0-r16-r26

> r16-r26 note: FCC API credentials remain gateway-wide and shared by every state. The WebUI now consolidates each state's carrier selection, FCC source inventory/acquisition, progress, source details, and Cellular package lifecycle into that state's CELL card in Package Status; the standalone Cellular Coverage section is removed.





## R16-r26 west-of-Mississippi state-profile contract

The state-source registry now supports declarative per-source profiles in `state_profiles.py`. The expansion covers `AK AR CO HI ID IA KS LA MN MO MT NE NV NM ND OK OR SD TX WA WY`; CA/AZ/UT keep their previously validated definitions. Each profiled source carries its own `profile_revision`, which participates in the owning state's source fingerprint without changing `ROUTING_PIPELINE_REVISION=0.2.0-r16`.

Expansion-state public-road profiles are supplemental `public_road_authority` sources. ArcGIS metadata is checked for polyline geometry and Query capability. Large sources may be persisted as newline-delimited GeoJSON (`.geojsonl`) and consumed incrementally by enrichment; legacy FeatureCollection `.geojson` remains supported. If an ArcGIS layer does not support offset pagination, NDM uses `returnIdsOnly` plus object-ID batches. Alaska state-source acquisition uses split longitude envelopes across the antimeridian, then exact polygon clipping.

The new generic state-road normalizer rejects explicit private, closed, prohibited, abandoned, proposed/planned/future/vacated, or unconstructed records when the upstream attributes expose those states. Newly profiled recreation/trail services use strict full-size-vehicle evidence; generic motorized/OHV wording alone is insufficient to make a line routable.

## R16-r25 Package Status Cellular UI contract

The WebUI has one state-local Cellular workspace per shown state: the **CELL** card inside Package Status. The separate Cellular Coverage section no longer exists. Gateway-wide FCC API status/settings remain a single global control in the Package Status header.

The CELL card exposes the existing state-specific APIs and lifecycle without changing their HTTP contracts: carrier selection, manual H3 import, FCC API acquisition, source-file removal, package build/update/rebuild/remove, and direct package download. Source details remain collapsible and live acquisition progress may report aggregate file counts, transferred bytes, worker count, and transfer rate.

## R16-r22 FCC API credential scope

FCC API credentials are TAK-Gateway-wide, not state-specific. Configure/test/save/clear them through:

```text
GET  /api/v1/cellular/api/status
GET  /api/v1/cellular/api/releases
POST /api/v1/cellular/api/test
POST /api/v1/cellular/api/save
POST /api/v1/cellular/api/clear
```

The stored credential set is reused by every state. State-specific carrier selection, cached source inventory, availability-vintage selection, and package state remain independent. Acquisition is still targeted to one state at a time:

```text
POST /api/v1/states/<STATE>/cellular/api/acquire
```

Legacy state-scoped FCC credential/status routes remain compatibility aliases, but they operate on the same gateway-wide credential set.

## R16-r20 Package Status download contract

The NDM WebUI exposes three independent primary data cards per state: Navigation Data, Elevation Data, and Cell Coverage. Each card may be in a different lifecycle state. A verified retained package remains downloadable while a replacement is being checked/built or when that replacement fails. Download is disabled only when no usable package descriptor/file exists.

```text
GET /api/v1/packages/<STATE>/download
GET /api/v1/terrain/<STATE>/download
GET /api/v1/cellular/<STATE>/download
```

R16-r20 removes the Outdoors Map Creator product and its API/catalog/runtime integration. Upgrade intentionally leaves any existing `/var/lib/takrig-routing/outdoors` files untouched; they are legacy retained data and are no longer managed by NDM.

## R16-r14 Cellular source-tier contract

For each selected carrier, the coherent FCC H3 source set requires `voice`, `lte`, `5g_7_1`, and `5g_35_3`; `3g` is optional. Both 5G source variants remain separate in the source inventory/fingerprint and are unioned during normalization into the final `5g` class. The client-facing H3 binary schema remains `takrig.cellular.h3.v1`.

## Manager → processor

The Navigation Data Manager owns downloading and source enrichment. A completed state source is handed atomically to the processor at:

```text
/var/lib/takrig-routing/incoming/<state>.osm.pbf
/var/lib/takrig-routing/incoming/<state>.osm.pbf.json
```

The PBF is copied to a `.part` name first; the final `.osm.pbf` appears last. The processor never consumes an incomplete download.

The sidecar includes state identity, bounds, expected source SHA-256, source composition, source revisions, source fingerprint, **effective build fingerprint**, and manager version. The processor carries that build fingerprint into failure and ready-package metadata so the manager can suppress an identical deterministic retry while still allowing a changed source/software fingerprint to proceed.

## Processor → ready package

Once claimed, the processor moves the job under `processing/`. The previous ready ZIP remains published until the replacement ZIP is fully built and verified.

Successful output:

```text
/var/lib/takrig-routing/ready/
  takrig-routing-<state>-valhalla-3.6.3.zip
  takrig-routing-<state>-valhalla-3.6.3.zip.json
```

The R9 package also contains graph-derived navigation coverage:

```text
routing_coverage/index.json
routing_coverage/11/<x>/<y>.geojson.gz
```

`routing_coverage/index.json` uses schema `takrig.routing.coverage.v2`. Its tiles come from the completed Valhalla graph, include unnamed graph edges, and classify retained automobile-accessible ways as `road` or `offroad`. The processor verifies every indexed gzip tile before publishing the ZIP. Coverage is a static graph-eligibility visualization; route-time restrictions can still make an edge unavailable.


## Per-state source configuration (R10)

```text
GET  /api/v1/states/<STATE>/sources
POST /api/v1/states/<STATE>/sources
POST /api/v1/states/<STATE>/sources/<SOURCE_ID>/check
```

`GET` returns the effective state-specific source registry grouped as `Core`, `Federal`, and `State Sources`, including built-in/default endpoints, effective endpoints, override mode, enabled state, health, revision, and check metadata. `POST` persists the selected preset/source set and endpoint overrides for only that state. The CHECK action probes the currently edited/effective endpoint and does not require saving the override first.

Source settings and effective endpoint URLs participate in that state's build fingerprint. State DOT/public-road authority sources are supplemental-only and are conflated against Core so only materially missing road geometry is injected.


## Cellular Coverage package contract (R16-r13)

Cellular Coverage is an independent NDM dataset. FCC acquisition and preprocessing run on TAK Gateway; TAK Rig receives only the compact best-available H3 result. Cellular never changes Valhalla graph input, Elevation/Terrain, or 3D Environment package formats.

### Source acquisition

The state Cellular card exposes only carrier selection (`AT&T`, `Verizon`, `T-Mobile`). A selected carrier implies all applicable FCC technologies. Two equivalent acquisition paths feed one normalized source inventory:

```text
PUT  /api/v1/states/<STATE>/cellular/import?filename=<FCC_FILE>
POST /api/v1/states/<STATE>/cellular/api/test
POST /api/v1/states/<STATE>/cellular/api/save
POST /api/v1/states/<STATE>/cellular/api/clear
GET  /api/v1/states/<STATE>/cellular/api/status
GET  /api/v1/states/<STATE>/cellular/api/releases
POST /api/v1/states/<STATE>/cellular/api/acquire
GET  /api/v1/states/<STATE>/cellular/sources
POST /api/v1/states/<STATE>/cellular/sources/<SOURCE_ID>/remove
POST /api/v1/states/<STATE>/cellular/carriers
```

Manual imports accept official provider-specific FCC **Hexagon Coverage – GeoPackage** ZIP/GPKG files and stream them to disk. API acquisition downloads the same FCC H3 inputs. Raw Coverage is intentionally not a valid final Cellular source. Both paths validate provider/state/vintage/H3-resolution/environment/technology and converge into the same source cache/inventory.

Web-managed gateway credentials in `/var/lib/takrig-routing/secrets/fcc-bdc.env` are authoritative; `/etc/takrig-routing/fcc-bdc.env` is an optional administrator fallback. Placeholder/example credential values are ignored. Credential/status responses never include the API token.

### Normalization

Only FCC `environmnt=1` rows are retained. Within each selected carrier, H3 resolution-9 cells are combined using numeric class precedence:

```text
0 = none
1 = voice_3g
2 = lte
3 = 5g
```

Voice and 3G therefore both map to class code 1. `MAX()` across source rows produces `5G > LTE > Voice/3G` for each carrier/H3 cell. Missing 3G is optional; a coherent source vintage requires Voice, LTE, and 5G for each selected carrier. Different FCC availability vintages are never mixed in one output.

### Ready package

Ready files:

```text
/var/lib/takrig-routing/cellular/ready/
  takrig-cellular-<state>-fcc-<as-of>-h3-r2.zip
  <state>.json
```

ZIP members:

```text
manifest.json
coverage.h3
```

Schemas/formats:

```text
takrig.cellular.region.v2
takrig.cellular.manifest.v2
takrig.cellular.h3.v1
```

The binary intentionally stores no polygon vertices or repeated FCC properties. Its geometry key is the canonical H3 resolution-9 cell index. Default spatial chunks are H3 parent resolution 6. Each chunk is independently zlib-compressed and indexed for bounded random access. The first child H3 index in a chunk is stored as a 64-bit value; later children use unsigned delta-varints.

One byte stores all carrier classes:

```text
bits 0-1: AT&T
bits 2-3: Verizon
bits 4-5: T-Mobile
bits 6-7: reserved (zero)

00 = none
01 = Voice/3G
10 = LTE
11 = 5G
```

TAK Rig reconstructs visible hex boundaries from H3 IDs and applies client-side styling. NDM determines cell geometry identity and best-available class; colors, shades, opacity, draw order, and carrier visibility remain TAK Rig responsibilities.

Catalog discovery remains `GET /api/v1/catalog`; ready Cellular rows are in the top-level `cellular_packages` collection. Package download is:

```text
GET /api/v1/cellular/<STATE>/download
```

The endpoint retains the NDM HTTP/1.1 `Content-Length`, Range, `Content-Range`, ETag, and If-Range contract. Cellular descriptors include package SHA-256 plus binary size/chunk/cell metadata for install and future peer-transfer integrity.

Administrative build actions remain:

```text
POST /api/v1/states/<STATE>/cellular/check
POST /api/v1/states/<STATE>/cellular/build
POST /api/v1/states/<STATE>/cellular/update
POST /api/v1/states/<STATE>/cellular/rebuild
POST /api/v1/states/<STATE>/cellular/remove
```

API/auth/import problems update acquisition state and do not mark an otherwise unattempted package build `FAILED`. Existing READY packages stay published until a replacement validates.

## Android-facing catalog

```text
GET /api/v1/catalog
```

Schema: `takrig.nav.catalog.v1`.

Each package includes:

- `state_code`, `state_name`
- `status=ready`
- `revision` / `package_version`
- `built_utc`
- `size_bytes`
- `format=takrig.valhalla.region.v1`
- `valhalla_version=3.6.3`
- `source_composition`
- `source_revisions`
- `routing_coverage` (R9 coverage descriptor when present)
- `download_url`

TAK Rig uses the non-checksum `revision` value to distinguish current installed data from an update. The current revision is also exposed as the HTTP ETag so a resumed Range request can restart cleanly if the package changed.


### R9 Android coverage contract

The catalog coverage descriptor identifies `takrig.routing.coverage.v2`; the package-local index supplies the fixed zoom, bounds, class counts, tile path template, and indexed non-empty cells. Android should map the current viewport to z11 cells, decompress only intersecting `.geojson.gz` files, cache them, and render `road` and `offroad` separately. The coverage layer must not be interpreted as an access guarantee because conditional/time-dependent restrictions are evaluated by Valhalla at routing time.

R8 and older packages have no R9 coverage descriptor/tree. Clients should distinguish that compatibility case from a missing or broken routing package.

## Download endpoint

```text
GET /api/v1/packages/<STATE>/download
```

The endpoint streams an already validated ZIP over HTTP/1.1. It provides exact `Content-Length`, supports HTTP Range requests with exact `Content-Range`, and uses a revision-based ETag/If-Range contract; it never invokes a Valhalla graph build synchronously. Invalid or unsatisfiable ranges return `416` with `Content-Length: 0`.

## Desired coverage behavior

`POST /api/v1/settings` can update selected states and source toggles. Newly selected states queue acquisition immediately. Deselecting a state removes its ready published package from the manager catalog; cached source material may remain server-side for efficient reselection.

Changing source toggles forces selected states to reconcile so a newly enabled source can become part of future packages. A deterministic failed build is persistent and is not relaunched by the normal reconciliation timer or Check Sources Now when its effective build fingerprint is unchanged. Retry/Rebuild explicitly bypasses that gate; changed source settings, upstream revisions, or manager software version naturally create a new fingerprint.

## Raw manual import

```text
PUT /api/v1/manual/osm?state=CA&filename=custom.osm.pbf
```

Supported: `.osm.pbf`, or `.pbf` only after OSM PBF validation. The manager derives the geographic bounding box with `osmium-tool`, treats that PBF as the state's manual base, refreshes enabled supplements, and queues a build immediately.
