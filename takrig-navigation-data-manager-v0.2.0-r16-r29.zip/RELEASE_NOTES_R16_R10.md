# TAK Rig Navigation Data Manager v0.2.0-r16-r10

## Scope
This release corrects Outdoors road completeness and reduces vector processing/runtime weight while adding a READY-map preview workflow.

## Road source correction
- `enriched.osm.pbf` is now the preferred Outdoors vector road/trail source for every map size whenever an overlapping NDM state source exists.
- Drawn selections discover overlapping state caches spatially from source-manifest bounds; multiple states may contribute to one Outdoors map.
- Overpass remains the fallback when no enriched source overlaps.
- MVUM is not fetched a second time when enriched routing data is used.

## Completeness gate
NDM compares paved and dirt/4x4 Outdoors geometry length against overlapping graph-derived `routing_coverage/*.geojson.gz` from READY routing packages. Coverage below 80% is reported as a warning; below 50% fails the build rather than silently publishing a materially incomplete map.

## Performance
- Low zoom vector geometry is simplified more aggressively than close-detail geometry.
- Runtime MVT properties are reduced to the fields TAK Rig actually renders.

## VIEW preview
Each READY Outdoors row has a VIEW button. NDM generates a centered/fitted PNG preview from the same normalized vector content used by `map.pmtiles`; the preview is stored beside the package and removed/renamed with it.

## Compatibility
`ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`; this release does not intentionally force routing graph rebuilds.
