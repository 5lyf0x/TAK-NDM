TAK Rig Navigation Data Manager v0.2.0-r11
=============================================

Off-Road Coverage Expansion

- NPS Public Trails now contribute routing only when trail attributes explicitly establish full-size/high-clearance motor-vehicle use and the route is not closed/private.
- USGS National Transportation 4WD Roads now contribute routable high-clearance gap-fill. Generic USGS Trails remain reference-only.
- Arizona State Parks, California OHMVR/SVRA, Nevada motorized trails, and Utah Trails & Pathways now use conservative per-feature full-size vehicle eligibility instead of blanket reference-only treatment.
- New Mexico State Highway OHV Routes remain routable.
- USFS/BLM trail eligibility recognizes alternate full-size vehicle evidence while continuing to exclude narrow-vehicle-only routes.
- Accepted routes enter the Valhalla graph and therefore the existing `takrig.routing.coverage.v2` Off-Road NAV COVERAGE output.
- Installation remains rooted in `~/Downloads`; the installer never deletes `~/Downloads` or the extracted release folder.

Version: v0.2.0-r11
Valhalla: 3.6.3
