# TAK Rig Navigation Data Manager v0.2.0-r16-r9

## Outdoors road-delivery integrity

r16-r9 fixes the production Outdoors vector pipeline so road geometry requested by the operator is retained in the neutral `components/map.pmtiles` package.

- OSM physical dirt/4x4 roads no longer require a redundant explicit `motor_vehicle=yes` tag. Road-like `service`, `unclassified`, `residential`, `track`, and related ways are classified from their physical surface/tracktype while access metadata is preserved.
- Expanded unpaved surface recognition includes `fine_gravel`, `earth`, `pebblestone`, `rock/rocky`, `grass`, `grass_paver`, and `woodchips` in addition to the existing dirt/gravel/ground/sand/mud/compacted/unpaved values.
- Pedestrian/path/cycle/bridle/steps geometry is kept out of the road class and remains eligible for the foot-trail component.
- USFS MVUM roads/trails continue to enter the same `roads / motorized_dirt` display class with `source=usfs_mvum`.
- Build telemetry now records unique-feature inventories after OSM normalization, authoritative-source acquisition, combined normalization, and final selection clipping. Paved and dirt/4x4 counts are visible in build progress.
- `manifest.json` now carries `feature_inventory` plus paved/dirt counts on the map component.
- If normalized paved or dirt/4x4 features exist but none survive into `map.pmtiles`, the build fails instead of publishing a silently incomplete READY map. If a requested class genuinely has no source features in the selected area, the package records an explicit warning.
- Added regression coverage for gravel service roads, earth unclassified roads, paved residential roads, trail separation, feature inventory, and paved+dirt survival through PMTiles construction.

`ROUTING_PIPELINE_REVISION = "0.2.0-r16"` remains unchanged; this Outdoors packaging correction does not intentionally invalidate current Valhalla routing graphs.
