# TAK Rig Navigation Data Manager v0.2.0-r16-r3

## Scope

r16-r3 is a manager-concurrency and Outdoors Map Creator interaction/estimate correction built on the validated r16-r2 local-Leaflet baseline. It intentionally preserves `ROUTING_PIPELINE_REVISION = "0.2.0-r16"`.

## Manager-state concurrency correction

- `state.json` read/modify/write operations are serialized with `/var/lib/takrig-routing/manager/state.lock` across both threads and processes.
- Atomic state temp files now include process ID, thread ID, and UUID rather than PID + millisecond timestamp.
- Temporary files are removed safely if a writer exits before replacement.
- Supplemental source progress updates use a dedicated in-process lock so completion counters remain monotonic while several download workers finish together.
- The normal operator-configurable source download concurrency remains available; this release does not force the setting to 1. Existing operator settings are preserved during upgrade.

## Outdoors Map Creator

- Rectangle and Polygon outlines are bright red (`#ff3030`) at 3 px.
- Rectangle and Polygon selections are filled with translucent red coverage shading.
- After the first rectangle corner, the mouse position previews and shades the provisional rectangle until the second corner is clicked.
- After polygon drawing has at least two committed points, the current mouse position is treated as a provisional next/final point, closing back to the first point for shaded live coverage.
- Provisional geometry drives a throttled live area/storage estimate, but Create Map still requires committed geometry; polygons must be finished with a double-click.
- A three-vertex polygon is normalized into a closed four-coordinate GeoJSON ring.
- Polygon area uses the actual polygon geometry instead of the enclosing rectangle. Radius estimates use circle area rather than the radius bounding square.
- Small selections count intersecting map tiles directly; larger selections use a geometry-area ratio plus boundary allowance to keep interactive estimates responsive. The package builder itself continues exact geometric clipping.

## Compatibility

- No change to routing graph format, Valhalla version, terrain package format, Outdoors package schema, CRC32 contract, or Android download API.
- The r16-r2 local Leaflet assets, resize handling, and NDM preview-tile proxy/cache remain in place.
- Existing ready routing and terrain packages remain preserved across installation.
