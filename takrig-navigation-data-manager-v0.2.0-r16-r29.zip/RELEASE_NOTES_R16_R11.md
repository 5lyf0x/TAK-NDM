# TAK Rig Navigation Data Manager v0.2.0-r16-r11

Baseline: v0.2.0-r16-r10.

## Outdoors preview/UI correction
- Leaflet Map Creator and zoom-preview containers now form isolated stacking contexts below the sticky NDM header.
- Source popovers, READY preview modal, and toast layers have explicit higher UI tiers.
- READY VIEW previews now render the selected footprint with the same normalized map features and cached USGS hillshade used to construct the package.
- Preview cartography includes terrain/hillshade, water/hydrography, public-land boundaries, paved roads, dirt/4x4 Road Corridor styling, trails, sampled contours, POIs, and restrained labels.
- Polygon/radius selection geometry hard-masks the preview to dark gray outside the downloaded area.
- The operator-supplied peak PNG is the peak symbol in the READY preview.

## Preserved
- r16-r10 enriched routing source preference and NAV Coverage road-completeness checks.
- zoom-aware MVT simplification and runtime-property allowlists.
- fast block hillshade, automatic contour generation, persistent caches, cancel/retry/rename/delete/VIEW workflow.
- ROUTING_PIPELINE_REVISION remains 0.2.0-r16.
