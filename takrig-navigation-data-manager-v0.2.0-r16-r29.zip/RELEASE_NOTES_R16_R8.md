# TAK Rig Navigation Data Manager v0.2.0-r16-r8

## Scope
This release removes the manual contour-GeoJSON prerequisite from the Outdoors Map Creator. Contours can now be generated automatically from READY NDM 3D-terrain packages before `contours.pmtiles` is built. Routing output semantics are unchanged.

## Automatic contour source preflight
- When Contours is enabled, NDM checks contour prerequisites immediately after resolving the selected area and before vector acquisition or USGS hillshade downloads.
- Existing operator-configured `outdoors_contours_geojson` remains the highest-priority advanced override.
- Existing legacy per-state contour GeoJSON/GeoJSONSeq caches remain compatible.
- Otherwise NDM scans READY 3D-terrain packages spatially, so Rectangle/Polygon/Radius selections do not require an explicit state code.
- If no READY terrain package overlaps the selection, the job fails immediately with an actionable 3D-terrain message instead of failing after the expensive map stages.

## Selection-only contour generation
- NDM extracts the terrain SQLite database only for candidate READY terrain packages.
- Only 0.5-degree terrain cells intersecting the actual selected geometry are considered.
- Each selected terrain cell is exposed to GDAL as its original georeferenced Int16 elevation raster and processed with `gdal_contour`.
- Generated contours use a deterministic 100-foot interval; every 1000-foot contour is marked as a major contour.
- Generated linework is clipped back to its terrain-cell bounds before entering the MVT pipeline.
- Up to four local contour-generation workers may run in parallel, bounded by available logical CPUs. This is internal and has no user-facing setting.

## Reusable contour cache
- Generated per-cell GeoJSONSeq is retained under the Outdoors cache in the `contours-terrain-v1` namespace.
- Cache identity includes the source terrain state/revision and contour interval, so a rebuilt terrain package cannot silently reuse stale contours.
- Retry builds and overlapping Outdoors maps reuse already-generated contour cells.
- Deleting an Outdoors map does not remove the shared contour cache.

## Progress and package metadata
- The Contours stage reports terrain preparation, generated/cached terrain-cell progress, geometry loading, and contour-MVT tile progress.
- Contour component metadata records source mode, interval, terrain-cell count, cache hits, newly generated cells, and feature count.
- The Outdoors manifest records the NDM terrain package(s) used to derive contours.

## Dependencies
No new dependency is required. `gdal-bin`, already installed by NDM for the terrain pipeline, supplies `gdal_contour`.

## Routing fingerprint
`ROUTING_PIPELINE_REVISION = "0.2.0-r16"` remains unchanged.
