# TAK Rig Navigation Data Manager v0.2.0-r15

R15 is an HTTP transport compatibility hardening release built from the validated r14 terrain baseline. It does not change routing or terrain package contents.

## Android/emulator package-delivery correction

Live TAK Rig r24/r25 testing isolated a repeated end-of-response truncation on the Android Studio emulator while the same NDM r14 payloads were byte-perfect through Windows curl. The r14 built-in listener advertised package bodies through Python's default HTTP/1.0 close-after-body behavior. R15 changes the listener to HTTP/1.1 and hardens response framing:

- `WebHandler.protocol_version = "HTTP/1.1"`;
- exact `Content-Length` remains mandatory for JSON, Web UI, full ZIP, and Range ZIP bodies;
- full and partial package bodies are explicitly flushed after the declared bytes are written;
- Range delivery retains `Accept-Ranges: bytes`, revision ETag/If-Range behavior, and exact `Content-Range`;
- invalid and unsatisfiable ranges return `416` with `Content-Range: bytes */<size>` and `Content-Length: 0`;
- an unexpected EOF while reading a local ready package raises an explicit server I/O failure instead of silently producing a short response.

## Regression coverage

R15 adds tests for:

- exact 4 MiB Range delivery (the TAK Rig r25 terrain chunk size);
- two sequential ranges over one persistent HTTP/1.1 connection;
- `416` zero-length framing followed by a valid Range request on the same connection;
- existing matching/mismatching If-Range behavior; and
- existing independent 3D Terrain Range delivery.

## Compatibility

No rebuild of existing Navigation Data or 3D Terrain packages is required solely for r15. Existing ready packages, source caches, manager state, and configuration are preserved by upgrade. Retest the existing TAK Rig r25 Android build unchanged after installing r15.
