# TAK Rig Navigation Data Manager v0.2.0-r16-r16-r2

## 3D Environment WorldCover coastal/no-coverage fix

The first California 3D Environment field build on r16-r16-r1 stopped immediately at `N30W126` with `WorldCover HTTP 404`. This tile is an ocean/no-product-coverage WorldCover 3×3-degree tile reached because the state/extract work polygon includes coastal buffer cells. ESA WorldCover does not publish COG objects for every theoretical grid tile.

r16-r16-r2 changes Environment acquisition so:

- HTTP 404 from the WorldCover source is treated as an expected no-coverage/ocean tile, not a state-build failure;
- all 0.5-degree work cells mapped to that absent source tile are skipped and the build continues;
- the missing 3-degree tile is cached in memory for the running build to avoid repeated 404 requests;
- skipped/empty work cells are persisted in `build-state.json`, so resumes do not lose progress;
- final Environment metadata records skipped work-cell count and missing WorldCover tile IDs;
- non-404 HTTP errors retain existing behavior and are never silently converted to no-coverage.

The package schema remains `takrig.environment.region.v1` / `takrig.environment.sqlite.v1`. No TAK Rig client update is required for this server-side correction. `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`.

The r16-r16-r1 installer fix that installs `environment.py` remains included.
