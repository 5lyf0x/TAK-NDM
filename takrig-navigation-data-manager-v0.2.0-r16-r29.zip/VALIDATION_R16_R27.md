# NDM v0.2.0-r16-r27 validation

Source baseline: exact uploaded r26 source ZIP, SHA-256 `4966f9ad96f6eeffb69b5ca781ea56fa8e9ebbe2d27e77cc2118434b10a15242`. Historical validation preserved as `VALIDATION_R16_R26.md`.

## Scope

- Executive Slate responsive live state dashboard (not demo page)
- Three-column state/current activity/packages overview with full-bleed per-state imagery
- 50 local offline state WebP assets; 20 detailed, 30 earlier illustrations
- Existing r26 Navigation, Elevation, Cellular, Environment, Sources, Maintenance, settings, downloads, and package actions kept
- Safe allowlisted same-origin WebP file route
- Fixed routing pipeline revision 0.2.0-r16; no intentional rebuild from UI-only release
- Existing config, stored credentials, cached sources, ready data, and state folders preserved by existing installer

## Checks

- Original r26 baseline: 121/121 unit/regression tests PASS
- Modified r27 source: 121 original tests PASS, 5 additional Executive Slate tests PASS
- HTTP/WebP allowlist positive/negative and MIME tests PASS
- JavaScript syntax node --check PASS
- Browser fixture at 390, 740, 1024, 1440, 1672 px: zero JS errors, no page-level horizontal overflow, no top panel clipping PASS
- State switch CA → AK → HI and navigation to Sources/Settings/Maintenance PASS (browser synthetic data fixtures)
- Python compile and shell syntax PASS
- Source ZIP and fresh extraction byte-for-byte comparison: PASS, 0 missing/extra/different files
- Fresh extraction test suite: 126/126 PASS

Notes: Browser rendering was tested with deterministic mocked live-status responses because this container does not have a running NDM installation. This is a real installable release, but it has not been field-tested against the user's live server or with a multi-GB production routing rebuild.
