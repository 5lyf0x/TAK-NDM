# TAK Rig Navigation Data Manager v0.2.0-r16-r16-r1

## Installer hotfix

This correction fixes a target-host installation failure in r16-r16. The r16-r16 archive contained `src/environment.py`, but `install.sh` did not copy it to `/usr/local/lib/takrig-routing/bin/environment.py`. Because `manager.py` imports the Environment module at startup, Step 6 failed with:

```text
ModuleNotFoundError: No module named 'environment'
```

r16-r16-r1 now:

- installs `environment.py` with the rest of the runtime modules;
- creates `/var/lib/takrig-routing/environment/{ready,work,status,cache/worldcover}` during installation;
- imports/validates `environment` in the dependency gate before service startup; and
- adds regression coverage for the installer module/deployment contract.

There are no routing/data-format changes from r16-r16. `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`, so this hotfix does not intentionally rebuild valid Navigation graphs. Existing NDM configuration, source caches, READY packages, Terrain, Outdoors, Cellular, and other state are preserved when the corrected installer is rerun.
