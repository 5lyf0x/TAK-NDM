TAK Rig Navigation Data Manager v0.2.0-r12

State Selection Persistence UI Fix

Changes from v0.2.0-r11:
- Fixes the Coverage state checkbox race where the 5-second status poll could overwrite unsaved user selections before APPLY SELECTION was pressed.
- Adds an explicit dirty state for Coverage selection. While dirty, background status polling continues to update package/source/build status without replacing checkbox choices.
- APPLY SELECTION clears the dirty state only after the settings save succeeds.
- REFRESH intentionally discards unsaved checkbox changes and reloads the server-saved selection.
- Southwest, West, All States, and Clear All controls now mark the selection dirty just like direct checkbox changes.
- APPLY SELECTION shows an asterisk while unsaved Coverage changes are pending.
- No routing-source, Valhalla, package-format, coverage-v2, or API behavior changes from r11.

Version: v0.2.0-r12
