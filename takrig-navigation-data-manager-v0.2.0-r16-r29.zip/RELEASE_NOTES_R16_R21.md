# TAK Rig Navigation Data Manager v0.2.0-r16-r21

## Scope

R16-r21 is a Package Status presentation refinement on the validated r16-r20 package-lifecycle release. `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`.

## Package Status formatting refinement

The approved **Data Cards + Actions** behavior is unchanged, but its desktop presentation is corrected to match the reviewed layout:

- Navigation, Elevation, and Cell Coverage cards use equal-height flexible card bodies.
- NAV / DEM / CELL identifiers are enlarged to 44 x 44 px with additional title/status spacing.
- Card title and metadata typography are increased and rebalanced.
- Download, Rebuild/Build/Update, and Remove controls use a stable three-column action grid.
- Primary card action text is increased to 11 px with 40 px minimum button height.
- Normal desktop action labels remain on one line.
- Package summary columns use proportional widths with more room for Current Activity.
- Long current-source endpoint text is constrained to a single ellipsized line instead of expanding the row.
- Maintenance controls receive larger, consistent typography and spacing.
- The NDM desktop content ceiling is increased from 1280 px to 1600 px so wide displays can use the available space.
- Responsive fallbacks retain a single-card stack on narrow screens.

## Preserved behavior

- Navigation, Elevation, and Cell Coverage package lifecycle and direct-download semantics from r16-r20.
- Retained verified packages remain downloadable during checks, replacement builds, and failed replacement attempts.
- 3D Environment remains separate from the three primary downloadable data cards.
- r16-r19 authoritative per-state source persistence and Utah defaults.
- Outdoors Map Creator remains removed.
- Existing configuration, state, caches, and built package data remain preserved during normal upgrade.
