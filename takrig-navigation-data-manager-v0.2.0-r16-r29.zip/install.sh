#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERROR: run this installer as root: sudo ./install.sh" >&2
  exit 1
fi

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_ROOT=/usr/local/lib/takrig-routing
CONFIG_DIR=/etc/takrig-routing
STATE_ROOT=/var/lib/takrig-routing
LOG_ROOT=/var/log/takrig-routing
SERVICE_USER=takrig-routing
SERVICE_GROUP=takrig-routing
VALHALLA_VERSION=3.6.3

if ! command -v apt-get >/dev/null 2>&1; then
  echo "ERROR: this installer currently targets Ubuntu/Debian systems with apt-get." >&2
  exit 1
fi

# Do not overwrite Python files while unowned background work (including
# the legacy SSH-based CA 30 m recovery helper) is still executing them.
# Systemd services are stopped in the existing upgrade flow below.
if pgrep -af '[/]tmp/ndm-ca-resume30[.]py|[/]usr/local/lib/takrig-routing/bin/(terrain[.]py.*build|cellular[.]py.*(build|rebuild|acquire-api)|processor[.]py.*scan|manager[.]py.*reconcile)' >/dev/null; then
  echo "ERROR: An NDM worker is active. Allow it to reach a safe checkpoint or stop it before upgrading; committed data is preserved." >&2
  pgrep -af '[/]tmp/ndm-ca-resume30[.]py|[/]usr/local/lib/takrig-routing/bin/(terrain[.]py.*build|cellular[.]py.*(build|rebuild|acquire-api)|processor[.]py.*scan|manager[.]py.*reconcile)' >&2 || true
  exit 1
fi

echo "[1/8] Installing OS prerequisites..."
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends ca-certificates python3 python3-venv osmium-tool gdal-bin

ARCH="$(uname -m)"
case "$ARCH" in
  x86_64|amd64|aarch64|arm64) ;;
  *)
    echo "ERROR: pyvalhalla 3.6.3 binary wheels are not published for Linux architecture: $ARCH" >&2
    exit 1
    ;;
esac

PYTHON=""
for candidate in python3.14 python3.13 python3.12 python3; do
  if command -v "$candidate" >/dev/null 2>&1 && "$candidate" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if sys.version_info >= (3, 12) else 1)
PY
  then
    PYTHON="$(command -v "$candidate")"
    break
  fi
done
if [[ -z "$PYTHON" ]]; then
  echo "ERROR: Python 3.12 or newer is required for the prebuilt pyvalhalla 3.6.3 Linux wheel." >&2
  echo "Install Python 3.12+ on this host, then rerun ./install.sh." >&2
  exit 1
fi
PY_VER="$($PYTHON - <<'PY'
import sys
print(f"{sys.version_info.major}.{sys.version_info.minor}")
PY
)"
echo "Using Python $PY_VER at $PYTHON"

if ! "$PYTHON" -m venv --help >/dev/null 2>&1; then
  VENV_PKG="$(basename "$PYTHON")-venv"
  if apt-cache show "$VENV_PKG" >/dev/null 2>&1; then
    apt-get install -y --no-install-recommends "$VENV_PKG"
  fi
fi
if ! "$PYTHON" -m venv --help >/dev/null 2>&1; then
  echo "ERROR: the venv module is not installed for Python $PY_VER ($PYTHON)." >&2
  echo "Install the matching Python venv package, then rerun ./install.sh." >&2
  exit 1
fi

echo "[2/8] Creating service account..."
if ! getent group "$SERVICE_GROUP" >/dev/null; then
  groupadd --system "$SERVICE_GROUP"
fi
if ! id "$SERVICE_USER" >/dev/null 2>&1; then
  useradd --system --gid "$SERVICE_GROUP" --home-dir "$STATE_ROOT" --shell /usr/sbin/nologin "$SERVICE_USER"
fi

echo "  Stopping existing TAK Rig navigation workers for a clean upgrade..."
systemctl stop takrig-nav-reconcile.timer takrig-nav-reconcile.service \
  takrig-routing-scan.timer takrig-routing-scan.service takrig-nav-manager.service 2>/dev/null || true

echo "[3/8] Installing processor and Navigation Data Manager files..."
install -d -m 0755 "$INSTALL_ROOT/bin" "$CONFIG_DIR"
install -m 0755 "$HERE/src/processor.py" "$INSTALL_ROOT/bin/processor.py"
install -m 0755 "$HERE/src/manager.py" "$INSTALL_ROOT/bin/manager.py"
install -m 0644 "$HERE/src/job_control.py" "$INSTALL_ROOT/bin/job_control.py"
install -m 0644 "$HERE/src/sources.py" "$INSTALL_ROOT/bin/sources.py"
install -m 0644 "$HERE/src/state_catalog.py" "$INSTALL_ROOT/bin/state_catalog.py"
install -m 0644 "$HERE/src/state_profiles.py" "$INSTALL_ROOT/bin/state_profiles.py"
install -m 0644 "$HERE/src/enrich.py" "$INSTALL_ROOT/bin/enrich.py"
install -m 0644 "$HERE/src/coverage.py" "$INSTALL_ROOT/bin/coverage.py"
install -m 0755 "$HERE/src/terrain.py" "$INSTALL_ROOT/bin/terrain.py"
install -m 0755 "$HERE/src/environment.py" "$INSTALL_ROOT/bin/environment.py"
install -m 0644 "$HERE/src/environment_assets.py" "$INSTALL_ROOT/bin/environment_assets.py"
install -m 0755 "$HERE/src/cellular.py" "$INSTALL_ROOT/bin/cellular.py"
install -m 0644 "$HERE/src/fcc_mobile.py" "$INSTALL_ROOT/bin/fcc_mobile.py"
install -d -m 0755 "$INSTALL_ROOT/web"
install -m 0644 "$HERE/web/index.html" "$INSTALL_ROOT/web/index.html"
install -d -m 0755 "$INSTALL_ROOT/web/assets/states" "$INSTALL_ROOT/web/assets/decor"
install -m 0644 "$HERE"/web/assets/states/*.webp "$INSTALL_ROOT/web/assets/states/"
install -m 0644 "$HERE"/web/assets/decor/*.webp "$INSTALL_ROOT/web/assets/decor/"
# r20 removes the Outdoors Map Creator and its Leaflet runtime.  Remove stale
# installed code/assets while preserving /var/lib/takrig-routing/outdoors data.
rm -f "$INSTALL_ROOT/bin/outdoors.py" "$INSTALL_ROOT/web/outdoors_peak.png"
rm -rf "$INSTALL_ROOT/web/vendor/leaflet"

install -m 0755 "$HERE/takrig-routing" /usr/local/bin/takrig-routing
install -m 0755 "$HERE/takrig-nav-manager" /usr/local/bin/takrig-nav-manager

install -d -o "$SERVICE_USER" -g "$SERVICE_GROUP" -m 2775 "$STATE_ROOT"
for d in manager/pauses manager/pauses/navigation manager/pauses/terrain manager/pauses/cellular; do
  install -d -o "$SERVICE_USER" -g "$SERVICE_GROUP" -m 2775 "$STATE_ROOT/$d"
done
for d in incoming processing ready failed history archive terrain terrain/ready terrain/work terrain/status environment environment/ready environment/work environment/status environment/cache environment/cache/worldcover cellular cellular/cache cellular/cache/sources cellular/work cellular/ready cellular/status cellular/imports; do
  install -d -o "$SERVICE_USER" -g "$SERVICE_GROUP" -m 2775 "$STATE_ROOT/$d"
done
install -d -o "$SERVICE_USER" -g "$SERVICE_GROUP" -m 0700 "$STATE_ROOT/secrets"
install -d -o "$SERVICE_USER" -g "$SERVICE_GROUP" -m 2775 "$LOG_ROOT"

# FCC BDC public-data API credentials are intentionally kept outside config.json/UI.
# The operator fills these from broadbandmap.fcc.gov -> Manage API Access.
if [[ ! -f "$CONFIG_DIR/fcc-bdc.env" ]]; then
  cat > "$CONFIG_DIR/fcc-bdc.env" <<'EOF_FCC'
# TAK Rig NDM FCC BDC Public Data API credentials
FCC_BDC_USERNAME=
FCC_BDC_HASH_VALUE=
EOF_FCC
fi
chown root:"$SERVICE_GROUP" "$CONFIG_DIR/fcc-bdc.env"
chmod 0640 "$CONFIG_DIR/fcc-bdc.env"

# R29 preserves existing enrichment scratch as part of checkpoint-safe
# upgrades. Do not silently discard resumable NAV/Elevation/Cellular work.

if [[ ! -f "$CONFIG_DIR/config.json" ]]; then
  install -m 0644 "$HERE/examples/config.json" "$CONFIG_DIR/config.json"
fi
# Preserve existing configuration and state across upgrades. Unknown keys are
# intentionally retained. A timestamped config backup is kept beside config.json.
if [[ -f "$CONFIG_DIR/config.json" ]]; then
  cp -a "$CONFIG_DIR/config.json" "$CONFIG_DIR/config.json.pre-r16-r7-$(date -u +%Y%m%dT%H%M%SZ).bak"
fi
"$PYTHON" - "$CONFIG_DIR/config.json" "$INSTALL_ROOT/venv" <<'PYCFG'
import json, sys
from pathlib import Path
p = Path(sys.argv[1])
new_venv = sys.argv[2]
data = json.loads(p.read_text(encoding="utf-8"))
data["venv_root"] = new_venv
data["jobs_per_scan"] = 1
# Migrate only the historical stock 8 GiB floor. Preserve explicit larger custom values.
if float(data.get("required_free_min_gib", 8.0)) <= 8.0:
    data["required_free_min_gib"] = 30.0
defaults = {
    "source_download_concurrency": 3,
    "source_per_host_concurrency": 2,
    "minimum_free_disk_gib": 30.0,
    "source_cache_limit_gib": 100.0,
    "maintenance_window_start_local": "00:00",
    "automatic_rebuild_enabled": True,
    "fcc_bdc_api_base": "https://broadbandmap.fcc.gov/api/public/map",
    "fcc_bdc_api_fallback": "https://bdc.fcc.gov/api/public/map",
    "fcc_bdc_credentials_file": "/etc/takrig-routing/fcc-bdc.env",
    "cellular_h3_chunk_resolution": 6,
    "allow_web_secret_management": True,
}
for key, value in defaults.items():
    data.setdefault(key, value)
tmp = p.with_suffix(p.suffix + ".tmp")
tmp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
tmp.replace(p)
PYCFG

echo "[4/8] Creating Python environment..."
if [[ ! -x "$INSTALL_ROOT/venv/bin/python" ]]; then
  "$PYTHON" -m venv "$INSTALL_ROOT/venv"
fi
"$INSTALL_ROOT/venv/bin/python" -m pip install --disable-pip-version-check --upgrade pip setuptools wheel

echo "[5/8] Installing pinned Valhalla build tools ${VALHALLA_VERSION}..."
"$INSTALL_ROOT/venv/bin/python" -m pip install --disable-pip-version-check --upgrade --only-binary=pyvalhalla "pyvalhalla==${VALHALLA_VERSION}"
"$INSTALL_ROOT/venv/bin/python" -m pip install --disable-pip-version-check --upgrade "shapely>=2.0,<3"
"$INSTALL_ROOT/venv/bin/python" -m pip install --disable-pip-version-check --upgrade "mapbox-vector-tile==2.2.0"
"$INSTALL_ROOT/venv/bin/python" -m pip install --disable-pip-version-check --upgrade "Pillow>=10,<13"

echo "  Validating NAV coverage Python dependencies..."
"$INSTALL_ROOT/venv/bin/python" - <<'PY'
from valhalla import Actor
import mapbox_vector_tile
import sys
sys.path.insert(0,"/usr/local/lib/takrig-routing/bin")
import cellular
import environment
import state_profiles
from PIL import Image
from shapely.geometry import LineString
assert Actor is not None and mapbox_vector_tile is not None and cellular is not None and environment is not None and state_profiles is not None and Image is not None
assert LineString([(0, 0), (1, 1)]).length > 0
PY

# pyvalhalla 3.6.3 contains the native C++ builder and its Python config
# generator inside the installed valhalla package.  Do not use
# `python -m valhalla valhalla_build_tiles` here: the 3.6.3 wrapper checks the
# caller PATH before resolving the bundled binary and can incorrectly report
# "Can't find executable" even when the bundled executable exists.
PYVALHALLA_DIR="$("$INSTALL_ROOT/venv/bin/python" - <<'PY'
from pathlib import Path
import valhalla
print(Path(valhalla.__file__).resolve().parent)
PY
)"
VALHALLA_BUILD_TILES="$PYVALHALLA_DIR/bin/valhalla_build_tiles"
VALHALLA_BUILD_CONFIG="$PYVALHALLA_DIR/valhalla_build_config.py"

if [[ ! -x "$VALHALLA_BUILD_TILES" ]]; then
  echo "ERROR: bundled Valhalla tile builder is missing or not executable: $VALHALLA_BUILD_TILES" >&2
  exit 1
fi
if [[ ! -f "$VALHALLA_BUILD_CONFIG" ]]; then
  echo "ERROR: bundled Valhalla config generator is missing: $VALHALLA_BUILD_CONFIG" >&2
  exit 1
fi

echo "  Testing native tile builder directly..."
"$VALHALLA_BUILD_TILES" --version
echo "  Testing bundled config generator..."
"$INSTALL_ROOT/venv/bin/python" "$VALHALLA_BUILD_CONFIG" --help >/dev/null

VALHALLA_TEST_DIR="$(mktemp -d /tmp/takrig-valhalla-r16-r7.XXXXXX)"
trap 'rm -rf "$VALHALLA_TEST_DIR"' EXIT
"$INSTALL_ROOT/venv/bin/python" "$VALHALLA_BUILD_CONFIG" \
  --mjolnir-tile-dir "$VALHALLA_TEST_DIR/tiles" \
  --mjolnir-tile-extract "$VALHALLA_TEST_DIR/tiles.tar" \
  -o "$VALHALLA_TEST_DIR/valhalla.json"
"$INSTALL_ROOT/venv/bin/python" - "$VALHALLA_TEST_DIR/valhalla.json" "$VALHALLA_TEST_DIR/tiles" "$VALHALLA_TEST_DIR/tiles.tar" <<'PY'
import json, sys
from pathlib import Path
cfg = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
assert cfg["mjolnir"]["tile_dir"] == sys.argv[2]
assert cfg["mjolnir"]["tile_extract"] == sys.argv[3]
assert "auto" in cfg["service_limits"] and "loki" in cfg and "thor" in cfg and "odin" in cfg
PY
rm -rf "$VALHALLA_TEST_DIR"
trap - EXIT

# Validate the exact execution identity used by systemd.  This catches parent
# directory traversal restrictions before services are installed.
echo "  Testing toolchain as service user..."
if ! runuser -u "$SERVICE_USER" -- "$INSTALL_ROOT/venv/bin/python" --version; then
  echo "ERROR: service user $SERVICE_USER cannot execute the Python environment at $INSTALL_ROOT." >&2
  exit 1
fi
if ! runuser -u "$SERVICE_USER" -- "$VALHALLA_BUILD_TILES" --version; then
  echo "ERROR: service user $SERVICE_USER cannot execute $VALHALLA_BUILD_TILES." >&2
  exit 1
fi

echo "[6/8] Validating processor..."
TAKRIG_ROUTING_CONFIG="$CONFIG_DIR/config.json" /usr/local/bin/takrig-routing --version
TAKRIG_ROUTING_CONFIG="$CONFIG_DIR/config.json" /usr/local/bin/takrig-routing catalog >/dev/null
TAKRIG_ROUTING_CONFIG="$CONFIG_DIR/config.json" /usr/local/bin/takrig-nav-manager status >/dev/null
chown -R "$SERVICE_USER:$SERVICE_GROUP" "$STATE_ROOT" "$LOG_ROOT"
chmod 0700 "$STATE_ROOT/secrets"

echo "[7/8] Installing systemd units..."
install -m 0644 "$HERE/systemd/takrig-routing-scan.service" /etc/systemd/system/takrig-routing-scan.service
install -m 0644 "$HERE/systemd/takrig-routing-scan.timer" /etc/systemd/system/takrig-routing-scan.timer
install -m 0644 "$HERE/systemd/takrig-nav-manager.service" /etc/systemd/system/takrig-nav-manager.service
install -m 0644 "$HERE/systemd/takrig-nav-reconcile.service" /etc/systemd/system/takrig-nav-reconcile.service
install -m 0644 "$HERE/systemd/takrig-nav-reconcile.timer" /etc/systemd/system/takrig-nav-reconcile.timer
systemctl daemon-reload
systemctl enable --now takrig-routing-scan.timer takrig-nav-reconcile.timer takrig-nav-manager.service
# `enable --now` starts an inactive service but does not restart an already-running
# manager during an in-place upgrade.  Restart explicitly so the newly installed
# Python/Web runtime is active immediately after the installer completes.
systemctl restart takrig-nav-manager.service
# Reconcile selected coverage immediately after an upgrade. The routing pipeline revision, rather than display-only correction releases,
# participates in the build fingerprint. This avoids unnecessary state graph
# rebuilds for r16-series manager/Web-UI-only corrections.
systemctl start --no-block takrig-nav-reconcile.service || true

# Failed v0.2.0/R1/R2 attempts used /opt/takrig-routing.  Only remove that
# legacy tree after the corrected services have been installed successfully.
if [[ -d /opt/takrig-routing ]]; then
  rm -rf /opt/takrig-routing
fi

echo "[8/8] Complete."
echo
echo "TAK Rig Navigation Data Manager v0.2.0-r16-r29 + routing processor installed."
echo "Incoming PBF directory: $STATE_ROOT/incoming"
echo "Ready packages:         $STATE_ROOT/ready"
echo "Failed jobs:            $STATE_ROOT/failed"
echo "Web GUI/API:            http://<server>:8765/"
echo
echo "Status:"
/usr/local/bin/takrig-routing status || true
