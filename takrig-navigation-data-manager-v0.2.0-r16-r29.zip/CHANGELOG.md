# v0.2.0-r16-r29

- USGS 3DEP downloads: four simultaneous terrain cells with a single SQLite writer, transient 502/503/504 retry, aligned four-part fallback and automatic worker reduction for repeated upstream failures.
- Correctly resume interrupted 30 m builds while retaining previously published 90 m packages until successful final validation.
- Recover stale queued elevation jobs without force/rebuild or deleting their work database.
- Independent, persistent Pause / Resume endpoints and responsive controls for Navigation Data, Elevation Data, and Cellular coverage; checkpoint-safe worker coordination.
- Retain cached source downloads and project data; installer protects running SSH recovery workers and no longer purges enrichment scratch on upgrade.
- Preserve Executive Slate fixed-card, centered layout and 50 state images from r28; routing pipeline and package format unchanged.

# v0.2.0-r16-r28

- Centered Executive Slate, fixed card/hero image framing, sidebar cleanup and finished Phase 5 scenic artwork (all 50 states).
- Navigation/elevation/cellular/routing behavior unchanged.

# v0.2.0-r16-r27

Executive Slate live WebUI with 50 local state hero assets; first 20 detailed. Original API actions and routing pipeline preserved.

# v0.2.0-r16-r26

- Added first-class authoritative state transportation profiles for AK, AR, CO, HI, ID, IA, KS, LA, MN, MO, MT, NE, NV, NM, ND, OK, OR, SD, TX, WA, and WY.
- Preserved CA/AZ/UT source definitions and behavior; global routing pipeline revision remains `0.2.0-r16`.
- Added declarative per-source profile revisions and state-local fingerprint invalidation.
- Added streamed GeoJSONL acquisition/enrichment for large state road inventories.
- Added ArcGIS schema validation and object-ID pagination fallback.
- Added Alaska antimeridian-safe split source queries with exact polygon clipping.
- Added conservative expansion-state public-road normalization and strict full-size-vehicle gating for newly profiled recreation sources.
- Added regression coverage for all 21 requested expansion states, CA/AZ/UT preservation, profile fingerprints, streaming, Alaska query envelopes, and non-pagination ArcGIS services.
- Preserved r25 Package Status/Cellular consolidation and r24 parallel FCC acquisition behavior.

# v0.2.0-r16-r25

- Consolidates Cellular Coverage controls and data into each state CELL card in Package Status.
- Removes the duplicate standalone Cellular Coverage section.
- Moves the gateway-wide FCC API status/settings control into the Package Status header while preserving one shared credential set for all states.
- Adds per-state carrier selectors/readiness, FCC vintage/source/H3 metadata, live acquisition progress and transfer rate, import/acquire actions, collapsible source-file details, and package lifecycle actions directly to the CELL card.
- Preserves r24 provider discovery and parallel FCC download behavior and keeps `ROUTING_PIPELINE_REVISION = 0.2.0-r16`.

# v0.2.0-r16-r24

- FCC mobile discovery now queries provider-specific Mobile Broadband and Mobile Voice manifests so AT&T, Verizon, and T-Mobile Hexagon Coverage files are selected correctly for each state.
- FCC API downloads now run concurrently (default 4, configurable 1-6) without the routing-source per-host throttle; server Retry-After/429 responses and resumable `.part` downloads remain honored.
- Cellular download progress now aggregates all concurrent files, reports transfer rate/bytes, and reserves the final progress segment for sequential validation/import.
- FCC WebUI credentials are authoritative gateway-wide credentials; the optional administrator credential file is fallback-only, and template credentials are ignored.
- Failed/empty FCC acquisitions no longer leave a stale ACQUIRING/100% state. Starting a new FCC check/acquisition clears stale errors and progress, and the WebUI suppresses previous acquisition errors while a new operation is active.

# v0.2.0-r16-r23

- Fixes Package Status summary overlap for long statuses such as WAITING FOR MAINTENANCE by giving the Status column a real minimum width and allowing summary status pills to wrap inside their own cell.
- Applies the same non-overlap protections at desktop and responsive breakpoints.
- Preserves r22 global FCC credentials and all package/data behavior.

# TAK Rig Navigation Data Manager v0.2.0-r16-r24

## v0.2.0-r16-r24

- Makes FCC API credentials gateway-wide in the WebUI: configure/test/save/clear once and automatically reuse the same credential set for every state.
- Adds global FCC API status/release/test/save/clear endpoints while preserving state-specific carrier selection, release/vintage choice, cached source inventory, acquisition, and Cellular package lifecycle.
- Replaces per-state FCC credential entry with per-state **ACQUIRE FCC DATA** actions that use the shared gateway credentials. Legacy state-scoped credential routes remain compatibility aliases to the same shared credential store.
- Makes Package Status state identity more prominent with a 20 px bold state name and separate state-code badge.
- Preserves r16-r21 Navigation/Elevation/Cellular package formats, download behavior, Package Status card geometry, Outdoors removal, and `ROUTING_PIPELINE_REVISION = 0.2.0-r16`.

## v0.2.0-r16-r21

- Refines the Package Status **Data Cards + Actions** presentation without changing package lifecycle semantics.
- Enlarges NAV / DEM / CELL identity blocks to 44 × 44 px, increases title/metadata spacing, and uses equal-height flexible data cards.
- Converts each card action row to a stable three-column Download / Build-or-Rebuild / Remove grid with larger 11 px labels and 40 px minimum height.
- Gives Current Activity more proportional desktop space, ellipsizes long active-source endpoint text, and raises the desktop content ceiling to 1600 px.
- Enlarges and aligns Maintenance controls while preserving the separate 3D Environment lifecycle.
- Preserves r16-r20 downloads, retained-package behavior, Utah/per-state source persistence, Outdoors removal, and `ROUTING_PIPELINE_REVISION = 0.2.0-r16`.

## v0.2.0-r16-r20

- Replaces Package Status vertical action stacks with the approved horizontal **Data Cards + Actions** layout.
- Adds direct Download controls for ready/retained Navigation, Elevation, and Cell Coverage packages.
- Keeps retained verified packages downloadable while checking, updating/rebuilding, or after a failed replacement; disables Download only when no usable package exists.
- Adds lifecycle-aware card actions for not-built, queued/building, ready, update-available, failed, waiting-space, and no-source/incomplete states.
- Integrates Cellular Coverage package status/actions into the same Package Status row as Navigation and Elevation.
- Retains compact source-cache and 3D Environment maintenance controls beneath the primary data cards.
- Removes the Outdoors Map Creator WebUI, APIs, catalog/status lifecycle, builder runtime/tests, and Leaflet-only runtime assets. Existing `/var/lib/takrig-routing/outdoors` data is deliberately preserved on upgrade but is no longer maintained or surfaced.
- Preserves r16-r19 authoritative per-state source persistence/Utah defaults and keeps `ROUTING_PIPELINE_REVISION` pinned to `0.2.0-r16`.

## v0.2.0-r16-r19
- Makes per-state source settings authoritative instead of inheriting legacy global source-group disables, restoring the expected Standard preset for Utah and other newly configured states.
- Serializes `settings.json` read/modify/write transactions with `settings.lock` so source saves cannot be lost to simultaneous settings updates.
- Preserves exact Custom checkbox choices across save/reopen/service restart and verifies the persisted values before the Web editor closes.
- Keeps source enablement independent from endpoint health and prevents per-source CHECK from reloading the editor and discarding unsaved edits.
- Explicitly restarts `takrig-nav-manager.service` during upgrades so the newly installed runtime is loaded immediately.
- Utah Standard now enables Core OSM plus every routable Federal/Utah source; Maximum Coverage additionally enables reference-only sources.
- Keeps `ROUTING_PIPELINE_REVISION = 0.2.0-r16`; routing normalization and Valhalla graph semantics are unchanged.

## v0.2.0-r16-r18
- Retunes the 3D Environment vegetation density used by TAK Rig Cinematic Terrain: WorldCover tree-cover cells rise from 220 to 245/255 and mangrove/tree cells from 235 to 250/255, while non-forest classes retain their existing sparse behavior.
- Publishes Cinematic Environment v1.1 render-tuning metadata for 1.50× tree height, 1.50× forest density, 60 m material-transition feathering, and a 0.60 px minimum tree projection target.
- Keeps the outer Environment archive contract unchanged (`manifest.json + environment.sqlite`), retains `takrig.environment.sqlite.v1` / `cinematic-environment-v1`, and requires only a state Environment rebuild to receive the denser classification data.
- Keeps `ROUTING_PIPELINE_REVISION = 0.2.0-r16`; Navigation graph rebuild behavior is unchanged.

## v0.2.0-r16-r17
- Adds the optional `cinematic-environment-v1` static asset set inside `environment.sqlite` while keeping the outer Environment ZIP strictly `manifest.json + environment.sqlite` and retaining `takrig.environment.sqlite.v1`.
- Adds the locked 35-source photographic ground-material catalog and 9-source vegetation-impostor catalog, material pools, physical-scale hints, and versioned atlas metadata.
- Adds cached NDM-side 2048×2048 ground-albedo, 1024×1024 ground-normal, and 2048×1024 tree-impostor atlas construction using Poly Haven CC0 sources.
- Adds front/side/top tree source renders for conifer, broadleaf, dry/windswept, alpine/subalpine, and arid visual families.
- Makes cinematic asset acquisition fail-soft: if optional source acquisition fails, the state still packages normal WorldCover classification cells and advertises `cinematic_assets_included=false`.
- Adds a visible `Powered by Poly Haven` credit to the NDM web UI for live API use.
- Retains r16-r16-r2 ocean/no-coverage 404 behavior and keeps `ROUTING_PIPELINE_REVISION = 0.2.0-r16`.
## v0.2.0-r16-r16-r2
- Fixes the field-confirmed 3D Environment failure where a legitimate ESA WorldCover HTTP 404 on an ocean/no-coverage 3° source tile (for example `N30W126` while building California) aborted the entire state build.
- Treats WorldCover HTTP 404 as an expected no-coverage tile for that build, skips the affected 0.5° work cells, and continues processing land-covered source tiles.
- Caches missing WorldCover tile IDs in-memory during the build so sibling work cells mapped to the same absent 3° tile do not repeat HTTP requests.
- Persists skipped/empty 0.5° work-cell IDs in the resumable Environment build state and reports skipped-cell/missing-source metadata in the final manifest.
- Non-404 HTTP failures retain the existing retry/fatal behavior.
- Retains the r16-r16-r1 installer correction that deploys `environment.py`.
- `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`.

## v0.2.0-r16-r16
- Adds native 30 m 3D Terrain package generation with 60/120/240 m phase-aligned overviews while preserving legacy 90 m package support and the existing terrain package contract.
- Adds a selectable 30 m / 90 m Terrain DEM build target; default is 30 m.
- Adds the independent `takrig.environment.region.v1` 3D Environment pipeline backed by ESA WorldCover 2021 v200, normalized to compact runtime land-cover + vegetation-density cells. Dynamic snow is intentionally excluded from static Environment packages.
- Adds Environment catalog/download/build/rebuild/remove endpoints and NDM discovery `environment` capability.
- Keeps `ROUTING_PIPELINE_REVISION` pinned to `0.2.0-r16`; Navigation graph rebuild behavior is unchanged.

# TAK Rig Navigation Data Manager v0.2.0-r16-r15

## v0.2.0-r16-r15

- Adds TAK Rig NDM UDP auto-discovery on port 47818 with unicast responses containing stable server identity, server name, HTTP port, release version, and Navigation/Elevation/Cellular capabilities.
- Persists discovery identity under the configured state root so DHCP address changes retain the same logical NDM server.
- Existing HTTP catalog/package transport, manual addressing, package formats, and routing pipeline revision remain unchanged.

## v0.2.0-r16-r14
- Fixes the confirmed r16-r13 Cellular defect where FCC 5G 7/1 and 5G 35/3 Hexagon Coverage shared the same logical `5g` inventory key and one tier could replace the other.
- Adds explicit source variants `5g_7_1` and `5g_35_3`; both are retained independently for the same carrier/provider/vintage.
- Requires Voice, LTE, 5G 7/1, and 5G 35/3 for each selected carrier; 3G remains optional.
- Unions both 5G tiers during H3 normalization using the existing max-precedence write, so either tier marks the cell as final `5g`.
- Adds in-place legacy inventory migration: official r16-r13 `5GNR_7_1` / `5GNR_35_3` filenames are backfilled to the correct source variant without re-upload.
- FCC API discovery/acquisition now distinguishes and downloads both 5G tiers rather than selecting a single generic 5G source.
- Cellular Web source details and missing-source status display `5G 7/1` and `5G 35/3` separately.
- Advances `CELLULAR_PIPELINE_REVISION` from 2 to 3 while keeping `takrig.cellular.h3.v1`, `takrig.cellular.region.v2`, and `ROUTING_PIPELINE_REVISION = 0.2.0-r16` unchanged.

## v0.2.0-r16-r13
- Replaces the r16-r12 Raw Coverage/PMTiles Cellular prototype with compact FCC provider-specific H3 Hexagon Coverage optimized for TAK Rig runtime performance.
- Cellular card exposes only carrier checkboxes: AT&T, Verizon, and T-Mobile. Selecting a carrier automatically includes all applicable Voice/3G, LTE, and 5G inputs.
- Adds two equal Cellular acquisition paths: multi-file `IMPORT FCC DATA` for official provider-specific Hexagon Coverage GeoPackage ZIP/GPKG files and an `FCC API` dialog for credential test/save/release discovery/acquisition.
- Keeps API/auth/import issues separate from package build state so missing FCC credentials do not incorrectly mark Cellular FAILED; manual import remains usable.
- Validates provider identity, state, FCC availability vintage, H3 resolution, CRS, technology class, and `environmnt=1`; mixed vintages and Raw Coverage inputs are rejected for the H3 package pipeline.
- Computes one best-available class per carrier/H3 cell using `5G > LTE > Voice/3G`; no signal-strength/heatmap values are packaged.
- Adds compact `takrig.cellular.h3.v1`: spatially chunked, independently compressed H3 records with delta-varint H3 IDs and one packed coverage byte for all three carriers. No polygon vertices or repeated FCC feature metadata are shipped to TAK Rig.
- Publishes `takrig.cellular.region.v2` packages containing only `manifest.json` and `coverage.h3`, with package/source SHA-256, cell/chunk/class counts, provider/vintage provenance, and HTTP Range/ETag delivery.
- Preserves existing READY Cellular packages until replacements fully validate; cached imports/API acquisitions survive restarts/upgrades.
- Keeps `ROUTING_PIPELINE_REVISION = 0.2.0-r16`; Navigation, Terrain, and Outdoors formats/lifecycles remain unchanged.

# TAK Rig Navigation Data Manager v0.2.0-r16-r12

## v0.2.0-r16-r12
- Adds independent per-state FCC BDC Cellular Coverage preprocessing and package lifecycle for AT&T, Verizon, and T-Mobile.
- Downloads/caches Raw Coverage GeoPackages with protected FCC API credentials stored outside normal NDM settings/UI.
- Filters to FCC in-vehicle coverage and derives mutually exclusive best-available `Voice/3G`, `LTE`, and `5G` classes (`5G > LTE > Voice/3G`).
- Discards modeled signal-strength bins; no heatmap data is packaged.
- Uses resumable 0.5-degree geographic partitions and produces gzip-MVT PMTiles (`takrig.cellular.region.v1`) with package/component SHA-256 metadata.
- Adds a dedicated Cellular Coverage Web card plus independent CHECK/BUILD/UPDATE/REBUILD/DOWNLOAD/REMOVE API actions and HTTP Range/ETag delivery.
- Adds FCC download retry/backoff, fallback API base, `.part` resume support, atomic READY promotion, and stale READY preservation on failed updates.
- Keeps `ROUTING_PIPELINE_REVISION = 0.2.0-r16`; existing current Navigation graphs are not intentionally invalidated.

# TAK Rig Navigation Data Manager v0.2.0-r16-r11

## v0.2.0-r16-r11
- Corrected Web UI stacking so Leaflet Map Creator panes/controls cannot cover the sticky NDM header or READY preview modal.
- Replaced the READY diagnostic sketch with a finished-map style cartographic preview using the same normalized vectors and cached USGS hillshade used by the package, plus contour sampling, labels, purpose-specific POIs, the approved Road Corridor treatment, and exact footprint masking.
- Adopted the operator-supplied peak icon for Outdoors previews.
- Preserves r16-r10 enriched routing-source road completeness, zoom-aware simplification, runtime attribute stripping, and VIEW workflow.

# TAK Rig Navigation Data Manager v0.2.0-r16-r10

## v0.2.0-r16-r10
- Outdoors roads now prefer every overlapping state `enriched.osm.pbf` regardless of selection size; Overpass is fallback only.
- Cross-state Outdoors selections combine overlapping enriched state sources and deduplicate identical features.
- Direct MVUM fetch is suppressed when enriched routing data is used, avoiding duplicate road geometry already accepted by NDM conflation.
- Adds graph-derived NAV Coverage road/off-road length comparison with warning/fail thresholds so incomplete Outdoors road networks cannot silently publish READY.
- Adds aggressive zoom-aware MVT geometry simplification and display-only property stripping.
- READY Outdoors maps now include a centered generated preview and a VIEW action in the Web GUI.
- Existing hillshade/contour caches and routing pipeline revision remain unchanged.

## v0.2.0-r16-r9
- Fixed Outdoors OSM road retention so ordinary unpaved service/unclassified/track roads do not require `motor_vehicle=yes`.
- Expanded dirt/unpaved surface classification and preserved access metadata.
- Added source/normalized/final unique-feature inventories and road counts to progress/component/manifest metadata.
- Added a hard road-encoding integrity check: normalized road classes may not silently disappear from `map.pmtiles`.
- Preserved USFS MVUM `motorized_dirt` integration and `ROUTING_PIPELINE_REVISION = 0.2.0-r16`.

# TAK Rig Navigation Data Manager v0.2.0-r16-r8

## v0.2.0-r16-r8
- Removes the manual contour-GeoJSON prerequisite by automatically deriving Outdoors contours from existing READY NDM 3D-terrain packages.
- Performs contour-source preflight immediately after area resolution, before vector/hillshade work, so missing terrain fails fast instead of after a long map build.
- Spatially discovers terrain packages for drawn Rectangle/Polygon/Radius selections; an explicit state code is not required.
- Generates only terrain cells intersecting the selected geometry, at a deterministic 100-ft contour interval with 1000-ft major contours.
- Adds a revision-keyed persistent per-cell `contours-terrain-v1` cache reused by retries and overlapping maps.
- Runs local GDAL contour generation with up to four CPU-bounded workers and exposes contour generation/cache progress in the existing compact build progress UI.
- Preserves `outdoors_contours_geojson` and legacy contour GeoJSON caches as advanced overrides.
- Records contour source, terrain package(s), interval, generated/cache-hit cell counts, and feature count in component/manifest metadata.
- No new installer dependency is needed because the existing `gdal-bin` dependency supplies `gdal_contour`.
- `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`.

## v0.2.0-r16-r7
- Replaces normal USGS 3DEP one-tile-per-request hillshade acquisition with Web-Mercator-aligned blocks up to 8x8 tiles / 2048x2048 pixels.
- A successful full block populates 64 normal persistent 256x256 cache tiles, dramatically reducing dynamic `exportImage` request count on uncached maps.
- Uses exact EPSG:3857 block bounds with `adjustAspectRatio=false`, then splits the returned PNG locally with Pillow.
- Failed blocks automatically subdivide toward 4x4 / 2x2 / 1x1 scale; only terminal single-tile failures enter the existing long deferred retry queue.
- Adds per-worker persistent HTTPS connection reuse while retaining automatic adaptive concurrency and the hard six-worker ceiling.
- Hillshade ETA now uses rolling recent completed-tiles/second and remaining uncached tiles instead of relying only on weighted historical build ETA.
- Preserves the r16-r6 persistent individual-tile cache namespace and all r16-r6 retry/Retry-After/READY-WITH-WARNINGS protections.
- Adds Pillow (`>=10,<13`) to the installer for local block splitting.
- `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`.

## v0.2.0-r16-r6
- Hardened USGS 3DEP hillshade downloads against transient `408/425/429/500/502/503/504`, timeout, reset, and temporary network failures.
- Normal hillshade retries now use 1/2/4-second exponential backoff with positive jitter and honor HTTP `Retry-After`.
- Failed hillshade tiles move to a deferred queue after the main acquisition pass and receive additional 8/16/30-second retry windows rather than aborting the entire map immediately.
- Adaptive hillshade concurrency still starts at 2 and is capped at 6; transient failures automatically reduce the active worker count.
- Added persistent reusable USGS hillshade source-tile cache under the Outdoors cache root. Retries and overlapping maps reuse verified cached PNG tiles.
- Hillshade PMTiles are written only after acquisition, in deterministic tile order, so deferred completions cannot violate PMTiles ordering.
- Tiny residual hillshade gaps (maximum 0.1% of requested tiles, hard capped at 25) may publish as READY WITH WARNINGS; larger gaps fail the build.
- Package manifest/descriptor record requested, written, missing, and cache-hit hillshade counts.
- Preserves r16-r5 rename/delete/cancel, polygon undo/editing, weighted progress/ETA, topology isolation, and manager-state concurrency fixes.
- `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`.

## v0.2.0-r16-r5

- Added READY-map rename, active-build cancel, canceled-build retry, and map delete actions for Outdoors packages.
- Added icon-only polygon Undo and draggable vertex editing after polygon closure.
- Added compact weighted build percentage progress and rolling/history-assisted ETA.
- Added automatic adaptive USGS hillshade download concurrency, starting at 2 and capped at 6 workers; no user-facing worker setting.
- Hardened Shapely/GEOS selection/tile overlay and MVT encoding against malformed/precision-sensitive source geometry, including the field-observed `TopologyException: Ring edge missing` on exact Web-Mercator tile edges.
- Malformed source fragments are isolated/skipped and counted rather than aborting the complete Outdoors map.
- Preserved `ROUTING_PIPELINE_REVISION = 0.2.0-r16`; this release does not intentionally invalidate current r16 routing graphs.

# TAK Rig Navigation Data Manager v0.2.0-r16-r4

## v0.2.0-r16-r4

- Fixes polygon completion in the Outdoors Map Creator so closing no longer depends on the browser preserving a native `dblclick` target while the preview layer is redrawn.
- Adds three reliable polygon completion paths: click the highlighted first vertex, double-click the final vertex using NDM's own time/distance detector, or press `FINISH POLYGON`.
- Shows a non-interactive red closure target over the first polygon vertex once three committed vertices exist.
- Prevents the second click of a detected double-click from adding a duplicate/fake polygon vertex.
- Updates the creator instructions and creation warning to describe all supported completion methods.
- Adds browser interaction regression coverage for first-vertex closure, double-click closure, and the explicit finish button.
- Preserves r16-r3 red coverage shading/live estimates, local Leaflet assets, manager-state concurrency locking, and `ROUTING_PIPELINE_REVISION = "0.2.0-r16"`.

## v0.2.0-r16-r3

- Fixes the field-confirmed concurrent `state.json` writer race during parallel supplemental-source downloads by locking each complete state read/modify/write transaction across threads and processes.
- Replaces PID+millisecond state temp names with PID+thread+UUID collision-proof atomic temp files and cleans unused temp files after failures.
- Serializes supplemental-source progress publication so late worker callbacks cannot overwrite newer source-completion progress.
- Changes Rectangle and Polygon drawing outlines to high-visibility red with translucent red coverage fill.
- Adds live Rectangle/Polygon coverage preview: the current mouse position is treated as the provisional next/final point while drawing, including shaded area and throttled live estimates.
- Keeps package creation gated on a committed rectangle or explicitly finished polygon; provisional mouse geometry cannot accidentally create a package.
- Fixes polygon estimates by canonicalizing three-point polygons into closed rings and calculating actual polygon area rather than bounding-box area.
- Estimates tile/storage coverage against the selected geometry: exact tile intersection counting for small selections and a responsive area-ratio estimate for large selections.
- Keeps `ROUTING_PIPELINE_REVISION = "0.2.0-r16"`, so these manager/UI fixes do not intentionally force a routing graph rebuild.

## v0.2.0-r16-r2

- Removes the Outdoors Map Creator browser runtime dependency on `unpkg.com` by serving Leaflet CSS, JavaScript, and image assets from local NDM `/vendor/leaflet/` paths.
- Corrects the r16-r1 Leaflet CSS integrity mismatch by packaging the exact Leaflet 1.9.4 stylesheet and installing the exact pinned JavaScript asset only after checksum verification.
- Adds a strict static-asset whitelist to the NDM Web server for Leaflet assets; arbitrary filesystem paths are not exposed.
- Calls `invalidateSize()` for the main Outdoors map and both min/max preview maps after initial layout and whenever their containers resize through `ResizeObserver`.
- Keeps the r16-r1 preview-tile proxy/cache and all operator-editable tile-source controls unchanged.
- Keeps `ROUTING_PIPELINE_REVISION = "0.2.0-r16"`, so this Web UI correction does not intentionally rebuild existing current r16 routing graphs.

## v0.2.0-r16-r1

- Fixes incomplete/checkerboard Outdoors Map Creator previews by routing all three Leaflet maps through the NDM server instead of having each browser map hit the public tile service directly.
- Adds a shared persistent preview-tile cache under `/var/lib/takrig-routing/outdoors/cache/preview-tiles/`, so the large selection map and min/max previews reuse the same tiles.
- Adds transient upstream retry/backoff, a configurable upstream concurrency cap, fresh-cache delivery, and stale-cache fallback when the upstream preview service is temporarily unavailable.
- Adds browser-side failed-tile retries and debounces the two small min/max preview maps; the large interactive selection map is loaded first and gets the initial network priority.
- Makes preview source URL, timeout, retry count, upstream concurrency, and cache age operator-editable in `/etc/takrig-routing/config.json`.
- Keeps the r16 routing-pipeline fingerprint unchanged, so installing this UI/transport correction does not force existing r16 state routing packages to rebuild.
- Does not change Outdoors package contents, PMTiles/MVT generation, routing, terrain/elevation, or TAK Rig r12.

## v0.2.0-r16

- Adds the first TAK Rig Outdoors Map Creator and PMTiles/MVT package pipeline.
- Adds State/County/Rectangle/Polygon/Radius selection, explicit min/max zoom, scaled zoom previews, Road Only/Offroad Only/Custom content, live storage estimates, and a user-set GB storage budget.
- Keeps map styles entirely in TAK Rig and does not duplicate the existing NDM elevation dataset.
- Publishes neutral vector, hillshade, and optional contour components through the existing catalog/download transport.
- Uses CRC32/ZIP CRC for the new Outdoors package contract; no SHA-256 is added to Outdoors packages.
- Reuses the existing resumable HTTP Range download path and preserves all r15 routing/terrain behavior.

# TAK Rig Navigation Data Manager v0.2.0-r15

## v0.2.0-r15

- Hardens Android package delivery by switching the built-in Web/API listener from HTTP/1.0 close-after-body responses to properly framed HTTP/1.1 responses.
- Keeps exact `Content-Length`, `Accept-Ranges`, revision ETag/If-Range semantics, and exact `Content-Range` behavior for routing and 3D Terrain ZIPs.
- Explicitly flushes completed JSON, Web UI, full-package, and Range response bodies before the handler returns.
- Makes invalid/unsatisfiable Range responses HTTP/1.1-safe by returning `416` with `Content-Range: bytes */<size>` and `Content-Length: 0`.
- Treats an unexpected local package-file EOF as an explicit server-side I/O failure rather than silently ending a response shorter than its advertised length.
- Adds persistent-connection regression coverage including the exact 4 MiB terrain chunk size used by TAK Rig r25, sequential ranges on one HTTP/1.1 connection, and a 416 followed by a valid Range request on that same connection.
- Does not change routing packages, terrain package contents, terrain resolution, or build formats.

## v0.2.0-r14

- Replaces r13's arbitrary `<1024 bytes` USGS terrain-response rejection with actual GDAL raster validation and actionable cell/HTTP/content/GDAL error detail.
- Treats valid all-NODATA edge/coastal terrain cells as skippable and reports actual stored valid `tile_count`.
- Converts source validity/NODATA through GDAL into TAK Rig's `-32768` Int16 NODATA samples.
- Fixes the 601×601 3-arc-second sample-grid alignment by expanding each 0.5° export request by half a sample on every edge, with `adjustAspectRatio=false`, so pixel centers align with the stored tile-bound nodes consumed by TAK Rig.
- Adds transient USGS retry/backoff and durable per-cell resumable terrain builds using crash-safe WAL/FULL SQLite commits.
- Fixes decimal terrain scratch filename collisions/cleanup and preserves legitimate zero-meter elevation maxima.
- Adds terrain-specific disk-space reserve checks, duplicate build request suppression, SQLite/package integrity validation, and improved GDAL stderr reporting.
- Surfaces 3D terrain build progress, disk waiting state, and exact failure detail directly in Package Status with explicit Retry 3D Terrain action.
- Adds antimeridian-safe `coverage_boxes`; legacy `bounds` remains compatible with the r23 Android client without advertising world-spanning Alaska coverage.
- Adds regression tests for tiny valid rasters, invalid non-rasters, all-NODATA skip, retry/backoff, resume, grid alignment, scratch cleanup, duplicate requests, zero-meter extrema, actual tile counts, and antimeridian coverage.

## v0.2.0-r12

- Fixed Coverage checkbox selections being reverted by the 5-second status refresh before APPLY SELECTION.
- Unsaved state selection is now protected by a dedicated dirty flag while status data continues to refresh.
- REFRESH explicitly discards unsaved state selection; successful APPLY SELECTION commits it and resumes server-state synchronization.
- Preset and clear-selection controls participate in the same dirty-state behavior.
- No routing-data/source behavior changes from r11.


## v0.2.0-r11

- Promotes legal full-size-vehicle off-road coverage to the primary NDM enrichment goal.
- Makes NPS Public Trails attribute-aware: only explicit full-size/high-clearance motor-vehicle routes that are open/public become routable; hiking/non-motorized, narrow-vehicle-only, closed, and ambiguous trails remain reference-only.
- Promotes USGS National Transportation 4WD Roads to routable high-clearance gap-fill while keeping generic USGS Trails reference-only.
- Activates conservative per-feature motorized/full-size adapters for Arizona State Parks trails, California OHMVR/SVRA routes, Nevada outdoor-recreation motorized trails, and Utah Trails & Pathways.
- Keeps New Mexico State Highway OHV routes routable and preserves State DOT Core-missing-only conflation.
- Expands USFS/BLM full-size evidence recognition when alternate route-use/vehicle-class fields establish 2WD/4WD/high-clearance/street-legal access, without promoting ATV/UTV/motorcycle-only trails.
- Preserves `takrig.routing.coverage.v2`; newly accepted off-road graph edges automatically appear as Off-Road NAV COVERAGE after package rebuild.
- Adds regression tests for the new source eligibility policy; suite is now 41 tests.


## v0.2.0-r10

- Replaces the ambiguous global source-selection UI with **state-scoped source configuration**. Every state retains its selection checkbox; clicking the state tile opens a compact `<State> Sources` panel without toggling selection.
- Removes the standalone main-page **Routing Sources & Health** panel. Source configuration and source health now live inside state tiles.
- Groups per-state sources into **Core**, **Federal**, and **State Sources**. State Parks/OHV/SVRA/equivalent state-managed sources are kept together.
- Adds **Standard**, **Maximum Coverage**, and **Custom** per-state source presets.
- Auto-populates known source endpoints from NDM's built-in registry while exposing editable endpoint fields, health/revision, CHECK, and RESET TO DEFAULT.
- Persists endpoint overrides independently per source/per state. Built-in defaults can be updated by future releases without overwriting user overrides.
- Scopes source configuration fingerprints to the affected state; a California source change does not force unrelated selected states to rebuild.
- Makes State DOT/public-road authority data supplemental-only. DOT geometry is conflated against Core and only materially missing fragments are added, reducing duplicate parallel road edges.
- Preserves R9 graph-derived `takrig.routing.coverage.v2`, serialized Valhalla builds, source concurrency limits, Range delivery, storage controls, failure persistence, and maintenance scheduling.

## v0.2.0-r9


## R9 graph-derived tiled NAV COVERAGE

- Adds NAV COVERAGE as a first-class output of every newly built routing package instead of relying on an optional Android-only sidecar that older packages never contained.
- Generates coverage from the **completed Valhalla 3.6.3 graph** through Valhalla's graph-backed vector-tile action, so the overlay describes graph edges rather than merely echoing source/basemap geometry.
- Includes unnamed graph edges and classifies automobile-accessible edges into `road` and `offroad`; track/service/driveway/alley/parking-aisle, unpaved, and rough-surface vehicle edges are shown as off-road coverage.
- Conservatively excludes graph edges without automobile access, impassable edges, non-vehicle uses, and destination-only edges from the general coverage overlay. Dynamic/conditional closures can still make a statically eligible edge unavailable at route time.
- Replaces the prototype monolithic coverage file with `takrig.routing.coverage.v2`: a z11 spatial index plus gzip-compressed GeoJSON tiles under `routing_coverage/11/<x>/<y>.geojson.gz`. This removes a whole-state in-memory/50,000-segment design ceiling and lets Android load only visible coverage cells.
- Adds coverage metadata to `manifest.json`, ready-package descriptors, and `takrig.nav.catalog.v1` rows. Package verification decompresses every indexed coverage tile and verifies the advertised feature count before publication.
- Configures the Valhalla graph-MVT endpoint to expose verbose access/use/surface attributes and to include all road classes at the fixed coverage zoom, preserving local/service/track visibility.
- Adds `mapbox-vector-tile==2.2.0` to the server runtime and validates the coverage dependencies during installation.
- Manager version changes the effective build fingerprint, so installing R9 makes existing selected-state R8 packages eligible for a new build containing coverage data. Existing ready packages remain published until their R9 replacements verify successfully.
- Keeps R8's no-public-SHA package policy, HTTP Range delivery, deterministic failure handling, storage controls, and all existing routing/source behavior.

## R8 routing-package checksum removal + action layout

- Removes routing-package SHA-256 calculation/publication and `.zip.sha256` ready sidecars.
- Migrates existing ready descriptors by removing legacy routing-package checksum fields and using the package build timestamp as the revision identifier.
- Public `takrig.nav.catalog.v1` rows no longer contain a `sha256` field.
- Package downloads use a non-checksum revision ETag; stale `If-Range` revisions cause a clean HTTP 200 restart instead of appending to an older partial.
- Keeps package-size metadata, Range support, package ZIP validation and the R7 operational architecture unchanged.
- Implements the approved full-stack Package Status action layout with equal-width vertically stacked controls.

## R7 operations, scheduling, storage safety, and status visibility

- Keeps the live-validated R6 OSM + supplemental enrichment + Valhalla 3.6.3 routing architecture unchanged.
- Fixes stale failure precedence: a newer source/download/build attempt is the current state immediately; older failures are retained as history/details instead of masking active work.
- Adds configurable source download concurrency (default 3, range 1–6) and per-host concurrency (default 2). Valhalla graph builds remain serialized at exactly one.
- Adds a hard storage policy with a default 30 GiB free-space reserve, configurable source-cache limit, projected per-state peak estimate, and `WAITING FOR SPACE` rather than destructive or repeated failures. Ready packages are never silently deleted.
- Adds a server-local daily maintenance start (default 00:00). Automatic large downloads/builds queue until the trigger; explicit Start/Update/Retry/Rebuild bypass timing but still obey the disk reserve. Once work starts it runs to completion.
- Separates update detection from rebuilding with `Automatically rebuild when newer sources are found`; when disabled, source checks continue and states report `UPDATE AVAILABLE`.
- Adds update reasons, live transfer counters/rates, build-stage detail, disk estimates, per-state cache/temp size, failure log tails/history, and retry eligibility to state status.
- Adds source-health reporting with actual upstream endpoints plus per-source Check actions in the Web GUI.
- Adds per-state **Clean Temporary Work** and **Clear Source Cache** controls with reclaimed-byte reporting; ready routing packages are preserved.
- Preserves the 7/14/30/60-day source-check cadence and deterministic failed-fingerprint retry suppression.
- Upgrade/install migration preserves existing `/etc/takrig-routing/config.json`, manager settings/state, selected coverage, caches, and ready packages while adding R7 defaults without discarding unknown settings. Normal uninstall preserves `/etc/takrig-routing` and `/var/lib/takrig-routing`; only `--purge` removes them.


## R6 Osmium stream hotfix + configurable update cadence

- Fixes the live California R5 indexing failure caused by passing `geojsonseq,print_record_separator=false` as the `-f/--output-format` value. Osmium requires the format to be `geojsonseq` and the record-separator setting to be supplied separately with `-x/--format-option print_record_separator=false`.
- Adds a persistent **Source Update Interval** control to the Web GUI with 7, 14, 30, and 60 day choices; 30 days remains the default.
- The selected interval controls normal automatic upstream source checks for already-maintained states. New selections and **Check Sources Now** remain immediate.
- Adds the manager software version to the effective build fingerprint so installing a software fix automatically invalidates a deterministic failure from an older manager version without requiring repeated manual retries.
- Preserves the R5 deterministic-failure gate: the same failed fingerprint still remains stopped until inputs, source revisions, software version, or an explicit Retry/Rebuild changes the attempt.

## R5 California first-build corrections

- Reworks supplemental OSM object allocation to use collision-free **positive** node/way IDs above the maximum IDs in the current state base PBF. This removes the R4 negative-ID `osmium merge` failure observed during the first California OSM + NPS build.
- Downloads and caches the exact Geofabrik `.poly` state boundary and clips supplemental agency geometry to that polygon before enrichment. National datasets are no longer accepted merely because they intersect a state's rectangular bounding envelope.
- Streams the OSM OPL and GeoJSONSeq representations directly into the SQLite conflation index instead of materializing multi-gigabyte text intermediates. The small filtered highway PBF and SQLite scratch index are also deleted after enrichment.
- Treats `enrich-work` as disposable scratch and cleans it on success or failure. Upgrading from R4 also purges stale `enrich-work` trees while preserving useful base/supplemental caches and ready packages.
- Adds persistent per-state manager failures with stage, error, timestamp, and an effective build fingerprint. Automatic reconciliation and **Check Sources Now** do not retry the same deterministic failed build.
- A failed state is retried only by an explicit Retry/Rebuild action, changed source/settings inputs, changed upstream source revisions, or a new manager software version that changes the effective fingerprint.
- Preserves the build fingerprint through manager → processor → package metadata so Valhalla/package failures are covered by the same retry gate and an explicit processor retry can reuse the already prepared PBF.
- Replaces the vague long-running `PENDING` presentation with source-check/download/index/enrich/merge/queue/build/package stages, exposes failure details and Retry, and auto-refreshes the Web GUI status every five seconds.
- Adds separate Web GUI storage metrics for source cache, temporary work, processing, ready packages, and failed jobs.

## R4 readability update

- Enlarges Web GUI typography throughout the header, buttons, metrics, section headings, helper text, state cards, source cards, pipeline steps, package tables, file inputs, status pills, and toast messages.
- Expands state cards and reduces the desktop state grid from four columns to three so the larger text remains uncluttered.
- Slightly increases button and text/select control heights for easier reading and interaction.
- No routing, source, processor, API, catalog, or package-format behavior is changed from the validated R3 baseline.


## R3 live-install correction

- Confirmed on the target Ubuntu 24.04 TAK Gateway that the pyvalhalla 3.6.3 native `valhalla_build_tiles` binary executes successfully and all shared libraries resolve.
- Bypasses the pyvalhalla 3.6.3 `python -m valhalla` wrapper, whose PATH pre-check can report `Can't find executable` even when the bundled binary exists.
- Resolves and invokes `valhalla/bin/valhalla_build_tiles` directly.
- Uses the actual `valhalla_build_config.py` shipped in the installed 3.6.3 wheel to generate each build config.
- Moves the application runtime/venv from `/opt/takrig-routing` to `/usr/local/lib/takrig-routing` so the `takrig-routing` systemd account is not blocked by a host-specific `/opt` mode of `0750 root:root`.
- Migrates an existing `/etc/takrig-routing/config.json` `venv_root` value in place without discarding selected states or source settings.
- Installer validates the native builder, config generator, generated config, and execution as the actual `takrig-routing` service account before installing/enabling systemd services.
- Removes the failed legacy `/opt/takrig-routing` tree only after corrected services install successfully.
- Keeps Valhalla 3.6.3 and `takrig.valhalla.region.v1` unchanged.

# Changelog

## v0.2.0 — Navigation Data Manager

- Added the user-friendly Navigation Data Manager Web GUI and JSON API.
- Added multi-selection for all 50 U.S. states plus Southwest/West/All presets and state search.
- Newly selected states reconcile immediately instead of waiting for the normal 30-day source update interval.
- Added desired-state reconciliation with source revision detection, source-configuration fingerprints, last-known-good revision handling, and background update/rebuild jobs.
- Added lightweight `takrig.nav.catalog.v1` catalog and verified state ZIP download endpoints for TAK Rig Android.
- Added HTTP byte-range delivery for state ZIPs so TAK Rig Android can pause and resume large downloads.
- Tightened USFS/BLM vehicle-class filtering so motorcycle/ATV/UTV-only trails are not promoted into the full-size TAK Rig vehicle routing graph.
- Added OpenStreetMap/Geofabrik automatic state PBF acquisition.
- Added national USFS MVUM, BLM GTLF, NPS, and USGS source adapters with conservative routing trust.
- Added vetted state DOT/statewide road adapters for CA/NV/UT/NM.
- Added State Parks/OHV/SVRA source tier, including California State Parks/OHMVR/SVRA, Arizona State Parks reference, Nevada motorized recreation reference, New Mexico official OHV State Highway routes, and Utah Trails & Pathways reference.
- Added geometry enrichment that suppresses highly overlapping agency lines and only injects adapters explicitly marked vehicle-routable.
- Added manual `.osm.pbf` / validated `.pbf` upload with visible format helper text, osmium bounding-box validation, immediate supplemental enrichment, and atomic processor queue handoff.
- Added Web/API, reconcile, and processor systemd units with reduced processing priority.
- Preserved the v0.1.0 Valhalla 3.6.3 processor, atomic incoming/processing/ready/failed lifecycle, package verification, failed-job retention, and retry support.

## v0.1.0

- Initial TAK Gateway-side navigation post-download processor.
- Pinned Valhalla graph generation to 3.6.3 for TAK Rig compatibility.
- Added atomic incoming/processing/ready/failed lifecycle.
- Added optional PBF metadata/checksum sidecars.
- Added disk-space preflight and one-build-at-a-time locking.
- Added exact `takrig.valhalla.region.v1` ZIP packaging and verifier.
- Added ready package descriptor and `catalog.json` generation.
- Added failed-build persistence and retry command.
- Added low-priority systemd scanner/timer.