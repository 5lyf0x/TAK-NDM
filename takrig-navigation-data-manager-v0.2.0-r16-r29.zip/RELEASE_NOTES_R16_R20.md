# TAK Rig Navigation Data Manager v0.2.0-r16-r20

## Scope

R16-r20 is a WebUI/package-lifecycle release on the validated r16-r19 source-persistence baseline. `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`.

## Package Status — Data Cards + Actions

Package Status now uses the approved horizontal **Data Cards + Actions** design. Navigation Data, Elevation Data, and Cell Coverage each receive an independent card with package size, lifecycle state, Download, Build/Update/Rebuild, and Remove behavior.

Downloads use the existing validated HTTP package endpoints:

```text
/api/v1/packages/<STATE>/download
/api/v1/terrain/<STATE>/download
/api/v1/cellular/<STATE>/download
```

A previously verified package remains downloadable while NDM checks sources, builds a replacement, or reports a failed replacement. The Download action is disabled only when no usable current package exists.

The UI covers Not Built, Queued, Building/Updating, Ready, Checking, Update Available, Failed, Waiting for Space, No Sources, and Sources Incomplete states where applicable.

Source-cache cleanup and 3D Environment controls remain available in a compact maintenance row below the three primary data cards.

## Outdoors removal

The standalone Outdoors Map Creator product is removed from active NDM functionality:

- no Outdoors creator WebUI;
- no Outdoors API/catalog/status lifecycle;
- no Outdoors package builder runtime or tests;
- no Leaflet runtime/assets used solely by the creator.

Upgrade deliberately does not delete existing `/var/lib/takrig-routing/outdoors` files. Legacy data remains on disk for operator-controlled cleanup/rollback but is no longer surfaced or maintained by NDM.

## Preserved behavior

- r16-r19 authoritative per-state source persistence and Utah defaults;
- Navigation/Valhalla package contract;
- 30 m Terrain/Elevation package contract;
- 3D Environment lifecycle;
- FCC H3 Cellular Coverage contract;
- HTTP Range/ETag package delivery;
- existing configuration, state, caches, and built package data during normal upgrade.
