# TAK Rig Navigation Data Manager v0.2.0-r16-r16

`r16-r16` is the coordinated Terrain/3D Environment data release for TAK Rig r46-i08. Routing pipeline revision remains `0.2.0-r16`.

## 30 m 3D Terrain
- New Terrain builds default to approximately 30 m / 1-arcsecond sampling (1801x1801 samples per 0.5-degree source cell).
- Operators may retain the legacy approximately 90 m / 3-arcsecond target.
- `terrain.sqlite` retains native Int16LE+zlib base rasters and adds optional `tile_overviews` at approximately 60, 120 and 240 m for 30 m builds (180/360 m for 90 m builds).
- Existing legacy Terrain packages without overviews remain valid.
- Terrain manifest metadata records the native resolution and available overview levels.

## 3D Environment packages
- Adds independent `takrig.environment.region.v1` packages (`manifest.json` + `environment.sqlite`).
- Static land-cover is sourced from ESA WorldCover 2021 v200 and normalized to stable TAK Rig classes: water, built, tree, shrub, grass, crop, bare/sparse, wetland, permanent snow/ice, unknown.
- Environment runtime cells carry class + vegetation density and are independent from Navigation, Terrain, Outdoors and Cellular lifecycles.
- Dynamic/recent-weather snow is deliberately not baked into Environment packages; TAK Rig derives transient snow separately at runtime.
- Discovery now advertises the `environment` capability.

## Compatibility
- `ROUTING_PIPELINE_REVISION` stays `0.2.0-r16`.
- Existing ready Navigation, 90 m Terrain, Outdoors and Cellular packages remain supported.
