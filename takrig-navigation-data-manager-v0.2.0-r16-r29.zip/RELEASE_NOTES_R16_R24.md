# TAK Rig Navigation Data Manager v0.2.0-r16-r24

## Changes

- Fixed FCC mobile provider discovery so state acquisitions select provider-specific AT&T, Verizon, and T-Mobile Hexagon Coverage files for Mobile Voice, LTE, 5G 7/1, and 5G 35/3.
- Added controlled parallel FCC downloads: 4 concurrent transfers by default, configurable from 1 through 6. FCC downloads are not constrained by the routing-source per-host throttle.
- Preserved FCC Retry-After/429 backoff and resumable `.part` downloads.
- Added aggregate concurrent-download progress including file counts, bytes, elapsed time, worker count, and transfer rate.
- Kept GeoPackage validation/import sequential after transfer completion to avoid contention in shared inventory/metadata updates.
- Fixed stale Cellular Coverage UI state: new check/acquire actions reset prior progress/errors, failed acquisitions cannot remain ACQUIRING at 100%, and old acquisition errors are hidden while a new operation is active.
- Gateway-wide WebUI FCC credentials are authoritative; administrator credentials are fallback-only and template credentials are ignored.
- Routing pipeline revision remains 0.2.0-r16.
