# TAK Rig Navigation Data Manager v0.2.0-r16-r13

## Compact FCC H3 Cellular Coverage

R16-r13 is the first production-oriented Cellular Coverage source/package release for TAK Rig NDM. It replaces the r16-r12 Raw Coverage/PMTiles prototype with provider-specific FCC Hexagon Coverage and a compact H3 binary designed to minimize TAK Rig storage, range-read, decode, and rendering overhead.

### Operator workflow

Each state Cellular card exposes only:

- AT&T
- Verizon
- T-Mobile

A checked carrier automatically includes all applicable FCC Voice/3G, LTE, and 5G source data. Data can be supplied by either **IMPORT FCC DATA** or **FCC API**; both converge on the same normalized H3 source inventory and downstream package builder.

Manual import accepts official provider-specific FCC **Hexagon Coverage – GeoPackage** ZIP/GPKG downloads and streams uploads to disk. The FCC API dialog can test/save credentials, discover availability releases, and acquire equivalent provider-specific H3 data. API problems are acquisition conditions rather than package-build failures.

### H3 package contract

Only FCC `environmnt=1` coverage is retained. NDM joins by H3 resolution-9 cell and precomputes one class per selected carrier/cell using:

`5G > LTE > Voice/3G`

The output ZIP contains:

```text
manifest.json
coverage.h3
```

`coverage.h3` uses schema `takrig.cellular.h3.v1`. It stores H3 cell identity instead of polygon vertices, groups records by H3 parent resolution 6, independently compresses chunks, delta/varint-encodes sorted child H3 IDs, and packs all three carrier classes into one byte. TAK Rig reconstructs visible hex boundaries from the H3 IDs and applies styling client-side.

No signal-strength heatmap values or raw FCC per-feature metadata are shipped to TAK Rig.

### Compatibility

`ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`. Installing r16-r13 does not intentionally invalidate current r16 Navigation graphs. Existing Terrain and Outdoors package contracts are unchanged.

### First live acceptance

The first target-host acceptance should use California and one coherent FCC availability release. Validate manual import and/or API acquisition, source completeness for the selected carriers, H3 package build, Range download, package/cell/chunk statistics, and eventual TAK Rig render performance.
