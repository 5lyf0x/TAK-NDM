# TAK Rig Navigation Data Manager v0.2.0-r16-r7

## Scope
This is an Outdoors hillshade-throughput release built on r16-r6. It does not change the routing pipeline revision.

## Batched USGS 3DEP acquisition
- Replaces the normal one-HTTP-request-per-256x256-tile path with Web-Mercator-aligned blocks up to 8x8 tiles / 2048x2048 pixels.
- One successful full block can populate 64 normal 256x256 persistent cache tiles.
- Requests use exact EPSG:3857 tile-grid bounds with `bboxSR=3857`, `imageSR=3857`, and `adjustAspectRatio=false`.
- Returned block PNGs are split locally with Pillow and written back into the existing individual-tile cache contract, so retries and overlapping maps retain normal per-tile reuse.

## Failure isolation
- A failed large block is subdivided into smaller tight blocks instead of immediately falling back to thousands of single-tile requests.
- Subdivision continues toward 4x4 / 2x2 / 1x1 scale as needed; only terminal single-tile failures enter the r16-r6 long deferred retry queue.
- Existing transient retry, Retry-After, adaptive backoff, READY WITH WARNINGS threshold, and six-worker hard ceiling remain in effect.

## HTTP efficiency
- Each downloader worker reuses a persistent HTTPS connection to the USGS service when the service keeps the connection alive.
- Network worker count remains automatic and is still hard capped at 6; there is no user-facing worker-count setting.

## Progress and ETA
- Hillshade progress remains tile-based even though network work is block-based.
- Hillshade ETA is calculated from a rolling recent completed-tiles/second rate and remaining uncached tiles; during the hillshade stage this rate-derived ETA overrides the generic build-history ETA.
- Telemetry records completed/split block counts, tile rate, byte rate, cache hits, and active workers.

## Cache compatibility
The persistent cache remains individual 256x256 PNG tiles under the existing `hillshade-usgs-3dep-v1` namespace. r16-r6 cached tiles remain reusable; r16-r7 block responses simply populate the same cache more efficiently.

## Dependency
The installer adds Pillow (`>=10,<13`) for deterministic local block splitting.

## Routing fingerprint
`ROUTING_PIPELINE_REVISION = "0.2.0-r16"` remains unchanged.
