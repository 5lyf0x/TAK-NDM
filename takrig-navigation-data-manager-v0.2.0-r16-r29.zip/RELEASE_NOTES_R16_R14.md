# TAK Rig Navigation Data Manager v0.2.0-r16-r14

## FCC dual-5G-tier correction

r16-r14 fixes the first live California Cellular-package issue found in r16-r13. FCC provider-specific 5G Hexagon Coverage is published at both 7/1 Mbps and 35/3 Mbps. r16-r13 classified both as one logical `5g` source, allowing a later import to replace the other tier.

This release:

- retains `5g_7_1` and `5g_35_3` as independent source variants;
- requires both tiers for each selected carrier;
- unions both into the final client-facing `5g` class;
- keeps Voice and LTE required and 3G optional;
- migrates already-imported r16-r13 5G sources in place from official FCC filenames;
- updates FCC API discovery/acquisition to fetch both 5G tiers;
- shows the two 5G tiers separately in Cellular source details/status;
- advances the Cellular pipeline revision to 3 so corrected source sets produce a new package; and
- leaves `takrig.cellular.h3.v1`, `takrig.cellular.region.v2`, Navigation, Terrain, Outdoors, and `ROUTING_PIPELINE_REVISION = 0.2.0-r16` unchanged.

After upgrading an existing T-Mobile California r16-r13 installation that already has Voice, LTE, and 5G 35/3 imported, NDM should recognize the existing 35/3 file automatically and report only `Needs 5G 7/1`. Import the matching FCC 5G 7/1 Hexagon Coverage file, then use UPDATE to build the corrected union package.
