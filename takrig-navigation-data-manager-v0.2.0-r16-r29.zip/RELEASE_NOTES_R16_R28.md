# TAK Rig Navigation Data Manager v0.2.0-r16-r28

## Executive Slate fixed cards, centered layout and completed 50-state scenic artwork

- Built on validated r27 (SHA-256 `62cf0fefbda6fbbe7f326af3e458a48c72c3b98207d2d3536b010e79f7a9b093`).
- Installs the approved real Executive Slate HTML/CSS implementation; **no demo data or screenshot substitute** is shipped.
- Centers the State view's content canvas, breadcrumb, toolbar, three top panels, package action cards and maintenance row, removing excessive whitespace to the right on wide screens.
- Fixed panel-height breakpoints for desktop/tablet/mobile; content flows into 2-column then 1-column modes at smaller viewports. Long live activity/packages data scroll inside their panels.
- Full state scenery shown using contain-fit image with subdued blurred-fill background for aspect ratio differences; retains accurate text overlay and state selection.
- Navigation and elevation illustration frames use fixed 150px heights.
- Removes left sidebar title entirely and removes sidebar menu icons, retaining all six navigation text items and their existing actions.
- Locally bundled WebP art for **all 50 states**: Phase 1–2 approved (20), Phase 3 scenic (10), Phase 4 provisional ground-first composites (10), Phase 5 new scenic artwork (10: SD, TN, TX, UT, VT, VA, WA, WV, WI, WY).
- The Phase 4 composites remain illustrative and not independently verified state-specific photographs; all artwork is stylized and not for geographic measurement.
- Existing source discovery, navigation/elevation/3D/cellular building, status reporting, FCC API controls, downloads, cached packages, and stored secrets unchanged.
- Upgrade install continues to preserve data and credentials.
- Routing pipeline revision remains `0.2.0-r16`, so the UI-only release does not intentionally invalidate navigation builds.

## Rollback

The untouched r27 source ZIP remains the preceding rollback release. No data migrations are performed.
