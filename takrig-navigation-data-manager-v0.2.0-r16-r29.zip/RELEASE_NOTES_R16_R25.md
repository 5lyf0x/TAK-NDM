# TAK Rig Navigation Data Manager v0.2.0-r16-r25

## Changes

- Consolidates the complete Cellular Coverage workflow into each state row in **Package Status**.
- Removes the old standalone **Cellular Coverage** section and its duplicate per-state cards.
- Keeps gateway-wide **FCC API status/settings** at the top of Package Status while leaving carrier selection and Cellular lifecycle state-specific.
- Expands each state CELL card with AT&T / Verizon / T-Mobile selectors, per-carrier readiness, FCC vintage/source count, H3 cell count, acquisition progress, aggregate transfer rate, source details, import/acquire controls, and package Download/Build/Update/Rebuild/Remove actions.
- Keeps Cellular source details collapsible so individual provider files can be inspected/removed without creating a second state interface.
- Preserves the r24 provider-specific FCC discovery, resumable parallel downloader (default 4; configurable 1-6), 429/Retry-After handling, stale-error cleanup, and gateway-wide credential behavior.
- Navigation, Elevation, 3D Environment, package formats, stored data, and routing behavior are unchanged.
- Routing pipeline revision remains `0.2.0-r16`.
