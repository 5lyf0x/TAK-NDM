import json
import os
import shutil
import sqlite3
import struct
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
import zipfile
import zlib
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / "src"))

import cellular
import fcc_mobile
import manager


H3_CELLS = [
    "89280048017ffff",
    "8928004804bffff",
    "89280048063ffff",
    "89280048073ffff",
    "89280048077ffff",
]
PROVIDERS = {
    "att": ("130077", "AT&T"),
    "verizon": ("131425", "Verizon"),
    "tmobile": ("130403", "T-Mobile"),
}


def official_name(carrier: str, klass: str, vintage: str = "D25") -> str:
    pid, _ = PROVIDERS[carrier]
    token = {
        "voice": "MobileVoice_mobile_voice_h3",
        "3g": "3G_mobile_broadband_h3",
        "lte": "4GLTE_mobile_broadband_h3",
        "5g": "5GNR_7_1_mobile_broadband_h3",
        "5g_7_1": "5GNR_7_1_mobile_broadband_h3",
        "5g_35_3": "5GNR_35_3_mobile_broadband_h3",
    }[klass]
    return f"bdc_06_{pid}_{token}_{vintage}_03sep2026.gpkg"


def create_h3_gpkg(path: Path, carrier: str, klass: str, cells, *,
                   as_srs: int = 4326, include_provider: bool = True,
                   env0: bool = True, h3_resolution: int = 9,
                   bounds=(-124.5, 32.5, -114.1, 42.0)) -> Path:
    """Create a tiny FCC-like H3 GeoPackage sufficient for deterministic tests."""
    pid, brand = PROVIDERS[carrier]
    table = path.stem
    conn = sqlite3.connect(path)
    try:
        conn.execute("CREATE TABLE gpkg_contents(table_name TEXT PRIMARY KEY, data_type TEXT, min_x REAL, min_y REAL, max_x REAL, max_y REAL)")
        conn.execute("CREATE TABLE gpkg_geometry_columns(table_name TEXT PRIMARY KEY, column_name TEXT, geometry_type_name TEXT, srs_id INTEGER, z INTEGER, m INTEGER)")
        conn.execute("INSERT INTO gpkg_contents VALUES(?,?,?,?,?,?)", (table, "features", *bounds))
        conn.execute("INSERT INTO gpkg_geometry_columns VALUES(?,?,?,?,0,0)", (table, "geom", "POLYGON", as_srs))
        fields = ["fid INTEGER PRIMARY KEY", "geom BLOB", "environmnt INTEGER", f"h3_res{h3_resolution}_id TEXT"]
        if include_provider:
            fields += ["frn TEXT", "providerid TEXT", "brandname TEXT"]
        source_class = "5g" if klass.startswith("5g") else klass
        if source_class != "voice":
            fields += ["technology INTEGER", "mindown REAL", "minup REAL"]
        conn.execute(f'CREATE TABLE "{table}"({", ".join(fields)})')
        tech = {"3g": 300, "lte": 400, "5g": 500}.get(source_class)
        rows = []
        fid = 1
        for h in cells:
            values = [fid, None, 1, h]
            if include_provider:
                values += ["0003766532", pid, brand]
            if source_class != "voice":
                if source_class == "5g":
                    values += [tech, 35, 3] if klass == "5g_35_3" else [tech, 7, 1]
                elif source_class == "lte":
                    values += [tech, 5, 1]
                else:
                    values += [tech, 0.2, 0.05]
            rows.append(values); fid += 1
        if env0 and cells:
            values = [fid, None, 0, cells[0]]
            if include_provider:
                values += ["0003766532", pid, brand]
            if source_class != "voice":
                if source_class == "5g":
                    values += [tech, 35, 3] if klass == "5g_35_3" else [tech, 7, 1]
                elif source_class == "lte":
                    values += [tech, 5, 1]
                else:
                    values += [tech, 0.2, 0.05]
            rows.append(values)
        placeholders = ",".join("?" for _ in rows[0]) if rows else ""
        if rows:
            conn.executemany(f'INSERT INTO "{table}" VALUES({placeholders})', rows)
        conn.commit()
    finally:
        conn.close()
    return path


def unzip_member(pkg: Path, member: str, target: Path) -> Path:
    with zipfile.ZipFile(pkg) as zf:
        target.write_bytes(zf.read(member))
    return target


def decode_h3_binary(path: Path):
    """Return list[(h3_int, coverage_byte)] from the test package."""
    out = []
    with path.open("rb") as fh:
        hdr = cellular.H3_HEADER.unpack(fh.read(cellular.H3_HEADER.size))
        _, _, _, _, _, _, _, chunks, records, _, data_offset, *_ = hdr
        entries = [cellular.H3_INDEX.unpack(fh.read(cellular.H3_INDEX.size)) for _ in range(chunks)]
        for parent, offset, comp_len, raw_len, count, crc, flags in entries:
            fh.seek(data_offset + offset)
            raw = zlib.decompress(fh.read(comp_len))
            assert len(raw) == raw_len and (zlib.crc32(raw) & 0xFFFFFFFF) == crc and flags == 1
            pos = 0
            first = struct.unpack_from("<Q", raw, pos)[0]; pos += 8
            cov = raw[pos]; pos += 1
            out.append((first, cov)); prev = first
            for _ in range(count - 1):
                delta, pos = cellular._decode_uvarint(raw, pos)
                h = prev + delta; cov = raw[pos]; pos += 1
                out.append((h, cov)); prev = h
            assert pos == len(raw)
    assert len(out) == records
    return out


class CellularTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="takrig-cellular-r16-r14-"))
        self.cfg = self.tmp / "config.json"
        self.cred = self.tmp / "fcc.env"
        self.operator_token = "operator-token-abcdefghijklmnopqrstuvwxyz-1234567890"
        self.cred.write_text(
            f"FCC_BDC_USERNAME=test@example.com\nFCC_BDC_HASH_VALUE={self.operator_token}\n",
            encoding="utf-8",
        )
        self.cfg.write_text(json.dumps({
            "state_root": str(self.tmp / "state"),
            "log_root": str(self.tmp / "log"),
            "fcc_bdc_credentials_file": str(self.cred),
            "cellular_h3_chunk_resolution": 6,
            "allow_web_secret_management": True,
            "minimum_free_disk_gib": 5.0,
        }), encoding="utf-8")
        cellular.ensure_roots(self.cfg)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _import(self, carrier, klass, cells, *, vintage="D25", include_provider=True, config=None):
        cfg = config or self.cfg
        srcdir = Path(tempfile.mkdtemp(prefix="fcc-src-", dir=self.tmp))
        name = official_name(carrier, klass, vintage)
        src = create_h3_gpkg(srcdir / name, carrier, klass, cells, include_provider=include_provider)
        return cellular.import_uploaded(cfg, "CA", src, name, provenance="manual")

    def _complete_sources(self, config=None, provenance="manual"):
        cfg = config or self.cfg
        patterns = {
            "voice": H3_CELLS[:3],      # A B C
            "lte": H3_CELLS[1:4],       # B C D
            "5g_7_1": H3_CELLS[2:4],    # C D
            "5g_35_3": H3_CELLS[3:5],   # D E; union => C D E
        }
        for carrier in cellular.CARRIERS:
            for klass, cells in patterns.items():
                srcdir = Path(tempfile.mkdtemp(prefix="fcc-src-", dir=self.tmp))
                name = official_name(carrier, klass)
                src = create_h3_gpkg(srcdir / name, carrier, klass, cells)
                kwargs = {}
                if provenance == "api":
                    pid, brand = PROVIDERS[carrier]
                    source_class = "5g" if klass.startswith("5g_") else klass
                    kwargs = {"carrier_hint": carrier, "as_of_hint": "2025-12-31",
                              "api_meta": {"class": source_class, "variant": klass, "provider_id": pid, "provider_name": brand, "file_id": f"api-{carrier}-{klass}"}}
                cellular.import_uploaded(cfg, "CA", src, name, provenance=provenance, **kwargs)

    def test_credentials_are_external_redacted_and_webui_file_wins(self):
        row = cellular.source_status(self.cfg)
        self.assertTrue(row["configured"])
        self.assertEqual(row["username"], "test@example.com")
        self.assertEqual(row["credential_source"], str(self.cred))
        self.assertEqual(row["token_last4"], self.operator_token[-4:])
        self.assertNotIn(self.operator_token, json.dumps(row))
        cellular.save_api_credentials(self.cfg, "ui@example.com", "ui-token-abcdefghijklmnopqrstuvwxyz-0987654321")
        row2 = cellular.source_status(self.cfg)
        self.assertEqual(row2["username"], "ui@example.com")
        self.assertEqual(row2["credential_source"], str(cellular.ui_secret_path(self.cfg)))
        self.assertEqual(oct(cellular.ui_secret_path(self.cfg).stat().st_mode & 0o777), "0o600")


    def test_placeholder_operator_credentials_are_ignored(self):
        self.cred.write_text(
            "FCC_BDC_USERNAME=your-fcc-account-email\nFCC_BDC_HASH_VALUE=your-fcc-api-token\n",
            encoding="utf-8",
        )
        cellular.ui_secret_path(self.cfg).unlink(missing_ok=True)
        row=cellular.source_status(self.cfg)
        self.assertFalse(row["configured"])
        self.assertEqual(row["credential_source"], "")

    def test_spawn_acquire_clears_stale_error_and_progress(self):
        cfg=manager.ManagerConfig(self.cfg); cfg.ensure()
        cellular.update_status(
            self.cfg,"AZ","no_sources","api_acquire_failed","Old failure",
            acquisition_error="HTTP 401 stale",progress={"percent":100,"failed":True},
        )
        class DummyProc: pass
        with patch.object(manager.subprocess,"Popen",return_value=DummyProc()):
            self.assertTrue(manager.spawn_cellular_action(cfg,"AZ","acquire"))
        row=cellular.status_summary(self.cfg,"AZ")
        self.assertEqual(row["status"],"acquiring")
        self.assertEqual(row.get("acquisition_error"),"")
        self.assertEqual(row.get("error"),"")
        self.assertEqual(row.get("progress",{}).get("percent"),0)
        self.assertEqual(row.get("progress",{}).get("phase"),"queued")

    def test_api_acquisition_downloads_in_parallel_without_per_host_serialization(self):
        rows=[]
        for i,(carrier,klass) in enumerate((("att","voice"),("att","lte"),("verizon","voice"),("tmobile","lte")),1):
            pid,brand=PROVIDERS[carrier]
            source_class="5g" if klass.startswith("5g") else klass
            rows.append((carrier,{"file_id":str(i),"file_name":official_name(carrier,klass),"_takrig_class":source_class,"_takrig_variant":klass,"provider_id":pid,"provider_name":brand}))
        selected={c:[] for c in cellular.CARRIERS}
        for carrier,row in rows: selected[carrier].append(row)
        disc={"as_of":"2025-12-31","selected_carriers":list(cellular.CARRIERS),"selected":selected,"sources":[],"availability":{},"api_base":"https://example.invalid"}
        active=0; peak=0; lock=threading.Lock()
        class FakeClient:
            def __init__(self,*a,**k): pass
            def download_file(self,fid,target,file_type=2,progress=None):
                nonlocal active,peak
                with lock:
                    active+=1; peak=max(peak,active)
                try:
                    target.parent.mkdir(parents=True,exist_ok=True)
                    if progress: progress(1,2,0.01)
                    import time as _time; _time.sleep(0.05)
                    target.write_bytes(b"xx")
                    if progress: progress(2,2,0.05)
                    return target
                finally:
                    with lock: active-=1
        def fake_import(*a,**k): return []
        complete={"ready_to_build":True,"active_as_of":"2025-12-31","records":[{"id":"x"}]}
        with patch.object(cellular,"discover_api",return_value=disc), \
             patch.object(cellular,"BdcClient",FakeClient), \
             patch.object(cellular,"import_uploaded",side_effect=fake_import), \
             patch.object(cellular,"source_inventory_summary",return_value=complete):
            result=cellular.acquire_api_sources(self.cfg,"CA")
        self.assertGreaterEqual(peak,2)
        self.assertLessEqual(peak,4)
        self.assertEqual(result["status"],"ready_to_build")
        self.assertEqual(result["progress"]["workers"],4)

    def test_manifest_selection_prefers_provider_h3_and_all_three_carriers(self):
        rows = [
            {"file_id": 1, "state": "CA", "provider_id": "130077", "technology": 500, "description": "Mobile Broadband Raw Coverage 5GNR 7 1 GeoPackage"},
            {"file_id": 2, "state": "CA", "provider_id": "130077", "technology": 500, "mindown": 7, "minup": 1, "description": "Mobile Broadband H3 Hexagon GeoPackage"},
            {"file_id": 6, "state": "CA", "provider_id": "130077", "technology": 500, "description": "5GNR_35_3 Mobile Broadband H3 Hexagon GeoPackage"},
            {"file_id": 3, "state_fips": "06", "provider_id": "131425", "technology": 400, "description": "Mobile Broadband H3 Hexagon GeoPackage"},
            {"file_id": 4, "state": "CA", "provider_id": "130403", "technology_type": "Mobile Voice", "description": "Mobile Voice H3 Hexagon GeoPackage"},
            {"file_id": 5, "state": "NV", "provider_id": "130077", "technology": 500, "mindown": 7, "minup": 1, "description": "Mobile Broadband H3 Hexagon GeoPackage"},
        ]
        selected = fcc_mobile.select_mobile_sources(rows, "CA")
        self.assertEqual([fcc_mobile.row_file_id(x) for x in selected["att"]], ["2", "6"])
        self.assertEqual({x["_takrig_variant"] for x in selected["att"]}, {"5g_7_1", "5g_35_3"})
        self.assertTrue(all(x["_takrig_class"] == "5g" for x in selected["att"]))
        self.assertEqual(selected["verizon"][0]["_takrig_class"], "lte")
        self.assertEqual(selected["tmobile"][0]["_takrig_class"], "voice")

    def test_major_carrier_legal_entity_aliases_resolve_for_h3(self):
        rows = [
            {"file_id": 11, "state": "CA", "provider_name": "New Cingular Wireless PCS, LLC", "technology": 400, "description": "Mobile Broadband H3 Hexagon GeoPackage"},
            {"file_id": 12, "state": "CA", "provider_name": "Cellco Partnership", "technology": 500, "mindown": 7, "minup": 1, "description": "Mobile Broadband H3 Hexagon GeoPackage"},
            {"file_id": 13, "state": "CA", "provider_name": "T-Mobile USA, Inc.", "technology": 500, "mindown": 35, "minup": 3, "description": "Mobile Broadband H3 Hexagon GeoPackage"},
        ]
        selected = fcc_mobile.select_mobile_sources(rows, "CA")
        self.assertEqual([fcc_mobile.row_file_id(x) for x in selected["att"]], ["11"])
        self.assertEqual([fcc_mobile.row_file_id(x) for x in selected["verizon"]], ["12"])
        self.assertEqual([fcc_mobile.row_file_id(x) for x in selected["tmobile"]], ["13"])

    def test_as_of_dates_ignore_challenge_only_rows(self):
        client = object.__new__(fcc_mobile.BdcClient)
        client.request_json = lambda *a, **k: {"data": [
            {"data_type": "availability", "as_of_date": "2025-12-31 00:00:00"},
            {"data_type": "challenge", "as_of_date": "2026-07-01 00:00:00"},
            {"data_type": "availability", "as_of_date": "2026-06-30 00:00:00"},
        ]}
        self.assertEqual(client.list_as_of_dates(), ["2025-12-31", "2026-06-30"])

    def test_inspector_accepts_voice_without_technology_field(self):
        path = self.tmp / official_name("att", "voice")
        create_h3_gpkg(path, "att", "voice", H3_CELLS[:2])
        info = cellular.inspect_h3_gpkg(path, path.name, "CA")
        self.assertEqual(info["carrier"], "att")
        self.assertEqual(info["source_class"], "voice")
        self.assertEqual(info["as_of"], "2025-12-31")
        self.assertEqual(info["h3_resolution"], 9)
        self.assertEqual(info["env1_count"], 2)
        self.assertEqual(info["provider_id"], "130077")

    def test_inspector_can_use_provider_id_from_official_filename(self):
        path = self.tmp / official_name("verizon", "lte")
        create_h3_gpkg(path, "verizon", "lte", H3_CELLS[:2], include_provider=False)
        info = cellular.inspect_h3_gpkg(path, path.name, "CA")
        self.assertEqual(info["carrier"], "verizon")
        self.assertEqual(info["provider_id"], "131425")
        self.assertEqual(info["source_class"], "lte")

    def test_inspector_rejects_raw_non_h3_and_wrong_crs(self):
        raw = self.tmp / "bdc_06_130077_MobileVoice_mobile_voice_D25.gpkg"
        conn = sqlite3.connect(raw)
        conn.execute("CREATE TABLE gpkg_contents(table_name TEXT,data_type TEXT,min_x REAL,min_y REAL,max_x REAL,max_y REAL)")
        conn.execute("CREATE TABLE x(fid INTEGER, geom BLOB, environmnt INTEGER, providerid TEXT, brandname TEXT)")
        conn.execute("INSERT INTO gpkg_contents VALUES('x','features',-124,32,-114,42)")
        conn.execute("INSERT INTO x VALUES(1,NULL,1,'130077','AT&T')"); conn.commit(); conn.close()
        with self.assertRaisesRegex(ValueError, "Hexagon Coverage"):
            cellular.inspect_h3_gpkg(raw, raw.name, "CA")
        wrong = self.tmp / official_name("att", "lte")
        create_h3_gpkg(wrong, "att", "lte", H3_CELLS[:1], as_srs=3857)
        with self.assertRaisesRegex(ValueError, "EPSG:4326"):
            cellular.inspect_h3_gpkg(wrong, wrong.name, "CA")

    def test_import_respects_selected_carrier_checkboxes(self):
        cellular.save_carrier_selection(self.cfg, "CA", ["att"])
        path = self.tmp / official_name("verizon", "lte")
        create_h3_gpkg(path, "verizon", "lte", H3_CELLS[:1])
        with self.assertRaisesRegex(ValueError, "not selected"):
            cellular.import_uploaded(self.cfg, "CA", path, path.name)
        self.assertEqual(cellular.source_inventory_summary(self.cfg, "CA")["records"], [])

    def test_inventory_requires_both_5g_tiers_but_not_3g(self):
        cellular.save_carrier_selection(self.cfg, "CA", ["att"])
        self._import("att", "voice", H3_CELLS[:2])
        self._import("att", "lte", H3_CELLS[:2])
        inv = cellular.source_inventory_summary(self.cfg, "CA")
        self.assertFalse(inv["ready_to_build"])
        self.assertEqual(inv["carrier_status"]["att"]["required_missing"], ["5g_35_3", "5g_7_1"])
        self._import("att", "5g_35_3", H3_CELLS[1:3])
        inv = cellular.source_inventory_summary(self.cfg, "CA")
        self.assertFalse(inv["ready_to_build"])
        self.assertEqual(inv["carrier_status"]["att"]["required_missing"], ["5g_7_1"])
        self._import("att", "5g_7_1", H3_CELLS[:2])
        inv = cellular.source_inventory_summary(self.cfg, "CA")
        self.assertTrue(inv["ready_to_build"])
        self.assertEqual(set(inv["carrier_status"]["att"]["variants"]), {"voice","lte","5g_7_1","5g_35_3"})
        self.assertTrue(inv["carrier_status"]["att"]["optional_3g_missing"])

    def test_inventory_never_mixes_fcc_vintages(self):
        cellular.save_carrier_selection(self.cfg, "CA", ["att"])
        for klass in ("voice", "lte", "5g_7_1", "5g_35_3"):
            self._import("att", klass, H3_CELLS[:2], vintage="D25")
        self._import("att", "voice", H3_CELLS[:2], vintage="J26")
        inv = cellular.source_inventory_summary(self.cfg, "CA")
        self.assertTrue(inv["ready_to_build"])
        self.assertEqual(inv["active_as_of"], "2025-12-31")
        self.assertIn("2026-06-30", inv["other_vintages"])
        # Completing the newer vintage moves the active coherent source set forward.
        for klass in ("lte", "5g_7_1", "5g_35_3"):
            self._import("att", klass, H3_CELLS[:2], vintage="J26")
        inv2 = cellular.source_inventory_summary(self.cfg, "CA")
        self.assertEqual(inv2["active_as_of"], "2026-06-30")

    def test_reimport_replaces_same_logical_provider_class_vintage(self):
        cellular.save_carrier_selection(self.cfg, "CA", ["att"])
        self._import("att", "lte", H3_CELLS[:2])
        first = cellular.source_inventory_summary(self.cfg, "CA")["records"]
        self.assertEqual(len(first), 1)
        self._import("att", "lte", H3_CELLS[:3])
        second = cellular.source_inventory_summary(self.cfg, "CA")["records"]
        self.assertEqual(len(second), 1)
        self.assertNotEqual(first[0]["sha256"], second[0]["sha256"])

    def test_h3_parent_and_unsigned_ids_are_supported(self):
        idx = int(H3_CELLS[0], 16)
        self.assertLess(idx, 2**63)  # FCC H3 indexes fit safely in SQLite signed INTEGER
        self.assertEqual(cellular.h3_resolution_int(idx), 9)
        parent = cellular.h3_parent_int(idx, 6)
        self.assertEqual(f"{parent:x}", "862800487ffffff")

    def test_build_packages_compact_h3_and_precedence_atomically(self):
        self._complete_sources()
        desc = cellular.build(self.cfg, "CA", force=True)
        pkg = cellular.roots(self.cfg)["ready"] / desc["package"]
        self.assertTrue(pkg.is_file())
        self.assertEqual(desc["format"], "takrig.cellular.region.v2")
        self.assertEqual(desc["binary_schema"], "takrig.cellular.h3.v1")
        self.assertEqual(desc["fcc_as_of"], "2025-12-31")
        self.assertEqual(desc["classes"], ["voice_3g", "lte", "5g"])
        self.assertEqual(desc["sha256"], fcc_mobile.sha256_file(pkg))
        self.assertEqual(desc["cell_count"], 5)
        for carrier in cellular.CARRIERS:
            self.assertEqual(desc["class_counts"][carrier], {"voice_3g": 1, "lte": 1, "5g": 3})
        with zipfile.ZipFile(pkg) as zf:
            self.assertEqual(set(zf.namelist()), {"manifest.json", "coverage.h3"})
            manifest = json.loads(zf.read("manifest.json"))
            self.assertEqual(manifest["environment"], "in_vehicle")
            self.assertEqual(manifest["class_precedence"], ["5g", "lte", "voice_3g"])
            self.assertEqual(manifest["coverage_byte"]["bits_per_carrier"], 2)
            self.assertEqual(manifest["coverage_byte"]["carrier_order"], ["att", "verizon", "tmobile"])
            target = self.tmp / "coverage.h3"
            target.write_bytes(zf.read("coverage.h3"))
        verification = cellular.verify_h3_binary(target, full=True)
        self.assertEqual(verification["cell_count"], 5)
        rows = decode_h3_binary(target)
        by_h3 = {f"{h:x}": cov for h, cov in rows}
        # Same source pattern for all three carriers: A=Voice/3G, B=LTE, C/D/E=5G.
        self.assertEqual(by_h3[H3_CELLS[0]], 21)  # 01 01 01
        self.assertEqual(by_h3[H3_CELLS[1]], 42)  # 10 10 10
        for h in H3_CELLS[2:]:
            self.assertEqual(by_h3[h], 63)        # 11 11 11

    def test_manual_and_api_acquisition_converge_to_identical_h3_payload(self):
        self._complete_sources(self.cfg, "manual")
        manual = cellular.build(self.cfg, "CA", force=True)
        manual_pkg = cellular.roots(self.cfg)["ready"] / manual["package"]
        manual_h3 = unzip_member(manual_pkg, "coverage.h3", self.tmp / "manual.h3")

        cfg2 = self.tmp / "api-config.json"
        cfg2.write_text(json.dumps({
            "state_root": str(self.tmp / "api-state"), "log_root": str(self.tmp / "api-log"),
            "fcc_bdc_credentials_file": str(self.cred), "cellular_h3_chunk_resolution": 6,
            "minimum_free_disk_gib": 5.0,
        }), encoding="utf-8")
        cellular.ensure_roots(cfg2)
        self._complete_sources(cfg2, "api")
        api = cellular.build(cfg2, "CA", force=True)
        api_pkg = cellular.roots(cfg2)["ready"] / api["package"]
        api_h3 = unzip_member(api_pkg, "coverage.h3", self.tmp / "api.h3")
        self.assertEqual(fcc_mobile.sha256_file(manual_h3), fcc_mobile.sha256_file(api_h3))

    def test_both_5g_tiers_are_retained_and_unioned(self):
        cellular.save_carrier_selection(self.cfg, "CA", ["tmobile"])
        self._import("tmobile", "voice", [H3_CELLS[0]])
        self._import("tmobile", "lte", [H3_CELLS[1]])
        self._import("tmobile", "5g_7_1", [H3_CELLS[2], H3_CELLS[3]])
        self._import("tmobile", "5g_35_3", [H3_CELLS[3], H3_CELLS[4]])
        inv=cellular.source_inventory_summary(self.cfg,"CA")
        fiveg=[r for r in inv["records"] if r["carrier"]=="tmobile" and r["source_class"]=="5g"]
        self.assertEqual({r["source_variant"] for r in fiveg},{"5g_7_1","5g_35_3"})
        desc=cellular.build(self.cfg,"CA",force=True)
        self.assertEqual(desc["class_counts"]["tmobile"]["5g"],3)
        self.assertEqual(set(desc["source_requirements"]["five_g_union"]),{"5g_7_1","5g_35_3"})

    def test_legacy_r13_35_3_inventory_is_migrated_without_reimport(self):
        cellular.save_carrier_selection(self.cfg,"CA",["tmobile"])
        self._import("tmobile","5g_35_3",H3_CELLS[:2])
        inv_path=cellular.inventory_path(self.cfg,"CA")
        raw=json.loads(inv_path.read_text())
        raw["records"][0].pop("source_variant",None)
        cellular.atomic_json(inv_path,raw)
        inv=cellular.source_inventory_summary(self.cfg,"CA")
        self.assertEqual(inv["records"][0]["source_variant"],"5g_35_3")

    def test_failed_new_build_preserves_previous_ready(self):
        ready = cellular.roots(self.cfg)["ready"]
        old = ready / "takrig-cellular-ca-old.zip"; old.write_bytes(b"old-ready")
        cellular.atomic_json(cellular.descriptor_path(self.cfg, "CA"), {
            "package": old.name, "state_code": "CA", "source_fingerprint": "old",
            "revision": "old", "size_bytes": old.stat().st_size,
        })
        self._complete_sources()
        with patch.object(cellular, "normalize_sources", side_effect=RuntimeError("synthetic failure")):
            with self.assertRaisesRegex(RuntimeError, "synthetic failure"):
                cellular.build(self.cfg, "CA", force=True)
        self.assertTrue(old.is_file())
        self.assertEqual(cellular.ready_descriptor(self.cfg, "CA")["revision"], "old")

    def test_check_without_api_credentials_is_not_failed(self):
        self.cred.write_text("", encoding="utf-8")
        row = cellular.check(self.cfg, "CA")
        self.assertEqual(row["status"], "no_sources")
        self.assertNotEqual(row["status"], "failed")
        self.assertIn("manual", row["detail"].lower())

    def test_catalog_and_http_range_expose_cellular_independently(self):
        cfg = manager.ManagerConfig(self.cfg); cfg.ensure()
        ready = cellular.roots(self.cfg)["ready"]
        pkg = ready / "takrig-cellular-ca-test.zip"; payload = b"cellular-0123456789"; pkg.write_bytes(payload)
        cellular.atomic_json(cellular.descriptor_path(self.cfg, "CA"), {
            "package": pkg.name, "state_code": "CA", "state_name": "California",
            "format": cellular.PACKAGE_FORMAT, "revision": "cell-r1", "size_bytes": len(payload),
            "fcc_as_of": "2025-12-31", "carriers": ["att", "verizon", "tmobile"],
            "classes": ["voice_3g", "lte", "5g"], "binary": {"schema": cellular.BINARY_SCHEMA},
        })
        catalog = manager.public_catalog(cfg)
        self.assertEqual(len(catalog["cellular_packages"]), 1)
        self.assertEqual(catalog["cellular_packages"][0]["download_url"], "/api/v1/cellular/CA/download")
        server = manager.ThreadingHTTPServer(("127.0.0.1", 0), manager.WebHandler); server.cfg = cfg
        t = threading.Thread(target=server.serve_forever, daemon=True); t.start()
        try:
            req = urllib.request.Request(
                f"http://127.0.0.1:{server.server_address[1]}/api/v1/cellular/CA/download",
                headers={"Range": "bytes=3-10", "If-Range": '"cell-r1"'},
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                self.assertEqual(resp.status, 206)
                self.assertEqual(resp.read(), payload[3:11])
        finally:
            server.shutdown(); server.server_close(); t.join(timeout=2)

    def test_manual_http_put_import_streams_to_inventory(self):
        cfg = manager.ManagerConfig(self.cfg); cfg.ensure()
        cellular.save_carrier_selection(self.cfg, "CA", ["att"])
        src = self.tmp / official_name("att", "voice")
        create_h3_gpkg(src, "att", "voice", H3_CELLS[:2])
        data = src.read_bytes()
        server = manager.ThreadingHTTPServer(("127.0.0.1", 0), manager.WebHandler); server.cfg = cfg
        t = threading.Thread(target=server.serve_forever, daemon=True); t.start()
        try:
            url = f"http://127.0.0.1:{server.server_address[1]}/api/v1/states/CA/cellular/import?filename={urllib.request.quote(src.name)}"
            req = urllib.request.Request(url, data=data, method="PUT", headers={"Content-Type": "application/octet-stream"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                body = json.loads(resp.read())
                self.assertEqual(resp.status, 201)
                self.assertTrue(body["ok"])
            inv = cellular.source_inventory_summary(self.cfg, "CA")
            self.assertEqual(len(inv["records"]), 1)
            self.assertEqual(inv["records"][0]["source_class"], "voice")
            # Upload staging .part files are not retained after successful import.
            self.assertFalse(list((cellular.roots(self.cfg)["imports"] / "ca").glob("*.part")))
        finally:
            server.shutdown(); server.server_close(); t.join(timeout=2)

    def test_web_has_state_integrated_carrier_controls_and_routing_revision_unchanged(self):
        web = (HERE / "web" / "index.html").read_text(encoding="utf-8")
        self.assertNotIn('id="cellularSection"', web)
        self.assertNotIn('id="cellularCards"', web)
        self.assertIn('package-data-card cell', web)
        self.assertIn('pkg-cell-controls', web)
        self.assertIn('pkg-cell-carrier-grid', web)
        self.assertIn('IMPORT FCC DATA', web)
        self.assertIn('ACQUIRE FCC DATA', web)
        self.assertIn('FCC API SETTINGS', web)
        self.assertIn("['att','verizon','tmobile']", web)
        self.assertIn('data-cell-carrier', web)
        self.assertNotIn('data-cell-tech', web)
        self.assertIn('/cellular/import?filename=', web)
        self.assertIn('/cellular/api/', web)
        self.assertIn('5G 7/1', web)
        self.assertIn('5G 35/3', web)
        self.assertEqual(manager.VERSION, "0.2.0-r16-r29")
        self.assertEqual(manager.ROUTING_PIPELINE_REVISION, "0.2.0-r16")
        self.assertEqual(cellular.PACKAGE_FORMAT, "takrig.cellular.region.v2")
        self.assertEqual(cellular.BINARY_SCHEMA, "takrig.cellular.h3.v1")


if __name__ == "__main__":
    unittest.main()
