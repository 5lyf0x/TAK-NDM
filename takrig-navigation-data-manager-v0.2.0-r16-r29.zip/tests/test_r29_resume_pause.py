"""Release R29 controls and terrain recovery regression tests."""
import json
import sys
import tempfile
import threading
import unittest
import urllib.request
from pathlib import Path
from unittest import mock
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
import job_control,terrain,cellular,manager,processor

class R29PauseRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.cfg=self.root/'config.json'
        self.cfg.write_text(json.dumps({'state_root':str(self.root/'state'),'log_root':str(self.root/'logs'), 'terrain_resolution_m':30,'selected_states':['CA']}))

    def test_per_domain_and_per_state_flags_are_independent_durable(self):
        p=job_control.pause(self.cfg,'terrain','CA')
        self.assertEqual(p['phase'],'pausing')
        self.assertFalse(job_control.requested(self.cfg,'cellular','CA'))
        self.assertFalse(job_control.requested(self.cfg,'terrain','NV'))
        job_control.pause(self.cfg,'navigation','CA',idle=True)
        with self.assertRaises(job_control.JobPaused): job_control.checkpoint(self.cfg,'terrain','CA')
        self.assertEqual(job_control.display(self.cfg,'terrain','CA'),'paused')
        self.assertTrue(job_control.resume(self.cfg,'terrain','CA'))
        job_control.checkpoint(self.cfg,'terrain','CA')
        self.assertTrue(job_control.requested(self.cfg,'navigation','CA'))
        self.assertFalse(job_control.resume(self.cfg,'terrain','CA'))

    def test_failed_90m_package_does_not_short_circuit_30m_build(self):
        ready=terrain.roots(self.cfg)['ready'];ready.mkdir(parents=True)
        package=terrain.package_path(self.cfg,'CA');package.write_bytes(b'OLD')
        terrain.atomic_json(terrain.descriptor_path(self.cfg,'CA'),{'package':package.name,'nominal_resolution_m':90})
        with mock.patch.object(terrain,'fetch_geofabrik_boundary',side_effect=RuntimeError('BOUNDARY_REACHED')):
            with self.assertRaisesRegex(RuntimeError,'BOUNDARY_REACHED'):
                terrain.build(self.cfg,'CA')
        self.assertEqual(package.read_bytes(),b'OLD')

    def test_stale_queue_becomes_interrupted_without_deletion(self):
        terrain._update_status(self.cfg,'CA','queued','queued','Old queue',progress={'completed':144,'total':372,'percent':38})
        row=terrain.read_json(terrain.status_path(self.cfg,'CA'),{})
        row['updated_utc']='2020-01-01T00:00:00Z'
        terrain.atomic_json(terrain.status_path(self.cfg,'CA'),row)
        result=terrain.status_summary(self.cfg,'CA')
        self.assertEqual(result['status'],'interrupted')
        self.assertEqual(result['progress']['completed'],144)

    def test_new_queue_drops_previous_error_and_stale_pid(self):
        terrain._update_status(self.cfg,'CA','failed','failed','upstream error',error='502')
        terrain._update_status(self.cfg,'CA','queued','queued','Retry queued')
        row=terrain.status_summary(self.cfg,'CA')
        self.assertEqual(row['status'],'queued')
        self.assertNotIn('error',row)
        self.assertNotIn('pid',row)

    def test_existing_downloaded_cells_untouched_by_pause(self):
        work=terrain.roots(self.cfg)['work']/'ca';work.mkdir(parents=True)
        saved=work/'terrain.sqlite';saved.write_bytes(b'checkpointed SQLite placeholder')
        job_control.pause(self.cfg,'terrain','CA')
        with self.assertRaises(job_control.JobPaused): terrain.build(self.cfg,'CA')
        self.assertEqual(saved.read_bytes(),b'checkpointed SQLite placeholder')

    def test_navigation_status_and_cellular_status_show_independent_pause(self):
        cfg=manager.ManagerConfig(self.cfg);cfg.ensure()
        job_control.pause(self.cfg,'navigation','CA',idle=True)
        self.assertEqual(manager.state_status(cfg,'CA')['status'],'paused')
        self.assertNotEqual(cellular.status_summary(self.cfg,'CA')['status'],'paused')
        job_control.pause(self.cfg,'cellular','CA',idle=True)
        self.assertEqual(cellular.status_summary(self.cfg,'CA')['status'],'paused')

    def test_post_pause_resume_http_does_not_start_duplicate_terrain_job(self):
        cfg=manager.ManagerConfig(self.cfg);cfg.ensure()
        terrain._update_status(self.cfg,'CA','building','downloading_3dep','running',pid=12345)
        server=manager.ThreadingHTTPServer(('127.0.0.1',0),manager.WebHandler)
        server.cfg=cfg
        th=threading.Thread(target=server.serve_forever,daemon=True);th.start()
        try:
            base=f'http://127.0.0.1:{server.server_address[1]}'
            def post(path):
                with urllib.request.urlopen(urllib.request.Request(base+path,data=b'',method='POST'),timeout=6) as response:
                    return json.loads(response.read())
            with mock.patch.object(terrain,'_matching_process',return_value=True):
                pause=post('/api/v1/states/CA/terrain/pause')
            self.assertTrue(pause['ok'])
            self.assertTrue(job_control.requested(self.cfg,'terrain','CA'))
            with mock.patch.object(manager,'spawn_terrain_build',return_value=True) as spawn:
                resume=post('/api/v1/states/CA/terrain/resume')
                self.assertTrue(resume['ok'])
                spawn.assert_called_once()
            self.assertFalse(job_control.requested(self.cfg,'terrain','CA'))
        finally:
            server.shutdown();server.server_close();th.join(timeout=5)

    def test_web_has_pause_resume_buttons_and_four_worker_progress(self):
        html=(HERE/'web'/'index.html').read_text()
        self.assertEqual(html.count('pauseResumeButton(st,active,'),3)
        self.assertIn('data-pause-domain',html)
        self.assertIn('grid-template-columns:minmax(0,1fr) minmax(0,1fr)',html)
        self.assertEqual(terrain.TERRAIN_DOWNLOAD_WORKERS,4)

if __name__=='__main__':unittest.main()
