#!/usr/bin/env python3
import http.client
import json
import shutil
import sys
import tempfile
import threading
import unittest
import unittest.mock
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / "src"))

import cellular
import manager
import terrain


class R23PackageStatusWebTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="takrig-r23-web-test-"))
        self.cfg_path = self.tmp / "config.json"
        self.cfg_path.write_text(json.dumps({
            "state_root": str(self.tmp / "state"),
            "log_root": str(self.tmp / "logs"),
            "selected_states": [],
        }), encoding="utf-8")
        self.cfg = manager.ManagerConfig(self.cfg_path)
        self.cfg.ensure()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_r23_display_version_preserves_r16_routing_revision(self):
        web = (HERE / "web" / "index.html").read_text(encoding="utf-8")
        self.assertEqual(manager.VERSION, "0.2.0-r16-r29")
        self.assertIn("c.acquisition_error&&!active", web)
        self.assertEqual(manager.ROUTING_PIPELINE_REVISION, "0.2.0-r16")

    def test_r23_outdoors_web_runtime_and_api_are_removed(self):
        web = (HERE / "web" / "index.html").read_text(encoding="utf-8")
        source = (HERE / "src" / "manager.py").read_text(encoding="utf-8")
        installer = (HERE / "install.sh").read_text(encoding="utf-8")
        self.assertNotIn("Outdoors Map Creator", web)
        self.assertNotIn("/api/v1/outdoors/", web)
        self.assertNotIn("leaflet", web.lower())
        self.assertNotIn("import outdoors", source)
        self.assertNotIn("/api/v1/outdoors/", source)
        self.assertEqual(manager.WEB_VENDOR_ASSETS, {})
        self.assertNotIn("LEAFLET_VERSION", installer)
        self.assertNotIn("src/outdoors.py", installer)
        self.assertIn('preserving /var/lib/takrig-routing/outdoors data', installer)

    def test_r23_package_status_has_three_downloadable_data_cards(self):
        web = (HERE / "web" / "index.html").read_text(encoding="utf-8")
        for text in ("Navigation Data", "Elevation Data", "Cell Coverage"):
            self.assertIn(text, web)
        self.assertIn('/api/v1/packages/${s.state_code}/download', web)
        self.assertIn('/api/v1/terrain/${s.state_code}/download', web)
        self.assertIn('/api/v1/cellular/${s.state_code}/download', web)
        self.assertIn('Existing verified package remains downloadable.', web)
        for state in ("NOT BUILT", "QUEUED", "UPDATE AVAILABLE", "UPDATE FAILED", "NO SOURCES", "SOURCES INCOMPLETE"):
            self.assertIn(state, web)
        self.assertIn("package-data-cards", web)
        self.assertIn("package-maint", web)
        # r21 formatting contract: spacious identifiers, stable card/action geometry, and wider desktop canvas.
        self.assertIn("grid-template-columns:48px minmax(0,1fr) auto", web)
        self.assertIn("width:44px;height:44px", web)
        self.assertIn("min-height:142px;display:flex;flex-direction:column", web)
        self.assertIn("grid-template-columns:minmax(0,1fr) minmax(0,1fr)", web)
        self.assertIn("min-height:40px", web)
        self.assertIn("font-size:11px;font-weight:900", web)
        self.assertIn("main{max-width:1600px", web)
        self.assertIn("text-overflow:ellipsis", web)

    def test_r23_download_routes_serve_navigation_elevation_and_cellular(self):
        # Navigation ready package/descriptor.
        nav_pkg = self.cfg.ready / "takrig-nav-ca-test.zip"
        nav_pkg.write_bytes(b"PK-nav-test")
        manager.atomic_json(Path(str(nav_pkg) + ".json"), {
            "region_id": "ca", "state_code": "CA", "package": nav_pkg.name,
            "size_bytes": nav_pkg.stat().st_size, "revision": "nav-r1", "created_utc": "2026-10-07T00:00:00Z",
        })

        # Elevation ready package/descriptor.
        tr = terrain.roots(self.cfg_path)
        terrain.ensure_roots(tr)
        elev_pkg = tr["ready"] / "takrig-terrain-ca.zip"
        elev_pkg.write_bytes(b"PK-elevation-test")
        terrain.atomic_json(terrain.descriptor_path(self.cfg_path, "CA"), {
            "state_code": "CA", "package": elev_pkg.name,
            "size_bytes": elev_pkg.stat().st_size, "revision": "elev-r1", "created_utc": "2026-10-07T00:00:00Z",
        })

        # Cellular ready package/descriptor.
        cr = cellular.ensure_roots(self.cfg_path)
        cell_pkg = cr["ready"] / "takrig-cellular-ca-test.zip"
        cell_pkg.write_bytes(b"PK-cell-test")
        cellular.atomic_json(cellular.descriptor_path(self.cfg_path, "CA"), {
            "state_code": "CA", "package": cell_pkg.name,
            "size_bytes": cell_pkg.stat().st_size, "revision": "cell-r1", "built_utc": "2026-10-07T00:00:00Z",
        })

        server = manager.ThreadingHTTPServer(("127.0.0.1", 0), manager.WebHandler)
        server.cfg = self.cfg
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            for route, expected_name in (
                ("/api/v1/packages/CA/download", nav_pkg.name),
                ("/api/v1/terrain/CA/download", elev_pkg.name),
                ("/api/v1/cellular/CA/download", cell_pkg.name),
            ):
                conn = http.client.HTTPConnection("127.0.0.1", server.server_address[1], timeout=5)
                conn.request("GET", route)
                resp = conn.getresponse(); body = resp.read()
                self.assertEqual(resp.status, 200, route)
                self.assertEqual(resp.getheader("Content-Type"), "application/zip")
                self.assertIn(expected_name, resp.getheader("Content-Disposition") or "")
                self.assertTrue(body.startswith(b"PK-"))
                conn.close()
        finally:
            server.shutdown(); server.server_close(); thread.join(timeout=5)

    def test_r19_state_source_check_does_not_reload_and_discard_draft(self):
        web = (HERE / "web" / "index.html").read_text(encoding="utf-8")
        start = web.index("async function checkStateSource")
        end = web.index("async function saveStateSources", start)
        check_fn = web[start:end]
        self.assertNotIn("openStateSources(", check_fn)
        self.assertIn("sourceDraftDirty", web)
        self.assertIn("Save verification failed; source selections were not closed.", web)

    def test_r23_catalog_has_no_outdoors_product(self):
        catalog = manager.public_catalog(self.cfg)
        self.assertNotIn("outdoors_packages", catalog)
        status = manager.manager_status(self.cfg)
        self.assertNotIn("outdoors", status)

    def test_r23_fcc_credentials_are_gateway_wide_and_state_acquisition_reuses_them(self):
        web = (HERE / "web" / "index.html").read_text(encoding="utf-8")
        source = (HERE / "src" / "manager.py").read_text(encoding="utf-8")
        self.assertIn('FCC API SETTINGS', web)
        self.assertIn('FCC API Settings · All States', web)
        self.assertIn('credentials are gateway-wide', web)
        self.assertIn("fetch('/api/v1/cellular/api/status'", web)
        self.assertIn("fetch('/api/v1/cellular/api/releases'", web)
        self.assertIn('`/api/v1/cellular/api/${action}`', web)
        self.assertIn('`/api/v1/states/${cellApiCode}/cellular/api/acquire`', web)
        self.assertIn('ACQUIRE FCC DATA', web)
        self.assertIn('path == "/api/v1/cellular/api/status"', source)
        self.assertIn('path == "/api/v1/cellular/api/releases"', source)
        self.assertIn('mcell_api_global = re.fullmatch', source)
        self.assertIn('mcell_api_acquire = re.fullmatch', source)

        server = manager.ThreadingHTTPServer(("127.0.0.1", 0), manager.WebHandler)
        server.cfg = self.cfg
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            conn = http.client.HTTPConnection("127.0.0.1", server.server_address[1], timeout=5)
            conn.request("GET", "/api/v1/cellular/api/status")
            resp = conn.getresponse(); status = json.loads(resp.read())
            self.assertEqual(resp.status, 200)
            self.assertFalse(status["source_access"]["configured"])
            conn.close()

            with unittest.mock.patch.object(cellular, "test_api_credentials", return_value={"ok": True, "latest_as_of": "2026-06-30", "as_of_dates": ["2026-06-30"]}):
                body = json.dumps({"username": "operator@example.com", "token": "0123456789abcdef0123456789abcdef"})
                conn = http.client.HTTPConnection("127.0.0.1", server.server_address[1], timeout=5)
                conn.request("POST", "/api/v1/cellular/api/save", body=body, headers={"Content-Type": "application/json"})
                resp = conn.getresponse(); saved = json.loads(resp.read())
                self.assertEqual(resp.status, 200)
                self.assertTrue(saved["ok"])
                self.assertTrue(saved["result"]["configured"])
                conn.close()

            conn = http.client.HTTPConnection("127.0.0.1", server.server_address[1], timeout=5)
            conn.request("GET", "/api/v1/cellular/api/status")
            resp = conn.getresponse(); status = json.loads(resp.read())
            self.assertTrue(status["source_access"]["configured"])
            self.assertEqual(status["source_access"]["username"], "operator@example.com")
            conn.close()

            with unittest.mock.patch.object(manager, "spawn_cellular_action", return_value=True) as spawn:
                conn = http.client.HTTPConnection("127.0.0.1", server.server_address[1], timeout=5)
                conn.request("POST", "/api/v1/states/AZ/cellular/api/acquire", body=json.dumps({"as_of": "2026-06-30"}), headers={"Content-Type": "application/json"})
                resp = conn.getresponse(); acquired = json.loads(resp.read())
                self.assertEqual(resp.status, 202)
                self.assertTrue(acquired["ok"])
                spawn.assert_called_once_with(self.cfg, "AZ", "acquire", as_of="2026-06-30")
                conn.close()
        finally:
            server.shutdown(); server.server_close(); thread.join(timeout=5)


    def test_r25_cellular_interface_is_consolidated_into_state_rows(self):
        web = (HERE / "web" / "index.html").read_text(encoding="utf-8")
        self.assertNotIn('id="cellularSection"', web)
        self.assertNotIn('id="cellularCards"', web)
        self.assertIn('Cellular carrier selection, FCC acquisition, build/update/download, and source details now live in each state CELL card.', web)
        self.assertIn('id="cellApiGlobalStatus"', web)
        self.assertIn('id="cellApiSettings"', web)
        self.assertIn('pkg-cell-controls', web)
        self.assertIn('pkg-cell-carrier-grid', web)
        self.assertIn('pkg-cell-management', web)
        self.assertIn('data-cell-import', web)
        self.assertIn('data-cell-api', web)
        self.assertIn('data-cell-carrier', web)
        self.assertIn('data-cell-source-remove', web)
        self.assertIn('SOURCE DETAILS · ${records.length} FILES', web)
        self.assertIn("document.querySelectorAll('#packageRows [data-cell-import]')", web)
        self.assertIn("document.querySelectorAll('#packageRows [data-cell-api]')", web)
        self.assertIn("document.querySelectorAll('#packageRows [data-cell-carrier]')", web)

    def test_r23_package_status_state_name_is_more_prominent(self):
        web = (HERE / "web" / "index.html").read_text(encoding="utf-8")
        self.assertIn('.package-state-name{font-size:20px;font-weight:950', web)
        self.assertIn('.package-state-name small{display:inline-block', web)
        self.assertIn('font-size:11px;font-weight:900;color:#a7b5bc', web)

    def test_r23_long_summary_status_cannot_overlap_current_activity(self):
        web = (HERE / "web" / "index.html").read_text(encoding="utf-8")
        self.assertIn("grid-template-columns:minmax(210px,15%) minmax(150px,11%) minmax(420px,1fr) minmax(190px,16%) minmax(150px,13%)", web)
        self.assertIn(".package-summary .pill{max-width:100%;white-space:normal;text-align:center;line-height:1.15;overflow-wrap:anywhere}", web)
        self.assertIn("grid-template-columns:minmax(190px,20%) minmax(140px,15%) minmax(340px,1fr) minmax(180px,18%)", web)
        self.assertIn("grid-template-columns:minmax(180px,30%) minmax(130px,22%) minmax(260px,1fr)", web)


if __name__ == "__main__":
    unittest.main()
