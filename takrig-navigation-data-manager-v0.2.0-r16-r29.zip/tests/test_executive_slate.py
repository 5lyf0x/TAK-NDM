"""r27 Executive Slate filesystem/static-serving regression coverage."""
from pathlib import Path
from tempfile import TemporaryDirectory
import http.client
import json
import sys
import threading
import unittest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / 'src'))
import manager

class ExecutiveSlateTest(unittest.TestCase):
    def test_version_and_pipeline_identity(self):
        self.assertEqual(manager.VERSION, '0.2.0-r16-r29')
        self.assertEqual(manager.ROUTING_PIPELINE_REVISION, '0.2.0-r16')

    def test_fifty_state_images_are_valid_and_decor_is_local(self):
        imgs = HERE / 'web' / 'assets' / 'states'
        self.assertEqual({x.stem for x in imgs.glob('*.webp')}, set(manager.STATES))
        for path in imgs.glob('*.webp'):
            b = path.read_bytes()
            self.assertGreater(len(b), 10000, path.name)
            self.assertTrue(b.startswith(b'RIFF') and b[8:12] == b'WEBP', path.name)
        self.assertEqual({x.name for x in (HERE / 'web' / 'assets' / 'decor').glob('*.webp')}, {'nav.webp','elevation.webp'})

    def test_html_uses_live_backend_and_correct_hero_selection(self):
        html = (HERE / 'web' / 'index.html').read_text(encoding='utf8')
        for text in ('ndm-selected-state','ndm-executive-top','ndm-state-hero','ndm-activity-panel','ndm-package-panel',
                     'states.filter(s=>s.state_code===ndmActiveState)', 'assets/states/${code}.webp',
                     "fetch('/api/v1/status'", 'data-cellular', 'data-terrain', 'data-environment', 'data-cache',
                     'cellApiSettings', 'openStateSources'):
            self.assertIn(text, html)
        self.assertNotIn('2,463,228 H3',html)
        self.assertNotIn('Reason: OSM revision changed',html)
        self.assertIn('body[data-ndm-view=states]',html)

    def test_installer_deploys_images_without_deleting_user_state(self):
        sh = (HERE / 'install.sh').read_text(encoding='utf8')
        for t in ('web/assets/states','web/assets/decor','"$HERE"/web/assets/states/*.webp','"$HERE"/web/assets/decor/*.webp'):
            self.assertIn(t,sh)
        self.assertNotIn('rm -rf "$STATE_ROOT"',sh)

    def test_static_assets_safely_allowlisted_and_servable(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'config.json'
            p.write_text(json.dumps({'state_root':str(Path(d)/'state'),'log_root':str(Path(d)/'logs'),'selected_states':[]}))
            cfg=manager.ManagerConfig(p); cfg.ensure()
            server = manager.ThreadingHTTPServer(('127.0.0.1',0), manager.WebHandler)
            server.cfg=cfg
            thr=threading.Thread(target=server.serve_forever, daemon=True);thr.start()
            try:
                for route,code in [('/assets/states/CA.webp',200),('/assets/states/HI.webp',200),('/assets/states/MD.webp',200),('/assets/states/WY.webp',200),('/assets/decor/nav.webp',200),('/assets/decor/elevation.webp',200),('/assets/states/ZZ.webp',404),('/assets/decor/secret.webp',404),('/assets/states/CA.png',404)]:
                    conn=http.client.HTTPConnection('127.0.0.1',server.server_address[1],timeout=5)
                    conn.request('GET',route);r=conn.getresponse();body=r.read();self.assertEqual(r.status,code,route)
                    if code==200:
                        self.assertEqual(r.getheader('Content-Type'),'image/webp'); self.assertEqual(r.getheader('X-Content-Type-Options'),'nosniff'); self.assertEqual(body[:4],b'RIFF')
                    conn.close()
            finally:
                server.shutdown();server.server_close();thr.join(timeout=3)

if __name__ == '__main__':unittest.main()
