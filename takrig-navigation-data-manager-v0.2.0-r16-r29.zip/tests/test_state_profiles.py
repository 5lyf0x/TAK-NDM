import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import enrich
import manager
import sources
from state_profiles import WEST_EXPANSION_STATES


class StateProfileExpansionTests(unittest.TestCase):
    def test_all_21_requested_states_have_first_class_state_road_sources(self):
        self.assertEqual(len(WEST_EXPANSION_STATES), 21)
        self.assertNotIn("CA", WEST_EXPANSION_STATES)
        self.assertNotIn("AZ", WEST_EXPANSION_STATES)
        self.assertNotIn("UT", WEST_EXPANSION_STATES)
        for code in WEST_EXPANSION_STATES:
            specs = sources.all_available_specs_for_state(sources.STATES[code])
            roads = [s for s in specs if s.role == "public_road_authority"]
            self.assertTrue(roads, code)
            for spec in roads:
                self.assertTrue(spec.routable, (code, spec.source_id))
                self.assertTrue(spec.profile_revision, (code, spec.source_id))
                self.assertTrue(spec.layer_url.startswith("https://"), (code, spec.source_id))

    def test_existing_ca_az_ut_source_catalogs_are_not_replaced_by_expansion_profiles(self):
        ca = {s.source_id for s in sources.all_available_specs_for_state(sources.STATES["CA"])}
        az = {s.source_id for s in sources.all_available_specs_for_state(sources.STATES["AZ"])}
        ut = {s.source_id for s in sources.all_available_specs_for_state(sources.STATES["UT"])}
        self.assertIn("ca_dot_all_roads", ca)
        self.assertIn("ca_state_parks_routes", ca)
        self.assertIn("az_state_parks_trails", az)
        self.assertIn("ut_dot_roads", ut)
        self.assertIn("ut_trails_pathways", ut)
        self.assertFalse(any(s.startswith("ca_") for s in {x.source_id for c in WEST_EXPANSION_STATES for x in sources._road_profile_specs(c)}))

    def test_standard_preset_enables_new_state_road_sources(self):
        with tempfile.TemporaryDirectory() as td:
            cfg_path = Path(td) / "config.json"
            cfg_path.write_text(json.dumps({"state_root": str(Path(td)/"state"), "log_root": str(Path(td)/"log")}), encoding="utf-8")
            cfg = manager.ManagerConfig(cfg_path)
            tx = cfg.state_source_settings("TX")
            self.assertTrue(tx["sources"]["tx_dot_roadway_inventory"]["enabled"])
            self.assertEqual(tx["sources"]["tx_dot_roadway_inventory"]["profile_revision"], "tx-road-v1")

    def test_profile_revision_changes_only_profiled_state_fingerprint(self):
        with tempfile.TemporaryDirectory() as td:
            cfg_path = Path(td) / "config.json"
            cfg_path.write_text(json.dumps({"state_root": str(Path(td)/"state"), "log_root": str(Path(td)/"log")}), encoding="utf-8")
            cfg = manager.ManagerConfig(cfg_path)
            tx = cfg.state_source_settings("TX")
            base = manager.current_source_fingerprint(tx, "TX")
            altered = json.loads(json.dumps(tx))
            altered["sources"]["tx_dot_roadway_inventory"]["profile_revision"] = "tx-road-v2"
            self.assertNotEqual(base, manager.current_source_fingerprint(altered, "TX"))
            ca = cfg.state_source_settings("CA")
            self.assertFalse(any("profile_revision" in row for row in ca["sources"].values()))

    def test_alaska_uses_split_antimeridian_envelopes(self):
        class Dummy:
            bounds = (-179.0, 50.0, 179.0, 72.0)
        boxes = sources.state_query_bboxes(Dummy(), "AK")
        self.assertEqual(len(boxes), 2)
        self.assertTrue(all((b[2] - b[0]) < 60 for b in boxes))
        self.assertEqual(sources.state_query_bboxes(Dummy(), "TX"), [Dummy.bounds])

    def test_new_state_road_normalizer_rejects_nonpublic_and_maps_class(self):
        private = {"type":"Feature","geometry":{"type":"LineString","coordinates":[[0,0],[1,1]]},"properties":{"ACCESS":"Private"}}
        self.assertIsNone(sources.normalize_state_dot(private, "x", "X"))
        planned = {"type":"Feature","geometry":{"type":"LineString","coordinates":[[0,0],[1,1]]},"properties":{"ROAD_STATUS":"Proposed"}}
        self.assertIsNone(sources.normalize_state_dot(planned, "x", "X"))
        public = {"type":"Feature","geometry":{"type":"LineString","coordinates":[[0,0],[1,1]]},"properties":{"ROAD_NAME":"Main","FUNCTIONAL_CLASS":"Minor Arterial","SURFACE":"Gravel"}}
        out = sources.normalize_state_dot(public, "x", "X")
        self.assertTrue(out["properties"]["takrig_routable"])
        self.assertEqual(out["properties"]["takrig_highway"], "primary")
        self.assertEqual(out["properties"]["takrig_surface"], "Gravel")

    def test_streaming_arcgis_writer_and_enrichment_reader(self):
        page = {"type":"FeatureCollection","features":[
            {"type":"Feature","geometry":{"type":"LineString","coordinates":[[0,0],[1,1]]},"properties":{"OBJECTID":1}},
            {"type":"Feature","geometry":{"type":"LineString","coordinates":[[1,1],[2,2]]},"properties":{"OBJECTID":2}},
        ]}
        with tempfile.TemporaryDirectory() as td, \
             patch.object(sources, "arcgis_layer_info", return_value={"max_record_count":2000,"supports_pagination":True}), \
             patch.object(sources, "arcgis_query_page", return_value=page):
            target = Path(td)/"roads.geojsonl"
            meta = sources.arcgis_download("https://example.invalid/FeatureServer/0", target, stream_ndjson=True)
            self.assertEqual(meta["feature_count"], 2)
            rows = list(enrich.iter_source_features(target))
            self.assertEqual([r["properties"]["OBJECTID"] for r in rows], [1,2])

    def test_installer_deploys_state_profiles_module(self):
        install = (ROOT / "install.sh").read_text(encoding="utf-8")
        self.assertIn('src/state_profiles.py', install)
        self.assertIn('$INSTALL_ROOT/bin/state_profiles.py', install)

    def test_nonpagination_arcgis_layers_use_object_id_batches(self):
        rows = [
            {"type":"Feature","geometry":{"type":"LineString","coordinates":[[0,0],[1,1]]},"properties":{"OBJECTID":1}},
            {"type":"Feature","geometry":{"type":"LineString","coordinates":[[1,1],[2,2]]},"properties":{"OBJECTID":2}},
        ]
        with tempfile.TemporaryDirectory() as td, \
             patch.object(sources, "arcgis_layer_info", return_value={"max_record_count":1,"supports_pagination":False}), \
             patch.object(sources, "arcgis_query_ids", return_value=[1,2]), \
             patch.object(sources, "arcgis_query_object_ids", side_effect=[{"type":"FeatureCollection","features":[rows[0]]},{"type":"FeatureCollection","features":[rows[1]]}]) as q:
            target = Path(td)/"roads.geojsonl"
            meta = sources.arcgis_download("https://example.invalid/FeatureServer/0", target, stream_ndjson=True)
            self.assertEqual(meta["pagination_mode"], "object_ids")
            self.assertEqual(meta["feature_count"], 2)
            self.assertEqual(q.call_count, 2)


if __name__ == "__main__":
    unittest.main()
