#!/usr/bin/env python3
import json
import sqlite3
import struct
import sys
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
import io
import zipfile
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / "src"))

import terrain
import manager

POLY = """California
1
  -120.10 35.10
  -119.90 35.10
  -119.90 35.30
  -120.10 35.30
  -120.10 35.10
END
END
"""


class TerrainPackageTest(unittest.TestCase):
    def config(self, root: Path) -> Path:
        p = root / "config.json"
        p.write_text(json.dumps({"state_root": str(root / "state"), "log_root": str(root / "log"), "minimum_free_disk_gib": 5.0, "terrain_resolution_m": 90}), encoding="utf-8")
        b = root / "state" / "manager" / "sources" / "ca" / "state.poly"
        b.parent.mkdir(parents=True, exist_ok=True)
        b.write_text(POLY, encoding="utf-8")
        return p

    def test_builds_random_access_90m_package(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); cfg = self.config(root)
            raw = struct.pack("<h", 123) * (terrain.GRID_SIZE * terrain.GRID_SIZE)
            with mock.patch.object(terrain, "fetch_geofabrik_boundary", return_value={"bounds": []}), \
                 mock.patch.object(terrain, "_download_export", side_effect=lambda *a, **k: a[-1].write_bytes(b"FAKE-TIFF")), \
                 mock.patch.object(terrain, "_tiff_to_int16_raw", return_value=raw):
                desc = terrain.build(cfg, "CA", force=True)
            self.assertEqual(desc["format"], terrain.PACKAGE_FORMAT)
            self.assertEqual(desc["nominal_resolution_m"], 90)
            self.assertEqual(desc["sample_spacing_arcseconds"], 3.0)
            self.assertGreater(desc["tile_count"], 0)
            package = terrain.package_path(cfg, "CA")
            with zipfile.ZipFile(package) as zf:
                self.assertEqual(set(zf.namelist()), {"manifest.json", "terrain.sqlite"})
                dbpath = root / "terrain.sqlite"
                dbpath.write_bytes(zf.read("terrain.sqlite"))
            db = sqlite3.connect(dbpath)
            row = db.execute("SELECT rows,cols,encoding,length(data) FROM tiles LIMIT 1").fetchone()
            db.close()
            self.assertEqual(row[:3], (601, 601, "int16le+zlib"))
            self.assertGreater(row[3], 0)

    def test_status_and_remove_are_independent(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); cfg = self.config(root)
            self.assertEqual(terrain.status_summary(cfg, "CA")["status"], "not_built")
            terrain._update_status(cfg, "CA", "failed", "failed", "boom")
            self.assertEqual(terrain.status_summary(cfg, "CA")["status"], "failed")
            removed = terrain.remove(cfg, "CA")
            self.assertTrue(any("status" in p for p in removed))
            self.assertEqual(terrain.status_summary(cfg, "CA")["status"], "not_built")

    def test_terrain_download_supports_range_resume(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); cfg_path = self.config(root)
            cfg = manager.ManagerConfig(cfg_path); cfg.ensure()
            ready = terrain.roots(cfg_path)["ready"]; ready.mkdir(parents=True, exist_ok=True)
            payload = b"terrain-0123456789abcdefghijklmnopqrstuvwxyz"
            pkg = terrain.package_path(cfg_path, "CA"); pkg.write_bytes(payload)
            terrain.atomic_json(terrain.descriptor_path(cfg_path, "CA"), {
                "package": pkg.name, "state_code": "CA", "state_name": "California",
                "format": terrain.PACKAGE_FORMAT, "revision": "terrain-r1",
                "created_utc": "2026-08-12T00:00:00Z", "size_bytes": len(payload),
                "nominal_resolution_m": 90, "sample_spacing_arcseconds": 3.0,
            })
            server = manager.ThreadingHTTPServer(("127.0.0.1", 0), manager.WebHandler)
            server.cfg = cfg
            thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
            try:
                url = f"http://127.0.0.1:{server.server_address[1]}/api/v1/terrain/CA/download"
                req = urllib.request.Request(url, headers={"Range": "bytes=8-16", "If-Range": '"terrain-r1"'})
                with urllib.request.urlopen(req, timeout=5) as resp:
                    self.assertEqual(resp.status, 206)
                    self.assertEqual(resp.headers.get("ETag"), '"terrain-r1"')
                    self.assertEqual(resp.headers.get("Content-Range"), f"bytes 8-16/{len(payload)}")
                    self.assertEqual(resp.read(), payload[8:17])
            finally:
                server.shutdown(); server.server_close(); thread.join(timeout=5)

    def test_catalog_exposes_separate_terrain_package(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); cfg_path = self.config(root)
            cfg = manager.ManagerConfig(cfg_path); cfg.ensure()
            ready = terrain.roots(cfg_path)["ready"]; ready.mkdir(parents=True, exist_ok=True)
            pkg = terrain.package_path(cfg_path, "CA"); pkg.write_bytes(b"terrain")
            desc = {"package": pkg.name, "state_code": "CA", "state_name": "California", "format": terrain.PACKAGE_FORMAT,
                    "revision": "r1", "created_utc": "2026-08-12T00:00:00Z", "size_bytes": pkg.stat().st_size,
                    "nominal_resolution_m": 90, "sample_spacing_arcseconds": 3.0, "tile_span_degrees": 0.5, "tile_count": 10,
                    "source": {"name": terrain.SOURCE_NAME}}
            terrain.atomic_json(terrain.descriptor_path(cfg_path, "CA"), desc)
            catalog = manager.public_catalog(cfg)
            self.assertEqual(len(catalog["terrain_packages"]), 1)
            self.assertEqual(catalog["terrain_packages"][0]["download_url"], "/api/v1/terrain/CA/download")


    def test_export_grid_pixel_centers_align_to_stored_tile_nodes(self):
        west, south, east, north = -120.0, 35.0, -119.5, 35.5
        params = terrain._export_params(west, south, east, north)
        bbox = [float(x) for x in params["bbox"].split(",")]
        self.assertEqual(params["adjustAspectRatio"], "false")
        self.assertNotIn("returnSquarePixels", params)
        self.assertAlmostEqual(bbox[0], west - terrain.HALF_SAMPLE_DEG, places=9)
        self.assertAlmostEqual(bbox[2], east + terrain.HALF_SAMPLE_DEG, places=9)
        pixel_width = (bbox[2] - bbox[0]) / terrain.GRID_SIZE
        self.assertAlmostEqual(pixel_width, terrain.SAMPLE_DEG, places=9)
        self.assertAlmostEqual(bbox[0] + pixel_width / 2.0, west, places=9)
        self.assertAlmostEqual(bbox[2] - pixel_width / 2.0, east, places=9)

    def test_tiny_valid_raster_response_is_accepted(self):
        class Resp(io.BytesIO):
            status = 200
            headers = {"Content-Type": "image/tiff"}
            def __enter__(self): return self
            def __exit__(self, *args): self.close()
        with tempfile.TemporaryDirectory() as td:
            target = Path(td) / "tiny.tif"
            with mock.patch.object(urllib.request, "urlopen", return_value=Resp(b"TIFF")), \
                 mock.patch.object(terrain, "_validate_raster", return_value={"size": [1, 1]}):
                meta = terrain._download_export(-120, 35, -119.5, 35.5, target, attempts=1)
            self.assertEqual(target.read_bytes(), b"TIFF")
            self.assertEqual(meta["size_bytes"], 4)

    def test_invalid_non_raster_response_reports_cell_and_http_detail(self):
        class Resp(io.BytesIO):
            status = 200
            headers = {"Content-Type": "application/octet-stream"}
            def __enter__(self): return self
            def __exit__(self, *args): self.close()
        with tempfile.TemporaryDirectory() as td:
            target = Path(td) / "bad.tif"
            with mock.patch.object(urllib.request, "urlopen", return_value=Resp(b"not-a-raster")), \
                 mock.patch.object(terrain, "_validate_raster", side_effect=RuntimeError("not recognized by GDAL")):
                with self.assertRaisesRegex(terrain.RasterValidationError, r"bbox=-120\.0000,35\.0000,-119\.5000,35\.5000.*size=12 bytes.*GDAL"):
                    terrain._download_export(-120, 35, -119.5, 35.5, target, attempts=1)

    def test_transient_usgs_error_retries(self):
        class Resp(io.BytesIO):
            status = 200
            headers = {"Content-Type": "image/tiff"}
            def __enter__(self): return self
            def __exit__(self, *args): self.close()
        calls = [urllib.error.HTTPError("x", 503, "busy", {}, io.BytesIO(b"busy")), Resp(b"ok")]
        with tempfile.TemporaryDirectory() as td:
            target = Path(td) / "retry.tif"
            with mock.patch.object(urllib.request, "urlopen", side_effect=calls), \
                 mock.patch.object(terrain, "_validate_raster", return_value={"size": [1, 1]}), \
                 mock.patch.object(terrain.time, "sleep") as sleep:
                terrain._download_export(-120, 35, -119.5, 35.5, target, attempts=2)
            self.assertEqual(target.read_bytes(), b"ok")
            sleep.assert_called_once()

    def test_clear_previous_failure_on_queue_without_erasing_resumable_progress(self):
        with tempfile.TemporaryDirectory() as td:
            cfg=self.config(Path(td))
            terrain._update_status(cfg, "CA", "failed", "failed", "USGS 504",error="USGS 504",
                                   progress={"completed":96,"total":372,"percent":25})
            terrain._update_status(cfg, "CA", "queued", "queued", "Build queued")
            row=terrain.status_summary(cfg, "CA")
            self.assertEqual(row["status"],"queued")
            self.assertNotIn("error",row)
            self.assertEqual(row["progress"]["completed"],96)

    def test_adaptive_504_split_keeps_30m_sample_alignment(self):
        with tempfile.TemporaryDirectory() as td:
            target=Path(td)/"tile.tif"
            profile=terrain.TerrainProfile(30,1.0,1801)
            args=[]
            def fake_export(w,s,e,n,path,*,profile):
                args.append((w,s,e,n,path,profile))
                if len(args)==1:
                    raise terrain.TransientTerrainExportError(504,"upstream timeout")
                path.write_bytes(b"TIFF")
                return {"gdal":{"size":[901,901]}}
            with mock.patch.object(terrain,"_download_export",side_effect=fake_export):
                result=terrain._download_export_with_fallback(-122.5,34.0,-122.0,34.5,target,profile)
            self.assertEqual(len(result),4)
            self.assertEqual(len(args),5)
            self.assertTrue(all(a[-1].grid_size==901 for a in args[1:]))
            self.assertEqual([a[:4] for a in args[1:]],[
               (-122.5,34.0,-122.25,34.25), (-122.25,34.0,-122.0,34.25),
               (-122.5,34.25,-122.25,34.5), (-122.25,34.25,-122.0,34.5)])

    def test_adaptive_split_cleans_partials_on_failure(self):
        with tempfile.TemporaryDirectory() as td:
            target=Path(td)/"tile.tif"
            def fail_export(*args,**kwargs):
                if not target.parent.joinpath('tile.quarter0.tif').exists():
                    p=target.parent/'tile.quarter0.tif';p.write_bytes(b"TIFF")
                    raise terrain.TransientTerrainExportError(504,"timeout")
                raise RuntimeError("persistent failure")
            with mock.patch.object(terrain,"_download_export",side_effect=fail_export):
                with self.assertRaises(RuntimeError):
                    terrain._download_export_with_fallback(-122.5,34.0,-122.0,34.5,target,terrain.TerrainProfile(30,1,1801))
            self.assertFalse(any(Path(td).glob('*.quarter*.tif')))

    def test_all_nodata_cells_are_skipped_and_tile_count_is_stored_count(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); cfg = self.config(root)
            valid = struct.pack("<h", 123) * (terrain.GRID_SIZE * terrain.GRID_SIZE)
            nodata = struct.pack("<h", terrain.NODATA) * (terrain.GRID_SIZE * terrain.GRID_SIZE)
            calls = {"n": 0}
            def convert(*args, **kwargs):
                calls["n"] += 1
                return valid if calls["n"] == 1 else nodata
            with mock.patch.object(terrain, "fetch_geofabrik_boundary", return_value={}), \
                 mock.patch.object(terrain, "_download_export", side_effect=lambda *a, **k: a[-1].write_bytes(b"T")), \
                 mock.patch.object(terrain, "_tiff_to_int16_raw", side_effect=convert):
                desc = terrain.build(cfg, "CA", force=True)
            self.assertGreater(desc["candidate_tile_count"], desc["tile_count"])
            self.assertEqual(desc["tile_count"], 1)
            self.assertGreaterEqual(desc["skipped_nodata_tiles"], 1)

    def test_resume_after_mid_state_failure_keeps_committed_valid_tiles(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); cfg = self.config(root)
            raw = struct.pack("<h", 25) * (terrain.GRID_SIZE * terrain.GRID_SIZE)
            calls = []
            def first_download(w, s, e, n, target, *args, **kwargs):
                calls.append((w, s)); target.write_bytes(b"T")
                if len(calls) == 2: raise RuntimeError("temporary mid-build failure")
            with mock.patch.object(terrain, "fetch_geofabrik_boundary", return_value={}), \
                 mock.patch.object(terrain, "_download_export", side_effect=first_download), \
                 mock.patch.object(terrain, "_tiff_to_int16_raw", return_value=raw):
                with self.assertRaisesRegex(RuntimeError, "mid-build"):
                    terrain.build(cfg, "CA", force=True)
            db = sqlite3.connect(terrain.roots(cfg)["work"] / "ca" / "terrain.sqlite")
            committed = db.execute("SELECT count(*) FROM tiles").fetchone()[0]; db.close()
            self.assertEqual(committed, 1)
            second_calls = []
            def second_download(w, s, e, n, target, *args, **kwargs): second_calls.append((w, s)); target.write_bytes(b"T")
            with mock.patch.object(terrain, "fetch_geofabrik_boundary", return_value={}), \
                 mock.patch.object(terrain, "_download_export", side_effect=second_download), \
                 mock.patch.object(terrain, "_tiff_to_int16_raw", return_value=raw):
                desc = terrain.build(cfg, "CA", force=False)
            self.assertEqual(desc["tile_count"], 2)
            self.assertEqual(len(second_calls), 1)

    def test_decimal_tile_scratch_names_do_not_collide_and_are_cleaned(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); tiff = root / "in.tif"; tiff.write_bytes(b"T")
            raw0 = root / "-117.5_+32.0"; raw5 = root / "-117.5_+32.5"
            self.assertNotEqual(terrain._scratch_paths(raw0)[0], terrain._scratch_paths(raw5)[0])
            def fake_run(cmd, label):
                out = Path(cmd[-1]); out.write_bytes(struct.pack("<h", 7) * (terrain.GRID_SIZE * terrain.GRID_SIZE))
                out.with_suffix(".hdr").write_text("byte order = 0\n")
                return mock.Mock(returncode=0)
            with mock.patch.object(terrain.shutil, "which", return_value="/usr/bin/gdalwarp"), \
                 mock.patch.object(terrain, "_run_checked", side_effect=fake_run):
                data = terrain._tiff_to_int16_raw(tiff, raw5, -117.5, 32.5, -117.0, 33.0)
            self.assertEqual(len(data), terrain.GRID_SIZE * terrain.GRID_SIZE * 2)
            for pth in terrain._scratch_paths(raw5): self.assertFalse(pth.exists())

    def test_zero_meter_max_is_preserved(self):
        data = struct.pack("<hhh", -5, 0, terrain.NODATA)
        self.assertEqual(terrain._valid_min_max(data), (-5, 0))

    def test_duplicate_terrain_build_requests_are_deduplicated(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); cfg_path = self.config(root)
            cfg = manager.ManagerConfig(cfg_path); cfg.ensure()
            with mock.patch.object(manager.subprocess, "Popen", return_value=mock.Mock()):
                self.assertTrue(manager.spawn_terrain_build(cfg, "CA"))
                self.assertFalse(manager.spawn_terrain_build(cfg, "CA"))
            self.assertEqual(terrain.status_summary(cfg_path, "CA")["status"], "queued")

    def test_antimeridian_coverage_is_split_instead_of_world_spanning(self):
        boxes = terrain._coverage_boxes([(-180.0, 51.0, -179.5, 51.5), (179.5, 51.0, 180.0, 51.5), (-150.0, 60.0, -149.5, 60.5)])
        self.assertEqual(len(boxes), 2)
        self.assertTrue(all((b[2] - b[0]) < 60.0 for b in boxes))

    def test_antimeridian_export_bbox_is_clamped_to_valid_longitudes(self):
        west = terrain._expanded_export_bbox(-180.0, 51.0, -179.5, 51.5)
        east = terrain._expanded_export_bbox(179.5, 51.0, 180.0, 51.5)
        self.assertEqual(west[0], -180.0)
        self.assertEqual(east[2], 180.0)


if __name__ == "__main__":
    unittest.main()
