#!/usr/bin/env python3
import gzip
import json
import os
import shutil
import subprocess
import struct
import tarfile
import tempfile
import unittest
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
SRC = HERE / "src" / "processor.py"

class ProcessorIntegrationTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="takrig-routing-test-"))
        self.state = self.tmp / "state"
        self.logs = self.tmp / "logs"
        self.venv = self.tmp / "venv"
        bindir = self.venv / "bin"
        bindir.mkdir(parents=True)
        self.cfg = self.tmp / "config.json"
        self.cfg.write_text(json.dumps({
            "state_root": str(self.state),
            "log_root": str(self.logs),
            "venv_root": str(self.venv),
            "valhalla_package_dir": str(self.tmp / "fake-valhalla"),
            "valhalla_version": "3.6.3",
            "package_format": "takrig.valhalla.region.v1",
            "settle_seconds": 0,
            "jobs_per_scan": 1,
            "keep_source_after_success": False,
            "required_free_multiplier": 0.0,
            "required_free_min_gib": 0.0,
        }), encoding="utf-8")

        # Fake pyvalhalla layout matching the R3 direct-binary/config-script flow.
        fake_python = bindir / "python"
        fake_python.write_text("#!/usr/bin/env bash\nexec python3 \"$@\"\n", encoding="utf-8")
        fake_python.chmod(0o755)

        package_dir = self.tmp / "fake-valhalla"
        (package_dir / "bin").mkdir(parents=True)
        build_config = package_dir / "valhalla_build_config.py"
        build_config.write_text(r"""#!/usr/bin/env python3
import argparse, json, pathlib
p=argparse.ArgumentParser()
p.add_argument('--mjolnir-tile-dir', required=True)
p.add_argument('--mjolnir-tile-extract', required=True)
p.add_argument('-o','--output', required=True)
a=p.parse_args()
cfg={
 'mjolnir':{'tile_dir':a.mjolnir_tile_dir,'tile_extract':a.mjolnir_tile_extract,'logging':{'type':'std_out'}},
 'service_limits':{'auto':{}}, 'loki':{}, 'thor':{}, 'odin':{}
}
pathlib.Path(a.output).write_text(json.dumps(cfg))
""", encoding="utf-8")
        build_config.chmod(0o755)

        build_tiles = package_dir / "bin" / "valhalla_build_tiles"
        build_tiles.write_text(r"""#!/usr/bin/env python3
import json, pathlib, sys
args=sys.argv[1:]
c=pathlib.Path(args[args.index('-c')+1])
cfg=json.loads(c.read_text())
td=pathlib.Path(cfg['mjolnir']['tile_dir'])
tile=td/'2'/'000'/'001.gph'
tile.parent.mkdir(parents=True,exist_ok=True)
tile.write_bytes(b'X'*64 + b'fake graph tile data'*40)
""", encoding="utf-8")
        build_tiles.chmod(0o755)

        # Fake pyvalhalla + MVT decoder for graph-derived R9 NAV coverage.
        # The production processor runs inside its pyvalhalla venv; tests supply a
        # deterministic graph-MVT fixture without requiring native Valhalla.
        fake_py = self.tmp / "fake-py"
        (fake_py / "valhalla").mkdir(parents=True)
        (fake_py / "valhalla" / "__init__.py").write_text(r"""
import json
class Actor:
    def __init__(self, config): self.config = config
    def tile(self, req):
        feats = [
          {'type':'Feature','id':1,'geometry':{'type':'LineString','coordinates':[[200,200],[3800,3800]]},
           'properties':{'road_class':6,'use':0,'unpaved':False,'surface':1,'access:fwd':1,'access:bwd':1,'destonly':False}},
          {'type':'Feature','id':2,'geometry':{'type':'LineString','coordinates':[[300,3300],[3500,500]]},
           'properties':{'road_class':7,'use':3,'unpaved':True,'surface':4,'access:fwd':1,'access:bwd':0,'destonly':False}},
          {'type':'Feature','id':3,'geometry':{'type':'LineString','coordinates':[[1000,1000],[2000,2000]]},
           'properties':{'road_class':7,'use':24,'unpaved':True,'surface':6,'access:fwd':2,'access:bwd':2,'destonly':False}},
          {'type':'Feature','id':4,'geometry':{'type':'LineString','coordinates':[[1000,2000],[2000,2500]]},
           'properties':{'road_class':7,'use':3,'unpaved':True,'surface':7,'access:fwd':1,'access:bwd':1,'destonly':False}},
        ]
        return json.dumps({'edges':{'extent':4096,'version':2,'features':feats}}).encode()
""", encoding="utf-8")
        (fake_py / "mapbox_vector_tile.py").write_text(r"""
import json
def decode(tile, per_layer_options=None, default_options=None, **kwargs):
    return json.loads(tile.decode())
""", encoding="utf-8")
        (fake_py / "shutil.py").write_text(r"""
import importlib.util, pathlib, sysconfig
_path=pathlib.Path(sysconfig.get_path('stdlib'))/'shutil.py'
_spec=importlib.util.spec_from_file_location('_takrig_real_shutil',_path)
_real=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(_real)
for _name in dir(_real):
    if not _name.startswith('__'): globals()[_name]=getattr(_real,_name)
def disk_usage(path):
    row=_real.disk_usage(path)
    return _real._ntuple_diskusage(row.total,row.used,max(row.free,64*1024**3))
""", encoding="utf-8")
        self.fake_py = fake_py

        self.pbf = self.tmp / "sample.osm.pbf"
        self.pbf.write_bytes(b'OSM-PBF-TEST' * 1000)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def run_cli(self, *args):
        env = dict(os.environ)
        env["PYTHONPATH"] = str(self.fake_py) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
        return subprocess.run(
            [os.environ.get("PYTHON", "python3"), str(SRC), "--config", str(self.cfg), *args],
            text=True, capture_output=True, env=env,
        )

    def test_end_to_end_queue_build_package_catalog(self):
        p = self.run_cli("enqueue", str(self.pbf), "--name", "Test Region", "--region-id", "test-region", "--bounds", "[10.0,10.0,10.01,10.01]")
        self.assertEqual(p.returncode, 0, p.stderr)
        p = self.run_cli("scan")
        self.assertEqual(p.returncode, 0, p.stderr + p.stdout)
        ready = self.state / "ready"
        pkg = ready / "takrig-routing-test-region-valhalla-3.6.3.zip"
        self.assertTrue(pkg.is_file())
        self.assertFalse((ready / (pkg.name + ".sha256")).exists())
        self.assertTrue((ready / (pkg.name + ".json")).is_file())
        self.assertTrue((ready / "catalog.json").is_file())
        with zipfile.ZipFile(pkg) as zf:
            names=set(zf.namelist())
            self.assertTrue({'manifest.json','valhalla.json','valhalla_tiles.tar','routing_coverage/index.json'} <= names)
            coverage_tiles=[n for n in names if n.startswith('routing_coverage/11/') and n.endswith('.geojson.gz')]
            self.assertTrue(coverage_tiles)
            m=json.loads(zf.read('manifest.json'))
            self.assertEqual(m['format'],'takrig.valhalla.region.v1')
            self.assertEqual(m['valhalla_version'],'3.6.3')
            self.assertEqual(m['routing_coverage']['schema'], 'takrig.routing.coverage.v2')
            self.assertGreaterEqual(m['routing_coverage']['offroad_feature_count'], 1)
            vc=json.loads(zf.read('valhalla.json'))
            self.assertEqual(vc['mjolnir']['logging']['type'], 'std_out')
            self.assertIn('service_limits', vc)
            self.assertIn('auto', vc['service_limits'])
            self.assertTrue(vc['service_limits']['status']['allow_verbose'])
            self.assertEqual(vc['loki']['service_defaults']['mvt_min_zoom_road_class'][-1], 11)
            self.assertIn('loki', vc)
            self.assertIn('thor', vc)
            self.assertIn('odin', vc)
            ci=json.loads(zf.read('routing_coverage/index.json'))
            self.assertEqual(ci['schema'], 'takrig.routing.coverage.v2')
            self.assertEqual(ci['road_feature_count'], ci['nonempty_tile_count'])
            self.assertEqual(ci['offroad_feature_count'], ci['nonempty_tile_count'])
            sample=json.loads(gzip.decompress(zf.read(coverage_tiles[0])).decode())
            classes={f['properties']['class'] for f in sample['features']}
            self.assertEqual(classes, {'road','offroad'})
            extract=self.tmp/'built-tiles.tar'
            extract.write_bytes(zf.read('valhalla_tiles.tar'))
        with tarfile.open(extract, 'r') as tf:
            names=tf.getnames()
            self.assertEqual(names[0], 'index.bin')
            self.assertIn('2/000/001.gph', names)
            index=tf.extractfile('index.bin').read()
            self.assertEqual(len(index), struct.calcsize('<QLL'))
            offset, graph_id, size=struct.unpack('<QLL', index)
            member=tf.getmember('2/000/001.gph')
            self.assertEqual(offset, member.offset_data)
            self.assertEqual(size, member.size)
            self.assertEqual(graph_id, 2 | (1 << 3))
        p = self.run_cli("verify", str(pkg))
        self.assertEqual(p.returncode, 0, p.stderr)
        verify=json.loads(p.stdout)
        self.assertTrue(verify['ok'])

    def test_catalog_migrates_legacy_ready_package_checksum_metadata(self):
        ready = self.state / "ready"
        ready.mkdir(parents=True, exist_ok=True)
        pkg = ready / "takrig-routing-ca-valhalla-3.6.3.zip"
        pkg.write_bytes(b"legacy package")
        desc = ready / (pkg.name + ".json")
        desc.write_text(json.dumps({
            "schema": "takrig.routing.package.v1",
            "region_id": "ca", "state_code": "CA", "name": "California",
            "package": pkg.name, "created_utc": "2026-08-08T12:00:00Z",
            "revision": "deadbeef", "sha256": "a"*64, "sha256_file": pkg.name + ".sha256",
            "source_pbf_sha256": "b"*64, "size_bytes": pkg.stat().st_size,
        }))
        (ready / (pkg.name + ".sha256")).write_text("a"*64 + "  " + pkg.name + "\n")
        p = self.run_cli("catalog")
        self.assertEqual(p.returncode, 0, p.stderr)
        migrated = json.loads(desc.read_text())
        self.assertNotIn("sha256", migrated)
        self.assertNotIn("sha256_file", migrated)
        self.assertNotIn("source_pbf_sha256", migrated)
        self.assertEqual(migrated["revision"], "2026-08-08T12:00:00Z")
        self.assertFalse((ready / (pkg.name + ".sha256")).exists())

    def test_checksum_mismatch_goes_failed(self):
        p = self.run_cli(
            "enqueue", str(self.pbf), "--name", "Bad Hash", "--region-id", "bad-hash",
            "--expected-sha256", "0"*64,
        )
        self.assertEqual(p.returncode, 0, p.stderr)
        p = self.run_cli("scan")
        self.assertNotEqual(p.returncode, 0)
        failed=list((self.state/"failed").iterdir())
        self.assertEqual(len(failed),1)
        self.assertTrue((failed[0]/"source.osm.pbf").is_file())
        job=json.loads((failed[0]/"job.json").read_text())
        self.assertEqual(job['state'],'failed')
        self.assertIn('mismatch',job['error'].lower())

if __name__ == '__main__':
    unittest.main()
