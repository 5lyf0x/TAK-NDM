#!/usr/bin/env python3
import gzip
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / "src"))

import coverage as navcov


class CoverageUnitTest(unittest.TestCase):
    def test_auto_paved_road_is_road(self):
        self.assertEqual(navcov.classify_edge({
            "access:fwd": 1, "access:bwd": 1, "use": 0, "surface": 1, "unpaved": False,
        }), "road")

    def test_auto_track_is_offroad(self):
        self.assertEqual(navcov.classify_edge({
            "access:fwd": 1, "access:bwd": 0, "use": 3, "surface": 4, "unpaved": True,
        }), "offroad")

    def test_unpaved_service_is_offroad(self):
        self.assertEqual(navcov.classify_edge({
            "access:fwd": 1, "use": 11, "surface": 3, "unpaved": True,
        }), "offroad")

    def test_pedestrian_only_is_not_advertised(self):
        self.assertIsNone(navcov.classify_edge({
            "access:fwd": 2, "access:bwd": 2, "use": 24, "surface": 6, "unpaved": True,
        }))

    def test_impassable_and_destination_only_are_not_advertised(self):
        self.assertIsNone(navcov.classify_edge({
            "access:fwd": 1, "use": 3, "surface": 7, "unpaved": True,
        }))
        self.assertIsNone(navcov.classify_edge({
            "access:fwd": 1, "use": 4, "surface": 1, "unpaved": False, "destonly": True,
        }))

    def test_mvt_slippy_coordinate_conversion(self):
        # Top-left corner of z1/x1/y1 is lon 0, lat 0.
        lon, lat = navcov.mvt_point_to_lonlat(0, 0, 1, 1, 1, 4096)
        self.assertAlmostEqual(lon, 0.0, places=6)
        self.assertAlmostEqual(lat, 0.0, places=6)

    def test_verify_coverage_tree(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            tile = root / "11" / "100" / "200.geojson.gz"
            tile.parent.mkdir(parents=True)
            data = {"type": "FeatureCollection", "features": [{
                "type": "Feature", "geometry": {"type": "LineString", "coordinates": [[0,0],[1,1]]},
                "properties": {"class": "road"},
            }]}
            with gzip.open(tile, "wt", encoding="utf-8") as fh:
                json.dump(data, fh)
            index = {
                "schema": navcov.COVERAGE_SCHEMA, "zoom": 11, "feature_count": 1,
                "road_feature_count": 1, "offroad_feature_count": 0,
                "tiles": [{"path": "11/100/200.geojson.gz"}],
            }
            (root / "index.json").write_text(json.dumps(index), encoding="utf-8")
            out = navcov.verify_coverage_tree(root)
            self.assertEqual(out["feature_count"], 1)
            self.assertEqual(out["tile_count"], 1)


if __name__ == "__main__":
    unittest.main()
