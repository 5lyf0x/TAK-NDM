#!/usr/bin/env python3
import json
import http.client
import os
import subprocess
import shutil
import tempfile
import unittest
import threading
import urllib.request
from pathlib import Path
from unittest.mock import patch
import sys

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / "src"))

import manager
import sources
import enrich


class NavigationDataManagerTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="takrig-nav-manager-test-"))
        self.cfg_path = self.tmp / "config.json"
        self.cfg_path.write_text(json.dumps({
            "state_root": str(self.tmp / "state"),
            "log_root": str(self.tmp / "logs"),
            "source_update_interval_days": 30,
            "selected_states": [],
            "minimum_free_disk_gib": 5.0,
        }), encoding="utf-8")
        self.cfg = manager.ManagerConfig(self.cfg_path)
        self.cfg.ensure()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_r16_r16_discovery_response_is_stable_and_transport_only(self):
        first = manager.discovery_response(self.cfg)
        second = manager.discovery_response(self.cfg)
        self.assertEqual(first["magic"], "TAKRIG_NDM_HERE")
        self.assertEqual(first["v"], 1)
        self.assertEqual(first["serverId"], second["serverId"])
        self.assertEqual(first["port"], 8765)
        self.assertEqual(first["version"], "0.2.0-r16-r29")
        self.assertEqual(first["capabilities"], ["navigation", "elevation", "environment", "cellular"])
        self.assertNotIn("states", first)
        self.assertNotIn("catalog", first)
        self.assertTrue((self.cfg.root / manager.DISCOVERY_ID_FILE).is_file())

    def test_r16_r16_discovery_defaults_to_udp_47818(self):
        self.assertTrue(self.cfg.data["discovery_enabled"])
        self.assertEqual(self.cfg.data["discovery_port"], 47818)

    def test_atomic_text_same_millisecond_concurrent_writers_do_not_collide(self):
        target=self.tmp / "atomic.json"
        errors=[]
        barrier=threading.Barrier(8)
        def writer(index):
            try:
                barrier.wait()
                for n in range(40):
                    manager.atomic_text(target,json.dumps({"writer":index,"n":n}))
            except Exception as exc:
                errors.append(exc)
        with patch.object(manager.time,"time",return_value=1787151527.210):
            threads=[threading.Thread(target=writer,args=(i,)) for i in range(8)]
            [t.start() for t in threads]
            [t.join() for t in threads]
        self.assertEqual(errors,[])
        self.assertIsInstance(json.loads(target.read_text(encoding="utf-8")),dict)
        self.assertEqual(list(target.parent.glob(target.name+".part-*")),[])

    def test_state_updates_are_serialized_across_threads_without_lost_fields(self):
        errors=[]
        barrier=threading.Barrier(6)
        def worker(index):
            try:
                barrier.wait()
                key=f"worker_{index}"
                for n in range(35):
                    manager.update_runtime(self.cfg,"CA","downloading_sources",stage="downloading_sources",**{key:n})
            except Exception as exc:
                errors.append(exc)
        threads=[threading.Thread(target=worker,args=(i,)) for i in range(6)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        self.assertEqual(errors,[])
        row=self.cfg.state()["states"]["CA"]
        for i in range(6):
            self.assertEqual(row[f"worker_{i}"],34)

    def test_state_updates_are_serialized_across_processes(self):
        codes=["CA","NV","AZ","OR"]
        script=("import sys\nfrom pathlib import Path\nsys.path.insert(0,sys.argv[1])\nimport manager\n"
                "cfg=manager.ManagerConfig(Path(sys.argv[2]))\ncode=sys.argv[3]\n"
                "for n in range(25): manager.update_runtime(cfg,code,'downloading_sources',stage='downloading_sources',process_counter=n)\n")
        env=dict(os.environ)
        processes=[subprocess.Popen([sys.executable,"-c",script,str(HERE/"src"),str(self.cfg_path),code],env=env) for code in codes]
        for proc in processes:
            self.assertEqual(proc.wait(timeout=30),0)
        states=self.cfg.state()["states"]
        for code in codes:
            self.assertIn(code,states)
            self.assertEqual(states[code]["process_counter"],24)

    def test_r12_state_selection_dirty_survives_status_poll(self):
        web = (HERE / "web" / "index.html").read_text(encoding="utf-8")
        self.assertIn("selectionDirty=false", web)
        self.assertIn("markSelectionDirty();refreshSelected()", web)
        self.assertIn("if(!selectionDirty)setSelected(settings.selected_states||[])", web)
        self.assertIn("setSelected(presets.southwest,true)", web)
        self.assertIn("setSelected(Object.keys(stateNames),true)", web)
        self.assertIn("clearSelectionDirty();load()", web)
        self.assertIn("if(j.ok)clearSelectionDirty()", web)

    def test_osmium_geojsonseq_stream_uses_format_option_flag(self):
        db = enrich.create_db(self.tmp / "index.sqlite")
        try:
            with patch.object(enrich, "run") as run_cmd, patch.object(enrich, "run_stream") as stream_cmd:
                enrich.build_base_index(
                    self.tmp / "base.osm.pbf", self.tmp / "work", db,
                    log=lambda _m: None, stage=lambda _s, _d: None,
                )
            export_calls = [c.args[0] for c in stream_cmd.call_args_list if c.args and "export" in c.args[0]]
            self.assertEqual(len(export_calls), 1)
            cmd = export_calls[0]
            self.assertIn("geojsonseq", cmd)
            self.assertIn("-x", cmd)
            self.assertIn("print_record_separator=false", cmd)
            self.assertNotIn("geojsonseq,print_record_separator=false", cmd)
        finally:
            db.close()

    def test_usfs_vehicle_flags_are_case_insensitive(self):
        feature = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-117.0, 34.0], [-116.9, 34.1]]},
            "properties": {"PASSENGERVEHICLE": "Y", "HIGHCLEARANCEVEHICLE": "N", "NAME": "Forest Road"},
        }
        normalized = sources.normalize_usfs(feature, "road")
        self.assertIsNotNone(normalized)
        self.assertTrue(normalized["properties"]["takrig_routable"])
        self.assertEqual(normalized["properties"]["takrig_name"], "Forest Road")

    def test_offroad_sources_do_not_promote_narrow_vehicle_only_trails(self):
        usfs_atv = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-117.0, 34.0], [-116.9, 34.1]]},
            "properties": {"ATV": "Y", "PASSENGERVEHICLE": "N", "HIGHCLEARANCEVEHICLE": "N", "SYMBOL": "7"},
        }
        self.assertIsNone(sources.normalize_usfs(usfs_atv, "trail"))

        blm_atv = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-115.0, 36.0], [-114.9, 36.1]]},
            "properties": {"PLAN_ALLOW_MODE_TRNSPRT": "MTC_ATV_UTV_ONLY", "PLAN_OHV_ROUTE_DSGNTN": "OPEN"},
        }
        self.assertIsNone(sources.normalize_blm(blm_atv, 2))

        blm_4wd = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-115.0, 36.0], [-114.9, 36.1]]},
            "properties": {"PLAN_ALLOW_MODE_TRNSPRT": "TECH_VEH_SHARED", "PLAN_OHV_ROUTE_DSGNTN": "OPEN", "OBSRVE_ROUTE_USE_CLASS": "4WD HIGH CLEARANCE / SPECIALIZED"},
        }
        normalized = sources.normalize_blm(blm_4wd, 2)
        self.assertIsNotNone(normalized)
        self.assertTrue(normalized["properties"]["takrig_high_clearance"])

    def test_nps_public_trails_promote_only_explicit_fullsize_motor_vehicle_use(self):
        motor_vehicle = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-112.1, 36.1], [-112.0, 36.2]]},
            "properties": {
                "TRLNAME": "High Clearance Route",
                "TRLUSE": "4WD / high clearance motor vehicle",
                "TRLSTATUS": "Open",
                "OPENTOPUBLIC": "Yes",
                "TRLSURFACE": "Native",
            },
        }
        normalized = sources.normalize_nps_trail(motor_vehicle)
        self.assertTrue(normalized["properties"]["takrig_routable"])
        self.assertTrue(normalized["properties"]["takrig_high_clearance"])

        hiking = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-112.1, 36.1], [-112.0, 36.2]]},
            "properties": {"TRLNAME": "Foot Trail", "TRLUSE": "Hiking / Equestrian", "OPENTOPUBLIC": "Yes"},
        }
        normalized = sources.normalize_nps_trail(hiking)
        self.assertFalse(normalized["properties"]["takrig_routable"])

        closed_4wd = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-112.1, 36.1], [-112.0, 36.2]]},
            "properties": {"TRLUSE": "4WD", "TRLSTATUS": "Closed", "OPENTOPUBLIC": "No"},
        }
        normalized = sources.normalize_nps_trail(closed_4wd)
        self.assertFalse(normalized["properties"]["takrig_routable"])

    def test_usgs_4wd_is_high_clearance_routable_gap_fill(self):
        feature = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-114.0, 37.0], [-113.9, 37.1]]},
            "properties": {"name": "Jeep Road"},
        }
        normalized = sources.normalize_usgs_4wd(feature)
        self.assertTrue(normalized["properties"]["takrig_routable"])
        self.assertTrue(normalized["properties"]["takrig_high_clearance"])
        self.assertEqual(normalized["properties"]["takrig_highway"], "track")

    def test_state_motorized_sources_require_fullsize_evidence(self):
        ut_fullsize = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-111.9, 40.4], [-111.8, 40.5]]},
            "properties": {
                "PrimaryName": "4x4 Connector",
                "MotorizedAllowed": "Yes",
                "DesignatedUses": "4WD high clearance motor vehicle",
                "Status": "Open",
            },
        }
        normalized = sources.normalize_state_motorized_trail(ut_fullsize, "ut_trails_pathways", "Utah Trails and Pathways")
        self.assertTrue(normalized["properties"]["takrig_routable"])

        ut_generic_motorized = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-111.9, 40.4], [-111.8, 40.5]]},
            "properties": {
                "PrimaryName": "Motorized Trail",
                "MotorizedAllowed": "Yes",
                "DesignatedUses": "Motorized / ATV / Motorcycle",
                "Status": "Open",
            },
        }
        normalized = sources.normalize_state_motorized_trail(ut_generic_motorized, "ut_trails_pathways", "Utah Trails and Pathways")
        self.assertFalse(normalized["properties"]["takrig_routable"])

        nv_wide = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-116.0, 39.0], [-115.9, 39.1]]},
            "properties": {"trailname": "Wide Motorized Route", "motorizeduse": "Motorized", "trailwidth": "84 inches", "status": "Open"},
        }
        normalized = sources.normalize_state_motorized_trail(nv_wide, "nv_outdoor_recreation_motorized", "Nevada Motorized Trails")
        self.assertTrue(normalized["properties"]["takrig_routable"])

    def test_usfs_trail_can_use_alternate_fullsize_vehicle_evidence(self):
        feature = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-117.0, 34.0], [-116.9, 34.1]]},
            "properties": {"ALLOWEDUSES": "4WD high clearance vehicle", "NAME": "Forest Trail"},
        }
        normalized = sources.normalize_usfs(feature, "trail")
        self.assertIsNotNone(normalized)
        self.assertTrue(normalized["properties"]["takrig_routable"])

    def test_multistate_settings_and_osm_lock(self):
        settings = self.cfg.save_settings(
            ["CA", "NV", "AZ", "UT"],
            {"osm": {"enabled": False}, "blm": {"enabled": False}},
        )
        self.assertEqual(settings["selected_states"], ["CA", "NV", "AZ", "UT"])
        self.assertTrue(settings["sources"]["osm"]["enabled"])
        self.assertFalse(settings["sources"]["blm"]["enabled"])

    def test_r10_state_sources_are_auto_populated_and_isolated(self):
        ca = self.cfg.state_source_settings("CA")
        nv = self.cfg.state_source_settings("NV")
        self.assertEqual(ca["preset"], "standard")
        self.assertTrue(ca["sources"]["osm"]["enabled"])
        self.assertIn("ca_state_parks_routes", ca["sources"])
        self.assertIn("ca_dot_all_roads", ca["sources"])
        self.assertNotIn("ca_state_parks_routes", nv["sources"])
        result = self.cfg.save_state_sources("CA", {
            "preset": "custom",
            "sources": {
                "ca_state_parks_routes": {"enabled": True, "endpoint_override": "https://example.invalid/parks"},
            },
        })
        self.assertTrue(result["changed"])
        ca2 = self.cfg.state_source_settings("CA")
        self.assertEqual(ca2["sources"]["ca_state_parks_routes"]["endpoint_override"], "https://example.invalid/parks")
        self.assertEqual(self.cfg.state_source_settings("NV")["preset"], "standard")

    def test_r10_source_panel_groups_state_sources_and_exposes_editable_urls(self):
        panel = manager.state_source_panel(self.cfg, "CA")
        groups = {row["group"] for row in panel["sources"]}
        self.assertIn("Core", groups)
        self.assertIn("Federal", groups)
        self.assertIn("State Sources", groups)
        parks = next(row for row in panel["sources"] if row["id"] == "ca_state_parks_routes")
        self.assertTrue(parks["default_endpoint"].startswith("https://"))
        dot = next(row for row in panel["sources"] if row["id"] == "ca_dot_all_roads")
        self.assertIn("Core-missing", dot["description"])

    def test_r19_per_state_standard_defaults_ignore_legacy_global_group_disables(self):
        raw = self.cfg.settings()
        for key in ("state_dot", "usfs", "blm", "state_recreation", "nps", "usgs"):
            raw["sources"][key]["enabled"] = False
        manager.atomic_json(self.cfg.settings_path, raw)

        ut = self.cfg.state_source_settings("UT")
        self.assertEqual(ut["preset"], "standard")
        available = sources.all_available_specs_for_state(sources.STATES["UT"])
        for spec in available:
            self.assertEqual(
                ut["sources"][spec.source_id]["enabled"], bool(spec.routable), spec.source_id
            )
        panel = manager.state_source_panel(self.cfg, "UT")
        self.assertEqual(panel["enabled_count"], 12)
        self.assertEqual(panel["available_count"], 13)
        self.assertTrue(ut["sources"]["ut_dot_roads"]["enabled"])
        self.assertTrue(ut["sources"]["ut_trails_pathways"]["enabled"])
        self.assertFalse(ut["sources"]["usgs_trails"]["enabled"])

    def test_r19_custom_state_source_choices_survive_general_save_and_restart(self):
        panel = manager.state_source_panel(self.cfg, "UT")
        choices = {}
        for row in panel["sources"]:
            choices[row["id"]] = {
                "enabled": row["id"] in {
                    "osm", "usfs_mvum_roads", "blm_limited_motorized_roads",
                    "ut_dot_roads", "ut_trails_pathways",
                },
                "endpoint_override": "",
            }
        self.cfg.save_state_sources("UT", {"preset": "custom", "sources": choices})
        self.cfg.save_settings(["UT"], source_update_interval_days=7)

        reloaded = manager.ManagerConfig(self.cfg_path)
        after = reloaded.state_source_settings("UT")
        self.assertEqual(after["preset"], "custom")
        self.assertEqual(after["sources"]["blm_limited_motorized_roads"]["enabled"], True)
        self.assertEqual(after["sources"]["blm_public_motorized_roads"]["enabled"], False)
        self.assertEqual(after["sources"]["ut_dot_roads"]["enabled"], True)
        self.assertEqual(after["sources"]["ut_trails_pathways"]["enabled"], True)
        self.assertEqual(reloaded.settings()["source_update_interval_days"], 7)

    def test_r19_disabled_source_keeps_health_separate_from_enablement(self):
        self.cfg.save_state_sources("UT", {
            "preset": "custom",
            "sources": {"blm_public_motorized_roads": {"enabled": False}},
        })
        panel = manager.state_source_panel(self.cfg, "UT")
        row = next(x for x in panel["sources"] if x["id"] == "blm_public_motorized_roads")
        self.assertFalse(row["enabled"])
        self.assertEqual(row["health"], "not_checked")

    def test_source_update_interval_is_user_configurable_and_persistent(self):
        self.assertEqual(self.cfg.settings()["source_update_interval_days"], 30)
        saved = self.cfg.save_settings(source_update_interval_days=14)
        self.assertEqual(saved["source_update_interval_days"], 14)
        self.assertEqual(self.cfg.settings()["source_update_interval_days"], 14)
        saved = self.cfg.save_settings(source_update_interval_days=60)
        self.assertEqual(saved["source_update_interval_days"], 60)

    def test_build_fingerprint_changes_with_routing_pipeline_revision(self):
        remote = {"osm_geofabrik": {"ok": True, "md5": "same"}, "agency": {}}
        fp = manager.effective_build_fingerprint("sources", remote)
        with patch.object(manager, "ROUTING_PIPELINE_REVISION", "0.2.0-test-newer"):
            newer = manager.effective_build_fingerprint("sources", remote)
        self.assertNotEqual(fp, newer)

    def test_r16_r1_display_fix_does_not_change_r16_routing_fingerprint(self):
        settings = self.cfg.state_source_settings("CA")
        rows = []
        for sid, row in sorted(settings["sources"].items()):
            rows.append({
                "id": sid,
                "enabled": True if sid == "osm" else bool(row.get("enabled", False)),
                "endpoint": str(row.get("endpoint_override") or row.get("default_endpoint") or ""),
                "metadata_url": str(row.get("metadata_url_override") or row.get("default_metadata_url") or "") if sid == "osm" else "",
                "boundary_url": str(row.get("boundary_url_override") or row.get("default_boundary_url") or "") if sid == "osm" else "",
            })
        legacy_r16 = manager.stable_hash({
            "manager_version": "0.2.0-r16", "state": "CA",
            "preset": settings.get("preset"), "sources": rows,
        })
        self.assertEqual(manager.current_source_fingerprint(settings, "CA"), legacy_r16)
        remote = {"osm_geofabrik": {"ok": True, "md5": "same"}, "agency": {}}
        legacy_build = manager.stable_hash({
            "manager_version": "0.2.0-r16",
            "source_fingerprint": legacy_r16,
            "remote_revision": manager.successful_revision_snapshot(remote),
        })
        self.assertEqual(manager.effective_build_fingerprint(legacy_r16, remote), legacy_build)

    def test_configured_source_update_interval_controls_due_checks(self):
        self.cfg.save_settings(["CA"], source_update_interval_days=30)
        p = manager.source_cache_paths(self.cfg, "CA")
        p["root"].mkdir(parents=True, exist_ok=True)
        p["base"].write_bytes(b"base")
        p["enriched"].write_bytes(b"enriched")
        remote = {"osm_geofabrik": {"ok": True, "md5": "same"}, "agency": {}}
        source_fp = manager.current_source_fingerprint(self.cfg.state_source_settings("CA"), "CA")
        manager.atomic_json(p["manifest"], {
            "checked_utc": "2026-08-01T00:00:00Z",
            "source_fingerprint": source_fp,
            "remote_revision": remote,
            "base": {"source_id": "osm_geofabrik"},
        })
        self.cfg.ready.mkdir(parents=True, exist_ok=True)
        pkg = self.cfg.ready / "takrig-routing-ca-valhalla-3.6.3.zip"
        pkg.write_bytes(b"package")
        manager.atomic_json(self.cfg.ready / (pkg.name + ".json"), {
            "state_code": "CA", "region_id": "ca", "package": pkg.name,
            "created_utc": "2026-08-01T00:00:00Z"
        })
        with patch.object(manager, "days_old", return_value=20), patch.object(manager, "remote_revision_for_state") as remote_call:
            result = manager.reconcile_state(self.cfg, "CA")
        self.assertEqual(result["action"], "none")
        remote_call.assert_not_called()

        self.cfg.save_settings(source_update_interval_days=14)
        with patch.object(manager, "days_old", return_value=20), patch.object(manager, "remote_revision_for_state", return_value=remote) as remote_call:
            result = manager.reconcile_state(self.cfg, "CA")
        remote_call.assert_called_once()
        self.assertIn(result["action"], {"checked", "deferred"})

    def test_manual_start_for_newly_selected_state_queues_immediately(self):
        self.cfg.save_settings(["UT"])
        fake_manifest = {
            "bounds": [-114.1, 36.9, -109.0, 42.1],
            "base": {"url": "fake"},
            "source_composition": [],
            "remote_revision": {},
            "source_fingerprint": "x",
        }
        with patch.object(manager, "remote_revision_for_state", return_value={"osm_geofabrik": {"ok": True, "md5": "a"}, "agency": {}}), \
             patch.object(manager, "fetch_and_prepare", return_value=fake_manifest) as prep, \
             patch.object(manager, "enqueue_for_processor") as enqueue:
            result = manager.reconcile_state(self.cfg, "UT", manual_override=True)
        self.assertEqual(result["action"], "queued_build")
        prep.assert_called_once()
        enqueue.assert_called_once()

    def test_temporary_revision_error_does_not_fake_update(self):
        self.cfg.save_settings(["CA"])
        p = manager.source_cache_paths(self.cfg, "CA")
        p["root"].mkdir(parents=True, exist_ok=True)
        p["base"].write_bytes(b"base")
        p["enriched"].write_bytes(b"enriched")
        previous = {
            "osm_geofabrik": {"ok": True, "md5": "same", "etag": "e", "last_modified": "x", "content_length": 1},
            "agency": {"usfs_mvum_roads": {"ok": True, "last_edit_date": 123, "service_item_id": "id", "name": "roads", "current_version": 11}},
        }
        manager.atomic_json(p["manifest"], {
            "checked_utc": "2026-01-01T00:00:00Z",
            "source_fingerprint": manager.current_source_fingerprint(self.cfg.state_source_settings("CA"), "CA"),
            "remote_revision": previous,
            "base": {"source_id": "osm_geofabrik"},
        })
        self.cfg.ready.mkdir(parents=True, exist_ok=True)
        pkg = self.cfg.ready / "takrig-routing-ca-valhalla-3.6.3.zip"
        pkg.write_bytes(b"package")
        manager.atomic_json(self.cfg.ready / (pkg.name + ".json"), {
            "state_code": "CA", "region_id": "ca", "package": pkg.name, "created_utc": "2026-08-01T00:00:00Z"
        })
        current = {
            "osm_geofabrik": {"ok": True, "md5": "same", "etag": "e", "last_modified": "x", "content_length": 1},
            "agency": {"usfs_mvum_roads": {"ok": False, "error": "temporary timeout"}},
        }
        with patch.object(manager, "remote_revision_for_state", return_value=current), \
             patch.object(manager, "fetch_and_prepare") as prep:
            result = manager.reconcile_state(self.cfg, "CA", force_refresh=True)
        self.assertEqual(result["action"], "deferred")
        self.assertEqual(result.get("status"), "partial_source_check_failed")
        prep.assert_not_called()


    def test_failed_build_with_same_inputs_is_not_automatically_retried(self):
        self.cfg.save_settings(["CA"], {"nps": {"enabled": True}})
        p = manager.source_cache_paths(self.cfg, "CA")
        p["root"].mkdir(parents=True, exist_ok=True)
        p["base"].write_bytes(b"base")
        previous = {
            "osm_geofabrik": {"ok": True, "md5": "same", "etag": "e", "last_modified": "x", "content_length": 1},
            "agency": {},
        }
        source_fp = manager.current_source_fingerprint(self.cfg.state_source_settings("CA"), "CA")
        build_fp = manager.effective_build_fingerprint(source_fp, previous)
        manager.atomic_json(p["manifest"], {
            "checked_utc": "",
            "source_fingerprint": source_fp,
            "build_fingerprint": build_fp,
            "remote_revision": previous,
            "base": {"source_id": "osm_geofabrik"},
        })
        manager.record_manager_failure(self.cfg, "CA", "deterministic merge error", build_fp)
        with patch.object(manager, "remote_revision_for_state", return_value=previous), \
             patch.object(manager, "fetch_and_prepare") as prep:
            result = manager.reconcile_state(self.cfg, "CA", force_refresh=True)
        self.assertEqual(result["action"], "blocked_failed")
        self.assertEqual(result["status"], "failed")
        prep.assert_not_called()
        status = manager.state_status(self.cfg, "CA")
        self.assertEqual(status["status"], "failed")
        self.assertIn("merge error", status["failure"]["error"])

    def test_processor_failure_with_same_fingerprint_is_not_auto_retried(self):
        self.cfg.save_settings(["CA"])
        p = manager.source_cache_paths(self.cfg, "CA")
        p["root"].mkdir(parents=True, exist_ok=True)
        p["base"].write_bytes(b"base")
        p["enriched"].write_bytes(b"prepared")
        previous = {"osm_geofabrik": {"ok": True, "md5": "same"}, "agency": {}}
        source_fp = manager.current_source_fingerprint(self.cfg.state_source_settings("CA"), "CA")
        build_fp = manager.effective_build_fingerprint(source_fp, previous)
        manager.atomic_json(p["manifest"], {
            "checked_utc": "",
            "source_fingerprint": source_fp,
            "build_fingerprint": build_fp,
            "remote_revision": previous,
            "base": {"source_id": "osm_geofabrik"},
        })
        failed = self.cfg.failed / "failed-ca-job"
        failed.mkdir(parents=True)
        manager.atomic_json(failed / "job.json", {
            "job_id": "failed-ca-job",
            "state_code": "CA",
            "region_id": "ca",
            "state": "failed",
            "error": "Valhalla deterministic failure",
            "failed_utc": "2026-08-08T22:00:00Z",
            "build_fingerprint": build_fp,
            "manager_version": manager.VERSION,
        })
        with patch.object(manager, "remote_revision_for_state", return_value=previous), \
             patch.object(manager, "fetch_and_prepare") as prep:
            result = manager.reconcile_state(self.cfg, "CA", force_refresh=True)
        self.assertEqual(result["action"], "blocked_failed")
        self.assertEqual(result["failure"]["kind"], "processor")
        prep.assert_not_called()

    def test_explicit_retry_bypasses_same_failure_gate(self):
        self.cfg.save_settings(["CA"])
        p = manager.source_cache_paths(self.cfg, "CA")
        p["root"].mkdir(parents=True, exist_ok=True)
        p["base"].write_bytes(b"base")
        previous = {"osm_geofabrik": {"ok": True, "md5": "same"}, "agency": {}}
        source_fp = manager.current_source_fingerprint(self.cfg.state_source_settings("CA"), "CA")
        build_fp = manager.effective_build_fingerprint(source_fp, previous)
        manager.atomic_json(p["manifest"], {
            "checked_utc": "",
            "source_fingerprint": source_fp,
            "build_fingerprint": build_fp,
            "remote_revision": previous,
            "base": {"source_id": "osm_geofabrik"},
        })
        manager.record_manager_failure(self.cfg, "CA", "old failure", build_fp)
        fake_manifest = {
            "bounds": [-124, 32, -114, 42], "base": {"url": "fake"}, "source_composition": [],
            "remote_revision": previous, "source_fingerprint": source_fp, "build_fingerprint": build_fp,
        }
        with patch.object(manager, "remote_revision_for_state", return_value=previous), \
             patch.object(manager, "fetch_and_prepare", return_value=fake_manifest) as prep, \
             patch.object(manager, "enqueue_for_processor") as enqueue:
            result = manager.reconcile_state(self.cfg, "CA", force_refresh=True, force_rebuild=True, manual_override=True)
        self.assertEqual(result["action"], "queued_build")
        prep.assert_called_once()
        enqueue.assert_called_once()

    def test_geofabrik_poly_clips_supplemental_geometry_to_exact_boundary(self):
        poly = """test\n1\n 0 0\n 1 0\n 1 1\n 0 1\n 0 0\nEND\nEND\n"""
        boundary = sources.parse_geofabrik_poly(poly)
        feature = {
            "type": "Feature",
            "properties": {"takrig_routable": True},
            "geometry": {"type": "LineString", "coordinates": [[-1, 0.5], [2, 0.5]]},
        }
        clipped = sources._clip_feature_to_boundary(feature, boundary)
        self.assertIsNotNone(clipped)
        coords = clipped["geometry"]["coordinates"]
        self.assertAlmostEqual(coords[0][0], 0.0, places=6)
        self.assertAlmostEqual(coords[-1][0], 1.0, places=6)

    def test_processor_sidecar_preserves_build_fingerprint(self):
        source = self.tmp / "prepared.osm.pbf"
        source.write_bytes(b"prepared-input")
        manifest = {
            "checked_utc": "2026-08-08T00:00:00Z",
            "bounds": [-124.5, 32.5, -114.0, 42.1],
            "source_composition": [],
            "remote_revision": {},
            "source_fingerprint": "source-fp",
            "build_fingerprint": "build-fp",
        }
        manager.enqueue_for_processor(self.cfg, "CA", source, manifest)
        sidecar = json.loads((self.cfg.incoming / "ca.osm.pbf.json").read_text())
        self.assertEqual(sidecar["build_fingerprint"], "build-fp")
        self.assertEqual(sidecar["manager_version"], manager.VERSION)

    def test_state_dot_conflation_adds_only_core_missing_geometry(self):
        from shapely.geometry import LineString
        from shapely import wkb
        work = self.tmp / "dot-conflation"
        work.mkdir()
        db = enrich.create_db(work / "base.sqlite")
        try:
            base = LineString([[-120.0, 35.0], [-119.9, 35.0]])
            minx, miny, maxx, maxy = base.bounds
            db.execute("INSERT INTO ways VALUES (?,?)", (1, wkb.dumps(base)))
            db.execute("INSERT INTO way_idx VALUES (?,?,?,?,?)", (1, minx, maxx, miny, maxy))
            db.commit()
            src = work / "dot.geojson"
            src.write_text(json.dumps({
                "type": "FeatureCollection",
                "features": [{
                    "type": "Feature",
                    "properties": {
                        "takrig_routable": True,
                        "takrig_source": "ca_dot_all_roads",
                        "takrig_source_name": "Caltrans",
                        "takrig_routing_role": "public_road_authority",
                        "takrig_highway": "unclassified",
                    },
                    "geometry": {"type": "LineString", "coordinates": [[-120.05,35.0],[-120.0,35.0],[-119.9,35.0],[-119.85,35.0]]},
                }],
            }), encoding="utf-8")
            out = work / "supplement.osm"
            result = enrich.generate_supplement_osm([src], db, out, 1000, 2000, lambda _: None)
        finally:
            db.close()
        stats = result["sources"]["ca_dot_all_roads"]
        self.assertGreaterEqual(stats["partial_added"], 1)
        self.assertGreaterEqual(stats["added"], 1)
        self.assertIn('takrig:conflation" v="core-missing-only', out.read_text(encoding="utf-8"))

    def test_supplemental_ids_are_positive_and_above_base_maxima(self):
        work = self.tmp / "enrich-test"
        work.mkdir()
        db = enrich.create_db(work / "base.sqlite")
        try:
            src = work / "supp.geojson"
            src.write_text(json.dumps({
                "type": "FeatureCollection",
                "features": [{
                    "type": "Feature",
                    "properties": {
                        "takrig_routable": True,
                        "takrig_source": "nps_public_roads",
                        "takrig_source_name": "NPS",
                        "takrig_highway": "service",
                    },
                    "geometry": {"type": "LineString", "coordinates": [[-120.0, 35.0], [-119.9, 35.1]]},
                }],
            }), encoding="utf-8")
            output = work / "supplement.osm"
            result = enrich.generate_supplement_osm([src], db, output, 1000, 2000, lambda _: None)
        finally:
            db.close()
        text = output.read_text(encoding="utf-8")
        self.assertEqual(result["synthetic_node_id_start"], 1001)
        self.assertEqual(result["synthetic_way_id_start"], 2001)
        self.assertIn('<node id="1001"', text)
        self.assertIn('<way id="2001"', text)
        self.assertNotIn('id="-', text)


    def test_package_download_supports_http_range_resume(self):
        self.cfg.ready.mkdir(parents=True, exist_ok=True)
        payload = b"0123456789abcdefghijklmnopqrstuvwxyz"
        pkg = self.cfg.ready / "takrig-routing-california-valhalla-3.6.3.zip"
        pkg.write_bytes(payload)
        manager.atomic_json(self.cfg.ready / (pkg.name + ".json"), {
            "state_code": "CA", "region_id": "ca", "package": pkg.name,
            "created_utc": "2026-08-08T12:00:00Z", "revision": "r1",
            "size_bytes": len(payload),
        })
        server = manager.ThreadingHTTPServer(("127.0.0.1", 0), manager.WebHandler)
        server.cfg = self.cfg
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            url = f"http://127.0.0.1:{server.server_address[1]}/api/v1/packages/CA/download"
            req = urllib.request.Request(url, headers={"Range": "bytes=10-15"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                self.assertEqual(resp.status, 206)
                self.assertEqual(resp.headers.get("Accept-Ranges"), "bytes")
                self.assertEqual(resp.headers.get("ETag"), '"r1"')
                self.assertEqual(resp.headers.get("Content-Range"), f"bytes 10-15/{len(payload)}")
                self.assertEqual(resp.read(), payload[10:16])
        finally:
            server.shutdown(); server.server_close(); thread.join(timeout=5)

    def test_package_http11_exact_4mib_ranges_reuse_one_connection(self):
        self.cfg.ready.mkdir(parents=True, exist_ok=True)
        first_len = 4 * 1024 * 1024
        payload = (bytes(range(256)) * ((first_len + 257) // 256 + 1))[: first_len + 257]
        pkg = self.cfg.ready / "takrig-routing-california-valhalla-3.6.3.zip"
        pkg.write_bytes(payload)
        manager.atomic_json(self.cfg.ready / (pkg.name + ".json"), {
            "state_code": "CA", "region_id": "ca", "package": pkg.name,
            "created_utc": "2026-08-13T02:31:42Z", "revision": "r15-http11",
            "size_bytes": len(payload),
        })
        server = manager.ThreadingHTTPServer(("127.0.0.1", 0), manager.WebHandler)
        server.cfg = self.cfg
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        conn = http.client.HTTPConnection("127.0.0.1", server.server_address[1], timeout=5)
        try:
            path = "/api/v1/packages/CA/download"
            conn.request("GET", path, headers={
                "Range": f"bytes=0-{first_len - 1}",
                "If-Range": '"r15-http11"',
                "Accept-Encoding": "identity",
            })
            first = conn.getresponse()
            self.assertEqual(first.version, 11)
            self.assertEqual(first.status, 206)
            self.assertEqual(first.getheader("Content-Length"), str(first_len))
            self.assertEqual(first.getheader("Content-Range"), f"bytes 0-{first_len - 1}/{len(payload)}")
            self.assertEqual(first.read(), payload[:first_len])
            sock = conn.sock
            self.assertIsNotNone(sock)

            conn.request("GET", path, headers={
                "Range": f"bytes={first_len}-{len(payload) - 1}",
                "If-Range": '"r15-http11"',
                "Accept-Encoding": "identity",
            })
            second = conn.getresponse()
            self.assertEqual(second.version, 11)
            self.assertEqual(second.status, 206)
            self.assertIs(conn.sock, sock)
            self.assertEqual(second.getheader("Content-Length"), str(len(payload) - first_len))
            self.assertEqual(second.getheader("Content-Range"), f"bytes {first_len}-{len(payload) - 1}/{len(payload)}")
            self.assertEqual(second.read(), payload[first_len:])
        finally:
            conn.close(); server.shutdown(); server.server_close(); thread.join(timeout=5)

    def test_http11_unsatisfiable_range_has_zero_length_and_connection_remains_usable(self):
        self.cfg.ready.mkdir(parents=True, exist_ok=True)
        payload = b"0123456789abcdefghijklmnopqrstuvwxyz"
        pkg = self.cfg.ready / "takrig-routing-california-valhalla-3.6.3.zip"
        pkg.write_bytes(payload)
        manager.atomic_json(self.cfg.ready / (pkg.name + ".json"), {
            "state_code": "CA", "region_id": "ca", "package": pkg.name,
            "created_utc": "2026-08-13T02:31:42Z", "revision": "r15-http11",
            "size_bytes": len(payload),
        })
        server = manager.ThreadingHTTPServer(("127.0.0.1", 0), manager.WebHandler)
        server.cfg = self.cfg
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        conn = http.client.HTTPConnection("127.0.0.1", server.server_address[1], timeout=5)
        try:
            path = "/api/v1/packages/CA/download"
            conn.request("GET", path, headers={"Range": "bytes=999999-", "Accept-Encoding": "identity"})
            bad = conn.getresponse()
            self.assertEqual(bad.version, 11)
            self.assertEqual(bad.status, 416)
            self.assertEqual(bad.getheader("Content-Range"), f"bytes */{len(payload)}")
            self.assertEqual(bad.getheader("Content-Length"), "0")
            self.assertEqual(bad.read(), b"")
            sock = conn.sock
            self.assertIsNotNone(sock)

            conn.request("GET", path, headers={"Range": "bytes=0-3", "Accept-Encoding": "identity"})
            good = conn.getresponse()
            self.assertEqual(good.status, 206)
            self.assertIs(conn.sock, sock)
            self.assertEqual(good.read(), payload[:4])
        finally:
            conn.close(); server.shutdown(); server.server_close(); thread.join(timeout=5)

    def test_package_download_if_range_revision_change_restarts_full_transfer(self):
        self.cfg.ready.mkdir(parents=True, exist_ok=True)
        payload = b"0123456789abcdefghijklmnopqrstuvwxyz"
        pkg = self.cfg.ready / "takrig-routing-california-valhalla-3.6.3.zip"
        pkg.write_bytes(payload)
        manager.atomic_json(self.cfg.ready / (pkg.name + ".json"), {
            "state_code": "CA", "region_id": "ca", "package": pkg.name,
            "created_utc": "2026-08-08T12:00:00Z", "revision": "r2",
            "size_bytes": len(payload),
        })
        server = manager.ThreadingHTTPServer(("127.0.0.1", 0), manager.WebHandler)
        server.cfg = self.cfg
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            url = f"http://127.0.0.1:{server.server_address[1]}/api/v1/packages/CA/download"
            req = urllib.request.Request(url, headers={"Range": "bytes=10-", "If-Range": '"r1"'})
            with urllib.request.urlopen(req, timeout=5) as resp:
                self.assertEqual(resp.status, 200)
                self.assertIsNone(resp.headers.get("Content-Range"))
                self.assertEqual(resp.headers.get("ETag"), '"r2"')
                self.assertEqual(resp.read(), payload)
        finally:
            server.shutdown(); server.server_close(); thread.join(timeout=5)

    def test_public_catalog_exposes_android_contract(self):
        self.cfg.ready.mkdir(parents=True, exist_ok=True)
        pkg = self.cfg.ready / "takrig-routing-california-valhalla-3.6.3.zip"
        pkg.write_bytes(b"package bytes")
        manager.atomic_json(self.cfg.ready / (pkg.name + ".json"), {
            "state_code": "CA",
            "region_id": "ca",
            "package": pkg.name,
            "created_utc": "2026-08-08T12:00:00Z",
            "revision": "abc123",
            "size_bytes": pkg.stat().st_size,
            "format": "takrig.valhalla.region.v1",
            "valhalla_version": "3.6.3",
            "source_composition": [{"name": "OpenStreetMap / Geofabrik", "status": "downloaded"}],
            "source_revisions": {"osm_geofabrik": {"md5": "x"}},
            "routing_coverage": {
                "schema": "takrig.routing.coverage.v2",
                "zoom": 11,
                "feature_count": 1234,
                "road_feature_count": 900,
                "offroad_feature_count": 334,
            },
        })
        catalog = manager.public_catalog(self.cfg)
        self.assertEqual(catalog["schema"], "takrig.nav.catalog.v1")
        self.assertEqual(len(catalog["packages"]), 1)
        row = catalog["packages"][0]
        self.assertEqual(row["state_code"], "CA")
        self.assertEqual(row["download_url"], "/api/v1/packages/CA/download")
        self.assertNotIn("sha256", row)
        self.assertEqual(row["revision"], "abc123")
        self.assertEqual(row["routing_coverage"]["schema"], "takrig.routing.coverage.v2")
        self.assertEqual(row["routing_coverage"]["offroad_feature_count"], 334)


    def test_r7_operation_settings_preserve_unknown_settings(self):
        raw = self.cfg.settings()
        raw["future_setting"] = {"keep": "me"}
        manager.atomic_json(self.cfg.settings_path, raw)
        saved = self.cfg.save_settings(
            source_download_concurrency=6, source_per_host_concurrency=2,
            minimum_free_disk_gib=35, source_cache_limit_gib=150,
            maintenance_window_start_local="01:30", automatic_rebuild_enabled=False,
        )
        self.assertEqual(saved["source_download_concurrency"], 6)
        self.assertEqual(saved["minimum_free_disk_gib"], 35.0)
        self.assertEqual(saved["maintenance_window_start_local"], "01:30")
        self.assertFalse(saved["automatic_rebuild_enabled"])
        self.assertEqual(saved["future_setting"], {"keep": "me"})

    def test_automatic_new_state_waits_for_maintenance_window(self):
        self.cfg.save_settings(["UT"], maintenance_window_start_local="00:00")
        remote = {"osm_geofabrik": {"ok": True, "md5": "a", "content_length": 1}, "agency": {}}
        with patch.object(manager, "remote_revision_for_state", return_value=remote), \
             patch.object(manager, "storage_gate", return_value=(True, {"free_ok": True, "cache_limit_ok": True})), \
             patch.object(manager, "maintenance_eligible_utc", return_value="2099-01-01T00:00:00Z"), \
             patch.object(manager, "fetch_and_prepare") as prep:
            result = manager.reconcile_state(self.cfg, "UT")
        self.assertEqual(result["status"], "waiting_maintenance")
        prep.assert_not_called()

    def test_storage_policy_blocks_even_manual_start(self):
        self.cfg.save_settings(["UT"])
        remote = {"osm_geofabrik": {"ok": True, "md5": "a", "content_length": 1}, "agency": {}}
        estimate = {"free_ok": False, "cache_limit_ok": True, "free_bytes": 1, "projected_required_free_bytes": 2}
        with patch.object(manager, "remote_revision_for_state", return_value=remote), \
             patch.object(manager, "storage_gate", return_value=(False, estimate)), \
             patch.object(manager, "fetch_and_prepare") as prep:
            result = manager.reconcile_state(self.cfg, "UT", manual_override=True)
        self.assertEqual(result["status"], "waiting_space")
        prep.assert_not_called()

    def test_auto_rebuild_off_reports_update_available(self):
        self.cfg.save_settings(["CA"], automatic_rebuild_enabled=False)
        pth = manager.source_cache_paths(self.cfg, "CA")
        pth["root"].mkdir(parents=True, exist_ok=True)
        pth["base"].write_bytes(b"base"); pth["enriched"].write_bytes(b"enriched")
        previous = {"osm_geofabrik": {"ok": True, "md5": "old"}, "agency": {}}
        manager.atomic_json(pth["manifest"], {
            "checked_utc": "", "source_fingerprint": manager.current_source_fingerprint(self.cfg.state_source_settings("CA"), "CA"),
            "remote_revision": previous, "base": {"source_id": "osm_geofabrik"}, "manager_version": manager.VERSION,
        })
        pkg = self.cfg.ready / "takrig-routing-ca-valhalla-3.6.3.zip"; pkg.write_bytes(b"package")
        manager.atomic_json(self.cfg.ready / (pkg.name + ".json"), {"state_code":"CA","region_id":"ca","package":pkg.name,"created_utc":"2026-08-01T00:00:00Z"})
        current = {"osm_geofabrik": {"ok": True, "md5": "new"}, "agency": {}}
        with patch.object(manager, "remote_revision_for_state", return_value=current), patch.object(manager, "fetch_and_prepare") as prep:
            result = manager.reconcile_state(self.cfg, "CA", force_refresh=True)
        self.assertEqual(result["status"], "update_available")
        prep.assert_not_called()

    def test_new_active_attempt_overrides_stale_processor_failure(self):
        self.cfg.save_settings(["CA"])
        failed = self.cfg.failed / "old-ca"; failed.mkdir(parents=True)
        manager.atomic_json(failed / "job.json", {
            "job_id":"old-ca","state_code":"CA","region_id":"ca","state":"failed","error":"old failure",
            "failed_utc":"2026-01-01T00:00:00Z","build_fingerprint":"old","manager_version":"0.2.0-r6"
        })
        manager.update_runtime(self.cfg, "CA", "downloading_osm", stage="downloading_osm", detail="new attempt", new_attempt=True)
        status = manager.state_status(self.cfg, "CA")
        self.assertEqual(status["status"], "downloading_osm")
        self.assertIsNone(status["failure"])
        self.assertTrue(status["failure_history"])

    def test_source_cache_cleanup_preserves_ready_package(self):
        self.cfg.save_settings(["CA"])
        pth = manager.source_cache_paths(self.cfg, "CA"); pth["root"].mkdir(parents=True, exist_ok=True)
        pth["base"].write_bytes(b"cache-data")
        pkg = self.cfg.ready / "takrig-routing-ca-valhalla-3.6.3.zip"; pkg.write_bytes(b"ready")
        manager.atomic_json(self.cfg.ready / (pkg.name + ".json"), {"state_code":"CA","region_id":"ca","package":pkg.name,"created_utc":"2026-08-01T00:00:00Z"})
        result = manager.clear_state_source_cache(self.cfg, "CA")
        self.assertGreater(result["reclaimed_bytes"], 0)
        self.assertTrue(result["ready_preserved"])
        self.assertTrue(pkg.is_file())


