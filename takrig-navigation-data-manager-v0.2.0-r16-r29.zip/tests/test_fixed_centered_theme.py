
"""r28 centered real NDM UI / state image regression checks."""
from pathlib import Path
import json,unittest,re
HERE=Path(__file__).resolve().parents[1]
class FixedCenteredThemeTest(unittest.TestCase):
    def test_approved_real_ui_and_centered_panels(self):
        s=(HERE/'web/index.html').read_text()
        self.assertIn('max-width:1450px;margin-left:auto;margin-right:auto',s)
        self.assertIn('.ndm-executive-top{width:100%;max-width:1388px;margin-left:auto;margin-right:auto',s)
        self.assertIn('object-fit:contain',s)
        self.assertIn('class="ndm-hero-image"',s)
        self.assertNotIn('<div class="ndm-sidebar-title"',s)
        self.assertNotIn('<span class="ndm-nav-icon"',s)
        for action in ('overview','states','packages','sources','maintenance','activity','settings'):
            self.assertIn('data-ndm-view="'+action+'"',s)
    def test_phase5_all_ten_source_images_and_manifest_hashes(self):
        m=json.loads((HERE/'web/assets/MANIFEST.json').read_text())
        self.assertEqual(m['package_version'],'0.2.0-r16-r29')
        self.assertEqual(set(m['phase5_state_codes']),set('SD TN TX UT VT VA WA WV WI WY'.split()))
        self.assertEqual(len(m['state_assets']),50)
        for code in m['phase5_state_codes']:
            p=HERE/'web/assets/states'/(code+'.webp')
            self.assertGreater(p.stat().st_size,80000)
    def test_original_routing_pipeline_version_unchanged(self):
        import sys
        sys.path.insert(0,str(HERE/'src'))
        import manager
        self.assertEqual(manager.VERSION,'0.2.0-r16-r29')
        self.assertEqual(manager.ROUTING_PIPELINE_REVISION,'0.2.0-r16')
