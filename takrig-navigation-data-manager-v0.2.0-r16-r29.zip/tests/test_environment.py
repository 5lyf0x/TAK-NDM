#!/usr/bin/env python3
import json, sqlite3, struct, tempfile, unittest, zipfile, zlib, sys, urllib.error
from unittest import mock
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'src'))
import environment, environment_assets, manager, terrain

class EnvironmentTests(unittest.TestCase):
    def config(self, root:Path)->Path:
        p=root/'config.json'
        p.write_text(json.dumps({'state_root':str(root/'state'),'log_root':str(root/'log'),'minimum_free_disk_gib':5,'terrain_resolution_m':30}),encoding='utf-8')
        return p

    def test_worldcover_mapping_and_runtime_cell_contract(self):
        raw=bytes([10,20,30,40,50,60,70,80,90,95,100,255])
        norm=environment._normalize_worldcover(raw)
        pairs=[tuple(norm[i:i+2]) for i in range(0,len(norm),2)]
        self.assertEqual(pairs[0],(environment.TREE,245))
        self.assertEqual(pairs[9],(environment.TREE,250))
        self.assertEqual(pairs[4],(environment.BUILT,0))
        self.assertEqual(pairs[6],(environment.PERMANENT_SNOW_ICE,0))
        self.assertEqual(pairs[7],(environment.WATER,0))
        self.assertEqual(pairs[-1],(environment.UNKNOWN,0))
        self.assertEqual(environment.SUBCELL_GRID,361)
        self.assertEqual(environment.RUNTIME_RESOLUTION_M,30)


    def test_worldcover_404_is_treated_as_no_coverage_not_failure(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=self.config(root); missing=set()
            err=urllib.error.HTTPError(
                environment._source_url('N30W126'), 404, 'Not Found', hdrs=None, fp=None
            )
            with mock.patch.object(environment.urllib.request, 'urlopen', side_effect=err) as urlopen:
                self.assertIsNone(environment._download_source(cfg,'N30W126',missing))
                self.assertIn('N30W126',missing)
                self.assertEqual(urlopen.call_count,1)
            # Once known absent during this build, sibling 0.5-degree cells mapped to the
            # same 3-degree ocean tile must not hit the network again.
            with mock.patch.object(environment.urllib.request, 'urlopen') as urlopen:
                self.assertIsNone(environment._download_source(cfg,'N30W126',missing))
                urlopen.assert_not_called()

    def test_worldcover_non_404_http_error_remains_fatal(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=self.config(root); missing=set()
            err=urllib.error.HTTPError(
                environment._source_url('N33W120'), 403, 'Forbidden', hdrs=None, fp=None
            )
            with mock.patch.object(environment.urllib.request, 'urlopen', side_effect=err):
                with self.assertRaisesRegex(RuntimeError, 'WorldCover HTTP 403'):
                    environment._download_source(cfg,'N33W120',missing)
            self.assertNotIn('N33W120',missing)

    def test_environment_db_roundtrip_and_validation(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=self.config(root); dbp=root/'environment.sqlite'
            db=environment._create_db(dbp,'CA','California','2026-09-12T00:00:00Z',True)
            payload=bytes([environment.TREE,220])*(environment.SUBCELL_GRID**2)
            db.execute('INSERT INTO cells(cell_id,west,south,east,north,rows,cols,encoding,data) VALUES(?,?,?,?,?,?,?,?,?)',
                       ('x/00',-120,35,-119.9,35.1,environment.SUBCELL_GRID,environment.SUBCELL_GRID,'u8class+density+zlib',zlib.compress(payload)))
            db.commit(); db.close()
            result=environment._validate_db(dbp)
            self.assertEqual(result['cell_count'],1)


    def test_cinematic_catalog_and_optional_sqlite_tables(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); dbp=root/'environment.sqlite'
            db=environment._create_db(dbp,'CA','California','2026-09-12T00:00:00Z',True)
            payload=bytes([environment.TREE,220])*(environment.SUBCELL_GRID**2)
            db.execute('INSERT INTO cells(cell_id,west,south,east,north,rows,cols,encoding,data) VALUES(?,?,?,?,?,?,?,?,?)',
                       ('x/00',-120,35,-119.9,35.1,environment.SUBCELL_GRID,environment.SUBCELL_GRID,'u8class+density+zlib',zlib.compress(payload)))
            # Install a tiny deterministic stand-in bundle; network acquisition is intentionally not part of unit tests.
            bundle={
                'materials':[{'id':m.id,'family':m.family,'slug':m.slug,'name':m.name,'atlas_index':m.id,'physical_width_m':m.physical_width_m,'normal_strength':m.normal_strength,'role':m.role} for m in environment_assets.MATERIAL_SPECS],
                'tree_catalog':[{'id':t.id,'family':t.family,'slug':t.slug,'name':t.name,'front_index':t.id*3,'side_index':t.id*3+1,'top_index':t.id*3+2,'nominal_height_m':t.nominal_height_m} for t in environment_assets.TREE_SPECS],
                'albedo':b'jpeg-albedo','normal':b'jpeg-normal','tree_atlas':b'png-trees',
                'albedo_width':2048,'albedo_height':2048,'normal_width':1024,'normal_height':1024,
                'tree_width':2048,'tree_height':1024,'material_grid':8,'tree_grid_cols':8,'tree_grid_rows':4,
            }
            environment_assets.install_bundle(db,bundle); db.close()
            check=sqlite3.connect(dbp)
            try:
                self.assertEqual(check.execute('SELECT count(*) FROM materials').fetchone()[0],35)
                self.assertEqual(check.execute('SELECT count(*) FROM tree_catalog').fetchone()[0],9)
                self.assertEqual(check.execute('SELECT count(*) FROM cinematic_assets').fetchone()[0],3)
                self.assertEqual(check.execute("SELECT value FROM cinematic_metadata WHERE name='asset_set'").fetchone()[0],'cinematic-environment-v1')
                self.assertEqual(check.execute("SELECT value FROM cinematic_metadata WHERE name='render_profile'").fetchone()[0],'cinematic-environment-v1.1')
                self.assertEqual(check.execute("SELECT value FROM cinematic_metadata WHERE name='forest_density_scale'").fetchone()[0],'1.50')
                self.assertEqual(check.execute("SELECT value FROM cinematic_metadata WHERE name='tree_height_scale'").fetchone()[0],'1.50')
            finally: check.close()
            self.assertEqual(environment._validate_db(dbp)['cell_count'],1)

    def test_cinematic_source_contract_is_locked(self):
        self.assertEqual(len(environment_assets.MATERIAL_SPECS),35)
        self.assertEqual(len(environment_assets.TREE_SPECS),9)
        self.assertEqual(environment_assets.ALBEDO_ATLAS_SIZE,2048)
        self.assertEqual(environment_assets.NORMAL_ATLAS_SIZE,1024)
        self.assertEqual(environment_assets.MATERIAL_SPECS[26].slug,'snow_field_aerial')
        self.assertNotIn('snow_04',{m.slug for m in environment_assets.MATERIAL_SPECS})
        self.assertEqual({t.slug for t in environment_assets.TREE_SPECS},{
            'pine_tree_01','fir_tree_01','pine_sapling_medium','tree_small_02','jacaranda_tree',
            'island_tree_01','island_tree_02','quiver_tree_01','quiver_tree_02'
        })

    def test_catalog_exposes_environment_package_and_discovery_capability(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfgp=self.config(root); cfg=manager.ManagerConfig(cfgp); cfg.ensure()
            ready=environment.roots(cfgp)['ready']; ready.mkdir(parents=True,exist_ok=True)
            pkg=environment.package_path(cfgp,'CA'); pkg.write_bytes(b'env')
            environment.atomic_json(environment.descriptor_path(cfgp,'CA'),{
                'package':pkg.name,'state_code':'CA','state_name':'California','format':environment.PACKAGE_FORMAT,
                'revision':'r1','created_utc':'2026-09-12T00:00:00Z','size_bytes':3,'runtime_resolution_m':30,'cell_count':1,
                'source':{'name':environment.SOURCE_NAME}
            })
            cat=manager.public_catalog(cfg)
            self.assertEqual(len(cat['environment_packages']),1)
            self.assertEqual(cat['environment_packages'][0]['download_url'],'/api/v1/environment/CA/download')
            self.assertIn('environment', manager.discovery_response(cfg, 'test-server')['capabilities'])

    def test_30m_profile_and_overview_decimation(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=self.config(root)
            profile=terrain.terrain_profile(cfg)
            self.assertEqual((profile.nominal_resolution_m,profile.sample_arcsec,profile.grid_size),(30,1.0,1801))
            self.assertEqual(terrain.overview_specs(profile),((60,2),(120,4),(240,8)))
            rows=cols=9
            raw=struct.pack('<'+'h'*(rows*cols),*range(rows*cols))
            dec,r,c=terrain._decimate_int16(raw,rows,cols,2)
            self.assertEqual((r,c),(5,5))
            vals=struct.unpack('<'+'h'*(r*c),dec)
            self.assertEqual(vals[0],0)
            self.assertEqual(vals[1],2)
            self.assertEqual(vals[5],18)

class EnvironmentInstallerRegressionTest(unittest.TestCase):
    def test_r16_r17_installer_deploys_environment_module_and_state_roots(self):
        installer = (HERE / "install.sh").read_text(encoding="utf-8")
        self.assertIn('src/environment.py" "$INSTALL_ROOT/bin/environment.py', installer)
        self.assertIn('src/environment_assets.py" "$INSTALL_ROOT/bin/environment_assets.py', installer)
        self.assertIn('environment environment/ready environment/work environment/status environment/cache environment/cache/worldcover', installer)
        self.assertIn('import environment', installer)
        self.assertIn('environment is not None', installer)

    def test_manager_local_imports_are_all_installed(self):
        installer = (HERE / "install.sh").read_text(encoding="utf-8")
        for module in ("sources", "state_catalog", "enrich", "coverage", "terrain", "environment", "environment_assets", "cellular", "fcc_mobile"):
            self.assertIn(f'src/{module}.py" "$INSTALL_ROOT/bin/{module}.py', installer)


if __name__=='__main__': unittest.main()
