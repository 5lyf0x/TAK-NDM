# TAK Rig Navigation Data Manager v0.2.0-r16-r12

## Scope

R16-r12 adds the first TAK Gateway-side Cellular Coverage preprocessing/package pipeline while preserving the field-proven r16 Navigation, Terrain, and Outdoors behavior. The routing pipeline revision remains pinned to `0.2.0-r16`.

## Cellular Coverage

- Independent per-state dataset/card/lifecycle.
- FCC BDC Raw Coverage GeoPackage acquisition for AT&T, Verizon, and T-Mobile.
- In-vehicle coverage only (`environmnt=1`).
- Best-available classes: Voice/3G, LTE, 5G with precedence 5G > LTE > Voice/3G.
- No signal-strength heatmap values.
- Resumable geographic partition preprocessing and PMTiles/MVT output.
- Package format `takrig.cellular.region.v1`; `manifest.json` + `coverage.pmtiles`.
- Protected FCC API credentials in `/etc/takrig-routing/fcc-bdc.env`.
- Dedicated Web controls and independent catalog/download API with HTTP Range/ETag support.
- Atomic READY replacement: a failed update does not remove the last known good Cellular package.

## First target-host validation

California is the first intended live FCC build. After installing r16-r12, configure FCC API credentials, use the California Cellular card to CHECK and BUILD, and record the FCC as-of date, raw cache size, build duration, final package size, class/area counts, and visual agreement with the same FCC release.
