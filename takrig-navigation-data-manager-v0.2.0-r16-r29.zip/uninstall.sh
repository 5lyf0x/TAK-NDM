#!/usr/bin/env bash
set -euo pipefail
if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERROR: run as root: sudo ./uninstall.sh [--purge]" >&2
  exit 1
fi
PURGE=false
[[ "${1:-}" == "--purge" ]] && PURGE=true
systemctl disable --now takrig-routing-scan.timer >/dev/null 2>&1 || true
systemctl stop takrig-routing-scan.service >/dev/null 2>&1 || true
systemctl disable --now takrig-nav-reconcile.timer takrig-nav-manager.service >/dev/null 2>&1 || true
systemctl stop takrig-nav-reconcile.service >/dev/null 2>&1 || true
rm -f /etc/systemd/system/takrig-routing-scan.timer /etc/systemd/system/takrig-routing-scan.service \
  /etc/systemd/system/takrig-nav-reconcile.timer /etc/systemd/system/takrig-nav-reconcile.service \
  /etc/systemd/system/takrig-nav-manager.service
systemctl daemon-reload || true
rm -f /usr/local/bin/takrig-routing /usr/local/bin/takrig-nav-manager
rm -rf /usr/local/lib/takrig-routing
if $PURGE; then
  rm -rf /etc/takrig-routing /var/lib/takrig-routing /var/log/takrig-routing
  userdel takrig-routing >/dev/null 2>&1 || true
  groupdel takrig-routing >/dev/null 2>&1 || true
  echo "Removed Navigation Data Manager, processor, and all routing state (--purge)."
else
  echo "Removed Navigation Data Manager and processor binaries/services. Preserved /etc/takrig-routing, /var/lib/takrig-routing, and /var/log/takrig-routing for reinstall."
fi
