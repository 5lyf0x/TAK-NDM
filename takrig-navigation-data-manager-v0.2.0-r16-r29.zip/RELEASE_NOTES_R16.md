# TAK Rig Navigation Data Manager v0.2.0-r16

R16 is the first TAK Rig Outdoors data-manager release, built from the validated r15 HTTP/Range-delivery baseline.

## Outdoors Map Creator

- Adds Outdoors Maps as a first-class NDM dataset alongside routing and 3D terrain.
- Adds a large interactive area-selection map with State, County, Rectangle, Polygon, and Radius selections. Route Corridor is intentionally not included.
- Uses explicit minimum and maximum zoom values only; there are no zoom presets.
- Adds two live min/max zoom preview maps below the main map, each with a visible scale control.
- Adds Road Only, Offroad Only, and Custom content modes. Custom starts with every component disabled.
- Keeps all POI classes in one package component; TAK Rig owns individual POI visibility at runtime.
- Adds a user-set storage budget in GB and a live component/total estimate. Contours are estimated separately and included in the total. Existing elevation data is not double-counted.
- Map palettes/styles are intentionally absent from NDM. Packages contain neutral data and TAK Rig owns runtime styling.

## Outdoors build/package pipeline

- Uses PMTiles v3 as the component archive format.
- Uses MVT for neutral map vectors and optional contours; hillshade is raster PMTiles.
- Produces `manifest.json`, `components/map.pmtiles`, `components/hillshade.pmtiles`, and optional `components/contours.pmtiles`.
- Reuses NDM's existing state OSM source cache for large builds; small custom selections may use Overpass directly.
- Adds USFS MVUM motorized-route enrichment, PAD-US public-land data, USGS 3DHP/NHD hydrography, and USGS 3DEP hillshade generation.
- Hydro flowlines are clipped at waterbody boundaries before tiling.
- Elevation is not duplicated in Outdoors packages; TAK Rig continues to use the existing NDM elevation dataset.
- Outdoors package/component integrity uses CRC32/ZIP CRC. R16 does not add SHA-256 to the Outdoors contract.

## Delivery and updates

- Publishes ready Outdoors packages through the existing NDM catalog.
- Outdoors downloads use the same HTTP/1.1 Range-capable transfer path as routing/elevation packages.
- Manifests carry stable package IDs, package/component revisions, component sizes and CRC32 metadata so future component-only replacement can be added without changing the package identity model.
- R16 transfers a complete generated Outdoors ZIP for install/update; TAK Rig reuses its existing navigation-data download/progress/pause/resume/retry UX.

## Operational notes

Large State/County or large custom builds need the corresponding state OSM source available in the NDM source cache; the builder reports this requirement instead of silently attempting an impractical Overpass request. Optional contour generation requires configured/generated contour source data. Both behaviors are operator-editable rather than hardcoded to one deployment.
