#!/usr/bin/env python3
from __future__ import annotations

import gzip
import json
import math
import os
import shutil
import uuid
from pathlib import Path
from typing import Any, Iterable

COVERAGE_SCHEMA = "takrig.routing.coverage.v2"
COVERAGE_ZOOM = 11
AUTO_ACCESS = 1
# Valhalla 3.6.3 baldr::Use values that are normally secondary/non-primary vehicle ways.
OFFROAD_USES = {3, 4, 5, 6, 11}  # track, driveway, alley, parking aisle, service road
VEHICLE_USES = set(range(0, 12))
IMPASSABLE_SURFACE = 7


def _clamp_lat(lat: float) -> float:
    return max(-85.05112878, min(85.05112878, float(lat)))


def validate_bounds(bounds: Iterable[Any]) -> tuple[float, float, float, float]:
    values = [float(v) for v in bounds]
    if len(values) != 4:
        raise ValueError("routing coverage bounds must contain [min_lon,min_lat,max_lon,max_lat]")
    min_lon, min_lat, max_lon, max_lat = values
    if not (-180 <= min_lon <= max_lon <= 180 and -90 <= min_lat <= max_lat <= 90):
        raise ValueError(f"invalid routing coverage bounds: {values}")
    return min_lon, min_lat, max_lon, max_lat


def lonlat_to_tile(lon: float, lat: float, zoom: int) -> tuple[int, int]:
    n = 1 << zoom
    x = int(math.floor((float(lon) + 180.0) / 360.0 * n))
    lat_rad = math.radians(_clamp_lat(lat))
    y = int(math.floor((1.0 - math.asinh(math.tan(lat_rad)) / math.pi) / 2.0 * n))
    return max(0, min(n - 1, x)), max(0, min(n - 1, y))


def tile_range(bounds: Iterable[Any], zoom: int = COVERAGE_ZOOM) -> tuple[range, range]:
    min_lon, min_lat, max_lon, max_lat = validate_bounds(bounds)
    min_x, max_y = lonlat_to_tile(min_lon, min_lat, zoom)
    max_x, min_y = lonlat_to_tile(max_lon, max_lat, zoom)
    return range(min_x, max_x + 1), range(min_y, max_y + 1)


def mvt_point_to_lonlat(x: float, y: float, tile_x: int, tile_y: int, zoom: int, extent: int) -> list[float]:
    # Decoder is invoked with y_coord_down=True, so local y follows slippy/MVT top-down coordinates.
    n = float(1 << zoom)
    gx = (tile_x + float(x) / extent) / n
    gy = (tile_y + float(y) / extent) / n
    lon = gx * 360.0 - 180.0
    merc = math.pi * (1.0 - 2.0 * gy)
    lat = math.degrees(math.atan(math.sinh(merc)))
    return [round(lon, 7), round(lat, 7)]


def _convert_line(coords: list[Any], tile_x: int, tile_y: int, zoom: int, extent: int) -> list[list[float]]:
    return [mvt_point_to_lonlat(pt[0], pt[1], tile_x, tile_y, zoom, extent) for pt in coords]


def convert_geometry(geometry: dict[str, Any], tile_x: int, tile_y: int, zoom: int, extent: int) -> dict[str, Any] | None:
    gtype = geometry.get("type")
    coords = geometry.get("coordinates")
    if gtype == "LineString" and isinstance(coords, list):
        line = _convert_line(coords, tile_x, tile_y, zoom, extent)
        return {"type": "LineString", "coordinates": line} if len(line) >= 2 else None
    if gtype == "MultiLineString" and isinstance(coords, list):
        lines = [_convert_line(line, tile_x, tile_y, zoom, extent) for line in coords]
        lines = [line for line in lines if len(line) >= 2]
        return {"type": "MultiLineString", "coordinates": lines} if lines else None
    return None


def classify_edge(properties: dict[str, Any]) -> str | None:
    """Return road/offroad only for edges usable by TAK Rig's automobile navigation profile.

    The static coverage layer intentionally represents graph eligibility, not a promise that an edge
    will be usable at every time. Dynamic/conditional restrictions can still affect a route request.
    """
    fwd = int(properties.get("access:fwd", 0) or 0)
    bwd = int(properties.get("access:bwd", 0) or 0)
    if not ((fwd & AUTO_ACCESS) or (bwd & AUTO_ACCESS)):
        return None
    use = int(properties.get("use", 0) or 0)
    if use not in VEHICLE_USES:
        return None
    surface = int(properties.get("surface", 0) or 0)
    if surface == IMPASSABLE_SURFACE:
        return None
    # Conservative visualization: private/destination-only ways are not advertised as general coverage.
    if bool(properties.get("destonly", False)):
        return None
    unpaved = bool(properties.get("unpaved", False))
    return "offroad" if (use in OFFROAD_USES or unpaved or surface >= 3) else "road"


def compact_feature(feature: dict[str, Any], tile_x: int, tile_y: int, zoom: int, extent: int) -> dict[str, Any] | None:
    props = feature.get("properties") or {}
    if not isinstance(props, dict):
        return None
    cls = classify_edge(props)
    if cls is None:
        return None
    geom = feature.get("geometry") or {}
    if not isinstance(geom, dict):
        return None
    converted = convert_geometry(geom, tile_x, tile_y, zoom, extent)
    if converted is None:
        return None
    out_props = {
        "class": cls,
        "use": int(props.get("use", 0) or 0),
        "unpaved": bool(props.get("unpaved", False)),
        "surface": int(props.get("surface", 0) or 0),
        "road_class": int(props.get("road_class", 0) or 0),
        "access_fwd": bool(int(props.get("access:fwd", 0) or 0) & AUTO_ACCESS),
        "access_bwd": bool(int(props.get("access:bwd", 0) or 0) & AUTO_ACCESS),
    }
    return {"type": "Feature", "geometry": converted, "properties": out_props}


def _write_gzip_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp-{os.getpid()}-{uuid.uuid4().hex[:6]}")
    with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=6) as fh:
        json.dump(data, fh, separators=(",", ":"), ensure_ascii=False)
    os.replace(tmp, path)


def build_routing_coverage(
    config_path: Path,
    bounds: Iterable[Any],
    out_dir: Path,
    logger: Any,
    zoom: int = COVERAGE_ZOOM,
) -> dict[str, Any]:
    try:
        from valhalla import Actor
    except Exception as exc:  # pragma: no cover - exercised on target host
        raise RuntimeError(f"pyvalhalla Actor is unavailable for NAV coverage generation: {exc}") from exc
    try:
        import mapbox_vector_tile
    except Exception as exc:  # pragma: no cover - exercised on target host
        raise RuntimeError(f"mapbox-vector-tile is unavailable for NAV coverage generation: {exc}") from exc

    normalized_bounds = list(validate_bounds(bounds))
    xs, ys = tile_range(normalized_bounds, zoom)
    total_candidates = len(xs) * len(ys)
    if total_candidates <= 0:
        raise RuntimeError("NAV coverage bounds produced no slippy-map tiles")

    if out_dir.exists():
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    actor = Actor(str(config_path))

    tiles: list[dict[str, Any]] = []
    feature_count = road_count = offroad_count = 0
    logger.log(f"Building NAV coverage from Valhalla graph at z{zoom}: {total_candidates} candidate map tiles")

    processed = 0
    for y in ys:
        for x in xs:
            processed += 1
            raw = actor.tile({
                "tile": {"z": zoom, "x": x, "y": y},
                "verbose": True,
                "generalize": 0.0,
                "tile_options": {"exclude_layers": ["nodes", "shortcuts", "access_restrictions"]},
            })
            decoded = mapbox_vector_tile.decode(raw, default_options={"y_coord_down": True})
            edge_layer = decoded.get("edges") or {}
            extent = int(edge_layer.get("extent") or 4096)
            output_features: list[dict[str, Any]] = []
            for feat in edge_layer.get("features") or []:
                compact = compact_feature(feat, x, y, zoom, extent)
                if compact is None:
                    continue
                output_features.append(compact)
                feature_count += 1
                if compact["properties"]["class"] == "offroad":
                    offroad_count += 1
                else:
                    road_count += 1
            if output_features:
                rel = Path(str(zoom)) / str(x) / f"{y}.geojson.gz"
                payload = {
                    "type": "FeatureCollection",
                    "takrig_schema": COVERAGE_SCHEMA,
                    "z": zoom,
                    "x": x,
                    "y": y,
                    "features": output_features,
                }
                path = out_dir / rel
                _write_gzip_json(path, payload)
                tiles.append({
                    "z": zoom, "x": x, "y": y,
                    "path": rel.as_posix(),
                    "features": len(output_features),
                    "bytes": path.stat().st_size,
                })
            if processed % 250 == 0 or processed == total_candidates:
                logger.log(
                    f"NAV coverage: {processed}/{total_candidates} candidate tiles; "
                    f"{len(tiles)} non-empty; {feature_count} vehicle edges"
                )

    if feature_count <= 0 or not tiles:
        raise RuntimeError(
            "Valhalla graph produced no automobile-accessible NAV coverage edges; refusing to publish an empty coverage layer"
        )

    index = {
        "schema": COVERAGE_SCHEMA,
        "generated_from": "valhalla-3.6.3-graph-mvt",
        "zoom": zoom,
        "bounds": normalized_bounds,
        "tile_format": "geojson.gz",
        "tile_path_template": f"{zoom}/{{x}}/{{y}}.geojson.gz",
        "vehicle_access_mask": AUTO_ACCESS,
        "classes": {
            "road": "automobile-accessible normal road edge",
            "offroad": "automobile-accessible track/service/unpaved edge",
        },
        "nonempty_tile_count": len(tiles),
        "feature_count": feature_count,
        "road_feature_count": road_count,
        "offroad_feature_count": offroad_count,
        "tiles": tiles,
        "note": "Static graph eligibility only; time-dependent closures and conditional restrictions can still affect routing.",
    }
    (out_dir / "index.json").write_text(json.dumps(index, indent=2) + "\n", encoding="utf-8")
    logger.log(
        f"NAV coverage complete: {len(tiles)} non-empty tiles, {road_count} road edges, "
        f"{offroad_count} off-road/track edges"
    )
    return index


def verify_coverage_tree(root: Path, index: dict[str, Any] | None = None) -> dict[str, Any]:
    index_path = root / "index.json"
    if index is None:
        if not index_path.is_file():
            raise RuntimeError("Routing package is missing routing_coverage/index.json")
        index = json.loads(index_path.read_text(encoding="utf-8"))
    if index.get("schema") != COVERAGE_SCHEMA:
        raise RuntimeError(f"Unexpected NAV coverage schema: {index.get('schema')!r}")
    tiles = index.get("tiles")
    if not isinstance(tiles, list) or not tiles:
        raise RuntimeError("NAV coverage index contains no non-empty tiles")
    counted = 0
    for item in tiles:
        rel = Path(str(item.get("path") or ""))
        if rel.is_absolute() or ".." in rel.parts or rel.suffixes[-2:] != [".geojson", ".gz"]:
            raise RuntimeError(f"Unsafe/invalid NAV coverage tile path: {rel}")
        path = root / rel
        if not path.is_file() or path.stat().st_size <= 0:
            raise RuntimeError(f"NAV coverage tile is missing/empty: {rel}")
        with gzip.open(path, "rt", encoding="utf-8") as fh:
            data = json.load(fh)
        feats = data.get("features") or []
        if data.get("type") != "FeatureCollection" or not isinstance(feats, list) or not feats:
            raise RuntimeError(f"NAV coverage tile is malformed/empty: {rel}")
        counted += len(feats)
    expected = int(index.get("feature_count") or 0)
    if counted != expected:
        raise RuntimeError(f"NAV coverage feature count mismatch: index={expected}, files={counted}")
    return {
        "schema": COVERAGE_SCHEMA,
        "zoom": int(index.get("zoom") or COVERAGE_ZOOM),
        "tile_count": len(tiles),
        "feature_count": counted,
        "road_feature_count": int(index.get("road_feature_count") or 0),
        "offroad_feature_count": int(index.get("offroad_feature_count") or 0),
    }
