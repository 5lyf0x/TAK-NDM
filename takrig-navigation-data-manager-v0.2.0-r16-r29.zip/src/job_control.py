"""Persistent, per-state checkpoint pause requests for NDM jobs.

Pause is cooperative: a worker commits a safe checkpoint before acknowledging.
A marker survives service restart; Resume removes the marker, never source data.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import uuid
from pathlib import Path
from typing import Any

DOMAINS = frozenset({'navigation', 'terrain', 'cellular'})

class JobPaused(Exception):
    """An orderly user-requested pause, never a failed job."""

def _now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace('+00:00','Z')

def _path(config: Path, domain: str, code: str) -> Path:
    if domain not in DOMAINS or len(code) != 2 or not code.isalpha():
        raise ValueError('Invalid pause target')
    try:
        cfg = json.loads(config.read_text()) if config.is_file() else {}
    except (ValueError, OSError):
        cfg = {}
    root = Path(str(cfg.get('state_root') or '/var/lib/takrig-routing')).expanduser().resolve()
    return root / 'manager' / 'pauses' / domain / f'{code.lower()}.json'

def state(config: Path, domain: str, code: str) -> dict[str, Any]:
    path = _path(config, domain, code)
    try:
        raw = json.loads(path.read_text())
        if isinstance(raw, dict) and raw.get('requested') is True:
            return raw
    except (ValueError, OSError):
        pass
    return {}

def requested(config: Path, domain: str, code: str) -> bool:
    return bool(state(config, domain, code))

def _atomic(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f'{path.name}.tmp-{os.getpid()}-{uuid.uuid4().hex[:6]}')
    try:
        tmp.write_text(json.dumps(row, indent=2) + '\n')
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)

def pause(config: Path, domain: str, code: str, *, idle: bool = False) -> dict[str, Any]:
    path = _path(config, domain, code)
    current = state(config, domain, code)
    if current:
        return current
    row = {'schema':'takrig.ndm.pause.v1', 'domain':domain, 'state_code':code.upper(),
           'requested':True, 'phase':'paused' if idle else 'pausing', 'requested_utc':_now()}
    if idle: row['acknowledged_utc'] = row['requested_utc']
    _atomic(path, row)
    return row

def acknowledge(config: Path, domain: str, code: str) -> None:
    path = _path(config, domain, code)
    current = state(config, domain, code)
    if current and current.get('phase') != 'paused':
        current.update(phase='paused', acknowledged_utc=_now())
        # A resume can remove the file between the read and write, so never
        # recreate it after an explicit resume.
        if path.is_file():
            _atomic(path, current)

def resume(config: Path, domain: str, code: str) -> bool:
    path = _path(config, domain, code)
    existed = path.is_file()
    path.unlink(missing_ok=True)
    return existed

def checkpoint(config: Path, domain: str, code: str) -> None:
    if requested(config, domain, code):
        acknowledge(config, domain, code)
        raise JobPaused(f'{domain.title()} for {code.upper()} paused at a safe checkpoint')

def display(config: Path, domain: str, code: str) -> str:
    row = state(config, domain, code)
    if not row: return ''
    return 'paused' if row.get('phase') == 'paused' else 'pausing'
