#!/usr/bin/env python3
"""TAK Rig NDM FCC Cellular Coverage builder.

r16-r14 uses provider-specific FCC H3 resolution-9 Hexagon Coverage as the
canonical source and publishes a compact random-access H3 coverage binary.
The Android client reconstructs visible hex boundaries from H3 IDs; no FCC
polygon geometry or repeated per-feature metadata is shipped to TAK Rig.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import contextlib
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import sqlite3
import struct
import sys
import tempfile
import threading
import time
import uuid
import zipfile
import zlib
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator, Sequence

HERE=Path(__file__).resolve().parent
if str(HERE) not in sys.path: sys.path.insert(0,str(HERE))

import job_control
from state_catalog import STATES
from fcc_mobile import (
    BdcClient, CredentialsMissing, DEFAULT_API_BASES, STATE_FIPS,
    carrier_from_provider_id, carrier_from_text, credentials_status,
    row_file_id,row_file_name,row_provider_id,row_provider_name,
    select_mobile_sources,sha256_file,utcnow,
)

VERSION="0.2.0-r16-r29"
CELLULAR_PIPELINE_REVISION=3
PACKAGE_FORMAT="takrig.cellular.region.v2"
MANIFEST_SCHEMA="takrig.cellular.manifest.v2"
BINARY_SCHEMA="takrig.cellular.h3.v1"
H3_RESOLUTION=9
DEFAULT_CHUNK_RESOLUTION=6
CARRIERS=("att","verizon","tmobile")
CLASSES=("voice_3g","lte","5g")
SOURCE_CLASSES=("voice","3g","lte","5g")
SOURCE_VARIANTS=("voice","3g","lte","5g_7_1","5g_35_3")
REQUIRED_SOURCE_VARIANTS=("voice","lte","5g_7_1","5g_35_3")
CLASS_CODE={"voice":1,"3g":1,"lte":2,"5g":3}
CODE_CLASS={0:"none",1:"voice_3g",2:"lte",3:"5g"}
ACTIVE_STATUSES={"queued","checking","acquiring","importing","processing","packaging"}
DEFAULT_MIN_FREE_GIB=30.0
CELLULAR_PEAK_HEADROOM_BYTES=6*1024**3

H3_MAGIC=b"TRH3COV1"
H3_FORMAT_VERSION=1
H3_HEADER=struct.Struct("<8sHBBBBHIQQQiiii4x")  # 64 bytes
H3_INDEX=struct.Struct("<QQIIIII4x")             # 40 bytes


def read_json(path:Path,default:Any=None)->Any:
    try:return json.loads(path.read_text(encoding="utf-8"))
    except Exception:return default

def atomic_json(path:Path,data:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+f".tmp-{os.getpid()}-{uuid.uuid4().hex[:8]}")
    tmp.write_text(json.dumps(data,indent=2,sort_keys=False)+"\n",encoding="utf-8");os.replace(tmp,path)

def atomic_text(path:Path,text:str,mode:int|None=None)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+f".tmp-{os.getpid()}-{uuid.uuid4().hex[:8]}")
    tmp.write_text(text,encoding="utf-8")
    if mode is not None: tmp.chmod(mode)
    os.replace(tmp,path)
    if mode is not None: path.chmod(mode)

def roots(config_path:Path)->dict[str,Path]:
    cfg=read_json(config_path,{}) or {};state_root=Path(str(cfg.get("state_root") or "/var/lib/takrig-routing")).expanduser().resolve();root=state_root/"cellular"
    return {"state_root":state_root,"root":root,"cache":root/"cache","work":root/"work","ready":root/"ready","status":root/"status","imports":root/"imports","secrets":state_root/"secrets"}

def ensure_roots(config_path:Path)->dict[str,Path]:
    r=roots(config_path)
    for k in ("root","cache","work","ready","status","imports","secrets"):
        r[k].mkdir(parents=True,exist_ok=True)
    with contextlib.suppress(Exception):r["secrets"].chmod(0o700)
    return r

def status_path(config_path:Path,code:str)->Path:return roots(config_path)["status"]/f"{code.lower()}.json"
def descriptor_path(config_path:Path,code:str)->Path:return roots(config_path)["ready"]/f"{code.lower()}.json"
def selection_path(config_path:Path,code:str)->Path:return roots(config_path)["status"]/f"{code.lower()}-selection.json"
def inventory_path(config_path:Path,code:str)->Path:return roots(config_path)["cache"]/"sources"/f"{code.lower()}.json"
def ui_secret_path(config_path:Path)->Path:return roots(config_path)["secrets"]/"fcc-bdc.env"

def operator_credential_path(config_path:Path)->Path:
    cfg=read_json(config_path,{}) or {}
    return Path(str(cfg.get("fcc_bdc_credentials_file") or "/etc/takrig-routing/fcc-bdc.env")).expanduser()

def credential_paths(config_path:Path)->tuple[Path,...]:
    # Gateway-wide WebUI credentials are authoritative. The optional operator
    # credential file is a fallback only.
    return (ui_secret_path(config_path),operator_credential_path(config_path))

def api_bases(config_path:Path)->tuple[str,...]:
    cfg=read_json(config_path,{}) or {};primary=str(cfg.get("fcc_bdc_api_base") or DEFAULT_API_BASES[0]).strip().rstrip("/");fallback=str(cfg.get("fcc_bdc_api_fallback") or DEFAULT_API_BASES[1]).strip().rstrip("/")
    return tuple(x for x in (primary,fallback) if x)

def chunk_resolution(config_path:Path)->int:
    cfg=read_json(config_path,{}) or {}
    return max(0,min(H3_RESOLUTION,int(cfg.get("cellular_h3_chunk_resolution",DEFAULT_CHUNK_RESOLUTION))))

def web_secret_management_allowed(config_path:Path)->bool:
    cfg=read_json(config_path,{}) or {}
    return bool(cfg.get("allow_web_secret_management",True))

def update_status(config_path:Path,code:str,status:str,stage:str,detail:str="",**extra:Any)->dict[str,Any]:
    row=read_json(status_path(config_path,code),{}) or {}
    row.update({"state_code":code.upper(),"state_name":STATES[code.upper()].name,"status":status,"stage":stage,"detail":detail,"updated_utc":utcnow()});row.update(extra)
    if (status in ACTIVE_STATUSES or status in {"ready", "ready_to_build"}) and "error" not in extra:
        row.pop("error",None)
    atomic_json(status_path(config_path,code),row);return row

def ready_descriptor(config_path:Path,code:str)->dict[str,Any]|None:
    d=read_json(descriptor_path(config_path,code),None)
    if not isinstance(d,dict):return None
    pkg=roots(config_path)["ready"]/str(d.get("package") or "")
    return d if pkg.is_file() else None

def package_path(config_path:Path,code:str)->Path|None:
    d=ready_descriptor(config_path,code);return roots(config_path)["ready"]/str(d.get("package")) if d else None

# ---------- carrier selection / credentials ----------
def carrier_selection(config_path:Path,code:str)->list[str]:
    row=read_json(selection_path(config_path,code),{}) or {};vals=row.get("carriers")
    if not isinstance(vals,list):return list(CARRIERS)
    out=[c for c in CARRIERS if c in vals]
    return out or list(CARRIERS)

def save_carrier_selection(config_path:Path,code:str,values:Sequence[str])->list[str]:
    selected=[c for c in CARRIERS if c in {str(v).strip().lower() for v in values}]
    if not selected:raise ValueError("Select at least one Cellular carrier")
    atomic_json(selection_path(config_path,code),{"state_code":code.upper(),"carriers":selected,"updated_utc":utcnow()});return selected

def source_status(config_path:Path)->dict[str,Any]:
    row=credentials_status(credential_paths(config_path));row["web_secret_management_allowed"]=web_secret_management_allowed(config_path);return row

def save_api_credentials(config_path:Path,username:str,token:str)->dict[str,Any]:
    if not web_secret_management_allowed(config_path):raise PermissionError("Web FCC credential management is disabled by NDM configuration")
    username=str(username or "").strip();token=str(token or "").strip()
    if not username or not token:raise ValueError("FCC username and API token are required")
    if len(token)<20:raise ValueError("FCC API token is unexpectedly short")
    path=ui_secret_path(config_path);ensure_roots(config_path)
    atomic_text(path,f"# TAK Rig NDM Web-managed FCC BDC credentials\nFCC_BDC_USERNAME={username}\nFCC_BDC_HASH_VALUE={token}\n",0o600)
    return source_status(config_path)

def clear_api_credentials(config_path:Path)->dict[str,Any]:
    if not web_secret_management_allowed(config_path):raise PermissionError("Web FCC credential management is disabled by NDM configuration")
    ui_secret_path(config_path).unlink(missing_ok=True);return source_status(config_path)

def test_api_credentials(config_path:Path,username:str="",token:str="")->dict[str,Any]:
    if username and token:client=BdcClient(None,api_bases(config_path),timeout=20,username=username,hash_value=token)
    else:client=BdcClient(credential_paths(config_path),api_bases(config_path),timeout=20)
    dates=client.list_as_of_dates()
    return {"ok":True,"api_base":client.active_base,"latest_as_of":dates[-1] if dates else "","as_of_dates":dates[-12:]}

def api_releases(config_path:Path)->list[str]:
    client=BdcClient(credential_paths(config_path),api_bases(config_path),timeout=20);return client.list_as_of_dates()

# ---------- inventory ----------
def _legacy_variant(rec:dict[str,Any])->str:
    variant=str(rec.get("source_variant") or "").strip()
    if variant:return variant
    klass=str(rec.get("source_class") or "").strip()
    if klass in {"voice","3g","lte"}:return klass
    if klass=="5g":
        text=" ".join(str(rec.get(k) or "") for k in ("original_filename","source_filename","gpkg")).lower()
        if re.search(r"5g(?:nr)?[_ -]*7[_ /-]*1(?:[_ .-]|$)",text):return "5g_7_1"
        if re.search(r"5g(?:nr)?[_ -]*35[_ /-]*3(?:[_ .-]|$)",text):return "5g_35_3"
    return klass

def _inventory(config_path:Path,code:str)->dict[str,Any]:
    row=read_json(inventory_path(config_path,code),{}) or {}
    records=row.get("records") if isinstance(row.get("records"),list) else []
    cleaned=[];changed=False
    for raw in records:
        if not isinstance(raw,dict):continue
        rec=dict(raw);variant=_legacy_variant(rec)
        if variant and rec.get("source_variant")!=variant:
            rec["source_variant"]=variant;changed=True
        cleaned.append(rec)
    out={"schema":"takrig.cellular.sources.v1","state_code":code.upper(),"records":cleaned}
    if changed:_save_inventory(config_path,code,out)
    return out

def _save_inventory(config_path:Path,code:str,row:dict[str,Any])->None:
    row=dict(row);row["schema"]="takrig.cellular.sources.v1";row["state_code"]=code.upper();row["updated_utc"]=utcnow();atomic_json(inventory_path(config_path,code),row)

def _relative_to_root(config_path:Path,path:Path)->str:
    try:return str(path.resolve().relative_to(roots(config_path)["state_root"]))
    except Exception:return str(path.resolve())

def _inventory_file(config_path:Path,value:str)->Path:
    p=Path(str(value or ""))
    return p if p.is_absolute() else roots(config_path)["state_root"]/p

def _register_records(config_path:Path,code:str,new_records:list[dict[str,Any]])->dict[str,Any]:
    inv=_inventory(config_path,code);rows=list(inv["records"])
    # Official provider-specific H3 downloads are one logical source per
    # carrier / source variant / availability vintage. Re-importing a corrected
    # copy of that same logical source replaces the older cached record rather
    # than silently unioning stale and current cells. Exact content remains
    # idempotent. Provider ID is preferred because brand labels can change.
    def logical_key(rec:dict[str,Any])->tuple[str,str,str,str]:
        provider=str(rec.get("provider_id") or rec.get("provider_name") or "").strip().lower()
        variant=str(rec.get("source_variant") or rec.get("source_class") or "")
        return (str(rec.get("carrier") or ""),variant,str(rec.get("as_of") or ""),provider)
    replaced=[]
    for rec in new_records:
        key=logical_key(rec)
        keep=[]
        for old in rows:
            if str(old.get("id"))==str(rec.get("id")):
                continue
            if key[3] and logical_key(old)==key:
                replaced.append(old);continue
            keep.append(old)
        rows=keep+[rec]
    inv["records"]=sorted(rows,key=lambda r:(str(r.get("as_of")),str(r.get("carrier")),str(r.get("source_variant") or r.get("source_class")),str(r.get("id"))))
    _save_inventory(config_path,code,inv)
    active_paths={str(r.get("gpkg") or "") for r in inv["records"]}
    for old in replaced:
        if str(old.get("gpkg") or "") in active_paths:continue
        p=_inventory_file(config_path,str(old.get("gpkg") or ""))
        with contextlib.suppress(Exception):shutil.rmtree(p.parent,ignore_errors=True)
    return inv

def remove_source(config_path:Path,code:str,source_id:str)->bool:
    inv=_inventory(config_path,code);before=len(inv["records"]);removed=[r for r in inv["records"] if str(r.get("id"))==str(source_id)];inv["records"]=[r for r in inv["records"] if str(r.get("id"))!=str(source_id)]
    if removed:_save_inventory(config_path,code,inv)
    # Cached source directories are content-addressed; remove only the source's own cache dir.
    for rec in removed:
        p=_inventory_file(config_path,str(rec.get("gpkg") or ""));
        with contextlib.suppress(Exception):shutil.rmtree(p.parent,ignore_errors=True)
    return len(inv["records"])<before

def _source_set(config_path:Path,code:str)->dict[str,Any]:
    selected=carrier_selection(config_path,code);records=_inventory(config_path,code)["records"]
    by_vintage:dict[str,list[dict[str,Any]]]={}
    for rec in records:
        if rec.get("carrier") in selected and rec.get("as_of"):by_vintage.setdefault(str(rec["as_of"]),[]).append(rec)
    vintages=sorted(by_vintage,reverse=True)
    def summarize(vintage:str)->dict[str,Any]:
        rows=by_vintage.get(vintage,[]);carrier_state={};complete=True
        for carrier in selected:
            carrier_rows=[r for r in rows if r.get("carrier")==carrier]
            classes={str(r.get("source_class")) for r in carrier_rows}
            variants={str(r.get("source_variant") or r.get("source_class")) for r in carrier_rows}
            missing=sorted(set(REQUIRED_SOURCE_VARIANTS)-variants);optional_3g="3g" not in variants
            if missing:complete=False
            carrier_state[carrier]={"status":"ready" if not missing else "incomplete","classes":sorted(classes),"variants":sorted(variants),"required_missing":missing,"optional_3g_missing":optional_3g}
        return {"as_of":vintage,"records":rows,"carrier_status":carrier_state,"complete":complete}
    candidates=[summarize(v) for v in vintages];chosen=next((x for x in candidates if x["complete"]),candidates[0] if candidates else {"as_of":"","records":[],"carrier_status":{c:{"status":"incomplete","classes":[],"variants":[],"required_missing":list(REQUIRED_SOURCE_VARIANTS),"optional_3g_missing":True} for c in selected},"complete":False})
    resolutions=sorted({int(r.get("h3_resolution") or 0) for r in chosen["records"] if r.get("h3_resolution")})
    if chosen["records"] and resolutions!=[H3_RESOLUTION]:chosen["complete"]=False;chosen["resolution_error"]=f"Cellular sources must all be FCC H3 resolution {H3_RESOLUTION}; found {resolutions}"
    chosen["selected_carriers"]=selected;chosen["available_vintages"]=vintages;chosen["other_vintages"]=[v for v in vintages if v!=chosen.get("as_of")]
    chosen["source_fingerprint"]=_source_fingerprint(code,chosen) if chosen.get("records") else ""
    return chosen

def _source_fingerprint(code:str,source_set:dict[str,Any])->str:
    rows=[{"id":r.get("id"),"sha256":r.get("sha256"),"carrier":r.get("carrier"),"class":r.get("source_class"),"variant":r.get("source_variant") or r.get("source_class"),"as_of":r.get("as_of"),"h3_resolution":r.get("h3_resolution")} for r in source_set.get("records",[])]
    obj={"pipeline":CELLULAR_PIPELINE_REVISION,"binary":BINARY_SCHEMA,"state":code.upper(),"carriers":source_set.get("selected_carriers") or [],"as_of":source_set.get("as_of"),"sources":sorted(rows,key=lambda x:(str(x["carrier"]),str(x["variant"]),str(x["id"])))}
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(",",":")).encode()).hexdigest()

def source_inventory_summary(config_path:Path,code:str)->dict[str,Any]:
    ss=_source_set(config_path,code);rows=[]
    for rec in _inventory(config_path,code)["records"]:
        rows.append({k:rec.get(k) for k in ("id","original_filename","carrier","source_class","source_variant","as_of","provider_id","provider_name","frn","size_bytes","sha256","h3_resolution","env1_count","provenance","imported_utc")})
    return {"selected_carriers":ss["selected_carriers"],"active_as_of":ss.get("as_of") or "","ready_to_build":bool(ss.get("complete")),"carrier_status":ss.get("carrier_status") or {},"available_vintages":ss.get("available_vintages") or [],"other_vintages":ss.get("other_vintages") or [],"source_fingerprint":ss.get("source_fingerprint") or "","resolution_error":ss.get("resolution_error") or "","records":rows}

# ---------- H3 GeoPackage inspection/import ----------
def _quote_ident(value:str)->str:return '"'+str(value).replace('"','""')+'"'

def _feature_tables(db:sqlite3.Connection)->list[str]:
    try:return [str(r[0]) for r in db.execute("SELECT table_name FROM gpkg_contents WHERE data_type='features'")]
    except sqlite3.Error:return []

def _columns(db:sqlite3.Connection,table:str)->dict[str,str]:
    return {str(r[1]).lower():str(r[1]) for r in db.execute(f"PRAGMA table_info({_quote_ident(table)})")}

def _filename_as_of(name:str)->str:
    m=re.search(r"(?:^|[_-])([DJ])(\d{2})(?:[_-]|$)",str(name),re.I)
    if not m:return ""
    year=2000+int(m.group(2));return f"{year}-12-31" if m.group(1).upper()=="D" else f"{year}-06-30"

def _filename_provider_id(name:str)->str:
    m=re.search(r"bdc_\d{2}_(\d{6})_",str(name),re.I);return m.group(1) if m else ""

def _filename_state_fips(name:str)->str:
    m=re.search(r"bdc_(\d{2})_",str(name),re.I);return m.group(1) if m else ""

def _infer_class(text:str,technology_values:Sequence[Any])->str:
    t=str(text or "").lower()
    if "mobilevoice" in t or "mobile_voice" in t or re.search(r"\bmobile[ -]?voice\b",t):return "voice"
    vals={str(v) for v in technology_values if v is not None}
    classes=set()
    if "300" in vals or re.search(r"(?:^|[_-])3g(?:[_-]|$)",t):classes.add("3g")
    if "400" in vals or "lte" in t or "4g" in t:classes.add("lte")
    if "500" in vals or "5gnr" in t or "5g" in t:classes.add("5g")
    if len(classes)==1:return next(iter(classes))
    if not classes:raise ValueError("Unable to determine FCC mobile technology from H3 dataset")
    raise ValueError(f"H3 dataset unexpectedly mixes mobile technology classes: {sorted(classes)}")

def _infer_variant(text:str,source_class:str,speed_pairs:Sequence[tuple[Any,Any]])->str:
    if source_class in {"voice","3g","lte"}:return source_class
    t=str(text or "").lower();tiers=set()
    for down,up in speed_pairs:
        try:d=float(down);u=float(up)
        except (TypeError,ValueError):continue
        if abs(d-7.0)<1e-6 and abs(u-1.0)<1e-6:tiers.add("5g_7_1")
        if abs(d-35.0)<1e-6 and abs(u-3.0)<1e-6:tiers.add("5g_35_3")
    if re.search(r"5g(?:nr)?[_ -]*7[_ /-]*1(?:[_ .-]|$)",t):tiers.add("5g_7_1")
    if re.search(r"5g(?:nr)?[_ -]*35[_ /-]*3(?:[_ .-]|$)",t):tiers.add("5g_35_3")
    if len(tiers)==1:return next(iter(tiers))
    if not tiers:raise ValueError("Unable to determine FCC 5G speed tier; expected 5G 7/1 or 5G 35/3 Hexagon Coverage")
    raise ValueError(f"FCC H3 dataset unexpectedly mixes 5G speed tiers: {sorted(tiers)}")

def h3_resolution_int(index:int)->int:return int((int(index)>>52)&0xF)

def h3_parent_int(index:int,parent_resolution:int)->int:
    index=int(index);res=h3_resolution_int(index);parent_resolution=int(parent_resolution)
    if parent_resolution<0 or parent_resolution>res:raise ValueError("Invalid H3 parent resolution")
    index=(index & ~(0xF<<52)) | (parent_resolution<<52)
    unused=3*(15-parent_resolution)
    if unused:index=(index & ~((1<<unused)-1)) | ((1<<unused)-1)
    return index

def _parse_h3(value:Any)->int:
    s=str(value or "").strip().lower().removeprefix("0x")
    if not re.fullmatch(r"[0-9a-f]{15,16}",s):raise ValueError(f"Invalid FCC H3 cell ID: {value}")
    idx=int(s,16)
    if h3_resolution_int(idx)!=H3_RESOLUTION:raise ValueError(f"Expected H3 resolution {H3_RESOLUTION}, got {h3_resolution_int(idx)}")
    return idx

def inspect_h3_gpkg(path:Path,original_filename:str,state_code:str,*,carrier_hint:str="",class_hint:str="",as_of_hint:str="") -> dict[str,Any]:
    if not path.is_file():raise ValueError("GeoPackage does not exist")
    db=sqlite3.connect(f"file:{path}?mode=ro",uri=True);db.row_factory=sqlite3.Row
    try:
        tables=_feature_tables(db)
        if not tables:raise ValueError("File is not an FCC feature GeoPackage")
        candidates=[]
        for table in tables:
            cols=_columns(db,table);h3_cols=[actual for low,actual in cols.items() if re.fullmatch(r"h3_res\d+_id",low)]
            if not h3_cols:continue
            h3_col=next((c for c in h3_cols if c.lower()==f"h3_res{H3_RESOLUTION}_id"),h3_cols[0]);m=re.search(r"res(\d+)",h3_col.lower());res=int(m.group(1)) if m else 0
            env_col=cols.get("environmnt") or cols.get("environment")
            if not env_col:raise ValueError("FCC H3 dataset is missing environmnt/environment")
            env1=int(db.execute(f"SELECT COUNT(*) FROM {_quote_ident(table)} WHERE {_quote_ident(env_col)}=1").fetchone()[0])
            if env1<=0:raise ValueError("FCC H3 dataset has no environmnt=1 in-vehicle coverage")
            tech_col=cols.get("technology");tech=[]
            if tech_col:
                tech=[r[0] for r in db.execute(f"SELECT DISTINCT {_quote_ident(tech_col)} FROM {_quote_ident(table)} WHERE {_quote_ident(env_col)}=1 LIMIT 16")]
            down_col=cols.get("mindown") or cols.get("min_down");up_col=cols.get("minup") or cols.get("min_up");speed_pairs=[]
            if down_col and up_col:
                speed_pairs=[(r[0],r[1]) for r in db.execute(f"SELECT DISTINCT {_quote_ident(down_col)},{_quote_ident(up_col)} FROM {_quote_ident(table)} WHERE {_quote_ident(env_col)}=1 LIMIT 16")]
            text=" ".join((original_filename,path.name,table));source_class=_infer_class(text,tech);source_variant=_infer_variant(text,source_class,speed_pairs)
            if class_hint and source_class!=class_hint:raise ValueError(f"FCC source class mismatch: expected {class_hint}, detected {source_class}")
            brand_col=cols.get("brandname") or cols.get("brand_name");pid_col=cols.get("providerid") or cols.get("provider_id");frn_col=cols.get("frn")
            wanted=[c for c in (pid_col,brand_col,frn_col,h3_col) if c]
            sample=db.execute(f"SELECT {','.join(_quote_ident(c) for c in wanted)} FROM {_quote_ident(table)} WHERE {_quote_ident(env_col)}=1 LIMIT 32").fetchall()
            pids=set();brands=set();frns=set();h3s=[]
            for row in sample:
                d={wanted[i]:row[i] for i in range(len(wanted))}
                if pid_col and d.get(pid_col) not in (None,""):pids.add(str(d[pid_col]))
                if brand_col and d.get(brand_col) not in (None,""):brands.add(str(d[brand_col]))
                if frn_col and d.get(frn_col) not in (None,""):frns.add(str(d[frn_col]))
                h3s.append(_parse_h3(d[h3_col]))
            carrier=""
            for brand in brands:
                c=carrier_from_text(brand)
                if c:carrier=c;break
            if not carrier:
                for pid in pids:
                    c=carrier_from_provider_id(pid)
                    if c:carrier=c;break
            fname_pid=_filename_provider_id(original_filename) or _filename_provider_id(path.name)
            if not carrier and fname_pid:carrier=carrier_from_provider_id(fname_pid) or ""
            if carrier_hint:
                if carrier and carrier!=carrier_hint:raise ValueError(f"FCC provider mismatch: expected {carrier_hint}, detected {carrier}")
                carrier=carrier_hint
            if not carrier:raise ValueError("Unable to identify AT&T, Verizon, or T-Mobile from the FCC provider-specific H3 file")
            state_fips=_filename_state_fips(original_filename) or _filename_state_fips(path.name);expected=STATE_FIPS.get(state_code.upper(),"")
            if state_fips and expected and state_fips!=expected:raise ValueError(f"FCC file state FIPS {state_fips} does not match {state_code.upper()} ({expected})")
            as_of=_filename_as_of(original_filename) or _filename_as_of(path.name) or str(as_of_hint or "")
            if as_of_hint and as_of and as_of!=as_of_hint:raise ValueError(f"FCC availability vintage mismatch: file {as_of}, selected {as_of_hint}")
            if not as_of:raise ValueError("Unable to determine FCC Availability Data As Of vintage from the official file name")
            extent=None
            with contextlib.suppress(Exception):
                r=db.execute("SELECT min_x,min_y,max_x,max_y FROM gpkg_contents WHERE table_name=?",(table,)).fetchone()
                if r and all(v is not None for v in r):extent=[float(v) for v in r]
            geom_type=""
            try:
                rr=db.execute("SELECT geometry_type_name,srs_id FROM gpkg_geometry_columns WHERE table_name=?",(table,)).fetchone()
            except sqlite3.Error:
                rr=None
            if rr:
                geom_type=str(rr[0] or "")
                if int(rr[1]) not in (4326,0):
                    raise ValueError(f"FCC H3 GeoPackage must use EPSG:4326; found {rr[1]}")
            if res!=H3_RESOLUTION:raise ValueError(f"FCC H3 input must be resolution {H3_RESOLUTION}; found {res}")
            candidates.append({"table":table,"h3_column":h3_col,"environment_column":env_col,"h3_resolution":res,"source_class":source_class,"source_variant":source_variant,"carrier":carrier,"provider_id":next(iter(pids),fname_pid),"provider_name":next(iter(brands),""),"frn":next(iter(frns),""),"as_of":as_of,"env1_count":env1,"extent":extent,"geometry_type":geom_type,"technology_values":[str(x) for x in tech],"speed_pairs":[[x[0],x[1]] for x in speed_pairs]})
        if not candidates:
            raise ValueError("This GeoPackage is not FCC Hexagon Coverage. Download Hexagon Coverage – GeoPackage, not Raw Coverage.")
        # Official download should contain one H3 feature layer. Multiple compatible layers are allowed only if same identity/class.
        first=candidates[0]
        for c in candidates[1:]:
            for key in ("carrier","source_class","source_variant","as_of","h3_resolution"):
                if c[key]!=first[key]:raise ValueError("GeoPackage contains incompatible H3 feature layers")
        first["layers"]=[c["table"] for c in candidates];first["layer_details"]=candidates;first["env1_count"]=sum(int(c["env1_count"]) for c in candidates)
        return first
    finally:db.close()

def _extract_gpkgs(archive:Path,target:Path)->list[Path]:
    target.mkdir(parents=True,exist_ok=True)
    with archive.open("rb") as fh:magic=fh.read(4)
    if magic==b"PK\x03\x04":
        with zipfile.ZipFile(archive,"r") as zf:
            safe=[n for n in zf.namelist() if n.lower().endswith(".gpkg") and not n.startswith(("/","\\")) and ".." not in Path(n).parts]
            if not safe:raise ValueError("FCC ZIP did not contain a GeoPackage")
            for n in safe:
                dest=target/Path(n).name
                if not dest.is_file() or dest.stat().st_size!=zf.getinfo(n).file_size:
                    with zf.open(n) as src,dest.open("wb") as out:shutil.copyfileobj(src,out,2*1024*1024)
    elif archive.suffix.lower()==".gpkg" or magic==b"SQLite format 3\x00"[:4]:
        dest=target/(archive.name if archive.suffix.lower()==".gpkg" else archive.stem+".gpkg");shutil.copy2(archive,dest)
    else:raise ValueError("Supported FCC imports are official .zip archives or .gpkg files")
    return sorted(target.glob("*.gpkg"))

def import_uploaded(config_path:Path,code:str,uploaded:Path,original_filename:str,*,carrier_hint:str="",as_of_hint:str="",provenance:str="manual",api_meta:dict[str,Any]|None=None,sha256_hint:str="")->list[dict[str,Any]]:
    code=code.upper();ensure_roots(config_path);sha=str(sha256_hint or "").strip().lower() or sha256_file(uploaded)
    if not re.fullmatch(r"[0-9a-f]{64}",sha):raise ValueError("FCC source SHA-256 is invalid")
    cache=roots(config_path)["cache"]/provenance/code.lower()/sha[:20];cache.mkdir(parents=True,exist_ok=True)
    source=cache/("source"+uploaded.suffix.lower());
    if not source.is_file():shutil.copy2(uploaded,source)
    gpkgs=_extract_gpkgs(source,cache/"extracted");records=[]
    selected=set(carrier_selection(config_path,code))
    for gpkg in gpkgs:
        info=inspect_h3_gpkg(gpkg,original_filename,code,carrier_hint=carrier_hint,class_hint=str((api_meta or {}).get("class") or ""),as_of_hint=as_of_hint)
        variant_hint=str((api_meta or {}).get("variant") or "")
        if variant_hint and info.get("source_variant")!=variant_hint:raise ValueError(f"FCC source variant mismatch: expected {variant_hint}, detected {info.get('source_variant')}")
        if info["carrier"] not in selected:
            raise ValueError(f"{info['carrier'].upper()} is not selected on the {code} Cellular card; select that carrier before importing its FCC data")
        rid=hashlib.sha256((sha+"|"+gpkg.name+"|"+info["table"]+"|"+info["carrier"]+"|"+info["source_variant"]).encode()).hexdigest()[:24]
        records.append({"id":rid,"state_code":code,"original_filename":Path(original_filename).name,"source_filename":source.name,"gpkg":_relative_to_root(config_path,gpkg),"carrier":info["carrier"],"source_class":info["source_class"],"source_variant":info["source_variant"],"as_of":info["as_of"],"provider_id":info.get("provider_id") or str((api_meta or {}).get("provider_id") or ""),"provider_name":info.get("provider_name") or str((api_meta or {}).get("provider_name") or ""),"frn":info.get("frn") or "","h3_resolution":info["h3_resolution"],"layers":info["layers"],"h3_column":info["h3_column"],"environment_column":info["environment_column"],"env1_count":info["env1_count"],"extent":info.get("extent"),"size_bytes":source.stat().st_size,"sha256":sha,"provenance":provenance,"imported_utc":utcnow(),"api_file_id":str((api_meta or {}).get("file_id") or "")})
    _register_records(config_path,code,records);return records

# ---------- API discovery/acquisition ----------
def _manifest_source_rows(selected:dict[str,list[dict[str,Any]]])->list[dict[str,Any]]:
    rows=[];seen=set()
    for carrier in CARRIERS:
        for row in selected.get(carrier,[]):
            fid=row_file_id(row);key=(carrier,row.get("_takrig_variant") or row.get("_takrig_class"),fid)
            if key in seen:continue
            seen.add(key);rows.append({"carrier":carrier,"class":row.get("_takrig_class"),"variant":row.get("_takrig_variant") or row.get("_takrig_class"),"file_id":fid,"file_name":row_file_name(row),"provider_id":row_provider_id(row),"provider_name":row_provider_name(row)})
    return sorted(rows,key=lambda x:(x["carrier"],str(x["variant"]),str(x["file_id"])))

def discover_api(config_path:Path,code:str,as_of:str="")->dict[str,Any]:
    code=code.upper();selected_carriers=carrier_selection(config_path,code);client=BdcClient(credential_paths(config_path),api_bases(config_path),timeout=30)
    dates=client.list_as_of_dates()
    if not dates:raise RuntimeError("FCC BDC API returned no availability as-of dates")
    if as_of and as_of not in dates:raise ValueError(f"FCC availability release {as_of} is not available")
    as_of=as_of or dates[-1];rows=client.list_availability(as_of);selected=select_mobile_sources(rows,code,selected_carriers);src_rows=_manifest_source_rows(selected)
    availability={}
    for carrier in selected_carriers:
        rows_for_carrier=selected.get(carrier,[]);classes={str(r.get("_takrig_class")) for r in rows_for_carrier};variants={str(r.get("_takrig_variant") or r.get("_takrig_class")) for r in rows_for_carrier};availability[carrier]={"classes":sorted(classes),"variants":sorted(variants),"required_missing":sorted(set(REQUIRED_SOURCE_VARIANTS)-variants),"optional_3g_missing":"3g" not in variants}
    return {"as_of":as_of,"selected":selected,"sources":src_rows,"availability":availability,"api_base":client.active_base or api_bases(config_path)[0],"selected_carriers":selected_carriers}

def check(config_path:Path,code:str)->dict[str,Any]:
    code=code.upper();job_control.checkpoint(config_path,"cellular",code);inv=source_inventory_summary(config_path,code)
    if not source_status(config_path).get("configured"):
        status="ready_to_build" if inv["ready_to_build"] else ("sources_incomplete" if inv["records"] else "no_sources")
        return update_status(config_path,code,status,"acquisition", "FCC API not configured; manual Hexagon Coverage import is available",source_inventory=inv)
    update_status(config_path,code,"checking","checking","Checking FCC BDC provider-specific Hexagon Coverage")
    try:
        d=discover_api(config_path,code);detail="FCC API Hexagon Coverage is available"
        return update_status(config_path,code,"ready_to_build" if inv["ready_to_build"] else "sources_incomplete","check_complete",detail,fcc_as_of=d["as_of"],api_available=d,source_inventory=inv,acquisition_error="",progress={})
    except Exception as exc:
        # API/auth problems are acquisition state, never a package-build failure.
        return update_status(config_path,code,"sources_incomplete" if inv["records"] else "no_sources","api_check_failed","FCC API check failed; manual import remains available",acquisition_error=str(exc),source_inventory=inv)

def acquire_api_sources(config_path:Path,code:str,as_of:str="",progress:Callable[[dict[str,Any]],None]|None=None)->dict[str,Any]:
    code=code.upper()
    job_control.checkpoint(config_path,"cellular",code)
    try:
        disc=discover_api(config_path,code,as_of)
    except Exception as exc:
        inv=source_inventory_summary(config_path,code)
        update_status(config_path,code,"sources_incomplete" if inv["records"] else "no_sources","api_acquire_failed","FCC API acquisition failed",acquisition_error=str(exc),source_inventory=inv,progress={"percent":0,"failed":True})
        raise

    r=ensure_roots(config_path)
    rows=[]
    for carrier in disc["selected_carriers"]:
        for row in disc["selected"].get(carrier,[]):
            rows.append((carrier,row))
    if not rows:
        inv=source_inventory_summary(config_path,code)
        msg=f"FCC API returned no matching provider-specific mobile Hexagon Coverage for {code} in {disc['as_of']}"
        update_status(config_path,code,"sources_incomplete" if inv["records"] else "no_sources","api_manifest_empty",msg,acquisition_error=msg,source_inventory=inv,fcc_as_of=disc["as_of"],api_available=disc,progress={"percent":0,"failed":True})
        raise RuntimeError(msg)

    cfg=read_json(config_path,{}) or {}
    try: workers=int(cfg.get("cellular_download_concurrency",4))
    except Exception: workers=4
    # Four parallel FCC payloads is the default. Allow up to six when explicitly
    # configured. Do not apply the routing-source per-host semaphore here; FCC
    # payload requests already honor Retry-After/429 in BdcClient.download_file().
    workers=max(1,min(6,workers))
    total=len(rows)
    state_lock=threading.Lock()
    file_progress={i:{"downloaded":0,"total":0,"done":False,"cached":False} for i in range(total)}
    last_emit=[0.0]
    started=time.monotonic()

    def emit(force:bool=False,active:dict[str,Any]|None=None)->None:
        now=time.monotonic()
        with state_lock:
            if not force and now-last_emit[0] < 0.5:
                return
            last_emit[0]=now
            fractions=[]; downloaded=0; known_total=0; finished=0; cached=0
            for st in file_progress.values():
                n=max(0,int(st.get("downloaded") or 0)); size=max(0,int(st.get("total") or 0))
                downloaded += n
                if size>0:
                    known_total += size
                    fractions.append(min(1.0,n/size))
                else:
                    fractions.append(1.0 if st.get("done") else 0.0)
                if st.get("done"): finished += 1
                if st.get("cached"): cached += 1
            pct=80.0*(sum(fractions)/max(1,total))
            elapsed=max(0.001,now-started)
            info={"phase":"download","file_total":total,"files_finished":finished,"files_cached":cached,
                  "downloaded_bytes":downloaded,"total_bytes":known_total,"workers":workers,
                  "elapsed_seconds":round(elapsed,1),"bytes_per_second":int(downloaded/elapsed),"percent":round(pct,1)}
            if active: info.update(active)
        update_status(config_path,code,"acquiring","acquiring",f"Downloading FCC Hexagon Coverage · {finished}/{total} files",fcc_as_of=disc["as_of"],progress=info,acquisition_error="")
        if progress: progress(info)

    def download_one(item:tuple[int,tuple[str,dict[str,Any]]])->tuple[int,str,dict[str,Any],Path,str]:
        index,(carrier,row)=item
        fid=row_file_id(row); name=row_file_name(row)
        cache=r["cache"]/"api-downloads"/disc["as_of"]/fid; cache.mkdir(parents=True,exist_ok=True)
        archive=cache/"source.zip"
        variant=row.get("_takrig_variant") or row.get("_takrig_class")
        if archive.is_file() and archive.stat().st_size>0:
            with state_lock:
                file_progress[index]={"downloaded":archive.stat().st_size,"total":archive.stat().st_size,"done":True,"cached":True}
            emit(True,{"carrier":carrier,"variant":variant,"file_index":index+1})
            return index,carrier,row,archive,name

        client=BdcClient(credential_paths(config_path),api_bases(config_path),timeout=30)
        def p(n:int,size:int,elapsed:float):
            with state_lock:
                st=file_progress[index]; st["downloaded"]=n; st["total"]=size
            emit(False,{"carrier":carrier,"variant":variant,"file_index":index+1,
                        "file_downloaded_bytes":n,"file_total_bytes":size})
        client.download_file(fid,archive,file_type=2,progress=p)
        with state_lock:
            size=archive.stat().st_size if archive.is_file() else 0
            file_progress[index]={"downloaded":size,"total":size,"done":True,"cached":False}
        emit(True,{"carrier":carrier,"variant":variant,"file_index":index+1})
        return index,carrier,row,archive,name

    update_status(config_path,code,"acquiring","acquiring",f"Acquiring FCC Hexagon Coverage · {disc['as_of']} · {workers} parallel downloads",fcc_as_of=disc["as_of"],progress={"phase":"download","percent":0,"file_total":total,"files_finished":0,"workers":workers},acquisition_error="")

    downloaded=[]
    # Schedule in bounded batches so a pause never queues the entire state.
    # Finished files remain cached and are reused on resume.
    for start in range(0,len(rows),workers):
        job_control.checkpoint(config_path,"cellular",code)
        batch=list(enumerate(rows))[start:start+workers]
        try:
            if len(batch)==1:
                downloaded.append(download_one(batch[0]))
            else:
                with concurrent.futures.ThreadPoolExecutor(max_workers=len(batch),thread_name_prefix="takrig-fcc") as pool:
                    futures=[pool.submit(download_one,item) for item in batch]
                    for future in concurrent.futures.as_completed(futures): downloaded.append(future.result())
        except Exception as exc:
            inv=source_inventory_summary(config_path,code)
            update_status(config_path,code,"sources_incomplete" if inv["records"] else "no_sources","api_acquire_failed","FCC file acquisition failed",fcc_as_of=disc["as_of"],acquisition_error=str(exc),source_inventory=inv,progress={"phase":"download","percent":round(80.0*sum(1 for st in file_progress.values() if st.get("done"))/total,1),"failed":True,"file_total":total,"files_finished":sum(1 for st in file_progress.values() if st.get("done")),"workers":workers})
            raise
    job_control.checkpoint(config_path,"cellular",code)

    # Import sequentially. Import updates shared inventory metadata and SQLite-backed
    # GeoPackages, so parallelizing this phase would add contention without helping
    # network throughput. Downloads are already complete and cached at this point.
    for import_index,(_,carrier,row,archive,name) in enumerate(sorted(downloaded,key=lambda x:x[0]),1):
        job_control.checkpoint(config_path,"cellular",code)
        variant=row.get("_takrig_variant") or row.get("_takrig_class")
        pct=80.0+(import_index/max(1,total))*20.0
        info={"phase":"import","file_index":import_index,"file_total":total,"carrier":carrier,"variant":variant,"workers":workers,"percent":round(pct,1)}
        update_status(config_path,code,"acquiring","importing",f"Importing {carrier.upper()} {variant} · {import_index}/{total}",fcc_as_of=disc["as_of"],progress=info,acquisition_error="")
        if progress: progress(info)
        import_uploaded(config_path,code,archive,name,carrier_hint=carrier,as_of_hint=disc["as_of"],provenance="api",api_meta={"class":row.get("_takrig_class"),"variant":variant,"file_id":row_file_id(row),"provider_id":row_provider_id(row),"provider_name":row_provider_name(row)})

    inv=source_inventory_summary(config_path,code);status="ready_to_build" if inv["ready_to_build"] else "sources_incomplete";detail="FCC Hexagon Coverage sources ready to build" if inv["ready_to_build"] else "FCC acquisition completed but required source classes are incomplete"
    return update_status(config_path,code,status,"acquisition_complete",detail,fcc_as_of=inv["active_as_of"],source_inventory=inv,progress={"phase":"complete","percent":100,"file_total":total,"files_finished":total,"workers":workers},acquisition_error="")

# ---------- compact H3 normalization ----------
def _minimum_free_bytes(config_path:Path)->int:
    cfg=read_json(config_path,{}) or {}
    try:gib=float(cfg.get("minimum_free_disk_gib",DEFAULT_MIN_FREE_GIB))
    except Exception:gib=DEFAULT_MIN_FREE_GIB
    return int(max(5.0,gib)*1024**3)

def disk_preflight(config_path:Path,code:str,projected_additional_bytes:int=CELLULAR_PEAK_HEADROOM_BYTES)->dict[str,int]:
    r=ensure_roots(config_path);usage=shutil.disk_usage(r["state_root"]);reserve=_minimum_free_bytes(config_path);projected=max(0,int(projected_additional_bytes));required=reserve+projected;detail={"free_bytes":int(usage.free),"minimum_free_bytes":reserve,"projected_additional_bytes":projected,"projected_required_free_bytes":required}
    if usage.free<required:update_status(config_path,code,"waiting_space","waiting_space","Cellular build is waiting for disk space policy",disk_estimate=detail);raise RuntimeError(f"Cellular coverage requires approximately {required} free bytes including reserve; {usage.free} bytes are free")
    return detail

def _gpkg_tables_for_record(gpkg:Path,rec:dict[str,Any])->list[tuple[str,str,str]]:
    db=sqlite3.connect(f"file:{gpkg}?mode=ro",uri=True)
    try:
        rows=[]
        for table in rec.get("layers") or _feature_tables(db):
            cols=_columns(db,str(table));h3col=cols.get(f"h3_res{H3_RESOLUTION}_id");envcol=cols.get("environmnt") or cols.get("environment")
            if h3col and envcol:rows.append((str(table),h3col,envcol))
        return rows
    finally:db.close()

def normalize_sources(config_path:Path,code:str,source_set:dict[str,Any],progress=None)->dict[str,Any]:
    fp=str(source_set["source_fingerprint"]);work=ensure_roots(config_path)["work"]/code.lower()/fp[:16];work.mkdir(parents=True,exist_ok=True);dbpath=work/"normalized.sqlite";db=sqlite3.connect(dbpath);db.execute("PRAGMA journal_mode=WAL");db.execute("PRAGMA synchronous=NORMAL");db.execute("CREATE TABLE IF NOT EXISTS cells(h3 INTEGER PRIMARY KEY, att INTEGER NOT NULL DEFAULT 0, verizon INTEGER NOT NULL DEFAULT 0, tmobile INTEGER NOT NULL DEFAULT 0)");db.execute("CREATE TABLE IF NOT EXISTS ingested(source_id TEXT PRIMARY KEY, rows INTEGER NOT NULL, completed_utc TEXT NOT NULL)");db.commit()
    records=list(source_set["records"]);total=max(1,len(records))
    try:
        for index,rec in enumerate(records,1):
            job_control.checkpoint(config_path,"cellular",code)
            sid=str(rec["id"])
            if db.execute("SELECT 1 FROM ingested WHERE source_id=?",(sid,)).fetchone():
                if progress:progress(index,total,rec,True,0)
                continue
            carrier=str(rec["carrier"]);codeval=CLASS_CODE[str(rec["source_class"])];gpkg=_inventory_file(config_path,str(rec["gpkg"]));rowcount=0
            src=sqlite3.connect(f"file:{gpkg}?mode=ro",uri=True)
            try:
                db.execute("BEGIN")
                for table,h3col,envcol in _gpkg_tables_for_record(gpkg,rec):
                    cur=src.execute(f"SELECT {_quote_ident(h3col)} FROM {_quote_ident(table)} WHERE {_quote_ident(envcol)}=1")
                    while True:
                        job_control.checkpoint(config_path,"cellular",code)
                        batch=cur.fetchmany(50000)
                        if not batch:break
                        vals=[]
                        for (value,) in batch:
                            h=_parse_h3(value);vals.append((h,codeval));rowcount+=1
                        sql=f"INSERT INTO cells(h3,{carrier}) VALUES(?,?) ON CONFLICT(h3) DO UPDATE SET {carrier}=MAX({carrier},excluded.{carrier})"
                        db.executemany(sql,vals)
                db.execute("INSERT INTO ingested(source_id,rows,completed_utc) VALUES(?,?,?)",(sid,rowcount,utcnow()));db.commit()
            except Exception:
                db.rollback();raise
            finally:src.close()
            if progress:progress(index,total,rec,False,rowcount)
        counts={c:{k:0 for k in CLASSES} for c in CARRIERS}
        for carrier in CARRIERS:
            for n,cls in ((1,"voice_3g"),(2,"lte"),(3,"5g")):
                counts[carrier][cls]=int(db.execute(f"SELECT COUNT(*) FROM cells WHERE {carrier}=?",(n,)).fetchone()[0])
        cell_count=int(db.execute("SELECT COUNT(*) FROM cells WHERE att>0 OR verizon>0 OR tmobile>0").fetchone()[0])
        db.execute("PRAGMA wal_checkpoint(TRUNCATE)");db.commit();return {"work":work,"database":dbpath,"counts":counts,"cell_count":cell_count}
    finally:db.close()

def _uvarint(value:int)->bytes:
    value=int(value)
    if value<0:raise ValueError("varint cannot encode negative values")
    out=bytearray()
    while value>=0x80:out.append((value&0x7F)|0x80);value>>=7
    out.append(value);return bytes(out)

def _decode_uvarint(data:bytes,pos:int)->tuple[int,int]:
    value=0;shift=0
    for _ in range(10):
        if pos>=len(data):raise ValueError("truncated varint")
        b=data[pos];pos+=1;value|=(b&0x7F)<<shift
        if not b&0x80:return value,pos
        shift+=7
    raise ValueError("invalid varint")

def pack_coverage_byte(att:int,verizon:int,tmobile:int)->int:
    return (int(att)&3)|((int(verizon)&3)<<2)|((int(tmobile)&3)<<4)

def _bounds_for_source_set(source_set:dict[str,Any])->list[float]:
    vals=[r.get("extent") for r in source_set.get("records",[]) if isinstance(r.get("extent"),list) and len(r.get("extent"))==4]
    if not vals:return [-180.0,-90.0,180.0,90.0]
    return [min(float(v[0]) for v in vals),min(float(v[1]) for v in vals),max(float(v[2]) for v in vals),max(float(v[3]) for v in vals)]

def _encode_chunk(rows:list[tuple[int,int]])->bytes:
    if not rows:return b""
    out=bytearray();first=rows[0][0];out.extend(struct.pack("<Q",first));out.append(rows[0][1]);prev=first
    for h,cov in rows[1:]:out.extend(_uvarint(h-prev));out.append(cov);prev=h
    return bytes(out)

def write_h3_binary(dbpath:Path,out:Path,bounds:list[float],chunk_res:int,progress=None)->dict[str,Any]:
    out.parent.mkdir(parents=True,exist_ok=True);tmpdata=out.with_suffix(".chunks.tmp");entries=[];record_total=0;raw_total=0;compressed_total=0;max_comp=0;db=sqlite3.connect(f"file:{dbpath}?mode=ro",uri=True)
    try:
        cur=db.execute("SELECT h3,att,verizon,tmobile FROM cells WHERE att>0 OR verizon>0 OR tmobile>0 ORDER BY h3");current_parent=None;chunk=[];seen_parents=set();offset=0
        def flush():
            nonlocal chunk,current_parent,offset,record_total,raw_total,compressed_total,max_comp
            if not chunk:return
            raw=_encode_chunk(chunk);comp=zlib.compress(raw,6);crc=zlib.crc32(raw)&0xFFFFFFFF;entries.append((current_parent,offset,len(comp),len(raw),len(chunk),crc,1));fh.write(comp);offset+=len(comp);record_total+=len(chunk);raw_total+=len(raw);compressed_total+=len(comp);max_comp=max(max_comp,len(comp));chunk=[]
        with tmpdata.open("wb") as fh:
            n=0
            for h,att,vz,tm in cur:
                h=int(h);parent=h3_parent_int(h,chunk_res)
                if current_parent is None:current_parent=parent
                if parent!=current_parent:
                    flush();seen_parents.add(current_parent)
                    if parent in seen_parents:raise RuntimeError("H3 numeric ordering produced a non-contiguous parent chunk")
                    current_parent=parent
                chunk.append((h,pack_coverage_byte(att,vz,tm)));n+=1
                if progress and n%250000==0:progress(n,0,len(entries))
            flush()
        index_offset=H3_HEADER.size;data_offset=index_offset+len(entries)*H3_INDEX.size;west,south,east,north=bounds
        header=H3_HEADER.pack(H3_MAGIC,H3_FORMAT_VERSION,H3_RESOLUTION,chunk_res,len(CARRIERS),2,0,len(entries),record_total,index_offset,data_offset,int(west*1e7),int(south*1e7),int(east*1e7),int(north*1e7))
        part=out.with_suffix(out.suffix+".part")
        with part.open("wb") as dst,tmpdata.open("rb") as src:
            dst.write(header)
            for entry in entries:dst.write(H3_INDEX.pack(*entry))
            shutil.copyfileobj(src,dst,2*1024*1024)
        os.replace(part,out)
    finally:
        db.close();tmpdata.unlink(missing_ok=True)
    size=out.stat().st_size
    return {"schema":BINARY_SCHEMA,"file":"coverage.h3","h3_resolution":H3_RESOLUTION,"chunk_resolution":chunk_res,"carrier_order":list(CARRIERS),"bits_per_carrier":2,"class_codes":{"0":"none","1":"voice_3g","2":"lte","3":"5g"},"chunk_count":len(entries),"cell_count":record_total,"header_bytes":H3_HEADER.size,"index_entry_bytes":H3_INDEX.size,"uncompressed_record_bytes":raw_total,"compressed_chunk_bytes":compressed_total,"average_compressed_chunk_bytes":round(compressed_total/max(1,len(entries)),1),"max_compressed_chunk_bytes":max_comp,"size_bytes":size,"sha256":sha256_file(out)}

def verify_h3_binary(path:Path,*,full:bool=True)->dict[str,Any]:
    with path.open("rb") as fh:
        raw=fh.read(H3_HEADER.size)
        if len(raw)!=H3_HEADER.size:raise ValueError("Cellular H3 header is truncated")
        magic,version,h3res,chunkres,carrier_count,bits,_,chunks,records,index_offset,data_offset,west,south,east,north=H3_HEADER.unpack(raw)
        if magic!=H3_MAGIC or version!=H3_FORMAT_VERSION:raise ValueError("Cellular H3 magic/version mismatch")
        if h3res!=H3_RESOLUTION or carrier_count!=3 or bits!=2:raise ValueError("Cellular H3 schema fields are invalid")
        if index_offset!=H3_HEADER.size or data_offset!=H3_HEADER.size+chunks*H3_INDEX.size:raise ValueError("Cellular H3 index offsets are invalid")
        entries=[]
        for _ in range(chunks):
            b=fh.read(H3_INDEX.size)
            if len(b)!=H3_INDEX.size:raise ValueError("Cellular H3 index is truncated")
            entries.append(H3_INDEX.unpack(b))
        last_end=0;seen=0
        for parent,offset,clen,rlen,count,crc,flags in entries:
            if offset!=last_end:raise ValueError("Cellular H3 chunk offsets are not contiguous")
            last_end=offset+clen;seen+=count
            if not full:continue
            fh.seek(data_offset+offset);comp=fh.read(clen)
            if len(comp)!=clen:raise ValueError("Cellular H3 chunk is truncated")
            body=zlib.decompress(comp) if flags&1 else comp
            if len(body)!=rlen or (zlib.crc32(body)&0xFFFFFFFF)!=crc:raise ValueError("Cellular H3 chunk integrity failed")
            pos=0;prev=0
            for i in range(count):
                if i==0:
                    if len(body)<9:raise ValueError("Cellular H3 chunk record is truncated")
                    h=struct.unpack_from("<Q",body,0)[0];pos=8
                else:
                    delta,pos=_decode_uvarint(body,pos);h=prev+delta
                if pos>=len(body):raise ValueError("Cellular H3 coverage byte is truncated")
                cov=body[pos];pos+=1
                if cov&0xC0:raise ValueError("Cellular H3 coverage byte uses reserved bits")
                if h3_resolution_int(h)!=h3res or h3_parent_int(h,chunkres)!=parent:raise ValueError("Cellular H3 cell/chunk identity mismatch")
                if i and h<=prev:raise ValueError("Cellular H3 cells are not strictly sorted")
                prev=h
            if pos!=len(body):raise ValueError("Cellular H3 chunk contains trailing bytes")
        if seen!=records:raise ValueError("Cellular H3 record count mismatch")
        if path.stat().st_size!=data_offset+last_end:raise ValueError("Cellular H3 file size does not match index")
        return {"h3_resolution":h3res,"chunk_resolution":chunkres,"chunk_count":chunks,"cell_count":records,"bounds_e7":[west,south,east,north]}

# ---------- status/package ----------
def status_summary(config_path:Path,code:str)->dict[str,Any]:
    code=code.upper();current=read_json(status_path(config_path,code),{}) or {};ready=ready_descriptor(config_path,code);inv=source_inventory_summary(config_path,code);status=str(current.get("status") or "")
    if status in ACTIVE_STATUSES or status in {"failed","waiting_space","update_available","paused","pausing","interrupted"}:out=dict(current)
    elif ready:
        current_fp=inv.get("source_fingerprint") if inv.get("ready_to_build") else ""
        if current_fp and current_fp!=ready.get("source_fingerprint"):out={"state_code":code,"state_name":STATES[code].name,"status":"update_available","stage":"sources","detail":"A different coherent FCC H3 source set is ready to build"}
        else:out={"state_code":code,"state_name":STATES[code].name,"status":"ready","stage":"ready","detail":"Cellular coverage package ready","updated_utc":ready.get("built_utc") or ""}
    else:
        out={"state_code":code,"state_name":STATES[code].name,"status":"ready_to_build" if inv["ready_to_build"] else ("sources_incomplete" if inv["records"] else "no_sources"),"stage":"sources","detail":"FCC H3 sources ready to build" if inv["ready_to_build"] else ("FCC H3 sources are incomplete" if inv["records"] else "Import FCC H3 data or configure FCC API")}
    pause = job_control.display(config_path,"cellular",code)
    if pause:
        out.update(status=pause,stage=pause,detail="Pausing after current FCC operation completes" if pause=="pausing" else "Cellular work paused; completed downloads preserved")
        out.pop("error",None)
    elif status in ACTIVE_STATUSES and (pid := int(current.get("pid") or 0)):
        try:
            actual=(Path("/proc")/str(pid)/"cmdline").read_bytes()
            active_pid=b"cellular.py" in actual
        except OSError:
            active_pid=False
        if not active_pid:
            out.update(status="interrupted",stage="interrupted",detail="Cellular worker stopped; cached inputs preserved")
    out["resume_action"]=str(current.get("resume_action") or "build")
    out["source_access"]=source_status(config_path);out["source_inventory"]=inv;out["carrier_selection"]=carrier_selection(config_path,code)
    if ready:out["package"]={k:ready.get(k) for k in ("package","revision","size_bytes","sha256","built_utc","fcc_as_of","format","carriers","class_counts","bounds","source_fingerprint","binary")}
    return out

def public_descriptor(config_path:Path,code:str)->dict[str,Any]|None:
    d=ready_descriptor(config_path,code)
    if not d:return None
    return {"state_code":code.upper(),"state_name":STATES[code.upper()].name,"status":"ready","revision":d.get("revision") or "","built_utc":d.get("built_utc") or "","size_bytes":int(d.get("size_bytes") or 0),"sha256":d.get("sha256") or "","format":d.get("format") or PACKAGE_FORMAT,"fcc_as_of":d.get("fcc_as_of") or "","carriers":d.get("carriers") or [],"classes":list(CLASSES),"bounds":d.get("bounds") or [],"binary":d.get("binary") or {},"download_url":f"/api/v1/cellular/{code.upper()}/download"}

def remove(config_path:Path,code:str)->bool:
    code=code.upper();r=ensure_roots(config_path);found=False;d=ready_descriptor(config_path,code)
    if d:(r["ready"]/str(d.get("package") or "")).unlink(missing_ok=True);found=True
    descriptor_path(config_path,code).unlink(missing_ok=True);shutil.rmtree(r["work"]/code.lower(),ignore_errors=True);status_path(config_path,code).unlink(missing_ok=True);return found

# ---------- build ----------
def build(config_path:Path,code:str,*,force:bool=False)->dict[str,Any]:
    code=code.upper()
    if code not in STATES:raise ValueError("Unknown state")
    job_control.checkpoint(config_path,"cellular",code)
    r=ensure_roots(config_path);disk_preflight(config_path,code);source_set=_source_set(config_path,code)
    if not source_set.get("complete"):raise RuntimeError(source_set.get("resolution_error") or "Cellular source inventory is incomplete. Import or acquire Voice, LTE, 5G 7/1, and 5G 35/3 H3 data for each selected carrier.")
    fp=str(source_set["source_fingerprint"]);ready=ready_descriptor(config_path,code)
    if ready and ready.get("source_fingerprint")==fp and not force:return ready
    work=r["work"]/code.lower()/fp[:16]
    if force:shutil.rmtree(work,ignore_errors=True)
    started=time.time();update_status(config_path,code,"processing","processing","Packing best-available FCC H3 coverage",fcc_as_of=source_set["as_of"],progress={"percent":0})
    def np(done,total,rec,resumed,rows):
        job_control.checkpoint(config_path,"cellular",code)
        update_status(config_path,code,"processing","processing",f"Normalizing {rec.get('carrier','').upper()} {rec.get('source_variant') or rec.get('source_class')} · {done}/{total}{' · cached' if resumed else ''}",fcc_as_of=source_set["as_of"],progress={"completed":done,"total":total,"source_rows":rows,"percent":round(done/max(1,total)*65,1)})
    norm=normalize_sources(config_path,code,source_set,np);bounds=_bounds_for_source_set(source_set);binary=norm["work"]/"coverage.h3";cres=chunk_resolution(config_path)
    update_status(config_path,code,"processing","encoding",f"Encoding compact H3 coverage chunks · resolution {H3_RESOLUTION}",fcc_as_of=source_set["as_of"],progress={"percent":68})
    def hp(done,total,chunks):
        job_control.checkpoint(config_path,"cellular",code)
        update_status(config_path,code,"processing","encoding",f"Encoding H3 cells · {done:,}",fcc_as_of=source_set["as_of"],progress={"cells":done,"chunks":chunks,"percent":82})
    bmeta=write_h3_binary(norm["database"],binary,bounds,cres,hp);verified=verify_h3_binary(binary,full=True)
    if int(verified["cell_count"])!=int(norm["cell_count"]):raise RuntimeError("Cellular H3 verification count does not match normalized database")
    job_control.checkpoint(config_path,"cellular",code)
    update_status(config_path,code,"packaging","packaging","Packaging compact Cellular H3 dataset",fcc_as_of=source_set["as_of"],progress={"percent":94})
    providers={c:sorted({(str(x.get("provider_id") or ""),str(x.get("provider_name") or "")) for x in source_set["records"] if x.get("carrier")==c}) for c in source_set["selected_carriers"]}
    revision=f"fcc-{source_set['as_of']}-h3-p{CELLULAR_PIPELINE_REVISION}-{fp[:12]}";manifest={"schema":MANIFEST_SCHEMA,"format":PACKAGE_FORMAT,"binary_schema":BINARY_SCHEMA,"revision":revision,"state_code":code,"state_name":STATES[code].name,"bounds":bounds,"fcc_as_of":source_set["as_of"],"source":"FCC Broadband Data Collection / National Broadband Map provider-specific Hexagon Coverage","geometry":"FCC H3 resolution-9 cells","environment":"in_vehicle","environment_code":1,"carriers":source_set["selected_carriers"],"providers":{c:[{"provider_id":p,"name":n} for p,n in providers[c]] for c in providers},"classes":list(CLASSES),"class_precedence":["5g","lte","voice_3g"],"source_requirements":{"required":["voice","lte","5g_7_1","5g_35_3"],"optional":["3g"],"five_g_union":["5g_7_1","5g_35_3"]},"coverage_byte":{"carrier_order":list(CARRIERS),"bits_per_carrier":2,"codes":{"0":"none","1":"voice_3g","2":"lte","3":"5g"}},"source_files":[{k:x.get(k) for k in ("id","original_filename","carrier","source_class","source_variant","as_of","provider_id","provider_name","frn","size_bytes","sha256","h3_resolution","provenance","api_file_id")} for x in source_set["records"]],"source_fingerprint":fp,"cellular_pipeline_revision":CELLULAR_PIPELINE_REVISION,"manager_version":VERSION,"class_counts":norm["counts"],"cell_count":norm["cell_count"],"binary":bmeta,"built_utc":utcnow()}
    mpath=norm["work"]/"manifest.json";atomic_json(mpath,manifest);pkg_name=f"takrig-cellular-{code.lower()}-fcc-{source_set['as_of']}-h3-r{CELLULAR_PIPELINE_REVISION}.zip";part=r["ready"]/(pkg_name+".part");final=r["ready"]/pkg_name;part.unlink(missing_ok=True)
    with zipfile.ZipFile(part,"w") as zf:
        zf.writestr("manifest.json",mpath.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=6);zf.write(binary,"coverage.h3",compress_type=zipfile.ZIP_STORED)
    with zipfile.ZipFile(part,"r") as zf:
        if set(zf.namelist())!={"manifest.json","coverage.h3"}:raise RuntimeError("Cellular package member validation failed")
        if zf.testzip() is not None:raise RuntimeError("Cellular package ZIP CRC validation failed")
        check=json.loads(zf.read("manifest.json"));
        if check.get("source_fingerprint")!=fp or check.get("binary_schema")!=BINARY_SCHEMA:raise RuntimeError("Cellular manifest validation failed")
    os.replace(part,final);desc={**manifest,"package":pkg_name,"size_bytes":final.stat().st_size,"sha256":sha256_file(final),"created_utc":manifest["built_utc"],"build_seconds":round(time.time()-started,1)};atomic_json(descriptor_path(config_path,code),desc)
    for old in r["ready"].glob(f"takrig-cellular-{code.lower()}-*.zip"):
        if old!=final:old.unlink(missing_ok=True)
    update_status(config_path,code,"ready","ready","Compact FCC H3 Cellular package ready",fcc_as_of=source_set["as_of"],progress={"percent":100},package={"package":pkg_name,"size_bytes":final.stat().st_size,"revision":revision});return desc

# ---------- CLI ----------
def parse_args(argv:list[str])->argparse.Namespace:
    p=argparse.ArgumentParser(prog="cellular.py");p.add_argument("--config",default=os.environ.get("TAKRIG_ROUTING_CONFIG","/etc/takrig-routing/config.json"));sub=p.add_subparsers(dest="command",required=True)
    for name in ("check","build","rebuild","status","remove"):
        q=sub.add_parser(name);q.add_argument("state")
    q=sub.add_parser("acquire-api");q.add_argument("state");q.add_argument("--as-of",default="")
    return p.parse_args(argv)
def main(argv:list[str]|None=None)->int:
    a=parse_args(argv or sys.argv[1:]);cfg=Path(a.config);code=a.state.upper();ensure_roots(cfg)
    if a.command=="check":
        try:print(json.dumps(check(cfg,code),indent=2));return 0
        except job_control.JobPaused:
            update_status(cfg,code,"paused","paused","FCC source check paused");return 0
    if a.command=="acquire-api":
        try: print(json.dumps(acquire_api_sources(cfg,code,a.as_of),indent=2));return 0
        except job_control.JobPaused:
            update_status(cfg,code,"paused","paused","FCC acquisition paused; completed files cached");return 0
    if a.command in {"build","rebuild"}:
        try:print(json.dumps(build(cfg,code,force=a.command=="rebuild"),indent=2));return 0
        except job_control.JobPaused:
            update_status(cfg,code,"paused","paused","Cellular build paused; cached input retained");return 0
        except Exception as exc:update_status(cfg,code,"failed","failed","Cellular H3 package build failed",error=str(exc));raise
    if a.command=="status":print(json.dumps(status_summary(cfg,code),indent=2));return 0
    if a.command=="remove":print(json.dumps({"removed":remove(cfg,code)},indent=2));return 0
    return 1
if __name__=="__main__":raise SystemExit(main())
