#!/usr/bin/env python3
"""TAK Rig per-state 3D terrain package builder.

r14 hardens the initial r13 terrain pipeline: actual GDAL raster validation,
all-NODATA skipping, aligned 3-arc-second node sampling, resumable per-cell
builds, transient retry/backoff, durable SQLite commits, package validation,
and actionable status/error reporting.
"""
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
import json
import math
import os
import shutil
import sqlite3
import struct
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from collections import deque
import zlib
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import job_control
from state_catalog import STATES
from sources import fetch_geofabrik_boundary, geofabrik_urls, parse_geofabrik_poly

VERSION = "0.2.0-r16-r29"
PACKAGE_FORMAT = "takrig.terrain.region.v1"
DB_SCHEMA = "takrig.terrain.sqlite.v1"
SOURCE_NAME = "USGS 3D Elevation Program (3DEP)"
SOURCE_URL = "https://elevation.nationalmap.gov/arcgis/rest/services/3DEPElevation/ImageServer"
EXPORT_URL = SOURCE_URL + "/exportImage"
TILE_SPAN_DEG = 0.5
NODATA = -32768
SUPPORTED_RESOLUTIONS_M = (30, 90)
DEFAULT_RESOLUTION_M = 30

@dataclass(frozen=True)
class TerrainProfile:
    nominal_resolution_m: int
    sample_arcsec: float
    grid_size: int

    @property
    def sample_deg(self) -> float:
        return self.sample_arcsec / 3600.0

    @property
    def half_sample_deg(self) -> float:
        return self.sample_deg / 2.0


def terrain_profile(config_path: Path) -> TerrainProfile:
    cfg = read_json(config_path, {}) if config_path.is_file() else {}
    settings = read_json(roots(config_path)["settings"], {})
    raw = (settings if isinstance(settings, dict) else {}).get("terrain_resolution_m")
    if raw is None:
        raw = (cfg if isinstance(cfg, dict) else {}).get("terrain_resolution_m", DEFAULT_RESOLUTION_M)
    try:
        resolution = int(raw)
    except (TypeError, ValueError):
        resolution = DEFAULT_RESOLUTION_M
    resolution = 30 if resolution <= 30 else 90
    return TerrainProfile(30, 1.0, 1801) if resolution == 30 else TerrainProfile(90, 3.0, 601)


# Legacy public constants remain for compatibility with existing tests/helpers.
# New builds use TerrainProfile explicitly and are not hard-wired to these values.
SAMPLE_ARCSEC = 3.0
SAMPLE_DEG = SAMPLE_ARCSEC / 3600.0
HALF_SAMPLE_DEG = SAMPLE_DEG / 2.0
GRID_SIZE = 601
LEGACY_PROFILE = TerrainProfile(90, SAMPLE_ARCSEC, GRID_SIZE)


def overview_specs(profile: TerrainProfile) -> tuple[tuple[int, int], ...]:
    # phase-aligned node decimation. 1801 -> 901/451/226; 601 -> 301/151.
    factors = (2, 4, 8) if profile.nominal_resolution_m == 30 else (2, 4)
    return tuple((profile.nominal_resolution_m * factor, factor) for factor in factors)
TRANSIENT_HTTP = {408, 425, 429, 500, 502, 503, 504}
MAX_DOWNLOAD_ATTEMPTS = 4
TERRAIN_DOWNLOAD_WORKERS = 4  # Concurrent 0.5-degree cell downloads; SQLite remains single-writer.
DEFAULT_MIN_FREE_GIB = 30.0
TERRAIN_ESTIMATE_PER_CELL_BYTES = 16 * 1024 * 1024
SCRATCH_HEADROOM_BYTES = 64 * 1024 * 1024
ACTIVE_STATES = {"queued", "preparing", "building", "packaging", "pausing", "paused"}


class TerrainWaitingSpace(RuntimeError):
    pass


class RasterValidationError(RuntimeError):
    pass


class TransientTerrainExportError(RuntimeError):
    """USGS temporary server-side error after the normal bounded retry budget."""
    def __init__(self, http_status: int, message: str):
        super().__init__(message)
        self.http_status = http_status


def utcnow() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def atomic_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp-{os.getpid()}-{uuid.uuid4().hex[:6]}")
    tmp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def roots(config_path: Path) -> dict[str, Path]:
    cfg: dict[str, Any] = read_json(config_path, {}) if config_path.is_file() else {}
    root = Path(str(cfg.get("state_root") or "/var/lib/takrig-routing")).expanduser().resolve()
    terrain = root / "terrain"
    return {
        "state_root": root,
        "terrain": terrain,
        "ready": terrain / "ready",
        "work": terrain / "work",
        "status": terrain / "status",
        "boundary_cache": root / "manager" / "sources",
        "settings": root / "manager" / "settings.json",
        "lock": terrain / "terrain-build.lock",
    }


def ensure_roots(r: dict[str, Path]) -> None:
    for key in ("terrain", "ready", "work", "status"):
        r[key].mkdir(parents=True, exist_ok=True)


def descriptor_path(config_path: Path, code: str) -> Path:
    return roots(config_path)["ready"] / f"takrig-terrain-{code.lower()}.zip.json"


def legacy_descriptor_path(config_path: Path, code: str) -> Path:
    return roots(config_path)["ready"] / f"takrig-terrain-{code.lower()}-3arcsec.zip.json"


def package_path(config_path: Path, code: str) -> Path:
    return roots(config_path)["ready"] / f"takrig-terrain-{code.lower()}.zip"


def status_path(config_path: Path, code: str) -> Path:
    return roots(config_path)["status"] / f"{code.lower()}.json"


def ready_descriptor(config_path: Path, code: str) -> dict[str, Any] | None:
    code = code.upper()
    p = descriptor_path(config_path, code)
    desc = read_json(p, None)
    if not isinstance(desc, dict):
        desc = read_json(legacy_descriptor_path(config_path, code), None)
    if not isinstance(desc, dict):
        return None
    package = roots(config_path)["ready"] / str(desc.get("package") or "")
    return desc if package.is_file() else None


def _matching_process(pid: int, identifier: str) -> bool:
    try:
        cmd = (Path("/proc") / str(pid) / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="ignore")
        return identifier in cmd
    except OSError:
        return False


def status_summary(config_path: Path, code: str) -> dict[str, Any]:
    code = code.upper()
    ready = ready_descriptor(config_path, code)
    status = read_json(status_path(config_path, code), {})
    if not isinstance(status, dict):
        status = {}
    state = str(status.get("status") or "")
    if state in ACTIVE_STATES or state in {"waiting_space", "failed", "interrupted"}:
        out = dict(status)
    elif ready:
        out = {"status": "ready", "stage": "ready", "detail": "3D terrain package is available"}
    else:
        out = {"status": "not_built", "stage": "not_built", "detail": "3D terrain has not been built"}
    out["package"] = ready
    pause = job_control.display(config_path, "terrain", code)
    if pause:
        out.update(status=pause, stage=pause,
                   detail="Pausing after active terrain requests finish" if pause == "pausing" else "Elevation download paused; completed cells retained")
        out.pop("error", None)
    elif out.get("status") in {"queued", "preparing", "building", "packaging"}:
        pid = int(out.get("pid") or 0)
        # A queued worker may be lost after an NDM restart. Avoid permanent
        # QUEUED state when a known child has exited unexpectedly.
        stale = False
        if not pid:
            try:
                last = dt.datetime.fromisoformat(str(out.get("updated_utc") or "").replace("Z", "+00:00"))
                stale = (dt.datetime.now(dt.timezone.utc) - last).total_seconds() > 60
            except ValueError:
                stale = True
        if (pid and not _matching_process(pid, "terrain.py")) or stale:
            out.update(status="interrupted", stage="interrupted",
                       detail="Previous elevation worker stopped; resume preserved cells")
    return out


def remove(config_path: Path, code: str) -> list[str]:
    code = code.upper(); removed: list[str] = []
    for path in (package_path(config_path, code), descriptor_path(config_path, code), legacy_descriptor_path(config_path, code), roots(config_path)["ready"] / f"takrig-terrain-{code.lower()}-3arcsec.zip", status_path(config_path, code)):
        if path.exists():
            shutil.rmtree(path, ignore_errors=True) if path.is_dir() else path.unlink(missing_ok=True)
            removed.append(str(path))
    work = roots(config_path)["work"] / code.lower()
    if work.exists(): shutil.rmtree(work, ignore_errors=True); removed.append(str(work))
    return removed


def _update_status(config_path: Path, code: str, status: str, stage: str, detail: str = "", **extra: Any) -> None:
    prior = read_json(status_path(config_path, code), {})
    row = dict(prior) if isinstance(prior, dict) else {}
    # Do not keep a previous failed HTTP response visible during a fresh attempt.
    # Progress remains so resumed cells are still shown accurately.
    if status in {"queued", "preparing", "building", "packaging", "ready"}:
        row.pop("error", None)
        row.pop("disk_estimate", None)
    row.update({"state_code": code, "state_name": STATES[code].name, "status": status, "stage": stage,
                "detail": detail, "updated_utc": utcnow(), **extra})
    if status in {"queued", "preparing", "building", "packaging", "ready"}:
        row.pop("error", None)
    if status == "queued":
        if "pid" not in extra: row.pop("pid", None)
    else: row["pid"] = os.getpid()
    atomic_json(status_path(config_path, code), row)


def _minimum_free_bytes(config_path: Path) -> int:
    r = roots(config_path)
    settings = read_json(r["settings"], {})
    config = read_json(config_path, {})
    gib = float((settings if isinstance(settings, dict) else {}).get("minimum_free_disk_gib") or
                (config if isinstance(config, dict) else {}).get("minimum_free_disk_gib") or DEFAULT_MIN_FREE_GIB)
    return int(gib * 1024**3)


def _disk_check(config_path: Path, code: str, remaining_cells: int, *, stage: str) -> dict[str, int]:
    r = roots(config_path); usage = shutil.disk_usage(r["state_root"])
    reserve = _minimum_free_bytes(config_path)
    estimate = max(SCRATCH_HEADROOM_BYTES, remaining_cells * TERRAIN_ESTIMATE_PER_CELL_BYTES)
    required = reserve + estimate
    detail = {"free_bytes": usage.free, "minimum_free_bytes": reserve,
              "projected_additional_bytes": estimate, "projected_required_free_bytes": required}
    if usage.free < required:
        _update_status(config_path, code, "waiting_space", "waiting_space",
                       "3D terrain build is waiting for disk space policy", disk_estimate=detail)
        raise TerrainWaitingSpace(
            f"3D terrain requires approximately {required} free bytes including the configured reserve; {usage.free} bytes are free")
    return detail


def _expanded_export_bbox(west: float, south: float, east: float, north: float, profile: TerrainProfile = LEGACY_PROFILE) -> tuple[float, float, float, float]:
    half = profile.half_sample_deg
    return max(-180.0, west - half), south - half, min(180.0, east + half), north + half


def _export_params(west: float, south: float, east: float, north: float, profile: TerrainProfile = LEGACY_PROFILE) -> dict[str, str]:
    xw, ys, xe, yn = _expanded_export_bbox(west, south, east, north, profile)
    return {
        "bbox": f"{xw:.10f},{ys:.10f},{xe:.10f},{yn:.10f}", "bboxSR": "4326", "imageSR": "4326",
        "size": f"{profile.grid_size},{profile.grid_size}", "adjustAspectRatio": "false", "format": "tiff",
        "pixelType": "F32", "interpolation": "RSP_BilinearInterpolation", "f": "image",
    }


def _run_checked(cmd: list[str], label: str) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        raise RuntimeError(f"{label} failed (exit {result.returncode}): {detail[:1200]}")
    return result


def _validate_raster(path: Path) -> dict[str, Any]:
    exe = shutil.which("gdalinfo")
    if exe is None: raise RuntimeError("gdalinfo is required; install the NDM package with gdal-bin")
    result = _run_checked([exe, "-json", str(path)], "GDAL raster validation")
    try: info = json.loads(result.stdout)
    except Exception as exc: raise RasterValidationError(f"GDAL returned unreadable raster metadata: {exc}")
    size = info.get("size") or []
    if len(size) != 2 or int(size[0]) <= 0 or int(size[1]) <= 0:
        raise RasterValidationError("GDAL did not report a valid raster size")
    return info


def _download_export(west: float, south: float, east: float, north: float, target: Path, profile: TerrainProfile = LEGACY_PROFILE,
                     timeout: int = 180, attempts: int = MAX_DOWNLOAD_ATTEMPTS) -> dict[str, Any]:
    params = _export_params(west, south, east, north, profile)
    url = EXPORT_URL + "?" + urllib.parse.urlencode(params)
    part = target.with_name(target.name + ".part")
    last: Exception | None = None
    for attempt in range(1, attempts + 1):
        part.unlink(missing_ok=True)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": f"TAK-Rig-NDM/{VERSION}", "Accept": "image/tiff,*/*"})
            with urllib.request.urlopen(req, timeout=timeout) as resp, part.open("wb") as out:
                ctype = str(resp.headers.get("Content-Type") or "").lower()
                status = int(getattr(resp, "status", 200) or 200)
                shutil.copyfileobj(resp, out, length=1024 * 1024)
                out.flush()
                headers = {"content_type": ctype, "http_status": status, "size_bytes": part.stat().st_size}
            try:
                info = _validate_raster(part)
            except Exception as exc:
                body_hint = ""
                if "json" in ctype or "text" in ctype or headers["size_bytes"] <= 4096:
                    with contextlib.suppress(Exception):
                        body_hint = part.read_text(encoding="utf-8", errors="replace")[:800].strip()
                suffix = f"; response={body_hint}" if body_hint else ""
                raise RasterValidationError(
                    f"USGS 3DEP export invalid for cell bbox={west:.4f},{south:.4f},{east:.4f},{north:.4f}; "
                    f"HTTP {headers['http_status']}; content-type={headers['content_type'] or 'unknown'}; "
                    f"size={headers['size_bytes']} bytes; {exc}{suffix}") from exc
            os.replace(part, target)
            return {**headers, "url": url, "gdal": info}
        except urllib.error.HTTPError as exc:
            last = exc
            body = ""
            with contextlib.suppress(Exception): body = exc.read(800).decode("utf-8", errors="replace")
            if exc.code not in TRANSIENT_HTTP or attempt >= attempts:
                message = f"USGS 3DEP HTTP {exc.code} for cell bbox={west},{south},{east},{north}: {body}"
                if exc.code in {502, 503, 504}:
                    raise TransientTerrainExportError(exc.code, message) from exc
                raise RuntimeError(message) from exc
        except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
            last = exc
            if attempt >= attempts: raise RuntimeError(f"USGS 3DEP network failure for cell bbox={west},{south},{east},{north}: {exc}") from exc
        except RasterValidationError:
            part.unlink(missing_ok=True); raise
        if attempt < attempts: time.sleep(min(8.0, 1.5 * (2 ** (attempt - 1))))
    raise RuntimeError(str(last or "USGS 3DEP download failed"))


def _download_export_with_fallback(west: float, south: float, east: float, north: float,
                                   target: Path, profile: TerrainProfile) -> list[Path]:
    """Use a full 0.5° request normally; split only after repeated upstream 502/503/504.

    The subexports overlap by one DEM grid node, preserving the exact full-grid
    pixel alignment. Existing database/manifest tile geometry is unchanged.
    """
    try:
        _download_export(west, south, east, north, target, profile=profile)
        return [target]
    except TransientTerrainExportError as exc:
        if exc.http_status not in {502, 503, 504}:
            raise
    midx=(west+east)/2.0
    midy=(south+north)/2.0
    quarters=((west,south,midx,midy), (midx,south,east,midy),
              (west,midy,midx,north), (midx,midy,east,north))
    half=TerrainProfile(profile.nominal_resolution_m, profile.sample_arcsec,
                        (profile.grid_size+1)//2)
    parts=[target.with_name(f"{target.stem}.quarter{idx}.tif") for idx in range(4)]
    try:
        for bounds, path in zip(quarters, parts):
            info=_download_export(*bounds, path, profile=half)
            actual=((info or {}).get('gdal') or {}).get('size') if isinstance(info,dict) else None
            if actual and [int(v) for v in actual] != [half.grid_size,half.grid_size]:
                raise RasterValidationError(f"Unexpected split terrain grid {actual}, expected {half.grid_size}x{half.grid_size}")
        return parts
    except Exception:
        for path in parts: path.unlink(missing_ok=True)
        raise


def _scratch_paths(raw: Path) -> tuple[Path, Path, Path]:
    stem = raw.name
    out = raw.parent / f"{stem}.terrain.bin"
    hdr = raw.parent / f"{stem}.terrain.hdr"
    aux = raw.parent / f"{stem}.terrain.bin.aux.xml"
    return out, hdr, aux


def _tiff_to_int16_raw(tiff: Path | list[Path], raw: Path, west: float, south: float, east: float, north: float, profile: TerrainProfile = LEGACY_PROFILE) -> bytes:
    exe = shutil.which("gdalwarp")
    if exe is None: raise RuntimeError("gdalwarp is required; install the NDM package with gdal-bin")
    out, hdr, aux = _scratch_paths(raw)
    for p in (out, hdr, aux): p.unlink(missing_ok=True)
    xw, ys, xe, yn = _expanded_export_bbox(west, south, east, north, profile)
    cmd = [exe, "-overwrite", "-of", "ENVI", "-ot", "Int16", "-r", "bilinear",
           "-dstnodata", str(NODATA), "-te", f"{xw:.10f}", f"{ys:.10f}", f"{xe:.10f}", f"{yn:.10f}",
           "-ts", str(profile.grid_size), str(profile.grid_size),
           *(str(p) for p in (tiff if isinstance(tiff,list) else [tiff])), str(out)]
    try:
        _run_checked(cmd, "GDAL terrain conversion")
        data = out.read_bytes()
        expected = profile.grid_size * profile.grid_size * 2
        if len(data) != expected: raise RuntimeError(f"Unexpected terrain raster size: {len(data)} bytes, expected {expected}")
        header = hdr.read_text(encoding="utf-8", errors="replace").lower() if hdr.is_file() else ""
        if "byte order = 1" in header:
            vals = struct.unpack(f">{profile.grid_size * profile.grid_size}h", data); data = struct.pack(f"<{len(vals)}h", *vals)
        return data
    finally:
        for p in (out, hdr, aux): p.unlink(missing_ok=True)


def _valid_min_max(data: bytes) -> tuple[int | None, int | None]:
    minimum = maximum = None
    for (v,) in struct.iter_unpack("<h", data):
        if v == NODATA: continue
        minimum = v if minimum is None else min(minimum, v)
        maximum = v if maximum is None else max(maximum, v)
    return minimum, maximum


def _aligned_floor(value: float) -> float: return math.floor(value / TILE_SPAN_DEG) * TILE_SPAN_DEG

def _aligned_ceil(value: float) -> float: return math.ceil(value / TILE_SPAN_DEG) * TILE_SPAN_DEG


def _create_or_open_db(path: Path, metadata: dict[str, str], *, reset: bool = False) -> sqlite3.Connection:
    if reset: path.unlink(missing_ok=True)
    new = not path.exists()
    db = sqlite3.connect(path)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA synchronous=FULL")
    db.execute("PRAGMA temp_store=MEMORY")
    if new:
        db.executescript("""
            CREATE TABLE metadata (name TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE tiles (
                tile_id TEXT PRIMARY KEY, west REAL NOT NULL, south REAL NOT NULL, east REAL NOT NULL, north REAL NOT NULL,
                rows INTEGER NOT NULL, cols INTEGER NOT NULL, min_elev_m INTEGER, max_elev_m INTEGER,
                encoding TEXT NOT NULL, data BLOB NOT NULL
            );
            CREATE INDEX tiles_bounds ON tiles(west, south, east, north);
            CREATE TABLE tile_overviews (
                tile_id TEXT NOT NULL, resolution_m INTEGER NOT NULL, sample_spacing_arcseconds REAL NOT NULL,
                west REAL NOT NULL, south REAL NOT NULL, east REAL NOT NULL, north REAL NOT NULL,
                rows INTEGER NOT NULL, cols INTEGER NOT NULL, min_elev_m INTEGER, max_elev_m INTEGER,
                encoding TEXT NOT NULL, data BLOB NOT NULL,
                PRIMARY KEY(tile_id, resolution_m)
            );
            CREATE INDEX tile_overviews_bounds ON tile_overviews(resolution_m, west, south, east, north);
        """)
        db.executemany("INSERT INTO metadata(name,value) VALUES(?,?)", metadata.items()); db.commit()
    else:
        check = db.execute("PRAGMA quick_check").fetchone()
        if not check or check[0] != "ok": raise RuntimeError(f"Resumable terrain database failed SQLite quick_check: {check}")
    return db


def _coverage_boxes(cells: list[tuple[float,float,float,float]]) -> list[list[float]]:
    if not cells: return []
    west_cells = [c for c in cells if c[0] < 0]; east_cells = [c for c in cells if c[2] > 0]
    crosses = any(c[0] <= -179.5 for c in cells) and any(c[2] >= 179.5 for c in cells)
    groups = [west_cells, east_cells] if crosses else [cells]
    out=[]
    for g in groups:
        if not g: continue
        out.append([min(c[0] for c in g), min(c[1] for c in g), max(c[2] for c in g), max(c[3] for c in g)])
    return out


def _decimate_int16(data: bytes, rows: int, cols: int, factor: int) -> tuple[bytes, int, int]:
    if factor <= 1:
        return data, rows, cols
    values = memoryview(data).cast("h")
    row_ids = list(range(0, rows - 1, factor)) + [rows - 1]
    col_ids = list(range(0, cols - 1, factor)) + [cols - 1]
    out = bytearray(len(row_ids) * len(col_ids) * 2)
    pos = 0
    for r in row_ids:
        base = r * cols
        for c in col_ids:
            struct.pack_into("<h", out, pos, int(values[base + c])); pos += 2
    return bytes(out), len(row_ids), len(col_ids)


def _ensure_overview_schema(db: sqlite3.Connection) -> None:
    db.executescript("""
        CREATE TABLE IF NOT EXISTS tile_overviews (
            tile_id TEXT NOT NULL, resolution_m INTEGER NOT NULL, sample_spacing_arcseconds REAL NOT NULL,
            west REAL NOT NULL, south REAL NOT NULL, east REAL NOT NULL, north REAL NOT NULL,
            rows INTEGER NOT NULL, cols INTEGER NOT NULL, min_elev_m INTEGER, max_elev_m INTEGER,
            encoding TEXT NOT NULL, data BLOB NOT NULL, PRIMARY KEY(tile_id, resolution_m)
        );
        CREATE INDEX IF NOT EXISTS tile_overviews_bounds ON tile_overviews(resolution_m, west, south, east, north);
    """)


def _validate_database(path: Path) -> dict[str, Any]:
    db = sqlite3.connect(path)
    try:
        quick = db.execute("PRAGMA quick_check").fetchone(); integrity = db.execute("PRAGMA integrity_check").fetchone()
        if not quick or quick[0] != "ok" or not integrity or integrity[0] != "ok": raise RuntimeError("Terrain SQLite integrity validation failed")
        meta = dict(db.execute("SELECT name,value FROM metadata").fetchall())
        if meta.get("schema") != DB_SCHEMA: raise RuntimeError("Terrain database schema metadata is invalid")
        base_resolution = int(float(meta.get("nominal_resolution_m") or 90))
        expected_grid = 1801 if base_resolution <= 30 else 601
        count = int(db.execute("SELECT count(*) FROM tiles").fetchone()[0])
        if count <= 0: raise RuntimeError("Terrain database contains no valid elevation tiles")
        valid = 0
        for rows, cols, encoding, blob, mn, mx in db.execute("SELECT rows,cols,encoding,data,min_elev_m,max_elev_m FROM tiles"):
            if rows != expected_grid or cols != expected_grid or encoding != "int16le+zlib": raise RuntimeError("Terrain database contains an invalid base tile shape/encoding")
            raw = zlib.decompress(blob)
            if len(raw) != rows * cols * 2: raise RuntimeError("Terrain database contains a malformed elevation tile")
            a, b = _valid_min_max(raw)
            if a is not None:
                valid += 1
                if mn != a or mx != b: raise RuntimeError("Terrain tile min/max metadata does not match payload")
        if valid <= 0: raise RuntimeError("Terrain database has no non-NODATA elevation tile")
        _ensure_overview_schema(db)
        overview_count = 0
        for tile_id, resolution_m, rows, cols, encoding, blob, mn, mx in db.execute("SELECT tile_id,resolution_m,rows,cols,encoding,data,min_elev_m,max_elev_m FROM tile_overviews"):
            if resolution_m <= base_resolution or rows < 2 or cols < 2 or encoding != "int16le+zlib": raise RuntimeError(f"Terrain overview {tile_id}/{resolution_m} is invalid")
            raw = zlib.decompress(blob)
            if len(raw) != rows * cols * 2: raise RuntimeError("Terrain database contains a malformed overview tile")
            a,b=_valid_min_max(raw)
            if a is not None and (mn != a or mx != b): raise RuntimeError("Terrain overview min/max metadata does not match payload")
            overview_count += 1
        return {"tile_count": count, "valid_tile_count": valid, "overview_count": overview_count, "base_resolution_m": base_resolution}
    finally: db.close()


def build(config_path: Path, code: str, *, force: bool = False) -> dict[str, Any]:
    code = code.upper()
    if code not in STATES: raise ValueError(f"Unknown state: {code}")
    r = roots(config_path); ensure_roots(r); state = STATES[code]
    profile = terrain_profile(config_path)
    job_control.checkpoint(config_path, "terrain", code)
    existing_before = ready_descriptor(config_path, code)
    # An older 90 m ready package must not prevent a partially downloaded
    # 30 m job from continuing. Retain old ready ZIP until atomic publication.
    if existing_before and not force and int(existing_before.get("nominal_resolution_m") or 90) == profile.nominal_resolution_m:
        return existing_before

    import fcntl
    invocation_started = utcnow()
    with r["lock"].open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        # Re-check after acquiring the global terrain lock. This prevents queued duplicate builds.
        current_ready = ready_descriptor(config_path, code)
        job_control.checkpoint(config_path, "terrain", code)
        if current_ready and not force and int(current_ready.get("nominal_resolution_m") or 90) == profile.nominal_resolution_m:
            return current_ready
        if force and current_ready and str(current_ready.get("built_utc") or "") > invocation_started:
            return current_ready

        _update_status(config_path, code, "preparing", "boundary", "Preparing 3D terrain state boundary")
        boundary_path = r["boundary_cache"] / code.lower() / "state.poly"; boundary_path.parent.mkdir(parents=True, exist_ok=True)
        fetch_geofabrik_boundary(state, boundary_path, force=False, urls=geofabrik_urls(state))
        geom = parse_geofabrik_poly(boundary_path.read_text(encoding="utf-8", errors="replace"))
        minx, miny, maxx, maxy = [float(v) for v in geom.bounds]
        from shapely.geometry import box
        cells=[]; y=_aligned_floor(miny); ymax=_aligned_ceil(maxy)
        while y < ymax - 1e-9:
            x=_aligned_floor(minx); xmax=_aligned_ceil(maxx)
            while x < xmax - 1e-9:
                cell=(round(x,10),round(y,10),round(x+TILE_SPAN_DEG,10),round(y+TILE_SPAN_DEG,10))
                if geom.intersects(box(*cell)): cells.append(cell)
                x += TILE_SPAN_DEG
            y += TILE_SPAN_DEG
        if not cells: raise RuntimeError("State boundary produced no candidate terrain cells")
        _disk_check(config_path, code, 1, stage="preflight")

        work=r["work"] / code.lower(); work.mkdir(parents=True, exist_ok=True)
        state_file=work / "build-state.json"
        fingerprint = json.dumps({"cells":cells,"resolution_m":profile.nominal_resolution_m,"grid_size":profile.grid_size}, separators=(",",":"))
        prior_state=read_json(state_file,{})
        # A resolution-upgrade keeps matching in-progress SQLite cells even
        # if a different-resolution ready package still exists.
        same_ready_resolution = bool(current_ready and int(current_ready.get("nominal_resolution_m") or 90) == profile.nominal_resolution_m)
        reset = bool(force and same_ready_resolution) or not isinstance(prior_state,dict) or prior_state.get("cells_fingerprint") != fingerprint
        if reset:
            for p in work.iterdir():
                if p.is_dir(): shutil.rmtree(p,ignore_errors=True)
                else: p.unlink(missing_ok=True)
            work.mkdir(parents=True, exist_ok=True); prior_state={}
        created = str(prior_state.get("created_utc") or utcnow())
        metadata={"schema":DB_SCHEMA,"package_format":PACKAGE_FORMAT,"state_code":code,"state_name":state.name,
                  "source_name":SOURCE_NAME,"source_url":SOURCE_URL,"sample_spacing_arcseconds":str(profile.sample_arcsec),
                  "nominal_resolution_m":str(profile.nominal_resolution_m),"tile_span_degrees":str(TILE_SPAN_DEG),
                  "grid_rows":str(profile.grid_size),"grid_cols":str(profile.grid_size),"nodata":str(NODATA),
                  "overview_resolutions_m":json.dumps([r for r,_ in overview_specs(profile)]),"created_utc":created}
        db_path=work/"terrain.sqlite"; db=_create_or_open_db(db_path,metadata,reset=reset)
        _ensure_overview_schema(db)
        atomic_json(state_file,{"schema":"takrig.terrain.build-state.v1","state_code":code,"created_utc":created,
                                "cells_fingerprint":fingerprint,"candidate_cells":len(cells),
                                "skipped_nodata":len((prior_state if isinstance(prior_state,dict) else {}).get("skipped_tile_ids") or []),
                                "skipped_tile_ids":(prior_state if isinstance(prior_state,dict) else {}).get("skipped_tile_ids") or []})
        existing_ids={row[0] for row in db.execute("SELECT tile_id FROM tiles")}
        skipped_ids=set(str(x) for x in ((prior_state if isinstance(prior_state,dict) else {}).get("skipped_tile_ids") or []))
        global_min=global_max=None
        for mn,mx in db.execute("SELECT min_elev_m,max_elev_m FROM tiles WHERE min_elev_m IS NOT NULL"):
            global_min=mn if global_min is None else min(global_min,mn)
            global_max=mx if global_max is None else max(global_max,mx)
        skipped=len(skipped_ids)
        completed=len(existing_ids)+skipped
        _disk_check(config_path, code, max(1, len(cells) - completed), stage="resume_preflight")
        job_control.checkpoint(config_path, "terrain", code)
        started=time.monotonic()
        try:
            # Keep up to four independent USGS cell requests in flight. The main
            # builder thread alone converts rasters and commits SQLite tiles.
            # Each cell has distinct scratch names, so downloads cannot collide.
            missing = [(west, south, east, north) for west, south, east, north in cells
                       if f"{west:+07.1f}_{south:+06.1f}" not in existing_ids
                       and f"{west:+07.1f}_{south:+06.1f}" not in skipped_ids]
            todo = iter(enumerate(missing))
            retry_queue = deque()
            retry_counts = {}
            worker_limit = TERRAIN_DOWNLOAD_WORKERS
            inflight = {}
            submitted_keys = set()
            def cleanup_cell(key):
                base = work / key
                for p in (work / f"{key}.tif", work / f"{key}.tif.part",
                          *work.glob(f"{key}.quarter*.tif"),
                          *work.glob(f"{key}.quarter*.tif.part"),
                          *_scratch_paths(base)):
                    p.unlink(missing_ok=True)

            def schedule(pool):
                # Stop new USGS requests as soon as Pause is requested;
                # already active requests finish and their tiles are committed.
                if job_control.requested(config_path, "terrain", code):
                    return False
                if retry_queue:
                    ordinal, (west, south, east, north) = retry_queue.popleft()
                else:
                    try:
                        ordinal, (west, south, east, north) = next(todo)
                    except StopIteration:
                        return False
                _disk_check(config_path, code, max(1, len(cells) - completed), stage="building")
                key = f"{west:+07.1f}_{south:+06.1f}"
                tiff = work / f"{key}.tif"
                submitted_keys.add(key)
                future = pool.submit(_download_export_with_fallback, west, south, east, north,
                                     tiff, profile)
                inflight[future] = (ordinal, west, south, east, north, key, tiff)
                return True

            try:
                with ThreadPoolExecutor(max_workers=TERRAIN_DOWNLOAD_WORKERS,
                                        thread_name_prefix="ndm-usgs") as pool:
                    for _ in range(TERRAIN_DOWNLOAD_WORKERS):
                        if not schedule(pool):
                            break
                    download_failure = None
                    while inflight:
                        _update_status(config_path,code,"building","downloading_3dep",
                                       f"Downloading up to {worker_limit} terrain cells; "
                                       f"{completed}/{len(cells)} complete",
                                       progress={"workers":worker_limit,"completed":completed,"total":len(cells),
                                                 "percent":int(completed*100/max(1,len(cells)))})
                        ready, _ = wait(tuple(inflight), return_when=FIRST_COMPLETED)
                        # Stable processing order when multiple requests complete together.
                        for future in sorted(ready, key=lambda f: inflight[f][0]):
                            ordinal,west,south,east,north,key,tiff = inflight.pop(future)
                            try:
                                tile_tiffs = future.result()
                                data = _tiff_to_int16_raw(tile_tiffs,work/key,west,south,east,north,profile=profile)
                                tile_min,tile_max = _valid_min_max(data)
                                if tile_min is None:
                                    skipped_ids.add(key); skipped=len(skipped_ids); completed += 1
                                else:
                                    global_min=tile_min if global_min is None else min(global_min,tile_min)
                                    global_max=tile_max if global_max is None else max(global_max,tile_max)
                                    db.execute("INSERT OR REPLACE INTO tiles(tile_id,west,south,east,north,rows,cols,min_elev_m,max_elev_m,encoding,data) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                                               (key,west,south,east,north,profile.grid_size,profile.grid_size,tile_min,tile_max,"int16le+zlib",zlib.compress(data,6)))
                                    db.execute("DELETE FROM tile_overviews WHERE tile_id=?", (key,))
                                    for resolution_m, factor in overview_specs(profile):
                                        overview, o_rows, o_cols = _decimate_int16(data, profile.grid_size, profile.grid_size, factor)
                                        o_min, o_max = _valid_min_max(overview)
                                        db.execute("INSERT OR REPLACE INTO tile_overviews(tile_id,resolution_m,sample_spacing_arcseconds,west,south,east,north,rows,cols,min_elev_m,max_elev_m,encoding,data) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                                                   (key,resolution_m,profile.sample_arcsec*factor,west,south,east,north,o_rows,o_cols,o_min,o_max,"int16le+zlib",zlib.compress(overview,6)))
                                    db.commit(); existing_ids.add(key); completed += 1
                                atomic_json(state_file,{"schema":"takrig.terrain.build-state.v1","state_code":code,"created_utc":created,
                                                        "cells_fingerprint":fingerprint,"candidate_cells":len(cells),"skipped_nodata":skipped,
                                                        "skipped_tile_ids":sorted(skipped_ids)})
                            except Exception as exc:
                                # After an exhausted USGS 502/503/504, retry
                                # the affected cell at a lower request rate.
                                # Other completed cells remain committed.
                                if (isinstance(exc, TransientTerrainExportError)
                                        and retry_counts.get(key,0) < 2
                                        and not job_control.requested(config_path,"terrain",code)):
                                    retry_counts[key] = retry_counts.get(key,0) + 1
                                    worker_limit = max(1, worker_limit // 2)
                                    retry_queue.append((ordinal,(west,south,east,north)))
                                    _update_status(config_path,code,"building","usgs_backoff",
                                                   f"USGS HTTP {exc.http_status}: retrying {key} with {worker_limit} simultaneous request(s)",
                                                   progress={"workers":worker_limit,"completed":completed,"total":len(cells),"percent":int(completed*100/max(1,len(cells)))})
                                elif download_failure is None:
                                    download_failure = exc
                            finally:
                                cleanup_cell(key)
                        # If one request fails, drain and commit any other already
                        # running successful downloads, then surface the first error.
                        # Do not dispatch additional work following a failure.
                        if download_failure is None:
                            while len(inflight) < worker_limit and schedule(pool):
                                pass
                    # The last in-flight request is committed before the pause
                    # is acknowledged and the process exits normally.
                    if download_failure is not None and not job_control.requested(config_path, "terrain", code):
                        raise download_failure
                    job_control.checkpoint(config_path, "terrain", code)
            finally:
                # Worker threads have finished before removing their scratch files.
                for key in submitted_keys:
                    cleanup_cell(key)
            job_control.checkpoint(config_path, "terrain", code)
            db.execute("PRAGMA wal_checkpoint(TRUNCATE)"); db.commit(); db.close(); db=None
            validation=_validate_database(db_path)
            stored_count=int(validation["tile_count"])
            coverage=_coverage_boxes(cells)
            # Preserve r23 compatibility. For antimeridian states, the legacy bounds field uses one safe coverage box
            # rather than spanning almost the whole world; coverage_boxes carries the complete r14 coverage model.
            legacy_bounds=coverage[0] if coverage else [minx,miny,maxx,maxy]
            manifest={"schema":PACKAGE_FORMAT,"format":PACKAGE_FORMAT,"state_code":code,"state_name":state.name,"revision":created,
                      "built_utc":created,"source":{"name":SOURCE_NAME,"url":SOURCE_URL,"product":"3DEP Bare Earth DEM Dynamic"},
                      "sample_spacing_arcseconds":profile.sample_arcsec,"nominal_resolution_m":profile.nominal_resolution_m,"tile_span_degrees":TILE_SPAN_DEG,
                      "grid_size":[profile.grid_size,profile.grid_size],"overview_resolutions_m":[r for r,_ in overview_specs(profile)],
                      "nodata":NODATA,"bounds":legacy_bounds,"coverage_boxes":coverage,
                      "antimeridian_wrapped":len(coverage)>1,"tile_count":stored_count,"candidate_tile_count":len(cells),
                      "skipped_nodata_tiles":skipped,"min_elevation_m":global_min,"max_elevation_m":global_max,
                      "database":"terrain.sqlite","database_schema":DB_SCHEMA,"manager_version":VERSION,
                      "sample_grid":f"{profile.sample_arcsec:g}-arc-second nodes; export pixel centers aligned to stored tile bounds"}
            atomic_json(work/"manifest.json",manifest)
            job_control.checkpoint(config_path, "terrain", code)
            _update_status(config_path,code,"packaging","validating_package","Validating and packaging 3D terrain",
                           progress={"completed":len(cells),"total":len(cells),"percent":100})
            final=package_path(config_path,code); part=final.with_name(final.name+".part"); part.unlink(missing_ok=True)
            with zipfile.ZipFile(part,"w",compression=zipfile.ZIP_STORED,allowZip64=True) as zf:
                zf.write(work/"manifest.json","manifest.json"); zf.write(db_path,"terrain.sqlite")
            with zipfile.ZipFile(part,"r") as zf:
                if {"manifest.json","terrain.sqlite"} - set(zf.namelist()): raise RuntimeError("Terrain package verification failed")
                bad=zf.testzip()
                if bad: raise RuntimeError(f"Terrain package CRC verification failed: {bad}")
            os.replace(part,final)
            desc=dict(manifest); desc.update({"package":final.name,"size_bytes":final.stat().st_size,"created_utc":created,
                                               "duration_seconds":round(time.monotonic()-started,2)})
            atomic_json(descriptor_path(config_path,code),desc)
            _update_status(config_path,code,"ready","ready","3D terrain package is ready",package=desc,
                           progress={"completed":len(cells),"total":len(cells),"percent":100})
            shutil.rmtree(work,ignore_errors=True); return desc
        finally:
            if db is not None:
                with contextlib.suppress(Exception): db.commit(); db.close()


def main() -> int:
    ap=argparse.ArgumentParser(description="TAK Rig 3D terrain package builder")
    ap.add_argument("--config",default=os.environ.get("TAKRIG_ROUTING_CONFIG","/etc/takrig-routing/config.json"))
    sub=ap.add_subparsers(dest="command",required=True)
    b=sub.add_parser("build"); b.add_argument("state"); b.add_argument("--force",action="store_true")
    s=sub.add_parser("status"); s.add_argument("state")
    r=sub.add_parser("remove"); r.add_argument("state")
    args=ap.parse_args(); cfg=Path(args.config)
    try:
        if args.command=="build": result=build(cfg,args.state,force=args.force)
        elif args.command=="status": result=status_summary(cfg,args.state)
        else: result={"removed":remove(cfg,args.state)}
        print(json.dumps(result,indent=2)); return 0
    except job_control.JobPaused as exc:
        print(f"PAUSED: {exc}", file=sys.stderr); return 0
    except TerrainWaitingSpace as exc:
        print(f"WAITING: {exc}",file=sys.stderr); return 3
    except Exception as exc:
        if getattr(args,"state","").upper() in STATES:
            code=args.state.upper(); prior=status_summary(cfg,code)
            if prior.get("status") != "waiting_space": _update_status(cfg,code,"failed","failed",str(exc),error=str(exc))
        print(f"ERROR: {exc}",file=sys.stderr); return 2


if __name__=="__main__": raise SystemExit(main())
