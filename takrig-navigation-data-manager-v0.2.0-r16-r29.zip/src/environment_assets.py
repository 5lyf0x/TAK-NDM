#!/usr/bin/env python3
"""Static photographic material and vegetation-impostor asset builder for TAK Rig.

The expensive source assets are acquired and normalized once on the Navigation Data
Manager and cached independently from state builds.  State environment packages keep
the strict two-member archive contract (manifest.json + environment.sqlite); the
prepared atlases and their compact catalogs are stored as optional SQLite BLOBs.

Live downloads use the public Poly Haven API/CDN.  Poly Haven's assets are CC0.  The
NDM UI includes the requested "Powered by Poly Haven" credit when the live API is used.
"""
from __future__ import annotations

import io
import json
import math
import os
import shutil
import sqlite3
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

ASSET_SET_REVISION = "cinematic-environment-v1"
ASSET_SCHEMA = "takrig.environment.assets.v1"
API_BASE = "https://api.polyhaven.com"
CDN_BASE = "https://cdn.polyhaven.com"
USER_AGENT = "TAK-Rig-NDM-cinematic-environment/1.0 (+OpenTAKServer field renderer)"
ALBEDO_ATLAS_SIZE = 2048
NORMAL_ATLAS_SIZE = 1024
MATERIAL_GRID = 8
TREE_ATLAS_WIDTH = 2048
TREE_ATLAS_HEIGHT = 1024
TREE_GRID_COLS = 8
TREE_GRID_ROWS = 4
HTTP_RETRIES = 4
TRANSIENT_HTTP = {408, 425, 429, 500, 502, 503, 504}

@dataclass(frozen=True)
class MaterialSpec:
    id: int
    family: str
    slug: str
    name: str
    physical_width_m: float
    normal_strength: float = 1.0
    role: str = "micro"

@dataclass(frozen=True)
class TreeSpec:
    id: int
    family: str
    slug: str
    name: str
    nominal_height_m: float

# Fixed atlas order.  IDs are part of the cinematic-environment-v1 wire contract.
# Physical widths are deliberately coarse renderer scales, not botanical/survey claims.
MATERIAL_SPECS: tuple[MaterialSpec, ...] = (
    MaterialSpec(0,"forest","forrest_ground_01","Forest Ground 01",4.0),
    MaterialSpec(1,"forest","forrest_ground_03","Forest Ground 03",4.0),
    MaterialSpec(2,"forest","forest_ground_04","Forest Ground 04",4.0),
    MaterialSpec(3,"shrub","dry_ground_rocks","Dry Ground Rocks",4.0),
    MaterialSpec(4,"shrub","rocky_trail_02","Rocky Trail 02",4.0),
    MaterialSpec(5,"shrub","rocks_ground_02","Rocks Ground 02",4.0),
    MaterialSpec(6,"grass","leafy_grass","Leafy Grass",4.0),
    MaterialSpec(7,"grass","sparse_grass","Sparse Grass",4.0),
    MaterialSpec(8,"grass","withered_grass","Withered Grass",4.0),
    MaterialSpec(9,"crop","farm_furrows","Farm Furrows",8.0),
    MaterialSpec(10,"crop","dry_mud_field_001","Dry Mud Field 001",6.0),
    MaterialSpec(11,"crop","dirt_aerial_02","Dirt Aerial 02",20.0,0.72,"macro"),
    MaterialSpec(12,"bare","dirt","Dirt",4.0),
    MaterialSpec(13,"bare","dry_ground_01","Dry Ground 01",4.0),
    MaterialSpec(14,"bare","gravelly_sand","Gravelly Sand",4.0),
    MaterialSpec(15,"bare","sand_01","Sand 01",4.0),
    MaterialSpec(16,"rock","rock_face","Rock Face",6.0,1.15),
    MaterialSpec(17,"rock","marble_cliff_03","Marble Cliff 03",5.7,1.15),
    MaterialSpec(18,"rock","rock_ground","Rock Ground",4.0,1.10),
    MaterialSpec(19,"rock","rocks_ground_04","Rocks Ground 04",4.0,1.10),
    MaterialSpec(20,"wetland","brown_mud_03","Brown Mud 03",4.0),
    MaterialSpec(21,"wetland","mud_forest","Mud Forest",4.0),
    MaterialSpec(22,"wetland","brown_mud_leaves_01","Brown Mud Leaves 01",4.0),
    MaterialSpec(23,"wetland","rocks_ground_08","Rocks Ground 08",4.0),
    MaterialSpec(24,"snow","snow_02","Snow 02",4.0,0.72),
    MaterialSpec(25,"snow","snow_01","Snow 01",4.0,0.76),
    MaterialSpec(26,"snow","snow_field_aerial","Snow Field Aerial",80.0,0.42,"macro"),
    MaterialSpec(27,"urban","asphalt_04","Asphalt 04",4.0,0.65),
    MaterialSpec(28,"urban","hangar_concrete_floor","Hangar Concrete Floor",4.0,0.55),
    MaterialSpec(29,"urban","gravel","Gravel",4.0),
    MaterialSpec(30,"urban","tarred_gravel","Tarred Gravel",4.0,0.85),
    MaterialSpec(31,"generic","dirt_aerial_03","Dirt Aerial 03",25.0,0.64,"macro"),
    MaterialSpec(32,"generic","aerial_ground_rock","Aerial Ground Rock",20.0,0.72,"macro"),
    MaterialSpec(33,"generic","park_dirt","Park Dirt",4.0),
    MaterialSpec(34,"generic","stony_dirt_path","Stony Dirt Path",4.0),
)

TREE_SPECS: tuple[TreeSpec, ...] = (
    TreeSpec(0,"conifer","pine_tree_01","Pine Tree 01",14.0),
    TreeSpec(1,"conifer","fir_tree_01","Fir Tree 01",16.0),
    TreeSpec(2,"conifer","pine_sapling_medium","Pine Sapling Medium",7.0),
    TreeSpec(3,"broadleaf","tree_small_02","Tree Small 02",4.6),
    TreeSpec(4,"broadleaf","jacaranda_tree","Jacaranda Tree",10.0),
    TreeSpec(5,"dry","island_tree_01","Island Tree 01",6.0),
    TreeSpec(6,"dry","island_tree_02","Island Tree 02",5.0),
    TreeSpec(7,"arid","quiver_tree_01","Quiver Tree 01",5.0),
    TreeSpec(8,"arid","quiver_tree_02","Quiver Tree 02",5.0),
)

# Normalized TAK Rig class -> weighted material IDs.  Duplicate IDs are intentional weights.
MATERIAL_POOLS: dict[int, tuple[int, ...]] = {
    0:(31,32,33,34), 1:(), 2:(27,28,29,30), 3:(0,1,2), 4:(3,4,5),
    5:(6,7,8), 6:(9,10,11), 7:(12,13,14,15), 8:(20,21,22,23), 9:(24,25,26),
}


def _http_bytes(url: str, accept: str = "*/*", timeout: int = 120) -> bytes:
    last: Exception | None = None
    for attempt in range(1, HTTP_RETRIES + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": accept})
            with urllib.request.urlopen(req, timeout=timeout) as response:
                data = response.read()
            if len(data) < 32:
                raise RuntimeError(f"Unexpectedly small asset response from {url}")
            return data
        except urllib.error.HTTPError as exc:
            last = exc
            if exc.code not in TRANSIENT_HTTP or attempt >= HTTP_RETRIES:
                raise
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as exc:
            last = exc
            if attempt >= HTTP_RETRIES:
                raise
        time.sleep(min(8.0, 1.25 * (2 ** (attempt - 1))))
    raise RuntimeError(str(last or f"Unable to download {url}"))


def _http_json(url: str) -> Any:
    return json.loads(_http_bytes(url, "application/json").decode("utf-8"))


def _walk_urls(node: Any, path: tuple[str, ...] = ()) -> Iterable[tuple[tuple[str, ...], str]]:
    if isinstance(node, dict):
        if isinstance(node.get("url"), str):
            yield path, node["url"]
        for key, value in node.items():
            if key == "url":
                continue
            yield from _walk_urls(value, path + (str(key).lower(),))
    elif isinstance(node, list):
        for index, value in enumerate(node):
            yield from _walk_urls(value, path + (str(index),))


def _pick_texture_map(files: Any, kind: str) -> str:
    candidates: list[tuple[int, str]] = []
    map_tokens = ("diff", "diffuse", "albedo", "basecolor", "base_color") if kind == "diff" else ("nor_gl", "normal_gl", "normal", "nor")
    for path, url in _walk_urls(files):
        text = "/".join(path) + " " + url.lower()
        score = 0
        if any(token in text for token in map_tokens): score += 80
        if kind == "normal" and ("nor_dx" in text or "normal_dx" in text): score -= 90
        if "1k" in text: score += 30
        elif "2k" in text: score += 18
        if ".png" in text: score += 12
        elif ".jpg" in text or ".jpeg" in text: score += 8
        if "blend" in text or ".zip" in text or ".exr" in text: score -= 25
        if score > 60: candidates.append((score, url))
    if not candidates:
        raise RuntimeError(f"Poly Haven file tree contains no usable {kind} map")
    candidates.sort(key=lambda item: (-item[0], item[1]))
    return candidates[0][1]


def _load_pil():
    try:
        from PIL import Image, ImageChops  # type: ignore
    except ImportError as exc:
        raise RuntimeError("Pillow is required for cinematic environment atlas generation") from exc
    return Image, ImageChops


def _paste_with_gutter(atlas: Any, image: Any, x: int, y: int, cell: int, gutter: int = 4) -> None:
    Image, _ = _load_pil()
    inner = max(1, cell - gutter * 2)
    fitted = image.convert(atlas.mode).resize((inner, inner), Image.Resampling.LANCZOS)
    atlas.paste(fitted, (x + gutter, y + gutter))
    # Duplicate edge pixels into the gutter so mipmapping cannot bleed adjacent materials.
    atlas.paste(fitted.crop((0, 0, 1, inner)).resize((gutter, inner)), (x, y + gutter))
    atlas.paste(fitted.crop((inner-1, 0, inner, inner)).resize((gutter, inner)), (x + cell - gutter, y + gutter))
    atlas.paste(fitted.crop((0, 0, inner, 1)).resize((inner, gutter)), (x + gutter, y))
    atlas.paste(fitted.crop((0, inner-1, inner, inner)).resize((inner, gutter)), (x + gutter, y + cell - gutter))
    atlas.paste(fitted.crop((0, 0, 1, 1)).resize((gutter, gutter)), (x, y))
    atlas.paste(fitted.crop((inner-1, 0, inner, 1)).resize((gutter, gutter)), (x + cell - gutter, y))
    atlas.paste(fitted.crop((0, inner-1, 1, inner)).resize((gutter, gutter)), (x, y + cell - gutter))
    atlas.paste(fitted.crop((inner-1, inner-1, inner, inner)).resize((gutter, gutter)), (x + cell - gutter, y + cell - gutter))


def _decode_image(data: bytes):
    Image, _ = _load_pil()
    with Image.open(io.BytesIO(data)) as source:
        source.load()
        return source.copy()


def _tree_render_url(slug: str, view: str, height: int = 512) -> str:
    return f"{CDN_BASE}/asset_img/renders/{slug}/orth_{view}.png?height={height}&quality=95"


def _tree_rgba(image: Any):
    Image, ImageChops = _load_pil()
    rgba = image.convert("RGBA")
    alpha = rgba.getchannel("A")
    if alpha.getextrema()[0] < 250:
        return rgba
    # Some CDN transforms may flatten transparency.  Remove only pixels near the corner
    # background color; this is a fail-soft source cleanup, not a foliage segmentation pass.
    rgb = rgba.convert("RGB")
    corner = rgb.getpixel((0, 0))
    bg = Image.new("RGB", rgb.size, corner)
    diff = ImageChops.difference(rgb, bg).convert("L")
    alpha = diff.point(lambda p: 0 if p < 10 else min(255, (p - 10) * 8))
    rgba.putalpha(alpha)
    return rgba


def _fit_tree_into_cell(image: Any, cell: int = 256, pad: int = 6):
    Image, _ = _load_pil()
    rgba = _tree_rgba(image)
    box = rgba.getbbox()
    if not box:
        return Image.new("RGBA", (cell, cell), (0,0,0,0))
    crop = rgba.crop(box)
    target = cell - pad * 2
    scale = min(target / max(1, crop.width), target / max(1, crop.height))
    new_size = (max(1, int(crop.width * scale)), max(1, int(crop.height * scale)))
    crop = crop.resize(new_size, Image.Resampling.LANCZOS)
    out = Image.new("RGBA", (cell, cell), (0,0,0,0))
    x = (cell - crop.width) // 2
    y = cell - pad - crop.height  # ground/base aligned near bottom
    out.alpha_composite(crop, (x, max(pad, y)))
    return out


def _save_jpeg(image: Any, quality: int) -> bytes:
    buf = io.BytesIO(); image.convert("RGB").save(buf, "JPEG", quality=quality, optimize=True, progressive=False); return buf.getvalue()


def _save_png(image: Any) -> bytes:
    buf = io.BytesIO(); image.save(buf, "PNG", optimize=True, compress_level=9); return buf.getvalue()


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".tmp-{os.getpid()}")
    temp.write_bytes(data); os.replace(temp, path)


def build_static_bundle(cache_dir: Path, force: bool = False) -> dict[str, Any]:
    """Return metadata plus prepared atlas byte payloads, building/cacheing as needed."""
    Image, _ = _load_pil()
    cache_dir.mkdir(parents=True, exist_ok=True)
    meta_path = cache_dir / "bundle.json"
    albedo_path = cache_dir / "ground-albedo.jpg"
    normal_path = cache_dir / "ground-normal.jpg"
    tree_path = cache_dir / "trees.png"
    required = (meta_path, albedo_path, normal_path, tree_path)
    if not force and all(p.is_file() and p.stat().st_size > 64 for p in required):
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        if meta.get("asset_set") == ASSET_SET_REVISION:
            return {**meta,"albedo":albedo_path.read_bytes(),"normal":normal_path.read_bytes(),"tree_atlas":tree_path.read_bytes()}

    albedo = Image.new("RGB", (ALBEDO_ATLAS_SIZE, ALBEDO_ATLAS_SIZE), (128,128,128))
    normal = Image.new("RGB", (NORMAL_ATLAS_SIZE, NORMAL_ATLAS_SIZE), (128,128,255))
    acell = ALBEDO_ATLAS_SIZE // MATERIAL_GRID
    ncell = NORMAL_ATLAS_SIZE // MATERIAL_GRID
    material_rows = []
    raw_cache = cache_dir / "source"
    raw_cache.mkdir(parents=True, exist_ok=True)

    for spec in MATERIAL_SPECS:
        file_tree_path = raw_cache / f"{spec.slug}.files.json"
        if force or not file_tree_path.is_file():
            tree = _http_json(f"{API_BASE}/files/{spec.slug}")
            _atomic_write(file_tree_path, (json.dumps(tree,sort_keys=True)+"\n").encode())
        else:
            tree = json.loads(file_tree_path.read_text(encoding="utf-8"))
        diff_url = _pick_texture_map(tree, "diff")
        normal_url = _pick_texture_map(tree, "normal")
        diff_file = raw_cache / f"{spec.slug}.diff"
        normal_file = raw_cache / f"{spec.slug}.normal"
        if force or not diff_file.is_file(): _atomic_write(diff_file, _http_bytes(diff_url, "image/*"))
        if force or not normal_file.is_file(): _atomic_write(normal_file, _http_bytes(normal_url, "image/*"))
        diff = _decode_image(diff_file.read_bytes())
        norm = _decode_image(normal_file.read_bytes())
        col = spec.id % MATERIAL_GRID; row = spec.id // MATERIAL_GRID
        _paste_with_gutter(albedo, diff, col * acell, row * acell, acell, 4)
        _paste_with_gutter(normal, norm, col * ncell, row * ncell, ncell, 3)
        material_rows.append({"id":spec.id,"family":spec.family,"slug":spec.slug,"name":spec.name,
                              "atlas_index":spec.id,"physical_width_m":spec.physical_width_m,
                              "normal_strength":spec.normal_strength,"role":spec.role})

    tree_atlas = Image.new("RGBA", (TREE_ATLAS_WIDTH, TREE_ATLAS_HEIGHT), (0,0,0,0))
    tcell = TREE_ATLAS_WIDTH // TREE_GRID_COLS
    tree_rows = []
    index = 0
    for spec in TREE_SPECS:
        indices = {}
        for view in ("front","side","top"):
            url = _tree_render_url(spec.slug, view)
            source_path = raw_cache / f"{spec.slug}.{view}.png"
            if force or not source_path.is_file(): _atomic_write(source_path, _http_bytes(url, "image/png,image/*"))
            fitted = _fit_tree_into_cell(_decode_image(source_path.read_bytes()), tcell)
            col = index % TREE_GRID_COLS; row = index // TREE_GRID_COLS
            tree_atlas.alpha_composite(fitted, (col*tcell, row*tcell))
            indices[view] = index; index += 1
        tree_rows.append({"id":spec.id,"family":spec.family,"slug":spec.slug,"name":spec.name,
                          "front_index":indices["front"],"side_index":indices["side"],"top_index":indices["top"],
                          "nominal_height_m":spec.nominal_height_m})

    albedo_bytes = _save_jpeg(albedo, 90)
    normal_bytes = _save_jpeg(normal, 92)
    tree_bytes = _save_png(tree_atlas)
    _atomic_write(albedo_path, albedo_bytes); _atomic_write(normal_path, normal_bytes); _atomic_write(tree_path, tree_bytes)
    meta = {"schema":ASSET_SCHEMA,"asset_set":ASSET_SET_REVISION,"powered_by":"Poly Haven","license":"CC0",
            "albedo_width":ALBEDO_ATLAS_SIZE,"albedo_height":ALBEDO_ATLAS_SIZE,
            "normal_width":NORMAL_ATLAS_SIZE,"normal_height":NORMAL_ATLAS_SIZE,
            "material_grid":MATERIAL_GRID,"tree_width":TREE_ATLAS_WIDTH,"tree_height":TREE_ATLAS_HEIGHT,
            "tree_grid_cols":TREE_GRID_COLS,"tree_grid_rows":TREE_GRID_ROWS,
            "materials":material_rows,"tree_catalog":tree_rows,"material_pools":{str(k):list(v) for k,v in MATERIAL_POOLS.items()}}
    _atomic_write(meta_path, (json.dumps(meta,indent=2,sort_keys=True)+"\n").encode())
    return {**meta,"albedo":albedo_bytes,"normal":normal_bytes,"tree_atlas":tree_bytes}


def ensure_tables(db: sqlite3.Connection) -> None:
    db.executescript("""
    CREATE TABLE IF NOT EXISTS cinematic_metadata(name TEXT PRIMARY KEY,value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS cinematic_assets(name TEXT PRIMARY KEY,mime TEXT NOT NULL,width INTEGER NOT NULL,height INTEGER NOT NULL,data BLOB NOT NULL);
    CREATE TABLE IF NOT EXISTS materials(material_id INTEGER PRIMARY KEY,family TEXT NOT NULL,slug TEXT NOT NULL,display_name TEXT NOT NULL,atlas_index INTEGER NOT NULL,physical_width_m REAL NOT NULL,normal_strength REAL NOT NULL,role TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS material_pools(class_id INTEGER NOT NULL,ordinal INTEGER NOT NULL,material_id INTEGER NOT NULL,weight REAL NOT NULL DEFAULT 1.0,PRIMARY KEY(class_id,ordinal));
    CREATE TABLE IF NOT EXISTS tree_catalog(tree_id INTEGER PRIMARY KEY,family TEXT NOT NULL,slug TEXT NOT NULL,display_name TEXT NOT NULL,front_index INTEGER NOT NULL,side_index INTEGER NOT NULL,top_index INTEGER NOT NULL,nominal_height_m REAL NOT NULL);
    """)


def install_bundle(db: sqlite3.Connection, bundle: dict[str, Any]) -> None:
    ensure_tables(db)
    for table in ("cinematic_metadata","cinematic_assets","materials","material_pools","tree_catalog"):
        db.execute(f"DELETE FROM {table}")
    metadata = {"schema":ASSET_SCHEMA,"asset_set":ASSET_SET_REVISION,"powered_by":"Poly Haven","license":"CC0",
                "material_count":str(len(bundle["materials"])),"tree_source_count":str(len(bundle["tree_catalog"])),
                "material_grid":str(bundle["material_grid"]),"tree_grid_cols":str(bundle["tree_grid_cols"]),
                "tree_grid_rows":str(bundle["tree_grid_rows"]),
                "render_profile":"cinematic-environment-v1.1",
                "material_transition_feather_m":"60",
                "tree_height_scale":"1.50",
                "forest_density_scale":"1.50",
                "tree_min_projected_px":"0.60"}
    db.executemany("INSERT INTO cinematic_metadata(name,value) VALUES(?,?)", metadata.items())
    db.executemany("INSERT INTO cinematic_assets(name,mime,width,height,data) VALUES(?,?,?,?,?)", (
        ("ground_albedo","image/jpeg",bundle["albedo_width"],bundle["albedo_height"],sqlite3.Binary(bundle["albedo"])),
        ("ground_normal","image/jpeg",bundle["normal_width"],bundle["normal_height"],sqlite3.Binary(bundle["normal"])),
        ("tree_impostors","image/png",bundle["tree_width"],bundle["tree_height"],sqlite3.Binary(bundle["tree_atlas"])),
    ))
    db.executemany("INSERT INTO materials VALUES(?,?,?,?,?,?,?,?)", ((m["id"],m["family"],m["slug"],m["name"],m["atlas_index"],m["physical_width_m"],m["normal_strength"],m["role"]) for m in bundle["materials"]))
    pool_rows=[]
    for class_id, ids in MATERIAL_POOLS.items():
        for ordinal, material_id in enumerate(ids): pool_rows.append((class_id,ordinal,material_id,1.0))
    db.executemany("INSERT INTO material_pools VALUES(?,?,?,?)",pool_rows)
    db.executemany("INSERT INTO tree_catalog VALUES(?,?,?,?,?,?,?,?)", ((t["id"],t["family"],t["slug"],t["name"],t["front_index"],t["side_index"],t["top_index"],t["nominal_height_m"]) for t in bundle["tree_catalog"]))
    db.commit()


def install_optional_cinematic_assets(db: sqlite3.Connection, cache_dir: Path, force: bool = False) -> dict[str, Any]:
    """Build/install the optional v1 assets.  Caller decides whether failures are fatal."""
    bundle = build_static_bundle(cache_dir, force=force)
    install_bundle(db,bundle)
    return {"asset_set":ASSET_SET_REVISION,"material_count":len(bundle["materials"]),"tree_source_count":len(bundle["tree_catalog"]),
            "asset_bytes":len(bundle["albedo"])+len(bundle["normal"])+len(bundle["tree_atlas"]),"powered_by":"Poly Haven"}
