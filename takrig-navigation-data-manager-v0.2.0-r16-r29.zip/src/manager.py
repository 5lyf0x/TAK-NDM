#!/usr/bin/env python3
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
import concurrent.futures
import fcntl
import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import uuid
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import job_control
from state_catalog import STATES, PRESETS, validate_states
from sources import (
    all_specs_for_state,
    all_available_specs_for_state,
    spec_group,
    fetch_geofabrik_state,
    fetch_geofabrik_boundary,
    fetch_supplemental_sources,
    geofabrik_urls,
    head_metadata,
    http_request,
    parse_geofabrik_md5,
    download_text,
    sha256_file,
    source_public_summary,
    utcnow,
)
from enrich import apply_supplemental
from terrain import ready_descriptor as terrain_ready_descriptor, status_summary as terrain_status_summary, remove as remove_terrain
import environment
import cellular

VERSION = "0.2.0-r16-r29"
# Display/service release can advance for UI/transport-only fixes without forcing routing rebuilds.
ROUTING_PIPELINE_REVISION = "0.2.0-r16"
CATALOG_SCHEMA = "takrig.nav.catalog.v1"
SETTINGS_SCHEMA = "takrig.nav.manager.settings.v2"
STATE_SCHEMA = "takrig.nav.manager.state.v1"
_TERRAIN_SPAWN_LOCK = threading.Lock()
_ENVIRONMENT_SPAWN_LOCK = threading.Lock()
_CELLULAR_SPAWN_LOCK = threading.Lock()

DEFAULT_CONFIG: dict[str, Any] = {
    "state_root": "/var/lib/takrig-routing",
    "log_root": "/var/log/takrig-routing",
    "web_host": "0.0.0.0",
    "web_port": 8765,
    "discovery_enabled": True,
    "discovery_port": 47818,
    "discovery_name": "",
    "source_update_interval_days": 30,
    "reconcile_min_interval_seconds": 60,
    "download_timeout_seconds": 300,
    "source_download_concurrency": 3,
    "source_per_host_concurrency": 2,
    "minimum_free_disk_gib": 30.0,
    "source_cache_limit_gib": 100.0,
    "maintenance_window_start_local": "00:00",
    "automatic_rebuild_enabled": True,
    "terrain_resolution_m": 30,
    "fcc_bdc_api_base": "https://broadbandmap.fcc.gov/api/public/map",
    "fcc_bdc_api_fallback": "https://bdc.fcc.gov/api/public/map",
    "fcc_bdc_credentials_file": "/etc/takrig-routing/fcc-bdc.env",
    "cellular_h3_chunk_resolution": 6,
    "allow_web_secret_management": True,
    "selected_states": [],
    "state_sources": {},
    "sources": {
        "osm": {"enabled": True},
        "state_dot": {"enabled": True},
        "usfs": {"enabled": True},
        "blm": {"enabled": True},
        "state_recreation": {"enabled": True},
        "nps": {"enabled": True},
        "usgs": {"enabled": True},
    },
}


def json_load(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def atomic_text(path: Path, text: str) -> None:
    """Atomically replace *path* using a collision-proof same-directory temporary file.

    r16-r2 used PID + millisecond timestamps. Concurrent supplemental-source
    callbacks can execute in the same process and millisecond, causing two writers
    to share one temporary filename. The first os.replace() then removes the file
    out from under the second writer. Include thread identity + UUID and clean up
    an unused temporary file on failure.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(
        path.name + f".part-{os.getpid()}-{threading.get_ident()}-{uuid.uuid4().hex}"
    )
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        with contextlib.suppress(FileNotFoundError):
            tmp.unlink()


def atomic_json(path: Path, data: Any) -> None:
    atomic_text(path, json.dumps(data, indent=2, sort_keys=False) + "\n")


def parse_iso(value: str) -> dt.datetime | None:
    value = str(value or "").strip()
    if not value:
        return None
    try:
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def days_old(value: str) -> float:
    stamp = parse_iso(value)
    if stamp is None:
        return 10**9
    return max(0.0, (dt.datetime.now(dt.timezone.utc) - stamp).total_seconds() / 86400.0)


def normalize_update_interval_days(value: Any, default: int = 30) -> int:
    """Validate the user-configurable normal upstream source-check interval."""
    try:
        days = int(value)
    except (TypeError, ValueError):
        return int(default)
    return max(1, min(365, days))


def normalize_int(value: Any, default: int, low: int, high: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = int(default)
    return max(low, min(high, parsed))


def normalize_float(value: Any, default: float, low: float, high: float) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        parsed = float(default)
    return max(low, min(high, parsed))


def normalize_local_time(value: Any, default: str = "00:00") -> str:
    text = str(value or default).strip()
    if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", text):
        return default
    return text


def stable_hash(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def successful_revision_snapshot(remote: dict[str, Any], *, include_osm: bool = True) -> dict[str, Any]:
    """Return only successful revision evidence so temporary endpoint errors never look like data changes."""
    out: dict[str, Any] = {"agency": {}}
    osm = remote.get("osm_geofabrik") or {}
    if include_osm and isinstance(osm, dict) and osm.get("ok"):
        out["osm_geofabrik"] = {k: osm.get(k) for k in ("md5", "etag", "last_modified", "content_length")}
    for key, value in (remote.get("agency") or {}).items():
        if isinstance(value, dict) and value.get("ok"):
            out["agency"][key] = {
                k: value.get(k) for k in ("last_edit_date", "service_item_id", "name", "current_version")
            }
    manual = remote.get("manual_osm_pbf") or {}
    if isinstance(manual, dict) and manual.get("ok"):
        out["manual_osm_pbf"] = {k: manual.get(k) for k in ("sha256", "size_bytes")}
    return out


def merge_remote_revisions(previous: dict[str, Any], current: dict[str, Any], *, include_osm: bool = True) -> dict[str, Any]:
    """Keep last-known-good validators for any upstream endpoint that is temporarily unavailable."""
    merged: dict[str, Any] = {"agency": {}}
    prev_osm = previous.get("osm_geofabrik") or {}
    cur_osm = current.get("osm_geofabrik") or {}
    if include_osm:
        merged["osm_geofabrik"] = cur_osm if isinstance(cur_osm, dict) and cur_osm.get("ok") else prev_osm
    if previous.get("manual_osm_pbf"):
        merged["manual_osm_pbf"] = previous.get("manual_osm_pbf")
    prev_agency = previous.get("agency") or {}
    cur_agency = current.get("agency") or {}
    for key in set(prev_agency) | set(cur_agency):
        value = cur_agency.get(key)
        if isinstance(value, dict) and value.get("ok"):
            merged["agency"][key] = value
        elif key in prev_agency:
            merged["agency"][key] = prev_agency[key]
    errors: dict[str, str] = {}
    if include_osm and isinstance(cur_osm, dict) and not cur_osm.get("ok"):
        errors["osm_geofabrik"] = str(cur_osm.get("error") or "revision check failed")
    for key, value in cur_agency.items():
        if isinstance(value, dict) and not value.get("ok"):
            errors[key] = str(value.get("error") or "revision check failed")
    if errors:
        merged["check_errors"] = errors
    return merged


class ManagerConfig:
    def __init__(self, path: Path):
        self.path = path
        loaded = json_load(path, {}) if path.is_file() else {}
        self.data = dict(DEFAULT_CONFIG)
        self.data.update({k: v for k, v in loaded.items() if k != "sources"})
        sources = json.loads(json.dumps(DEFAULT_CONFIG["sources"]))
        for key, value in (loaded.get("sources") or {}).items():
            if isinstance(value, dict):
                sources.setdefault(key, {}).update(value)
        self.data["sources"] = sources

    @property
    def root(self) -> Path: return Path(str(self.data["state_root"])).expanduser().resolve()
    @property
    def manager_root(self) -> Path: return self.root / "manager"
    @property
    def cache_root(self) -> Path: return self.manager_root / "sources"
    @property
    def incoming(self) -> Path: return self.root / "incoming"
    @property
    def processing(self) -> Path: return self.root / "processing"
    @property
    def ready(self) -> Path: return self.root / "ready"
    @property
    def failed(self) -> Path: return self.root / "failed"
    @property
    def log_root(self) -> Path: return Path(str(self.data["log_root"])).expanduser().resolve()
    @property
    def settings_path(self) -> Path: return self.manager_root / "settings.json"
    @property
    def state_path(self) -> Path: return self.manager_root / "state.json"
    def ensure(self) -> None:
        for p in [self.root, self.manager_root, self.cache_root, self.incoming, self.processing,
                  self.ready, self.failed, self.log_root, self.manager_root / "manual"]:
            p.mkdir(parents=True, exist_ok=True)
        if not self.settings_path.is_file():
            atomic_json(self.settings_path, {
                "schema": SETTINGS_SCHEMA,
                "selected_states": validate_states(list(self.data.get("selected_states") or [])),
                "sources": self.data["sources"],
                "state_sources": {},
                "source_update_interval_days": normalize_update_interval_days(
                    self.data.get("source_update_interval_days", 30)
                ),
                "source_download_concurrency": normalize_int(self.data.get("source_download_concurrency", 3), 3, 1, 6),
                "source_per_host_concurrency": normalize_int(self.data.get("source_per_host_concurrency", 2), 2, 1, 4),
                "minimum_free_disk_gib": normalize_float(self.data.get("minimum_free_disk_gib", 30.0), 30.0, 5.0, 5000.0),
                "source_cache_limit_gib": normalize_float(self.data.get("source_cache_limit_gib", 100.0), 100.0, 1.0, 5000.0),
                "maintenance_window_start_local": normalize_local_time(self.data.get("maintenance_window_start_local", "00:00")),
                "automatic_rebuild_enabled": bool(self.data.get("automatic_rebuild_enabled", True)),
                "terrain_resolution_m": 30 if int(self.data.get("terrain_resolution_m", 30) or 30) <= 30 else 90,
                "updated_utc": utcnow(),
            })
        if not self.state_path.is_file():
            atomic_json(self.state_path, {"schema": STATE_SCHEMA, "states": {}, "updated_utc": utcnow()})

    def settings(self) -> dict[str, Any]:
        self.ensure()
        raw = json_load(self.settings_path, {})
        data = dict(raw) if isinstance(raw, dict) else {}
        data.setdefault("schema", SETTINGS_SCHEMA)
        data["selected_states"] = validate_states(list(data.get("selected_states") or self.data.get("selected_states") or []))
        sources = json.loads(json.dumps(self.data["sources"]))
        for key, value in (data.get("sources") or {}).items():
            if isinstance(value, dict):
                sources.setdefault(key, {}).update(value)
        sources.setdefault("osm", {})["enabled"] = True
        data["sources"] = sources
        state_sources = data.get("state_sources") or {}
        if not isinstance(state_sources, dict):
            state_sources = {}
        data["state_sources"] = {str(k).upper(): v for k, v in state_sources.items() if str(k).upper() in STATES and isinstance(v, dict)}
        data["source_update_interval_days"] = normalize_update_interval_days(
            data.get("source_update_interval_days", self.data.get("source_update_interval_days", 30)),
            normalize_update_interval_days(self.data.get("source_update_interval_days", 30)),
        )
        data["source_download_concurrency"] = normalize_int(
            data.get("source_download_concurrency", self.data.get("source_download_concurrency", 3)), 3, 1, 6
        )
        data["source_per_host_concurrency"] = normalize_int(
            data.get("source_per_host_concurrency", self.data.get("source_per_host_concurrency", 2)), 2, 1, 4
        )
        data["minimum_free_disk_gib"] = normalize_float(
            data.get("minimum_free_disk_gib", self.data.get("minimum_free_disk_gib", 30.0)), 30.0, 5.0, 5000.0
        )
        data["source_cache_limit_gib"] = normalize_float(
            data.get("source_cache_limit_gib", self.data.get("source_cache_limit_gib", 100.0)), 100.0, 1.0, 5000.0
        )
        data["maintenance_window_start_local"] = normalize_local_time(
            data.get("maintenance_window_start_local", self.data.get("maintenance_window_start_local", "00:00"))
        )
        data["automatic_rebuild_enabled"] = bool(
            data.get("automatic_rebuild_enabled", self.data.get("automatic_rebuild_enabled", True))
        )
        try:
            terrain_res = int(data.get("terrain_resolution_m", self.data.get("terrain_resolution_m", 30)) or 30)
        except (TypeError, ValueError):
            terrain_res = 30
        data["terrain_resolution_m"] = 30 if terrain_res <= 30 else 90
        data.setdefault("updated_utc", "")
        return data

    def save_settings(self, selected_states: list[str] | None = None,
                      sources: dict[str, Any] | None = None,
                      source_update_interval_days: Any | None = None,
                      source_download_concurrency: Any | None = None,
                      source_per_host_concurrency: Any | None = None,
                      minimum_free_disk_gib: Any | None = None,
                      source_cache_limit_gib: Any | None = None,
                      maintenance_window_start_local: Any | None = None,
                      automatic_rebuild_enabled: Any | None = None,
                      terrain_resolution_m: Any | None = None) -> dict[str, Any]:
        # settings.json is modified by multiple independent Web/API actions.  Keep
        # the complete read/modify/write transaction under one lock so a state-
        # source save cannot be lost if an operations/selection save lands at the
        # same time (and vice versa).
        with self.settings_write_lock():
            current = self.settings()
            if selected_states is not None:
                current["selected_states"] = validate_states(selected_states)
            if sources is not None:
                for key, value in sources.items():
                    if key == "osm":
                        continue
                    if key in current["sources"] and isinstance(value, dict):
                        current["sources"][key].update({"enabled": bool(value.get("enabled", True))})
            current["sources"].setdefault("osm", {})["enabled"] = True
            if source_update_interval_days is not None:
                current["source_update_interval_days"] = normalize_update_interval_days(
                    source_update_interval_days, current.get("source_update_interval_days", 30)
                )
            if source_download_concurrency is not None:
                current["source_download_concurrency"] = normalize_int(source_download_concurrency, current.get("source_download_concurrency", 3), 1, 6)
            if source_per_host_concurrency is not None:
                current["source_per_host_concurrency"] = normalize_int(source_per_host_concurrency, current.get("source_per_host_concurrency", 2), 1, 4)
            if minimum_free_disk_gib is not None:
                current["minimum_free_disk_gib"] = normalize_float(minimum_free_disk_gib, current.get("minimum_free_disk_gib", 30.0), 5.0, 5000.0)
            if source_cache_limit_gib is not None:
                current["source_cache_limit_gib"] = normalize_float(source_cache_limit_gib, current.get("source_cache_limit_gib", 100.0), 1.0, 5000.0)
            if maintenance_window_start_local is not None:
                current["maintenance_window_start_local"] = normalize_local_time(maintenance_window_start_local)
            if automatic_rebuild_enabled is not None:
                current["automatic_rebuild_enabled"] = bool(automatic_rebuild_enabled)
            if terrain_resolution_m is not None:
                try: terrain_res = int(terrain_resolution_m)
                except (TypeError, ValueError): terrain_res = int(current.get("terrain_resolution_m", 30))
                current["terrain_resolution_m"] = 30 if terrain_res <= 30 else 90
            current["schema"] = SETTINGS_SCHEMA
            current["updated_utc"] = utcnow()
            atomic_json(self.settings_path, current)
            return current


    def state_source_settings(self, code: str) -> dict[str, Any]:
        """Return normalized per-state source settings, auto-populated from the built-in registry."""
        code = str(code).upper()
        if code not in STATES:
            raise ValueError("Unknown state")
        settings = self.settings()
        state = STATES[code]
        raw = dict((settings.get("state_sources") or {}).get(code) or {})
        preset = str(raw.get("preset") or "standard").lower()
        if preset not in {"standard", "maximum", "custom"}:
            preset = "standard"
        saved = raw.get("sources") or {}
        if not isinstance(saved, dict):
            saved = {}
        entries: dict[str, Any] = {}
        core_default = geofabrik_urls(state)
        core_saved = saved.get("osm") if isinstance(saved.get("osm"), dict) else {}
        entries["osm"] = {
            "enabled": True,
            "endpoint_override": str(core_saved.get("endpoint_override") or "").strip(),
            "metadata_url_override": str(core_saved.get("metadata_url_override") or "").strip(),
            "boundary_url_override": str(core_saved.get("boundary_url_override") or "").strip(),
            "default_endpoint": core_default["pbf"],
            "default_metadata_url": core_default["md5"],
            "default_boundary_url": core_default["poly"],
        }
        for spec in all_available_specs_for_state(state):
            old = saved.get(spec.source_id) if isinstance(saved.get(spec.source_id), dict) else {}
            # Per-state source policy is authoritative in r19.  The old global
            # group toggles were an r9 compatibility layer and must not silently
            # disable the majority of sources for a newly opened state.  They are
            # still understood by sources.all_specs_for_state() for old callers,
            # but state-scoped defaults now depend only on the selected preset.
            if preset == "maximum":
                default_on = True
            elif preset == "standard":
                default_on = bool(spec.routable)
            else:
                default_on = bool(spec.routable)
            entries[spec.source_id] = {
                "enabled": bool(old.get("enabled", default_on)),
                "endpoint_override": str(old.get("endpoint_override") or "").strip(),
                "default_endpoint": spec.layer_url,
            }
            if spec.profile_revision:
                entries[spec.source_id]["profile_revision"] = spec.profile_revision
        return {"preset": preset, "sources": entries}

    def save_state_sources(self, code: str, payload: dict[str, Any]) -> dict[str, Any]:
        code = str(code).upper()
        if code not in STATES:
            raise ValueError("Unknown state")
        with self.settings_write_lock():
            current = self.state_source_settings(code)
            preset = str(payload.get("preset") or current.get("preset") or "custom").lower()
            if preset not in {"standard", "maximum", "custom"}:
                raise ValueError("Preset must be Standard, Maximum Coverage, or Custom")
            incoming = payload.get("sources") or {}
            if not isinstance(incoming, dict):
                raise ValueError("sources must be an object")
            state = STATES[code]
            known = {"osm": None, **{s.source_id: s for s in all_available_specs_for_state(state)}}
            out_sources: dict[str, Any] = {}
            for sid, spec in known.items():
                old = current["sources"].get(sid) or {}
                row = incoming.get(sid) if isinstance(incoming.get(sid), dict) else {}
                if sid == "osm":
                    out_sources[sid] = {
                        "enabled": True,
                        "endpoint_override": str(row.get("endpoint_override", old.get("endpoint_override", "")) or "").strip(),
                        "metadata_url_override": str(row.get("metadata_url_override", old.get("metadata_url_override", "")) or "").strip(),
                        "boundary_url_override": str(row.get("boundary_url_override", old.get("boundary_url_override", "")) or "").strip(),
                    }
                    continue
                assert spec is not None
                if preset == "standard":
                    enabled = bool(spec.routable)
                elif preset == "maximum":
                    enabled = True
                else:
                    # The Web state editor submits every row.  Honor those values
                    # exactly in Custom mode; partial API callers remain backwards
                    # compatible by inheriting the previously saved value.
                    enabled = bool(row.get("enabled", old.get("enabled", spec.routable)))
                out_sources[sid] = {
                    "enabled": enabled,
                    "endpoint_override": str(row.get("endpoint_override", old.get("endpoint_override", "")) or "").strip(),
                }
            settings = self.settings()
            before = current
            state_sources = dict(settings.get("state_sources") or {})
            state_sources[code] = {"preset": preset, "sources": out_sources, "updated_utc": utcnow()}
            settings["state_sources"] = state_sources
            settings["schema"] = SETTINGS_SCHEMA
            settings["updated_utc"] = utcnow()
            atomic_json(self.settings_path, settings)
            after = self.state_source_settings(code)
            return {"settings": after, "changed": stable_hash(before) != stable_hash(after)}

    @contextlib.contextmanager
    def settings_write_lock(self):
        """Serialize settings.json read/modify/write across threads and processes."""
        self.ensure()
        lock_path = self.manager_root / "settings.lock"
        with lock_path.open("a+") as fh:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)

    def _state_unlocked(self) -> dict[str, Any]:
        data = json_load(self.state_path, {})
        if not isinstance(data, dict):
            data = {}
        if not isinstance(data.get("states"), dict):
            data["states"] = {}
        data.setdefault("schema", STATE_SCHEMA)
        return data

    def _save_state_unlocked(self, data: dict[str, Any]) -> None:
        data["schema"] = STATE_SCHEMA
        data["updated_utc"] = utcnow()
        atomic_json(self.state_path, data)

    @contextlib.contextmanager
    def state_write_lock(self):
        """Serialize state.json read/modify/write across threads and processes."""
        self.ensure()
        lock_path = self.manager_root / "state.lock"
        with lock_path.open("a+") as fh:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)

    def state(self) -> dict[str, Any]:
        self.ensure()
        return self._state_unlocked()

    def update_state(self, mutator) -> Any:
        """Run one complete state.json read/modify/write transaction under state.lock."""
        with self.state_write_lock():
            data = self._state_unlocked()
            result = mutator(data)
            self._save_state_unlocked(data)
            return result

    def save_state(self, data: dict[str, Any]) -> None:
        # Direct whole-state writes are also serialized. Read/modify/write callers
        # should prefer update_state() so no concurrent writer can be lost.
        with self.state_write_lock():
            self._save_state_unlocked(data)


@contextlib.contextmanager
def manager_lock(cfg: ManagerConfig):
    cfg.ensure()
    path = cfg.manager_root / "manager.lock"
    with path.open("a+") as fh:
        try:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("Navigation Data Manager reconciliation is already running")
        try:
            yield
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def log_line(cfg: ManagerConfig, text: str) -> None:
    stamp = utcnow()
    line = f"[{stamp}] {text}"
    print(line, flush=True)
    cfg.log_root.mkdir(parents=True, exist_ok=True)
    with (cfg.log_root / "manager.log").open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def arcgis_revision(layer_url: str) -> dict[str, Any]:
    url = layer_url.rstrip("/") + "?f=pjson"
    try:
        with http_request(url, timeout=35) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
        editing = data.get("editingInfo") or {}
        geometry_type = str(data.get("geometryType") or "")
        capabilities = str(data.get("capabilities") or "")
        schema_ok = geometry_type in {"esriGeometryPolyline", ""} and (not capabilities or "Query" in capabilities)
        return {
            "ok": True,
            "schema_ok": schema_ok,
            "geometry_type": geometry_type,
            "capabilities": capabilities,
            "last_edit_date": editing.get("lastEditDate"),
            "service_item_id": data.get("serviceItemId") or data.get("serviceItemID") or "",
            "name": data.get("name") or "",
            "current_version": data.get("currentVersion"),
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def effective_geofabrik_urls(state_code: str, source_settings: dict[str, Any]) -> dict[str, str]:
    state = STATES[state_code]
    defaults = geofabrik_urls(state)
    entries = source_settings.get("sources") if isinstance(source_settings.get("sources"), dict) else {}
    core = entries.get("osm") if isinstance(entries.get("osm"), dict) else {}
    pbf = str(core.get("endpoint_override") or defaults["pbf"]).strip()
    # When a custom PBF endpoint is supplied and metadata is not, a conventional
    # adjacent .md5 is the safest default.  The exact boundary remains the built-in
    # state polygon unless the user explicitly overrides it.
    md5 = str(core.get("metadata_url_override") or (pbf + ".md5" if core.get("endpoint_override") else defaults["md5"])).strip()
    poly = str(core.get("boundary_url_override") or defaults["poly"]).strip()
    return {"pbf": pbf, "md5": md5, "poly": poly}


def remote_revision_for_state(state_code: str, source_settings: dict[str, Any]) -> dict[str, Any]:
    state = STATES[state_code]
    urls = effective_geofabrik_urls(state_code, source_settings)
    geofabrik: dict[str, Any] = {}
    try:
        md5 = parse_geofabrik_md5(download_text(urls["md5"], timeout=30))
        meta = head_metadata(urls["pbf"], timeout=30)
        geofabrik = {"ok": True, "md5": md5, "etag": meta.get("etag", ""),
                     "last_modified": meta.get("last_modified", ""),
                     "content_length": meta.get("content_length", 0),
                     "url": urls["pbf"], "metadata_url": urls["md5"], "boundary_url": urls["poly"]}
    except Exception as exc:
        geofabrik = {"ok": False, "error": str(exc), "url": urls["pbf"], "metadata_url": urls["md5"], "boundary_url": urls["poly"]}
    agency: dict[str, Any] = {}
    for spec in all_specs_for_state(state, source_settings):
        revision = arcgis_revision(spec.layer_url)
        revision["url"] = spec.layer_url
        agency[spec.source_id] = revision
    return {"osm_geofabrik": geofabrik, "agency": agency}


def current_source_fingerprint(source_settings: dict[str, Any], state_code: str = "") -> str:
    # r10 state-scoped configuration.  Include effective endpoints so a URL edit
    # invalidates only the affected state's package fingerprint.
    if isinstance(source_settings.get("sources"), dict) and "preset" in source_settings:
        rows = []
        for sid, row in sorted((source_settings.get("sources") or {}).items()):
            if not isinstance(row, dict):
                continue
            fingerprint_row = {
                "id": sid,
                "enabled": True if sid == "osm" else bool(row.get("enabled", False)),
                "endpoint": str(row.get("endpoint_override") or row.get("default_endpoint") or ""),
                "metadata_url": str(row.get("metadata_url_override") or row.get("default_metadata_url") or "") if sid == "osm" else "",
                "boundary_url": str(row.get("boundary_url_override") or row.get("default_boundary_url") or "") if sid == "osm" else "",
            }
            # Keep CA/AZ/UT and legacy r16 fingerprints byte-for-byte stable.
            # Only newly versioned state adapters contribute this key.
            if row.get("profile_revision"):
                fingerprint_row["profile_revision"] = str(row.get("profile_revision"))
            rows.append(fingerprint_row)
        return stable_hash({"manager_version": ROUTING_PIPELINE_REVISION, "state": state_code, "preset": source_settings.get("preset"), "sources": rows})

    # Legacy r9 global-group settings are still understood for migration/tests.
    public = []
    for src in source_public_summary():
        key = src["id"]
        enabled = True if key == "osm" else bool((source_settings.get(key) or {}).get("enabled", True))
        public.append({"id": key, "enabled": enabled})
    return stable_hash({"manager_version": ROUTING_PIPELINE_REVISION, "sources": public})


def effective_build_fingerprint(source_fingerprint: str, remote_revision: dict[str, Any], *, include_osm: bool = True) -> str:
    """Fingerprint the exact desired inputs used to decide whether a failed build may be retried."""
    return stable_hash({
        # Keep the historical key name so r16 fingerprints remain byte-for-byte compatible.
        "manager_version": ROUTING_PIPELINE_REVISION,
        "source_fingerprint": source_fingerprint,
        "remote_revision": successful_revision_snapshot(remote_revision, include_osm=include_osm),
    })


def _runtime_entry(cfg: ManagerConfig, code: str) -> dict[str, Any]:
    state = cfg.state()
    states = state.setdefault("states", {})
    row = states.get(code)
    return dict(row) if isinstance(row, dict) else {}


def update_runtime(cfg: ManagerConfig, code: str, status: str, *, stage: str = "", detail: str = "",
                   new_attempt: bool = False, clear_failure: bool = False, **extra: Any) -> dict[str, Any]:
    def mutate(state: dict[str, Any]) -> dict[str, Any]:
        states = state.setdefault("states", {})
        row = dict(states.get(code) or {})
        now = utcnow()
        previous_stage = str(row.get("stage") or "")
        row.update({"status": status, "stage": stage or status, "detail": detail, "updated_utc": now, **extra})
        if new_attempt:
            previous_failure = row.get("failure")
            if isinstance(previous_failure, dict):
                history = list(row.get("failure_history") or [])
                history.append(previous_failure)
                row["failure_history"] = history[-10:]
                row.pop("failure", None)
            row["attempt_started_utc"] = now
            row["last_attempt_utc"] = now
        if (stage or status) != previous_stage:
            row["stage_started_utc"] = now
        if clear_failure:
            row.pop("failure", None)
        states[code] = row
        return dict(row)
    return cfg.update_state(mutate)


def record_manager_failure(cfg: ManagerConfig, code: str, error: Exception | str,
                           build_fingerprint: str = "") -> dict[str, Any]:
    current = _runtime_entry(cfg, code)
    now = utcnow()
    failure = {
        "kind": "manager",
        "stage": current.get("stage") or "preparing",
        "error": str(error),
        "failed_utc": now,
        "build_fingerprint": build_fingerprint or current.get("build_fingerprint") or "",
        "manager_version": VERSION,
    }
    return update_runtime(
        cfg, code, "failed", stage=str(failure["stage"]), detail=str(error),
        failure=failure, last_attempt_utc=now, build_fingerprint=failure["build_fingerprint"],
    )


def manager_failure_for_state(cfg: ManagerConfig, code: str) -> dict[str, Any] | None:
    row = _runtime_entry(cfg, code)
    failure = row.get("failure")
    if isinstance(failure, dict):
        return dict(failure)
    return None


def _directory_size(root: Path, *, exclude_dir_name: str | None = None) -> int:
    total = 0
    if not root.exists():
        return 0
    for current, dirs, files in os.walk(root):
        if exclude_dir_name:
            dirs[:] = [d for d in dirs if d != exclude_dir_name]
        for name in files:
            with contextlib.suppress(OSError):
                total += (Path(current) / name).stat().st_size
    return total


_STORAGE_CACHE_LOCK = threading.Lock()
_STORAGE_CACHE_AT = 0.0
_STORAGE_CACHE_VALUE: dict[str, int] = {}


def storage_summary(cfg: ManagerConfig) -> dict[str, int]:
    global _STORAGE_CACHE_AT, _STORAGE_CACHE_VALUE
    now = time.monotonic()
    with _STORAGE_CACHE_LOCK:
        if _STORAGE_CACHE_VALUE and now - _STORAGE_CACHE_AT < 30.0:
            return dict(_STORAGE_CACHE_VALUE)
        temp = 0
        for path in cfg.cache_root.glob("*/enrich-work"):
            temp += _directory_size(path)
        value = {
            "source_cache_bytes": _directory_size(cfg.cache_root, exclude_dir_name="enrich-work"),
            "temporary_work_bytes": temp,
            "processing_bytes": _directory_size(cfg.incoming) + _directory_size(cfg.processing),
            "ready_packages_bytes": _directory_size(cfg.ready),
            "failed_jobs_bytes": _directory_size(cfg.failed),
        }
        _STORAGE_CACHE_AT = now
        _STORAGE_CACHE_VALUE = value
        return dict(value)



def disk_policy_summary(cfg: ManagerConfig) -> dict[str, Any]:
    settings = cfg.settings()
    usage = shutil.disk_usage(cfg.root)
    return {
        "total_bytes": usage.total,
        "used_bytes": usage.used,
        "free_bytes": usage.free,
        "minimum_free_bytes": int(float(settings.get("minimum_free_disk_gib", 30.0)) * 1024**3),
        "source_cache_limit_bytes": int(float(settings.get("source_cache_limit_gib", 100.0)) * 1024**3),
    }


def state_storage_summary(cfg: ManagerConfig, code: str) -> dict[str, int]:
    p = source_cache_paths(cfg, code)
    source = _directory_size(p["root"], exclude_dir_name="enrich-work")
    temp = _directory_size(p["enrich_work"])
    return {"source_cache_bytes": source, "temporary_work_bytes": temp, "reclaimable_bytes": source + temp}


def estimate_state_peak(cfg: ManagerConfig, code: str, remote: dict[str, Any] | None = None) -> dict[str, int]:
    p = source_cache_paths(cfg, code)
    existing_base = p["base"].stat().st_size if p["base"].is_file() else 0
    remote_base = int(((remote or {}).get("osm_geofabrik") or {}).get("content_length") or 0)
    base = max(existing_base, remote_base, 512 * 1024**2)
    supplemental = _directory_size(p["supplemental"])
    ready = ready_descriptor(cfg, code) or {}
    package = int(ready.get("size_bytes") or max(base, 512 * 1024**2))
    # R7 intentionally keeps the R6 enriched-PBF architecture. Peak estimate includes
    # base replacement, enriched graph input, processor copy/build scratch, and package.
    projected_peak = int(base * 3.6 + max(supplemental, 256 * 1024**2) + package * 1.35)
    return {
        "base_source_bytes": base,
        "supplemental_bytes": supplemental,
        "expected_package_bytes": package,
        "projected_peak_additional_bytes": projected_peak,
    }


def storage_gate(cfg: ManagerConfig, code: str, remote: dict[str, Any] | None = None) -> tuple[bool, dict[str, Any]]:
    policy = disk_policy_summary(cfg)
    estimate = estimate_state_peak(cfg, code, remote)
    storage = storage_summary(cfg)
    projected_required = policy["minimum_free_bytes"] + estimate["projected_peak_additional_bytes"]
    cache_after = storage["source_cache_bytes"] + max(0, estimate["base_source_bytes"] - state_storage_summary(cfg, code)["source_cache_bytes"])
    ok_free = policy["free_bytes"] >= projected_required
    ok_cache = cache_after <= policy["source_cache_limit_bytes"]
    detail = {
        **policy,
        **estimate,
        "projected_required_free_bytes": projected_required,
        "projected_source_cache_bytes": cache_after,
        "free_ok": ok_free,
        "cache_limit_ok": ok_cache,
    }
    return bool(ok_free and ok_cache), detail


def maintenance_eligible_utc(start_local: str, now: dt.datetime | None = None) -> str:
    local_now = now or dt.datetime.now().astimezone()
    if local_now.tzinfo is None:
        local_now = local_now.astimezone()
    hh, mm = (int(x) for x in normalize_local_time(start_local).split(":"))
    candidate = local_now.replace(hour=hh, minute=mm, second=0, microsecond=0)
    # Allow the periodic reconciler to start queued work shortly after the daily
    # trigger; otherwise discoveries made after the trigger wait for the next one.
    if candidate <= local_now <= candidate + dt.timedelta(hours=1):
        eligible = candidate
    elif local_now < candidate:
        eligible = candidate
    else:
        eligible = candidate + dt.timedelta(days=1)
    return eligible.astimezone(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def maintenance_due(eligible_utc: str) -> bool:
    stamp = parse_iso(eligible_utc)
    return bool(stamp and dt.datetime.now(dt.timezone.utc) >= stamp)


def determine_update_reason(prior: dict[str, Any], remote: dict[str, Any], previous_remote: dict[str, Any],
                            source_config_changed: bool, missing: bool, force_rebuild: bool) -> str:
    if force_rebuild:
        return "Manual rebuild"
    if missing:
        return "Initial state build"
    prior_pipeline = str(prior.get("routing_pipeline_revision") or prior.get("manager_version") or "")
    if prior_pipeline and prior_pipeline != ROUTING_PIPELINE_REVISION:
        return f"Routing pipeline upgraded {prior_pipeline} → {ROUTING_PIPELINE_REVISION}"
    if source_config_changed:
        return "Source configuration or manager revision changed"
    prev_osm = str(((previous_remote.get("osm_geofabrik") or {}).get("md5") or ""))
    cur_osm = str(((remote.get("osm_geofabrik") or {}).get("md5") or ""))
    if cur_osm and prev_osm and cur_osm != prev_osm:
        return "OSM revision changed"
    prev_agency = previous_remote.get("agency") or {}
    cur_agency = remote.get("agency") or {}
    changed = []
    for key in sorted(set(prev_agency) | set(cur_agency)):
        if stable_hash((prev_agency.get(key) or {})) != stable_hash((cur_agency.get(key) or {})):
            changed.append(key)
    if changed:
        return (changed[0] + " changed") if len(changed) == 1 else f"{len(changed)} supplemental sources changed"
    return "Source refresh requested"


def source_group_for_id(source_id: str, role: str = "") -> str:
    if source_id.startswith("usfs_"): return "usfs"
    if source_id.startswith("blm_"): return "blm"
    if source_id.startswith("nps_"): return "nps"
    if source_id.startswith("usgs_"): return "usgs"
    if role == "public_road_authority": return "state_dot"
    if role in {"state_recreation_authority", "reference_only"} and not source_id.startswith(("nps_", "usgs_")):
        return "state_recreation"
    return "state_recreation"


def source_health_summary(cfg: ManagerConfig) -> list[dict[str, Any]]:
    settings = cfg.settings()
    selected = settings.get("selected_states") or []
    base_rows = {row["id"]: dict(row) for row in source_public_summary()}
    for key, row in base_rows.items():
        row["enabled"] = True if key == "osm" else bool((settings.get("sources", {}).get(key) or {}).get("enabled", True))
        row["endpoints"] = []
        row["last_checked_utc"] = ""
        row["health"] = "not_checked"
        row["last_error"] = ""
        row["revision"] = ""
    for code in selected:
        state = STATES[code]
        urls = geofabrik_urls(state)
        base_rows["osm"]["endpoints"].append({"state": code, "url": urls["pbf"], "metadata_url": urls["md5"], "boundary_url": urls["poly"]})
        for spec in all_specs_for_state(state, settings.get("sources") or {}):
            key = source_group_for_id(spec.source_id, spec.role)
            if key in base_rows:
                base_rows[key]["endpoints"].append({"state": code, "source_id": spec.source_id, "url": spec.layer_url})
        manifest = json_load(source_cache_paths(cfg, code)["manifest"], {})
        checked = str(manifest.get("checked_utc") or "")
        remote = manifest.get("remote_revision") or {}
        if checked:
            base_rows["osm"]["last_checked_utc"] = max(str(base_rows["osm"].get("last_checked_utc") or ""), checked)
        osm = remote.get("osm_geofabrik") or {}
        if isinstance(osm, dict) and osm.get("ok"):
            base_rows["osm"]["health"] = "healthy"
            base_rows["osm"]["revision"] = str(osm.get("md5") or osm.get("etag") or osm.get("last_modified") or "")
        elif isinstance(osm, dict) and osm.get("error"):
            base_rows["osm"]["health"] = "error"
            base_rows["osm"]["last_error"] = str(osm.get("error"))
        for sid, rev in (remote.get("agency") or {}).items():
            spec = next((x for x in all_specs_for_state(state, settings.get("sources") or {}) if x.source_id == sid), None)
            if not spec: continue
            key = source_group_for_id(sid, spec.role)
            if key not in base_rows: continue
            if checked: base_rows[key]["last_checked_utc"] = max(str(base_rows[key].get("last_checked_utc") or ""), checked)
            if isinstance(rev, dict) and rev.get("ok"):
                if base_rows[key]["health"] != "error": base_rows[key]["health"] = "healthy"
                base_rows[key]["revision"] = str(rev.get("last_edit_date") or rev.get("service_item_id") or rev.get("current_version") or "")
            elif isinstance(rev, dict) and rev.get("error"):
                base_rows[key]["health"] = "error"
                base_rows[key]["last_error"] = str(rev.get("error"))
    probes = cfg.state().get("source_probes") or {}
    for key, probe in probes.items():
        if key not in base_rows or not isinstance(probe, dict):
            continue
        row = base_rows[key]
        checked = str(probe.get("checked_utc") or "")
        if checked >= str(row.get("last_checked_utc") or ""):
            row["last_checked_utc"] = checked
            row["health"] = str(probe.get("health") or row.get("health") or "not_checked")
            errors = [str(x.get("error")) for x in (probe.get("results") or []) if isinstance(x, dict) and x.get("error")]
            if errors: row["last_error"] = errors[0]
    for row in base_rows.values():
        seen = set(); unique = []
        for endpoint in row["endpoints"]:
            key = json.dumps(endpoint, sort_keys=True)
            if key not in seen:
                seen.add(key); unique.append(endpoint)
        row["endpoints"] = unique
        if not row["enabled"]:
            row["health"] = "disabled"
    return list(base_rows.values())


def source_probe(cfg: ManagerConfig, source_id: str) -> dict[str, Any]:
    rows = {row["id"]: row for row in source_health_summary(cfg)}
    if source_id not in rows:
        raise ValueError("Unknown source")
    row = rows[source_id]
    results = []
    for endpoint in row.get("endpoints") or []:
        url = str(endpoint.get("url") or "")
        if not url: continue
        try:
            meta = head_metadata(url, timeout=30)
            results.append({**endpoint, "ok": True, "status": meta.get("status", 200), "content_length": meta.get("content_length", 0), "last_modified": meta.get("last_modified", ""), "etag": meta.get("etag", "")})
        except Exception as exc:
            results.append({**endpoint, "ok": False, "error": str(exc)})
    health = "healthy" if results and all(x.get("ok") for x in results) else "error" if results else "not_configured"
    probe = {"source_id": source_id, "checked_utc": utcnow(), "health": health, "results": results}
    cfg.update_state(lambda state: state.setdefault("source_probes", {}).__setitem__(source_id, probe))
    return probe

def _state_probe_record(cfg: ManagerConfig, code: str, source_id: str) -> dict[str, Any]:
    state = cfg.state()
    return dict((((state.get("state_source_probes") or {}).get(code) or {}).get(source_id) or {}))


def state_source_probe(cfg: ManagerConfig, code: str, source_id: str, overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    code = str(code).upper()
    if code not in STATES:
        raise ValueError("Unknown state")
    state_cfg = cfg.state_source_settings(code)
    state = STATES[code]
    overrides = overrides if isinstance(overrides, dict) else {}
    if source_id == "osm":
        probe_cfg = json.loads(json.dumps(state_cfg))
        core = probe_cfg.setdefault("sources", {}).setdefault("osm", {})
        for key in ("endpoint_override", "metadata_url_override", "boundary_url_override"):
            if key in overrides:
                core[key] = str(overrides.get(key) or "").strip()
        urls = effective_geofabrik_urls(code, probe_cfg)
        try:
            meta = head_metadata(urls["pbf"], timeout=30)
            md5 = ""
            try:
                md5 = parse_geofabrik_md5(download_text(urls["md5"], timeout=30))
            except Exception:
                pass
            result = {"ok": True, "status": meta.get("status", 200), "content_length": meta.get("content_length", 0),
                      "last_modified": meta.get("last_modified", ""), "etag": meta.get("etag", ""), "md5": md5,
                      "url": urls["pbf"], "metadata_url": urls["md5"], "boundary_url": urls["poly"]}
        except Exception as exc:
            result = {"ok": False, "error": str(exc), "url": urls["pbf"], "metadata_url": urls["md5"], "boundary_url": urls["poly"]}
    else:
        spec = next((x for x in all_specs_for_state(state, {"preset": "custom", "sources": {
            sid: {**row, "enabled": (sid == source_id)} for sid, row in state_cfg["sources"].items()
        }}) if x.source_id == source_id), None)
        if spec is None:
            # Source may currently be disabled; resolve directly from the registry and override.
            base = next((x for x in all_available_specs_for_state(state) if x.source_id == source_id), None)
            if base is None:
                raise ValueError("Source is not configured for this state")
            row = state_cfg["sources"].get(source_id) or {}
            from dataclasses import replace as _dc_replace
            endpoint = str(overrides.get("endpoint_override") if "endpoint_override" in overrides else row.get("endpoint_override") or "").strip()
            spec = _dc_replace(base, layer_url=endpoint or base.layer_url)
        if "endpoint_override" in overrides:
            from dataclasses import replace as _dc_replace
            endpoint = str(overrides.get("endpoint_override") or "").strip()
            base_default = next((x.layer_url for x in all_available_specs_for_state(state) if x.source_id == source_id), spec.layer_url)
            spec = _dc_replace(spec, layer_url=endpoint or base_default)
        result = arcgis_revision(spec.layer_url)
        result["url"] = spec.layer_url
    probe_health = "healthy" if result.get("ok") else "error"
    if result.get("ok") and result.get("schema_ok") is False:
        probe_health = "schema_changed"
    probe = {"state_code": code, "source_id": source_id, "checked_utc": utcnow(),
             "health": probe_health, "result": result}
    def save_probe(root: dict[str, Any]) -> None:
        root.setdefault("state_source_probes", {}).setdefault(code, {})[source_id] = probe
    cfg.update_state(save_probe)
    return probe


def state_source_panel(cfg: ManagerConfig, code: str) -> dict[str, Any]:
    code = str(code).upper()
    if code not in STATES:
        raise ValueError("Unknown state")
    state = STATES[code]
    state_cfg = cfg.state_source_settings(code)
    manifest = json_load(source_cache_paths(cfg, code)["manifest"], {})
    remote = manifest.get("remote_revision") or {}
    checked = str(manifest.get("checked_utc") or "")
    rows: list[dict[str, Any]] = []

    core = state_cfg["sources"]["osm"]
    core_urls = effective_geofabrik_urls(code, state_cfg)
    osm_rev = remote.get("osm_geofabrik") or {}
    core_probe = _state_probe_record(cfg, code, "osm")
    health = "not_checked"
    error = ""
    revision = ""
    last_checked = checked
    if isinstance(osm_rev, dict) and osm_rev.get("ok"):
        health = "healthy"; revision = str(osm_rev.get("md5") or osm_rev.get("etag") or osm_rev.get("last_modified") or "")
    elif isinstance(osm_rev, dict) and osm_rev.get("error"):
        health = "error"; error = str(osm_rev.get("error"))
    if core_probe and str(core_probe.get("checked_utc") or "") >= last_checked:
        last_checked = str(core_probe.get("checked_utc") or "")
        health = str(core_probe.get("health") or health)
        if not (core_probe.get("result") or {}).get("ok"):
            error = str((core_probe.get("result") or {}).get("error") or error)
    rows.append({
        "id": "osm", "name": "OpenStreetMap / Geofabrik", "group": "Core", "role": "Base Network",
        "description": "Primary connected road network. Always enabled.", "enabled": True, "locked": True, "routable": True,
        "endpoint": core_urls["pbf"], "default_endpoint": core.get("default_endpoint") or geofabrik_urls(state)["pbf"],
        "metadata_url": core_urls["md5"], "default_metadata_url": core.get("default_metadata_url") or geofabrik_urls(state)["md5"],
        "boundary_url": core_urls["poly"], "default_boundary_url": core.get("default_boundary_url") or geofabrik_urls(state)["poly"],
        "endpoint_mode": "custom" if core.get("endpoint_override") or core.get("metadata_url_override") or core.get("boundary_url_override") else "default",
        "health": health, "last_checked_utc": last_checked, "revision": revision, "last_error": error,
    })

    available = {spec.source_id: spec for spec in all_available_specs_for_state(state)}
    agency = remote.get("agency") or {}
    for sid, spec in available.items():
        row_cfg = state_cfg["sources"].get(sid) or {}
        endpoint = str(row_cfg.get("endpoint_override") or spec.layer_url)
        rev = agency.get(sid) or {}
        probe = _state_probe_record(cfg, code, sid)
        src_health = "not_checked"; src_error = ""; src_revision = ""; src_checked = checked
        if isinstance(rev, dict) and rev.get("ok"):
            src_health = "schema_changed" if rev.get("schema_ok") is False else "healthy"
            src_revision = str(rev.get("last_edit_date") or rev.get("service_item_id") or rev.get("current_version") or "")
            if rev.get("schema_ok") is False:
                src_error = f"Expected queryable polyline layer; got {rev.get('geometry_type') or 'unknown geometry/capabilities'}"
        elif isinstance(rev, dict) and rev.get("error"):
            src_health = "error"; src_error = str(rev.get("error"))
        if probe and str(probe.get("checked_utc") or "") >= src_checked:
            src_checked = str(probe.get("checked_utc") or "")
            src_health = str(probe.get("health") or src_health)
            if not (probe.get("result") or {}).get("ok"):
                src_error = str((probe.get("result") or {}).get("error") or src_error)
        rows.append({
            "id": sid, "name": spec.name, "group": spec_group(spec), "role": spec.role,
            "description": ("Supplemental state road authority; only Core-missing geometry is added." if spec.role == "public_road_authority" else
                            "Reference-only; does not independently grant vehicle routing access." if not spec.routable else
                            "Vehicle-capable supplemental routing source."),
            "enabled": bool(row_cfg.get("enabled", False)), "locked": False, "routable": bool(spec.routable),
            "endpoint": endpoint, "default_endpoint": spec.layer_url,
            "endpoint_mode": "custom" if row_cfg.get("endpoint_override") else "default",
            # Keep endpoint health independent from enablement.  The checkbox is
            # the source-of-truth for enabled/disabled; a disabled source may still
            # have a useful last-known HEALTHY/ERROR/NOT_CHECKED probe state.
            "health": src_health,
            "last_checked_utc": src_checked, "revision": src_revision, "last_error": src_error,
        })
    enabled_count = sum(1 for r in rows if r.get("enabled"))
    group_counts: dict[str, int] = {}
    for row in rows:
        if row.get("enabled"):
            group_counts[row["group"]] = group_counts.get(row["group"], 0) + 1
    return {"state_code": code, "state_name": state.name, "preset": state_cfg.get("preset", "standard"),
            "sources": rows, "enabled_count": enabled_count, "available_count": len(rows), "group_counts": group_counts}


def state_source_selection_summary(cfg: ManagerConfig, code: str) -> dict[str, Any]:
    state_cfg = cfg.state_source_settings(code)
    rows = state_cfg.get("sources") or {}
    enabled_count = 1  # Core OSM is locked on.
    available_count = 1
    groups = {"Core"}
    for spec in all_available_specs_for_state(STATES[code]):
        available_count += 1
        row = rows.get(spec.source_id) or {}
        if row.get("enabled"):
            enabled_count += 1
            groups.add(spec_group(spec))
    ordered = [g for g in ("Core", "Federal", "State Sources") if g in groups]
    return {"preset": state_cfg.get("preset", "standard"), "enabled_count": enabled_count,
            "available_count": available_count, "groups": ordered, "label": " + ".join(ordered)}


def job_for_region(cfg: ManagerConfig, state_code: str) -> dict[str, Any] | None:
    region_id = state_code.lower()
    for job_dir in cfg.processing.glob("*"):
        job = json_load(job_dir / "job.json", {})
        if str(job.get("region_id", "")).lower() == region_id:
            return {"kind": "processing", "job": job}
    pbf = cfg.incoming / f"{region_id}.osm.pbf"
    if pbf.is_file():
        return {"kind": "queued", "job": json_load(Path(str(pbf) + ".json"), {})}
    return None


def ready_descriptor(cfg: ManagerConfig, state_code: str) -> dict[str, Any] | None:
    region_id = state_code.lower()
    best: dict[str, Any] | None = None
    for path in cfg.ready.glob("*.zip.json"):
        d = json_load(path, {})
        rid = str(d.get("region_id", "")).lower()
        code = str(d.get("state_code", "")).upper()
        if rid == region_id or code == state_code:
            if best is None or str(d.get("created_utc", "")) > str(best.get("created_utc", "")):
                best = d
    return best


def source_cache_paths(cfg: ManagerConfig, code: str) -> dict[str, Path]:
    root = cfg.cache_root / code.lower()
    return {
        "root": root,
        "base": root / "base.osm.pbf",
        "base_meta": root / "base.osm.pbf.json",
        "boundary": root / "state.poly",
        "supplemental": root / "supplemental",
        "enriched": root / "enriched.osm.pbf",
        "manifest": root / "source-manifest.json",
        "enrich_work": root / "enrich-work",
    }


def enqueue_for_processor(cfg: ManagerConfig, code: str, source: Path, manifest: dict[str, Any]) -> None:
    state = STATES[code]
    cfg.incoming.mkdir(parents=True, exist_ok=True)
    final = cfg.incoming / f"{code.lower()}.osm.pbf"
    if final.exists() or job_for_region(cfg, code):
        raise RuntimeError(f"{state.name} already has a queued/processing build")
    part = final.with_name(final.name + ".part")
    part.unlink(missing_ok=True)
    shutil.copy2(source, part)
    meta = {
        "name": state.name,
        "region_id": code.lower(),
        "state_code": code,
        "source_url": manifest.get("base", {}).get("url", ""),
        "source_updated_utc": manifest.get("checked_utc", utcnow()),
        "expected_sha256": sha256_file(part),
        "bounds": manifest.get("bounds"),
        "source_composition": manifest.get("source_composition", []),
        "source_selection": state_source_selection_summary(cfg, code),
        "source_revisions": manifest.get("remote_revision", {}),
        "source_fingerprint": manifest.get("source_fingerprint", ""),
        "build_fingerprint": manifest.get("build_fingerprint", ""),
        "manager_version": VERSION,
        "routing_pipeline_revision": ROUTING_PIPELINE_REVISION,
    }
    atomic_json(Path(str(final) + ".json"), meta)
    os.replace(part, final)


def fetch_and_prepare(cfg: ManagerConfig, code: str, source_settings: dict[str, Any],
                      remote_revision: dict[str, Any], force_base: bool,
                      build_fingerprint: str = "", update_reason: str = "") -> dict[str, Any]:
    job_control.checkpoint(cfg.path,"navigation",code)
    state = STATES[code]
    p = source_cache_paths(cfg, code)
    p["root"].mkdir(parents=True, exist_ok=True)
    existing_base = json_load(p["base_meta"], {})
    core_urls = effective_geofabrik_urls(code, source_settings)
    remote_md5 = str((remote_revision.get("osm_geofabrik") or {}).get("md5") or "")
    local_md5 = str(existing_base.get("md5") or "")
    manual_base = str(existing_base.get("source_id") or "") == "manual_osm_pbf"
    need_base = (not manual_base) and (force_base or not p["base"].is_file() or (remote_md5 and remote_md5 != local_md5))
    if need_base:
        update_runtime(cfg, code, "downloading_osm", stage="downloading_osm", detail="Downloading OpenStreetMap / Geofabrik base")
        log_line(cfg, f"{code}: downloading OpenStreetMap / Geofabrik base")
        def base_progress(info: dict[str, Any]) -> None:
            downloaded = int(info.get("downloaded_bytes") or 0)
            total = int(info.get("total_bytes") or 0)
            speed = int(info.get("bytes_per_second") or 0)
            pct = round(downloaded * 100.0 / total, 1) if total > 0 else None
            update_runtime(cfg, code, "downloading_osm", stage="downloading_osm",
                           detail=f"Downloading OpenStreetMap / Geofabrik base{f' · {pct:.1f}%' if pct is not None else ''}",
                           progress={"downloaded_bytes": downloaded, "total_bytes": total, "bytes_per_second": speed, "percent": pct})
        base_meta = fetch_geofabrik_state(state, p["base"], p["base_meta"], p["boundary"], progress=base_progress, urls=core_urls)
    else:
        base_meta = existing_base
        base_label = "manual OpenStreetMap PBF" if manual_base else f"cached Geofabrik base ({local_md5[:10] or 'hash cached'})"
        log_line(cfg, f"{code}: reusing {base_label}")
        # R4 cached only the rectangular bounds. R6 always acquires/persists the
        # actual Geofabrik .poly so agency features can be clipped to the state.
        update_runtime(cfg, code, "checking_boundary", stage="checking_boundary", detail="Validating exact state boundary")
        boundary_meta = fetch_geofabrik_boundary(state, p["boundary"], force=False, urls=core_urls)
        base_meta = dict(base_meta)
        base_meta.update(boundary_meta)
        atomic_json(p["base_meta"], base_meta)

    bounds = base_meta.get("bounds")
    if not isinstance(bounds, list) or len(bounds) != 4:
        raise RuntimeError(f"{code}: base source does not have valid bounds")
    bbox = tuple(float(x) for x in bounds)

    job_control.checkpoint(cfg.path,"navigation",code)
    update_runtime(cfg, code, "downloading_sources", stage="downloading_sources", detail="Refreshing enabled supplemental sources")
    log_line(cfg, f"{code}: refreshing enabled supplemental sources")
    settings = cfg.settings()
    source_progress = {"completed": 0, "total": 0}
    source_progress_lock = threading.Lock()
    def supplemental_progress(info: dict[str, Any]) -> None:
        # Source callbacks run on ThreadPoolExecutor workers. Serialize both the
        # in-memory counter and its state.json publication so an older callback
        # cannot overwrite a newer completed count.
        with source_progress_lock:
            source_progress["total"] = int(info.get("total_sources") or source_progress["total"] or 0)
            if info.get("event") == "source_finished":
                source_progress["completed"] += 1
            update_runtime(cfg, code, "downloading_sources", stage="downloading_sources",
                           detail=f"Refreshing enabled supplemental sources · {source_progress['completed']}/{source_progress['total'] or '?'}",
                           progress={"sources_completed": source_progress["completed"], "sources_total": source_progress["total"],
                                     "current_source": info.get("name") or "", "endpoint": info.get("url") or ""})
    descriptors = fetch_supplemental_sources(
        state, p["boundary"], p["supplemental"], source_settings,
        max_workers=int(settings.get("source_download_concurrency", 3)),
        per_host_limit=int(settings.get("source_per_host_concurrency", 2)),
        progress=supplemental_progress,
    )
    job_control.checkpoint(cfg.path,"navigation",code)
    if p["enriched"].exists():
        p["enriched"].unlink()

    def enrich_stage(stage_name: str, detail: str) -> None:
        update_runtime(cfg, code, stage_name, stage=stage_name, detail=detail)

    enrich_result = apply_supplemental(
        p["base"], p["supplemental"], p["enriched"], p["enrich_work"],
        log=lambda m: log_line(cfg, f"{code}: {m}"),
        stage=enrich_stage,
    )
    job_control.checkpoint(cfg.path,"navigation",code)
    for d in descriptors:
        sid = str(d.get("source_id", ""))
        stats = (enrich_result.get("sources") or {}).get(sid)
        d["applied_to_graph"] = bool(stats and int(stats.get("added", 0)) > 0)
        if stats:
            d["merge_stats"] = stats
    base_source_id = str(base_meta.get("source_id") or ("manual_osm_pbf" if manual_base else "osm_geofabrik"))
    base_source_name = str(base_meta.get("source_name") or ("Manual OpenStreetMap PBF" if manual_base else "OpenStreetMap / Geofabrik"))
    composition = [{
        "source_id": base_source_id, "name": base_source_name, "role": "base_network",
        "status": "downloaded", "applied_to_graph": True,
        "revision": {
            "md5": base_meta.get("md5", ""),
            "sha256": base_meta.get("sha256", ""),
            "last_modified": base_meta.get("last_modified", ""),
            "boundary_sha256": base_meta.get("boundary_sha256", ""),
        },
    }]
    for d in descriptors:
        composition.append({k: d.get(k) for k in [
            "source_id", "name", "role", "status", "applied_to_graph", "error", "endpoint",
            "feature_count", "queried_feature_count", "outside_state_dropped",
        ] if d.get(k) not in (None, "")})
    manifest = {
        "schema": "takrig.nav.sources.v1",
        "state_code": code,
        "state_name": state.name,
        "checked_utc": utcnow(),
        "bounds": list(bbox),
        "boundary_file": p["boundary"].name,
        "boundary_sha256": base_meta.get("boundary_sha256", ""),
        "base": base_meta,
        "source_composition": composition,
        "remote_revision": remote_revision,
        "source_fingerprint": current_source_fingerprint(source_settings, code),
        "build_fingerprint": build_fingerprint,
        "manager_version": VERSION,
        "routing_pipeline_revision": ROUTING_PIPELINE_REVISION,
        "update_reason": update_reason,
        "enrichment": enrich_result,
    }
    atomic_json(p["manifest"], manifest)
    return manifest

def reconcile_state(cfg: ManagerConfig, code: str, force_refresh: bool = False,
                    force_rebuild: bool = False, manual_override: bool = False) -> dict[str, Any]:
    """Reconcile one desired state without ever taking its last-known-good package offline.

    Metadata checks are lightweight and can run at any time. Automatic large work is
    storage-gated and starts at the configured daily maintenance trigger. Explicit
    Start/Update/Retry/Rebuild actions bypass only the maintenance timing gate.
    """
    job_control.checkpoint(cfg.path, "navigation", code)
    settings = cfg.settings()
    source_settings = cfg.state_source_settings(code)
    p = source_cache_paths(cfg, code)
    prior = json_load(p["manifest"], {})
    ready = ready_descriptor(cfg, code)
    active_job = job_for_region(cfg, code)
    if active_job:
        return {"state_code": code, "action": "already_queued", "status": active_job["kind"]}

    source_fp = current_source_fingerprint(source_settings, code)
    source_config_changed = str(prior.get("source_fingerprint", "")) != source_fp
    missing = not ready or not p["base"].is_file() or not p["enriched"].is_file()
    due = days_old(str(prior.get("checked_utc", ""))) >= float(
        settings.get("source_update_interval_days", cfg.data.get("source_update_interval_days", 30))
    )
    check_remote = missing or force_refresh or force_rebuild or source_config_changed or due
    if not check_remote:
        if ready:
            update_runtime(cfg, code, "ready", stage="ready", detail="Verified package is current")
        return {"state_code": code, "action": "none", "status": "current"}

    update_runtime(cfg, code, "checking_sources", stage="checking_sources", detail="Checking upstream source revisions")
    log_line(cfg, f"{code}: checking upstream source revisions")
    remote_raw = remote_revision_for_state(code, source_settings)
    previous_remote = prior.get("remote_revision") or {}
    manual_base = str((prior.get("base") or {}).get("source_id") or "") == "manual_osm_pbf"
    if not prior and p["base_meta"].is_file():
        manual_base = str(json_load(p["base_meta"], {}).get("source_id") or "") == "manual_osm_pbf"
    remote = merge_remote_revisions(previous_remote, remote_raw, include_osm=not manual_base)
    previous_snapshot = successful_revision_snapshot(previous_remote, include_osm=not manual_base)
    current_snapshot = successful_revision_snapshot(remote, include_osm=not manual_base)
    remote_changed = stable_hash(current_snapshot) != stable_hash(previous_snapshot)
    build_fp = effective_build_fingerprint(source_fp, remote, include_osm=not manual_base)

    # R5/R6 deterministic failure gate: source checks are allowed, but an identical
    # failed build is not automatically rerun. Explicit Retry/Rebuild bypasses it.
    failure = latest_failure_for_state(cfg, code)
    same_failed_inputs = bool(failure and failure.get("build_fingerprint") and failure.get("build_fingerprint") == build_fp)
    if same_failed_inputs and not force_rebuild:
        update_runtime(
            cfg, code, "failed", stage=str(failure.get("stage") or "failed"),
            detail=str(failure.get("error") or "Previous build failed"), failure=failure,
            build_fingerprint=build_fp, last_source_probe_utc=utcnow(),
        )
        return {
            "state_code": code, "action": "blocked_failed", "status": "failed", "failure": failure,
            "message": "Previous build failed with the same effective inputs; waiting for Retry or changed inputs",
        }

    # Endpoint errors never invalidate the last known good package or fabricate an update.
    any_revision_ok = (not manual_base and bool((remote_raw.get("osm_geofabrik") or {}).get("ok"))) or any(
        bool(v.get("ok")) for v in (remote_raw.get("agency") or {}).values() if isinstance(v, dict)
    )
    if manual_base:
        any_revision_ok = any_revision_ok or bool((previous_remote.get("manual_osm_pbf") or {}).get("ok"))
    if not any_revision_ok and not missing and not source_config_changed and not force_rebuild:
        update_runtime(cfg, code, "ready" if ready else "pending", stage="source_check_deferred",
                       detail="Upstream revision check failed; keeping last known good package")
        return {"state_code": code, "action": "deferred", "status": "source_check_failed"}

    agency_raw = remote_raw.get("agency") or {}
    unknown_revision_due = due and any(
        isinstance(value, dict) and value.get("ok") and not value.get("last_edit_date")
        for value in agency_raw.values()
    )
    should_build = missing or force_rebuild or source_config_changed or remote_changed or unknown_revision_due
    if not should_build:
        prior["remote_revision"] = remote
        if remote.get("check_errors"):
            prior["last_revision_errors"] = remote.get("check_errors")
            atomic_json(p["manifest"], prior)
            update_runtime(cfg, code, "ready" if ready else "pending", stage="source_check_partial",
                           detail="Some source revision checks failed; no rebuild started")
            return {"state_code": code, "action": "deferred", "status": "partial_source_check_failed"}
        prior["checked_utc"] = utcnow()
        prior.pop("last_revision_errors", None)
        atomic_json(p["manifest"], prior)
        update_runtime(cfg, code, "ready" if ready else "pending", stage="current", detail="Sources are current")
        return {"state_code": code, "action": "checked", "status": "current"}

    reason = determine_update_reason(prior, remote, previous_remote, source_config_changed, missing, force_rebuild)

    # Detection is independent from automatic rebuilding. Initial desired-state builds
    # still proceed; this switch only suppresses replacement of an existing ready package.
    if ready and not manual_override and not force_rebuild and not bool(settings.get("automatic_rebuild_enabled", True)):
        update_runtime(cfg, code, "update_available", stage="update_available",
                       detail=f"Update available · {reason}", build_fingerprint=build_fp,
                       update_reason=reason, last_source_probe_utc=utcnow())
        return {"state_code": code, "action": "update_available", "status": "update_available", "update_reason": reason}

    # Storage reserve is a hard safety boundary for both automatic and manual starts.
    space_ok, disk_estimate = storage_gate(cfg, code, remote)
    if not space_ok:
        update_runtime(cfg, code, "waiting_space", stage="waiting_space",
                       detail="Waiting for disk space policy", build_fingerprint=build_fp,
                       update_reason=reason, disk_estimate=disk_estimate, last_source_probe_utc=utcnow())
        return {"state_code": code, "action": "waiting_space", "status": "waiting_space",
                "update_reason": reason, "disk_estimate": disk_estimate}

    # Automatic large downloads/builds begin at the next daily maintenance trigger.
    # Preserve a previously assigned trigger so a post-midnight reconcile actually starts it.
    if not manual_override:
        runtime = _runtime_entry(cfg, code)
        eligible = ""
        if str(runtime.get("build_fingerprint") or "") == build_fp:
            eligible = str(runtime.get("maintenance_eligible_utc") or "")
        if not eligible:
            eligible = maintenance_eligible_utc(str(settings.get("maintenance_window_start_local") or "00:00"))
        if not maintenance_due(eligible):
            update_runtime(cfg, code, "waiting_maintenance", stage="waiting_maintenance",
                           detail=f"Queued for maintenance window · {reason}", build_fingerprint=build_fp,
                           update_reason=reason, maintenance_eligible_utc=eligible,
                           disk_estimate=disk_estimate, last_source_probe_utc=utcnow())
            return {"state_code": code, "action": "waiting_maintenance", "status": "waiting_maintenance",
                    "update_reason": reason, "maintenance_eligible_utc": eligible, "disk_estimate": disk_estimate}

    # Explicit retry can reuse already-prepared input if it matches exactly.
    processor_failure = processor_failed_for_state(cfg, code)
    if (force_rebuild and processor_failure and processor_failure.get("build_fingerprint") == build_fp
            and str(prior.get("build_fingerprint") or "") == build_fp and p["enriched"].is_file()):
        update_runtime(cfg, code, "queued", stage="queued", detail="Reusing prepared input for explicit Valhalla retry",
                       new_attempt=True, clear_failure=True, build_fingerprint=build_fp,
                       update_reason=reason, disk_estimate=disk_estimate, maintenance_eligible_utc="")
        enqueue_for_processor(cfg, code, p["enriched"], prior)
        return {"state_code": code, "action": "queued_retry", "status": "queued", "update_reason": reason}

    base_changed = False if manual_base else str(((remote.get("osm_geofabrik") or {}).get("md5") or "")) != str(
        ((previous_remote.get("osm_geofabrik") or {}).get("md5") or "")
    )
    job_control.checkpoint(cfg.path, "navigation", code)
    update_runtime(cfg, code, "preparing", stage="preparing", detail="Preparing state graph input",
                   new_attempt=True, clear_failure=True, build_fingerprint=build_fp,
                   update_reason=reason, disk_estimate=disk_estimate, maintenance_eligible_utc="")
    try:
        manifest = fetch_and_prepare(
            cfg, code, source_settings, remote,
            force_base=(not p["base"].is_file() or base_changed),
            build_fingerprint=build_fp, update_reason=reason,
        )
        enqueue_for_processor(cfg, code, p["enriched"], manifest)
        job_control.checkpoint(cfg.path, "navigation", code)
        update_runtime(cfg, code, "queued", stage="queued", detail="Prepared input queued for Valhalla",
                       clear_failure=True, build_fingerprint=build_fp, update_reason=reason, disk_estimate=disk_estimate)
        return {"state_code": code, "action": "queued_build", "status": "queued", "update_reason": reason}
    except Exception as exc:
        record_manager_failure(cfg, code, exc, build_fp)
        raise


def reconcile(cfg: ManagerConfig, only: list[str] | None = None, force_refresh: bool = False,
              force_rebuild: bool = False, manual_override: bool = False) -> dict[str, Any]:
    cfg.ensure()
    settings = cfg.settings()
    selected = settings["selected_states"]
    if only:
        requested = validate_states(only)
        selected = [c for c in requested if c in settings["selected_states"]]
    results = []
    errors = []
    for code in selected:
        try:
            results.append(reconcile_state(cfg, code, force_refresh=force_refresh,
                                           force_rebuild=force_rebuild, manual_override=manual_override))
        except job_control.JobPaused:
            update_runtime(cfg, code, "paused", stage="paused", detail="Navigation paused; cached sources retained")
            results.append({"state_code":code,"action":"paused","status":"paused"})
        except Exception as exc:
            log_line(cfg, f"{code}: ERROR {exc}")
            errors.append({"state_code": code, "error": str(exc)})
    reconciled_utc = utcnow()
    def save_reconcile_summary(state: dict[str, Any]) -> None:
        state["last_reconcile_utc"] = reconciled_utc
        state["last_results"] = results
        state["last_errors"] = errors
    cfg.update_state(save_reconcile_summary)
    return {"ok": not errors, "results": results, "errors": errors, "reconciled_utc": reconciled_utc}


def processor_failed_for_state(cfg: ManagerConfig, code: str) -> dict[str, Any] | None:
    best: dict[str, Any] | None = None
    for job_dir in cfg.failed.glob("*"):
        job = json_load(job_dir / "job.json", {})
        if str(job.get("state_code", "")).upper() != code and str(job.get("region_id", "")).lower() != code.lower():
            continue
        log_path = job_dir / "build.log"
        log_tail = ""
        if log_path.is_file():
            with contextlib.suppress(Exception):
                lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
                log_tail = "\n".join(lines[-30:])
        row = {
            "kind": "processor", "job_id": job.get("job_id") or job_dir.name,
            "stage": job.get("state") or "valhalla_build",
            "error": job.get("error") or job.get("failure") or "Build failed",
            "failed_utc": job.get("failed_utc") or job.get("updated_utc") or "",
            "build_fingerprint": job.get("build_fingerprint") or "",
            "manager_version": job.get("manager_version") or "", "log_tail": log_tail,
            "retry_eligible": True,
        }
        if best is None or str(row.get("failed_utc", "")) > str(best.get("failed_utc", "")):
            best = row
    return best


def latest_failure_for_state(cfg: ManagerConfig, code: str) -> dict[str, Any] | None:
    candidates = [x for x in (manager_failure_for_state(cfg, code), processor_failed_for_state(cfg, code)) if x]
    if not candidates:
        return None
    result = max(candidates, key=lambda x: str(x.get("failed_utc") or ""))
    result.setdefault("retry_eligible", True)
    return result


def state_status(cfg: ManagerConfig, code: str) -> dict[str, Any]:
    settings = cfg.settings()
    selected = code in settings["selected_states"]
    job = job_for_region(cfg, code)
    ready = ready_descriptor(cfg, code)
    failure = latest_failure_for_state(cfg, code)
    runtime = _runtime_entry(cfg, code)
    p = source_cache_paths(cfg, code)
    manifest = json_load(p["manifest"], {})

    status = "not_selected"; stage = "not_selected"; detail = ""
    activity_utc = str(runtime.get("updated_utc") or "")
    stage_started_utc = str(runtime.get("stage_started_utc") or "")
    attempt_started_utc = str(runtime.get("attempt_started_utc") or "")

    if job:
        job_data = job.get("job") or {}
        activity_utc = str(job_data.get("updated_utc") or activity_utc)
        stage_started_utc = str(job_data.get("stage_started_utc") or stage_started_utc)
        attempt_started_utc = str(job_data.get("started_utc") or job_data.get("created_utc") or attempt_started_utc)
        if job["kind"] == "queued":
            status = stage = "queued"; detail = "Prepared input is waiting for the Valhalla processor"
        else:
            job_state = str(job_data.get("state") or "processing")
            mapping = {
                "claimed": ("preparing_build", "Valhalla processor claimed the state input"),
                "hashing": ("preparing_build", "Verifying prepared OSM input"),
                "configuring": ("preparing_build", "Generating Valhalla build configuration"),
                "building_tiles": ("building", "Building Valhalla graph tiles"),
                "building_extract": ("building_extract", "Building indexed mobile tile archive"),
                "packaging": ("packaging", "Packaging and verifying TAK Rig routing ZIP"),
            }
            status, detail = mapping.get(job_state, ("building", f"Valhalla processor: {job_state.replace('_', ' ')}"))
            stage = job_state
            if job_data.get("detail"):
                detail = str(job_data.get("detail"))
    else:
        ready_time = str((ready or {}).get("created_utc") or "")
        failure_time = str((failure or {}).get("failed_utc") or "")
        runtime_status = str(runtime.get("status") or "")
        active_runtime = runtime_status not in {"", "ready", "failed", "not_selected"}
        # R7 precedence fix: any newer active attempt wins over stale historical failure.
        runtime_activity = str(runtime.get("updated_utc") or "")
        newer_attempt = bool(active_runtime and (attempt_started_utc or runtime_activity) and
                             (not failure_time or max(attempt_started_utc, runtime_activity) > failure_time))
        failure_is_newer = bool(failure and not newer_attempt and (not ready or failure_time >= ready_time))
        if not selected and not ready:
            status = stage = "not_selected"
        elif newer_attempt:
            status = runtime_status
            stage = str(runtime.get("stage") or runtime_status)
            detail = str(runtime.get("detail") or "")
        elif failure_is_newer:
            status = "failed"; stage = str(failure.get("stage") or "failed")
            detail = str(failure.get("error") or "Build failed"); activity_utc = failure_time or activity_utc
        elif runtime_status in {"waiting_space", "waiting_maintenance", "update_available"}:
            status = runtime_status; stage = str(runtime.get("stage") or runtime_status); detail = str(runtime.get("detail") or "")
        elif ready:
            status = stage = "ready"; detail = "Verified package is available to TAK Rig"; activity_utc = ready_time or activity_utc
        elif selected:
            if active_runtime:
                status = runtime_status; stage = str(runtime.get("stage") or runtime_status); detail = str(runtime.get("detail") or "")
            else:
                status = stage = "pending"; detail = "Waiting for reconciliation"

    history = list(runtime.get("failure_history") or [])
    if failure and status != "failed":
        if not history or stable_hash(history[-1]) != stable_hash(failure):
            history = (history + [failure])[-10:]
    progress = runtime.get("progress") if isinstance(runtime.get("progress"), dict) else {}
    if job and isinstance((job.get("job") or {}).get("progress"), dict):
        progress = (job.get("job") or {}).get("progress") or progress

    pause_state = job_control.display(cfg.path, "navigation", code)
    if pause_state:
        status = stage = pause_state
        detail = "Finishing current NAV step before pause" if pause_state == "pausing" else "Navigation paused; source and build checkpoints retained"
    return {
        "state_code": code, "state_name": STATES[code].name, "selected": selected,
        "status": status, "stage": stage, "detail": detail, "activity_utc": activity_utc,
        "stage_started_utc": stage_started_utc, "attempt_started_utc": attempt_started_utc,
        "package": ready, "failure": failure if status == "failed" else None,
        "failure_history": history, "retained_ready_package": bool(ready and status == "failed"),
        "last_source_check_utc": manifest.get("checked_utc", ""),
        "source_composition": manifest.get("source_composition", []),
        "source_selection": state_source_selection_summary(cfg, code),
        "build_fingerprint": manifest.get("build_fingerprint") or runtime.get("build_fingerprint") or "",
        "update_reason": runtime.get("update_reason") or manifest.get("update_reason") or "",
        "progress": progress, "disk_estimate": runtime.get("disk_estimate") or {},
        "maintenance_eligible_utc": runtime.get("maintenance_eligible_utc") or "",
        "storage": state_storage_summary(cfg, code),
        "terrain": terrain_status_summary(cfg.path, code),
        "environment": environment.status_summary(cfg.path, code),
        "cellular": cellular.status_summary(cfg.path, code),
    }


def public_catalog(cfg: ManagerConfig) -> dict[str, Any]:
    packages = []
    for code in STATES:
        desc = ready_descriptor(cfg, code)
        if not desc: continue
        source_comp = desc.get("source_composition") or []
        package_name = str(desc.get("package") or "")
        if not package_name or not (cfg.ready / package_name).is_file(): continue
        row = {
            "state_code": code, "state_name": STATES[code].name, "status": "ready",
            "package_version": desc.get("revision") or desc.get("created_utc") or "",
            "revision": desc.get("revision") or desc.get("created_utc") or "",
            "built_utc": desc.get("created_utc") or "", "size_bytes": int(desc.get("size_bytes") or 0),
            "format": desc.get("format") or "takrig.valhalla.region.v1",
            "valhalla_version": desc.get("valhalla_version") or "3.6.3",
            "source_composition": source_comp, "source_revisions": desc.get("source_revisions") or {},
            "routing_coverage": desc.get("routing_coverage") or {},
            "download_url": f"/api/v1/packages/{code}/download",
        }
        terrain = terrain_public_descriptor(cfg, code)
        if terrain:
            row["terrain"] = terrain
        packages.append(row)
    packages.sort(key=lambda x: x["state_name"])
    terrain_packages = [t for code in STATES if (t := terrain_public_descriptor(cfg, code))]
    terrain_packages.sort(key=lambda x: x["state_name"])
    cellular_packages = [c for code in STATES if (c := cellular.public_descriptor(cfg.path, code))]
    cellular_packages.sort(key=lambda x: x["state_name"])
    environment_packages = [e for code in STATES if (e := environment_public_descriptor(cfg, code))]
    environment_packages.sort(key=lambda x: x["state_name"])
    return {"schema": CATALOG_SCHEMA, "manager_version": VERSION, "generated_utc": utcnow(),
            "packages": packages, "terrain_packages": terrain_packages, "environment_packages": environment_packages,
            "cellular_packages": cellular_packages}


def manager_status(cfg: ManagerConfig) -> dict[str, Any]:
    storage = storage_summary(cfg)
    storage.update(disk_policy_summary(cfg))
    return {
        "version": VERSION, "settings": cfg.settings(), "states": [state_status(cfg, code) for code in STATES],
        "sources": source_health_summary(cfg), "storage": storage,
        "cellular": {"source_access": cellular.source_status(cfg.path), "packages": [c for code in STATES if (c := cellular.public_descriptor(cfg.path, code))]},
        "environment": {"packages": [e for code in STATES if (e := environment_public_descriptor(cfg, code))]},
        "last_reconcile": cfg.state().get("last_reconcile_utc", ""),
    }


def spawn_reconcile(cfg: ManagerConfig, states: list[str] | None = None,
                    force_refresh: bool = False, force_rebuild: bool = False,
                    manual_override: bool = False) -> None:
    cmd = [sys.executable, str(Path(__file__).resolve()), "--config", str(cfg.path), "reconcile"]
    if states:
        for code in states: cmd += ["--state", code]
    if force_refresh: cmd.append("--force-refresh")
    if force_rebuild: cmd.append("--force-rebuild")
    if manual_override: cmd.append("--manual")
    log_file = (cfg.log_root / "manager-background.log").open("a", encoding="utf-8")
    subprocess.Popen(cmd, stdout=log_file, stderr=subprocess.STDOUT, start_new_session=True, close_fds=True)


def spawn_terrain_build(cfg: ManagerConfig, code: str, *, force: bool = False) -> bool:
    """Claim and start one per-state 3D terrain build; repeated clicks are deduplicated."""
    code = code.upper()
    with _TERRAIN_SPAWN_LOCK:
        current = terrain_status_summary(cfg.path, code)
        if job_control.requested(cfg.path, "terrain", code):
            return False
        if str(current.get("status") or "") in {"queued", "preparing", "building", "packaging"}:
            return False
        # Claim synchronously before Popen so concurrent Web requests cannot queue duplicate builds.
        from terrain import _update_status as terrain_update_status
        terrain_update_status(cfg.path, code, "queued", "queued", "3D terrain build queued")
        cmd = [sys.executable, str(HERE / "terrain.py"), "--config", str(cfg.path), "build", code]
        if force:
            cmd.append("--force")
        log = cfg.log_root / f"terrain-{code.lower()}.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        fh = log.open("ab")
        try:
            proc = subprocess.Popen(cmd, stdout=fh, stderr=subprocess.STDOUT, start_new_session=True, close_fds=True)
            # Child will publish its own PID when it advances to PREPARING.
            if str(terrain_status_summary(cfg.path, code).get("status")) == "queued" and isinstance(proc.pid, int) and proc.pid > 0:
                terrain_update_status(cfg.path, code, "queued", "queued", "3D terrain build queued", pid=proc.pid)
        except Exception as exc:
            terrain_update_status(cfg.path, code, "failed", "failed", f"Unable to start 3D terrain builder: {exc}", error=str(exc))
            raise
        finally:
            fh.close()
        return True


def spawn_environment_build(cfg: ManagerConfig, code: str, *, force: bool = False) -> bool:
    code=code.upper()
    with _ENVIRONMENT_SPAWN_LOCK:
        current=environment.status_summary(cfg.path, code)
        if str(current.get("status") or "") in environment.ACTIVE_STATES: return False
        environment._update_status(cfg.path, code, "queued", "queued", "3D environment build queued")
        cmd=[sys.executable, str(HERE/"environment.py"), "--config", str(cfg.path), "build", code]
        if force: cmd.append("--force")
        log=cfg.log_root/f"environment-{code.lower()}.log"; log.parent.mkdir(parents=True,exist_ok=True); fh=log.open("ab")
        try: subprocess.Popen(cmd,stdout=fh,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
        except Exception as exc:
            environment._update_status(cfg.path,code,"failed","failed",f"Unable to start 3D environment builder: {exc}",error=str(exc)); raise
        finally: fh.close()
        return True


def spawn_cellular_action(cfg: ManagerConfig, code: str, action: str, *, as_of: str = "") -> bool:
    """Start one independent FCC Cellular action per state; repeated clicks are deduplicated."""
    code = code.upper(); action = action.lower()
    if action not in {"check", "build", "update", "rebuild", "acquire"}:
        raise ValueError("Unsupported Cellular action")
    with _CELLULAR_SPAWN_LOCK:
        current = cellular.status_summary(cfg.path, code)
        if job_control.requested(cfg.path, "cellular", code):
            return False
        if str(current.get("status") or "") in cellular.ACTIVE_STATUSES:
            return False
        if action == "check":
            status, stage, detail, command = "checking", "checking", "Cellular coverage source check queued", "check"
        elif action == "acquire":
            status, stage, detail, command = "acquiring", "acquiring", "FCC H3 acquisition queued", "acquire-api"
        else:
            status, stage, detail = "queued", "queued", "Cellular H3 package build queued"
            command = "rebuild" if action == "rebuild" else "build"
        cellular.update_status(
            cfg.path, code, status, stage, detail,
            acquisition_error="" if action in {"check", "acquire"} else str(current.get("acquisition_error") or ""),
            error="" if action in {"check", "acquire"} else str(current.get("error") or ""),
            progress={"percent": 0, "phase": "queued"} if action in {"check", "acquire"} else current.get("progress", {}),
            resume_action=action, resume_as_of=as_of,
        )
        cmd = [sys.executable, str(HERE / "cellular.py"), "--config", str(cfg.path), command, code]
        if action == "acquire" and as_of:
            cmd += ["--as-of", as_of]
        log = cfg.log_root / f"cellular-{code.lower()}.log"; log.parent.mkdir(parents=True, exist_ok=True)
        fh = log.open("ab")
        try:
            proc=subprocess.Popen(cmd, stdout=fh, stderr=subprocess.STDOUT, start_new_session=True, close_fds=True)
            if getattr(proc,"pid",None):
                cur=cellular.read_json(cellular.status_path(cfg.path,code),{}) or {}
                if cur.get("status")==status:
                    cur["pid"]=proc.pid
                    cellular.atomic_json(cellular.status_path(cfg.path,code),cur)
        except Exception as exc:
            fail_status = "no_sources" if action in {"check", "acquire"} else "failed"
            cellular.update_status(cfg.path, code, fail_status, "spawn_failed", f"Unable to start Cellular action: {exc}", acquisition_error=str(exc) if action in {"check", "acquire"} else "", error=str(exc) if action not in {"check", "acquire"} else "")
            raise
        finally:
            fh.close()
        return True


def terrain_public_descriptor(cfg: ManagerConfig, code: str) -> dict[str, Any] | None:
    desc = terrain_ready_descriptor(cfg.path, code)
    if not desc:
        return None
    return {
        "state_code": code,
        "state_name": STATES[code].name,
        "status": "ready",
        "revision": desc.get("revision") or desc.get("created_utc") or "",
        "built_utc": desc.get("built_utc") or desc.get("created_utc") or "",
        "size_bytes": int(desc.get("size_bytes") or 0),
        "format": desc.get("format") or "takrig.terrain.region.v1",
        "nominal_resolution_m": int(desc.get("nominal_resolution_m") or 90),
        "sample_spacing_arcseconds": float(desc.get("sample_spacing_arcseconds") or 3.0),
        "tile_span_degrees": float(desc.get("tile_span_degrees") or 0.5),
        "tile_count": int(desc.get("tile_count") or 0),
        "overview_resolutions_m": desc.get("overview_resolutions_m") or [],
        "source": desc.get("source") or {},
        "download_url": f"/api/v1/terrain/{code}/download",
    }


def environment_public_descriptor(cfg: ManagerConfig, code: str) -> dict[str, Any] | None:
    desc = environment.ready_descriptor(cfg.path, code)
    if not desc: return None
    return {
        "state_code": code, "state_name": STATES[code].name, "status": "ready",
        "revision": desc.get("revision") or desc.get("created_utc") or "",
        "built_utc": desc.get("built_utc") or desc.get("created_utc") or "",
        "size_bytes": int(desc.get("size_bytes") or 0), "format": desc.get("format") or environment.PACKAGE_FORMAT,
        "runtime_resolution_m": int(desc.get("runtime_resolution_m") or 30),
        "cell_span_degrees": float(desc.get("cell_span_degrees") or 0.1), "cell_count": int(desc.get("cell_count") or 0),
        "source": desc.get("source") or {}, "download_url": f"/api/v1/environment/{code}/download",
    }


def remove_package(cfg: ManagerConfig, code: str) -> bool:
    desc = ready_descriptor(cfg, code)
    if not desc:
        return False
    name = str(desc.get("package") or "")
    if name:
        (cfg.ready / name).unlink(missing_ok=True)
        (cfg.ready / (name + ".sha256")).unlink(missing_ok=True)  # clean pre-R8 sidecar if present
    pkg = str(desc.get("package") or "")
    if pkg: (cfg.ready / (pkg + ".json")).unlink(missing_ok=True)
    # Fallback descriptor naming already ends in .zip.json.
    for path in cfg.ready.glob("*.zip.json"):
        d = json_load(path, {})
        if str(d.get("state_code", "")).upper() == code or str(d.get("region_id", "")).lower() == code.lower():
            path.unlink(missing_ok=True)
    return True



def clean_state_temporary_work(cfg: ManagerConfig, code: str) -> dict[str, Any]:
    p = source_cache_paths(cfg, code)
    before = _directory_size(p["enrich_work"])
    if p["enrich_work"].exists(): shutil.rmtree(p["enrich_work"], ignore_errors=True)
    global _STORAGE_CACHE_AT
    _STORAGE_CACHE_AT = 0.0
    return {"state_code": code, "reclaimed_bytes": before, "kind": "temporary_work"}


def clear_state_source_cache(cfg: ManagerConfig, code: str) -> dict[str, Any]:
    p = source_cache_paths(cfg, code)
    before = _directory_size(p["root"])
    if p["root"].exists(): shutil.rmtree(p["root"], ignore_errors=True)
    global _STORAGE_CACHE_AT
    _STORAGE_CACHE_AT = 0.0
    update_runtime(cfg, code, "pending" if code in cfg.settings()["selected_states"] else "not_selected",
                   stage="source_cache_cleared", detail="Source cache cleared; ready package preserved")
    return {"state_code": code, "reclaimed_bytes": before, "kind": "source_cache", "ready_preserved": bool(ready_descriptor(cfg, code))}


def osm_pbf_bounds(path: Path) -> list[float]:
    """Read the data bounding box using osmium-tool without loading the PBF into memory."""
    proc = subprocess.run(
        ["osmium", "fileinfo", "-e", "-g", "data.bbox", str(path)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=120, check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError("Unable to inspect OSM PBF bounds with osmium-tool: " + (proc.stderr.strip() or "fileinfo failed"))
    nums = [float(x) for x in re.findall(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", proc.stdout)]
    if len(nums) < 4:
        raise RuntimeError("OSM PBF does not report a usable geographic bounding box")
    bounds = nums[-4:]
    min_lon, min_lat, max_lon, max_lat = bounds
    if not (-180 <= min_lon <= max_lon <= 180 and -90 <= min_lat <= max_lat <= 90):
        raise RuntimeError("OSM PBF reported invalid geographic bounds")
    return bounds


def validate_osm_pbf(path: Path, allow_plain_pbf: bool) -> None:
    if path.stat().st_size < 1024:
        raise ValueError("OSM PBF is unexpectedly small")
    lower = path.name.lower()
    if lower.endswith(".osm.pbf"):
        return
    if lower.endswith(".pbf") and allow_plain_pbf:
        head = path.read_bytes()[:65536]
        if b"OSMHeader" in head:
            return
    raise ValueError("Supported base road-network files are .osm.pbf (or validated OSM .pbf)")




WEB_VENDOR_ASSETS: dict[str, tuple[str, str]] = {}

def web_asset_for_path(path: str) -> tuple[Path, str] | None:
    # r20 removes the Outdoors/Leaflet Web runtime; no standalone vendor assets remain.
    return None


class WebHandler(BaseHTTPRequestHandler):
    server_version = "TakRigNavManager/0.2.0-r16-r29"
    protocol_version = "HTTP/1.1"

    @property
    def cfg(self) -> ManagerConfig:
        return self.server.cfg  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args: Any) -> None:
        log_line(self.cfg, "WEB " + (fmt % args))

    def send_json(self, data: Any, status: int = 200) -> None:
        raw = (json.dumps(data, indent=2) + "\n").encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers(); self.wfile.write(raw); self.wfile.flush()

    def read_json_body(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0 or length > 4 * 1024 * 1024:
            raise ValueError("JSON body is missing or too large")
        data = json.loads(self.rfile.read(length).decode("utf-8"))
        if not isinstance(data, dict): raise ValueError("JSON body must be an object")
        return data

    def send_zip_range(self, package: Path, desc: dict[str, Any]) -> None:
        size = package.stat().st_size
        start, end = 0, size - 1
        range_header = self.headers.get("Range", "").strip()
        revision = str(desc.get("revision") or desc.get("created_utc") or "").replace("\\", "").replace(chr(34), "")
        if_range = self.headers.get("If-Range", "").strip().strip('"')
        if range_header and if_range and revision and if_range != revision:
            range_header = ""
        if range_header:
            match = re.fullmatch(r"bytes=(\d+)-(\d*)", range_header)
            if not match:
                self.send_response(416); self.send_header("Content-Range", f"bytes */{size}"); self.send_header("Content-Length", "0"); self.end_headers(); return
            start = int(match.group(1)); requested_end = int(match.group(2)) if match.group(2) else end
            if start >= size or requested_end < start:
                self.send_response(416); self.send_header("Content-Range", f"bytes */{size}"); self.send_header("Content-Length", "0"); self.end_headers(); return
            end = min(requested_end, end)
        partial = bool(range_header); length = end - start + 1
        self.send_response(206 if partial else 200)
        self.send_header("Content-Type", "application/zip")
        self.send_header("Content-Disposition", f'attachment; filename="{package.name}"')
        self.send_header("Accept-Ranges", "bytes"); self.send_header("Content-Length", str(length))
        if revision: self.send_header("ETag", f'"{revision}"')
        if partial: self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        with package.open("rb") as fh:
            fh.seek(start); remaining = length
            while remaining > 0:
                block = fh.read(min(1024 * 1024, remaining))
                if not block:
                    raise IOError(f"package file ended {remaining} bytes before declared response length")
                self.wfile.write(block); remaining -= len(block)
        self.wfile.flush()

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path == "/" or path == "/index.html":
            page = Path("/usr/local/lib/takrig-routing/web/index.html")
            if not page.is_file(): page = HERE.parent / "web" / "index.html"
            if not page.is_file():
                self.send_error(404); return
            raw = page.read_bytes()
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw); self.wfile.flush(); return
        # r27 Executive Slate: immutable names, same-origin WebP state/decor assets.
        # Explicit allowlist avoids generic filesystem serving and path traversal.
        visual = re.fullmatch(r"/assets/(states|decor)/([A-Za-z0-9_-]+)\.webp", path)
        if visual:
            kind, name = visual.groups()
            allowed = name in STATES if kind == "states" else name in {"nav", "elevation"}
            if not allowed:
                self.send_error(404); return
            web_root = Path("/usr/local/lib/takrig-routing/web")
            if not (web_root / "assets").is_dir():
                web_root = HERE.parent / "web"
            image_path = web_root / "assets" / kind / f"{name}.webp"
            if not image_path.is_file():
                self.send_error(404); return
            raw = image_path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "image/webp")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-cache")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers(); self.wfile.write(raw); self.wfile.flush(); return
        asset = web_asset_for_path(path)
        if asset is not None:
            page, content_type = asset
            raw = page.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "public, max-age=31536000, immutable")
            self.end_headers(); self.wfile.write(raw); self.wfile.flush(); return
        if path == "/api/v1/catalog":
            self.send_json(public_catalog(self.cfg)); return
        if path == "/api/v1/status":
            self.send_json(manager_status(self.cfg)); return
        if path == "/api/v1/settings":
            self.send_json(self.cfg.settings()); return
        mcell_sources = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/cellular/sources", path)
        if mcell_sources:
            code = mcell_sources.group(1).upper()
            if code not in STATES: self.send_error(404); return
            self.send_json({"state_code": code, "inventory": cellular.source_inventory_summary(self.cfg.path, code),
                            "source_access": cellular.source_status(self.cfg.path),
                            "carrier_selection": cellular.carrier_selection(self.cfg.path, code)}); return
        if path == "/api/v1/cellular/api/status":
            self.send_json({"source_access": cellular.source_status(self.cfg.path)}); return
        if path == "/api/v1/cellular/api/releases":
            try:
                dates = cellular.api_releases(self.cfg.path)
                self.send_json({"ok": True, "as_of_dates": dates, "latest_as_of": dates[-1] if dates else ""}); return
            except Exception as exc:
                self.send_json({"ok": False, "error": str(exc)}, 400); return
        # Legacy state-scoped read endpoints remain as compatibility aliases.
        # FCC credentials/releases are gateway-wide and are not stored per-state.
        mcell_api_status = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/cellular/api/status", path)
        if mcell_api_status:
            code = mcell_api_status.group(1).upper()
            if code not in STATES: self.send_error(404); return
            self.send_json({"state_code": code, "source_access": cellular.source_status(self.cfg.path),
                            "carrier_selection": cellular.carrier_selection(self.cfg.path, code)}); return
        mcell_api_releases = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/cellular/api/releases", path)
        if mcell_api_releases:
            code = mcell_api_releases.group(1).upper()
            if code not in STATES: self.send_error(404); return
            try:
                dates = cellular.api_releases(self.cfg.path)
                self.send_json({"ok": True, "state_code": code, "as_of_dates": dates, "latest_as_of": dates[-1] if dates else ""}); return
            except Exception as exc:
                self.send_json({"ok": False, "error": str(exc)}, 400); return
        mstate_sources = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/sources", path)
        if mstate_sources:
            code = mstate_sources.group(1).upper()
            if code not in STATES: self.send_error(404); return
            self.send_json(state_source_panel(self.cfg, code)); return
        m = re.fullmatch(r"/api/v1/packages/([A-Za-z]{2})/download", path)
        if m:
            code = m.group(1).upper()
            if code not in STATES: self.send_error(404); return
            desc = ready_descriptor(self.cfg, code)
            if not desc: self.send_error(404, "Package not ready"); return
            package = self.cfg.ready / str(desc.get("package") or "")
            if not package.is_file(): self.send_error(404); return
            self.send_zip_range(package, desc); return
        mt = re.fullmatch(r"/api/v1/terrain/([A-Za-z]{2})/download", path)
        if mt:
            code = mt.group(1).upper()
            if code not in STATES: self.send_error(404); return
            desc = terrain_ready_descriptor(self.cfg.path, code)
            if not desc: self.send_error(404, "3D terrain package not ready"); return
            package = self.cfg.root / "terrain" / "ready" / str(desc.get("package") or "")
            if not package.is_file(): self.send_error(404); return
            self.send_zip_range(package, desc); return
        me = re.fullmatch(r"/api/v1/environment/([A-Za-z]{2})/download", path)
        if me:
            code=me.group(1).upper()
            if code not in STATES: self.send_error(404); return
            desc=environment.ready_descriptor(self.cfg.path,code)
            if not desc: self.send_error(404,"3D environment package not ready"); return
            package=self.cfg.root/"environment"/"ready"/str(desc.get("package") or "")
            if not package.is_file(): self.send_error(404); return
            self.send_zip_range(package,desc); return
        mc = re.fullmatch(r"/api/v1/cellular/([A-Za-z]{2})/download", path)
        if mc:
            code = mc.group(1).upper()
            if code not in STATES: self.send_error(404); return
            desc = cellular.ready_descriptor(self.cfg.path, code)
            if not desc: self.send_error(404, "Cellular coverage package not ready"); return
            package = self.cfg.root / "cellular" / "ready" / str(desc.get("package") or "")
            if not package.is_file(): self.send_error(404); return
            self.send_zip_range(package, desc); return
        self.send_error(404)

    def do_POST(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        try:
            if path == "/api/v1/settings":
                body = self.read_json_body()
                old = self.cfg.settings()
                settings = self.cfg.save_settings(
                    body.get("selected_states"), body.get("sources"), body.get("source_update_interval_days"),
                    body.get("source_download_concurrency"), body.get("source_per_host_concurrency"),
                    body.get("minimum_free_disk_gib"), body.get("source_cache_limit_gib"),
                    body.get("maintenance_window_start_local"), body.get("automatic_rebuild_enabled"),
                    body.get("terrain_resolution_m"),
                )
                new_states = sorted(set(settings["selected_states"]) - set(old["selected_states"]))
                removed_states = sorted(set(old["selected_states"]) - set(settings["selected_states"]))
                changed_sources = stable_hash(settings["sources"]) != stable_hash(old["sources"])
                changed_interval = settings.get("source_update_interval_days") != old.get("source_update_interval_days")
                reconcile_policy_keys = ("minimum_free_disk_gib", "source_cache_limit_gib",
                                         "maintenance_window_start_local", "automatic_rebuild_enabled")
                terrain_resolution_changed = settings.get("terrain_resolution_m") != old.get("terrain_resolution_m")
                changed_policy = any(settings.get(k) != old.get(k) for k in reconcile_policy_keys)
                for code in removed_states:
                    remove_package(self.cfg, code)
                if changed_sources and settings["selected_states"]:
                    spawn_reconcile(self.cfg, states=None, force_refresh=True)
                elif new_states:
                    # Discovery is immediate; large automatic work obeys maintenance/storage policy.
                    spawn_reconcile(self.cfg, states=new_states)
                elif changed_policy and settings["selected_states"]:
                    spawn_reconcile(self.cfg, states=None, force_refresh=False)
                self.send_json({"ok": True, "settings": settings, "new_states": new_states,
                                "removed_states": removed_states, "sources_changed": changed_sources,
                                "update_interval_changed": changed_interval, "policy_changed": changed_policy,
                                "terrain_resolution_changed": terrain_resolution_changed}, 202); return
            mstate_sources = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/sources", path)
            if mstate_sources:
                code = mstate_sources.group(1).upper()
                if code not in STATES: raise ValueError("Unknown state")
                body = self.read_json_body()
                result = self.cfg.save_state_sources(code, body)
                settings = self.cfg.settings()
                if result.get("changed") and code in settings.get("selected_states", []):
                    spawn_reconcile(self.cfg, states=[code], force_refresh=True)
                self.send_json({"ok": True, **result}, 202 if result.get("changed") else 200); return
            mstate_check = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/sources/([A-Za-z0-9_-]+)/check", path)
            if mstate_check:
                code = mstate_check.group(1).upper(); sid = mstate_check.group(2)
                if code not in STATES: raise ValueError("Unknown state")
                overrides = self.read_json_body() if int(self.headers.get("Content-Length") or 0) else {}
                self.send_json({"ok": True, "probe": state_source_probe(self.cfg, code, sid, overrides)}); return
            if path == "/api/v1/reconcile":
                body = self.read_json_body() if int(self.headers.get("Content-Length") or 0) else {}
                states = validate_states(list(body.get("states") or [])) if body.get("states") else None
                spawn_reconcile(self.cfg, states=states, force_refresh=bool(body.get("force_refresh")),
                                force_rebuild=bool(body.get("force_rebuild")), manual_override=False)
                self.send_json({"ok": True, "queued": True}, 202); return
            msrc = re.fullmatch(r"/api/v1/sources/([A-Za-z0-9_-]+)/check", path)
            if msrc:
                self.send_json({"ok": True, "probe": source_probe(self.cfg, msrc.group(1))}); return
            mcache = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/(clean-temp|clear-cache)", path)
            if mcache:
                code = mcache.group(1).upper(); action = mcache.group(2)
                if code not in STATES: raise ValueError("Unknown state")
                result = clean_state_temporary_work(self.cfg, code) if action == "clean-temp" else clear_state_source_cache(self.cfg, code)
                self.send_json({"ok": True, **result}); return
            mcell_carriers = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/cellular/carriers", path)
            if mcell_carriers:
                code = mcell_carriers.group(1).upper()
                if code not in STATES: raise ValueError("Unknown state")
                body = self.read_json_body(); selected = cellular.save_carrier_selection(self.cfg.path, code, list(body.get("carriers") or []))
                self.send_json({"ok": True, "carriers": selected, "cellular": cellular.status_summary(self.cfg.path, code)}); return
            mcell_api_global = re.fullmatch(r"/api/v1/cellular/api/(test|save|clear)", path)
            if mcell_api_global:
                action = mcell_api_global.group(1)
                body = self.read_json_body() if int(self.headers.get("Content-Length") or 0) else {}
                if action == "test":
                    result = cellular.test_api_credentials(self.cfg.path, str(body.get("username") or ""), str(body.get("token") or ""))
                    self.send_json({"ok": True, "result": result}); return
                if action == "save":
                    # Validate once, then persist one gateway-wide FCC credential set.
                    test = cellular.test_api_credentials(self.cfg.path, str(body.get("username") or ""), str(body.get("token") or ""))
                    result = cellular.save_api_credentials(self.cfg.path, str(body.get("username") or ""), str(body.get("token") or ""))
                    self.send_json({"ok": True, "result": result, "test": test}); return
                self.send_json({"ok": True, "result": cellular.clear_api_credentials(self.cfg.path)}); return
            mcell_api_acquire = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/cellular/api/acquire", path)
            if mcell_api_acquire:
                code = mcell_api_acquire.group(1).upper()
                if code not in STATES: raise ValueError("Unknown state")
                body = self.read_json_body() if int(self.headers.get("Content-Length") or 0) else {}
                if not cellular.source_status(self.cfg.path).get("configured"):
                    raise ValueError("FCC API credentials are not configured for this TAK Gateway")
                as_of = str(body.get("as_of") or "").strip()
                queued = spawn_cellular_action(self.cfg, code, "acquire", as_of=as_of)
                self.send_json({"ok": True, "queued": queued, "detail": "FCC H3 acquisition queued" if queued else "Cellular action is already active"}, 202); return
            # Legacy state-scoped credential actions remain as compatibility aliases.
            # They still operate on the same gateway-wide credential file.
            mcell_api = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/cellular/api/(test|save|clear)", path)
            if mcell_api:
                code, action = mcell_api.group(1).upper(), mcell_api.group(2)
                if code not in STATES: raise ValueError("Unknown state")
                body = self.read_json_body() if int(self.headers.get("Content-Length") or 0) else {}
                if action == "test":
                    result = cellular.test_api_credentials(self.cfg.path, str(body.get("username") or ""), str(body.get("token") or ""))
                    self.send_json({"ok": True, "result": result}); return
                if action == "save":
                    test = cellular.test_api_credentials(self.cfg.path, str(body.get("username") or ""), str(body.get("token") or ""))
                    result = cellular.save_api_credentials(self.cfg.path, str(body.get("username") or ""), str(body.get("token") or ""))
                    self.send_json({"ok": True, "result": result, "test": test}); return
                self.send_json({"ok": True, "result": cellular.clear_api_credentials(self.cfg.path)}); return
            mcell_remove_source = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/cellular/sources/([A-Za-z0-9_-]+)/remove", path)
            if mcell_remove_source:
                code, source_id = mcell_remove_source.group(1).upper(), mcell_remove_source.group(2)
                if code not in STATES: raise ValueError("Unknown state")
                removed = cellular.remove_source(self.cfg.path, code, source_id)
                self.send_json({"ok": True, "removed": removed, "inventory": cellular.source_inventory_summary(self.cfg.path, code)}); return
            mpause = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/(navigation|terrain|cellular)/(pause|resume)", path)
            if mpause:
                code, domain, action = mpause.group(1).upper(), mpause.group(2), mpause.group(3)
                if code not in STATES: raise ValueError("Unknown state")
                before = (state_status(self.cfg,code) if domain == "navigation" else
                          terrain_status_summary(self.cfg.path,code) if domain == "terrain" else
                          cellular.status_summary(self.cfg.path,code))
                if action == "pause":
                    active = (str(before.get("status")) in
                              ({"queued", "preparing", "building", "packaging", "pausing"} if domain == "terrain" else
                               cellular.ACTIVE_STATUSES | {"pausing"} if domain == "cellular" else
                               {"queued","preparing","checking_boundary","downloading_osm","downloading_sources","enriching","merging","indexing_osm","building","preparing_build","building_extract","packaging","checking_sources","pausing"}))
                    if not active and not job_control.requested(self.cfg.path,domain,code):
                        raise ValueError("No active operation to pause")
                    row = job_control.pause(self.cfg.path,domain,code, idle=not active)
                    self.send_json({"ok":True,"action":"pause","status":row['phase'],"detail":"Pause requested; waiting for a safe checkpoint"},202)
                else:
                    if not job_control.resume(self.cfg.path,domain,code):
                        raise ValueError("Operation is not paused")
                    if domain == "terrain":
                        queued = spawn_terrain_build(self.cfg,code)
                    elif domain == "cellular":
                        prior_action = str(before.get("resume_action") or "build")
                        queued = spawn_cellular_action(self.cfg,code, prior_action if prior_action in {"acquire","check","build","update"} else "build", as_of=str(before.get("resume_as_of") or ""))
                    else:
                        update_runtime(self.cfg,code,"pending",stage="resuming",detail="Navigation resume requested")
                        spawn_reconcile(self.cfg,states=[code],manual_override=True)
                        queued = True
                    self.send_json({"ok":True,"action":"resume","queued":queued,"status":"queued" if queued else "running"},202)
                return
            mc = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/cellular/(check|build|update|rebuild|remove)", path)
            if mc:
                code = mc.group(1).upper(); action = mc.group(2)
                if job_control.requested(self.cfg.path,"cellular",code):
                    raise ValueError("Cellular work paused; use Resume first")
                if code not in STATES: raise ValueError("Unknown state")
                if action == "remove":
                    removed = cellular.remove(self.cfg.path, code)
                    self.send_json({"ok": True, "removed": removed, "cellular": cellular.status_summary(self.cfg.path, code)}); return
                queued = spawn_cellular_action(self.cfg, code, action)
                self.send_json({"ok": True, "queued": queued, "action": action,
                                "detail": "Cellular action queued" if queued else "Cellular action is already active"}, 202); return
            me = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/environment/(build|rebuild|remove)", path)
            if me:
                code=me.group(1).upper(); action=me.group(2)
                if code not in STATES: raise ValueError("Unknown state")
                if action=="remove":
                    removed=environment.remove(self.cfg.path,code); self.send_json({"ok":True,"removed":removed,"environment":environment.status_summary(self.cfg.path,code)}); return
                queued=spawn_environment_build(self.cfg,code,force=(action=="rebuild"))
                self.send_json({"ok":True,"queued":queued,"action":action,"detail":"3D environment build queued" if queued else "3D environment build is already active"},202); return
            mt = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/terrain/(build|rebuild|remove)", path)
            if mt:
                code = mt.group(1).upper(); action = mt.group(2)
                if job_control.requested(self.cfg.path,"terrain",code):
                    raise ValueError("Elevation work paused; use Resume first")
                if code not in STATES: raise ValueError("Unknown state")
                if action == "remove":
                    removed = remove_terrain(self.cfg.path, code)
                    self.send_json({"ok": True, "removed": removed, "terrain": terrain_status_summary(self.cfg.path, code)}); return
                queued = spawn_terrain_build(self.cfg, code, force=(action == "rebuild"))
                self.send_json({"ok": True, "queued": queued, "action": action,
                                "detail": "3D terrain build queued" if queued else "3D terrain build is already active"}, 202); return
            m = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/(update|retry|rebuild|remove)", path)
            if m:
                code = m.group(1).upper(); action = m.group(2)
                if job_control.requested(self.cfg.path,"navigation",code):
                    raise ValueError("Navigation work paused; use Resume first")
                if code not in STATES: raise ValueError("Unknown state")
                if action == "remove":
                    settings = self.cfg.settings()
                    self.cfg.save_settings([s for s in settings["selected_states"] if s != code])
                    removed = remove_package(self.cfg, code)
                    self.send_json({"ok": True, "removed": removed}); return
                spawn_reconcile(self.cfg, states=[code], force_refresh=True, force_rebuild=(action in {"retry", "rebuild"}), manual_override=True)
                self.send_json({"ok": True, "queued": True, "action": action}, 202); return
            self.send_error(404)
        except Exception as exc:
            self.send_json({"ok": False, "error": str(exc)}, 400)

    def do_PUT(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        mcell_import = re.fullmatch(r"/api/v1/states/([A-Za-z]{2})/cellular/import", parsed.path)
        if mcell_import:
            code = mcell_import.group(1).upper()
            staged = None
            try:
                if code not in STATES: raise ValueError("Unknown state")
                q = urllib.parse.parse_qs(parsed.query)
                filename = Path(str((q.get("filename") or [""])[0])).name
                if not filename.lower().endswith((".zip", ".gpkg")):
                    raise ValueError("Import official FCC Hexagon Coverage .zip or .gpkg files")
                length = int(self.headers.get("Content-Length") or 0)
                if length <= 0: raise ValueError("Upload is empty")
                if length > 12 * 1024**3: raise ValueError("FCC import exceeds the 12 GiB per-file safety limit")
                incoming = cellular.roots(self.cfg.path)["imports"] / code.lower()
                incoming.mkdir(parents=True, exist_ok=True)
                staged = incoming / (uuid.uuid4().hex + Path(filename).suffix.lower())
                part = staged.with_suffix(staged.suffix + ".part")
                remaining = length
                cellular.update_status(self.cfg.path, code, "importing", "importing", f"Uploading FCC H3 source · {filename}", progress={"uploaded_bytes": 0, "total_bytes": length, "percent": 0})
                written = 0; hasher = hashlib.sha256(); last_report = 0
                with part.open("wb") as out:
                    while remaining > 0:
                        block = self.rfile.read(min(2 * 1024 * 1024, remaining))
                        if not block: break
                        out.write(block); hasher.update(block); remaining -= len(block); written += len(block)
                        if written - last_report >= 16 * 1024 * 1024 or remaining == 0:
                            last_report = written
                            cellular.update_status(self.cfg.path, code, "importing", "importing", f"Uploading FCC H3 source · {filename}", progress={"uploaded_bytes": written, "total_bytes": length, "percent": round(written / max(1, length) * 100, 1)})
                if remaining != 0:
                    part.unlink(missing_ok=True); raise ValueError("Upload ended before Content-Length")
                os.replace(part, staged)
                records = cellular.import_uploaded(self.cfg.path, code, staged, filename, provenance="manual", sha256_hint=hasher.hexdigest())
                inventory = cellular.source_inventory_summary(self.cfg.path, code)
                status = "ready_to_build" if inventory.get("ready_to_build") else "sources_incomplete"
                detail = "FCC H3 sources ready to build" if inventory.get("ready_to_build") else "FCC H3 import accepted; additional carrier/technology files are required"
                cellular.update_status(self.cfg.path, code, status, "acquisition", detail, source_inventory=inventory)
                self.send_json({"ok": True, "state_code": code, "filename": filename, "records": records, "inventory": inventory}, 201); return
            except Exception as exc:
                inventory = cellular.source_inventory_summary(self.cfg.path, code) if code in STATES else {}
                if code in STATES:
                    cellular.update_status(self.cfg.path, code, "sources_incomplete" if inventory.get("records") else "no_sources", "import_failed", "FCC H3 import rejected; existing sources were preserved", acquisition_error=str(exc), source_inventory=inventory)
                self.send_json({"ok": False, "error": str(exc)}, 400); return
            finally:
                if staged is not None:
                    with contextlib.suppress(Exception): staged.unlink()
        if parsed.path != "/api/v1/manual/osm":
            self.send_error(404); return
        try:
            q = urllib.parse.parse_qs(parsed.query)
            code = str((q.get("state") or [""])[0]).upper()
            filename = Path(str((q.get("filename") or [""])[0])).name
            if code not in STATES: raise ValueError("Choose a valid U.S. state")
            if not filename.lower().endswith((".osm.pbf", ".pbf")):
                raise ValueError("Supported road-network files: .osm.pbf (or validated OSM .pbf)")
            length = int(self.headers.get("Content-Length") or 0)
            if length <= 0: raise ValueError("Upload is empty")
            manual = self.cfg.manager_root / "manual" / code.lower()
            manual.mkdir(parents=True, exist_ok=True)
            target = manual / filename
            part = target.with_name(target.name + ".part")
            remaining = length
            with part.open("wb") as out:
                while remaining > 0:
                    block = self.rfile.read(min(1024 * 1024, remaining))
                    if not block: break
                    out.write(block); remaining -= len(block)
            if remaining != 0:
                part.unlink(missing_ok=True); raise ValueError("Upload ended before Content-Length")
            os.replace(part, target)
            validate_osm_pbf(target, allow_plain_pbf=True)
            # Use this validated manual PBF as the state's persistent base cache.
            # It is enriched and queued immediately; configured update checks refresh the
            # enabled supplemental sources without silently replacing the manual base.
            p = source_cache_paths(self.cfg, code)
            p["root"].mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, p["base"])
            bounds = osm_pbf_bounds(p["base"])
            base_sha = sha256_file(p["base"])
            base_meta = {
                "source_id": "manual_osm_pbf", "source_name": "Manual OpenStreetMap PBF",
                "state": code, "state_name": STATES[code].name, "url": "manual-upload",
                "sha256": base_sha, "size_bytes": p["base"].stat().st_size,
                "downloaded_utc": utcnow(), "bounds": bounds, "role": "base_network",
                "applied_to_graph": True,
            }
            atomic_json(p["base_meta"], base_meta)
            settings = self.cfg.settings()
            if code not in settings["selected_states"]:
                self.cfg.save_settings(settings["selected_states"] + [code])
            state_source_settings = self.cfg.state_source_settings(code)
            agency_raw = remote_revision_for_state(code, state_source_settings)
            remote = {
                "manual_osm_pbf": {"ok": True, "sha256": base_sha, "size_bytes": p["base"].stat().st_size},
                "agency": agency_raw.get("agency") or {},
            }
            source_fp = current_source_fingerprint(state_source_settings, code)
            build_fp = effective_build_fingerprint(source_fp, remote, include_osm=False)
            ok_space, disk_estimate = storage_gate(self.cfg, code, remote)
            if not ok_space:
                update_runtime(self.cfg, code, "waiting_space", stage="waiting_space", detail="Manual import saved; waiting for disk space policy",
                               build_fingerprint=build_fp, update_reason="Manual OSM import", disk_estimate=disk_estimate)
                self.send_json({"ok": True, "file": str(target), "state": code, "queued_build": False, "waiting_space": True, "disk_estimate": disk_estimate}, 202); return
            update_runtime(self.cfg, code, "preparing", stage="manual_import", detail="Preparing uploaded OSM PBF",
                           new_attempt=True, clear_failure=True, build_fingerprint=build_fp, update_reason="Manual OSM import", disk_estimate=disk_estimate)
            try:
                manifest = fetch_and_prepare(
                    self.cfg, code, state_source_settings, remote, force_base=False, build_fingerprint=build_fp, update_reason="Manual OSM import"
                )
                enqueue_for_processor(self.cfg, code, p["enriched"], manifest)
                update_runtime(self.cfg, code, "queued", stage="queued", detail="Uploaded input queued for Valhalla",
                               clear_failure=True, build_fingerprint=build_fp)
            except Exception as exc:
                record_manager_failure(self.cfg, code, exc, build_fp)
                raise
            self.send_json({"ok": True, "file": str(target), "state": code, "queued_build": True}, 201)
        except Exception as exc:
            self.send_json({"ok": False, "error": str(exc)}, 400)


DISCOVERY_QUERY_MAGIC = "TAKRIG_NDM_DISCOVER"
DISCOVERY_RESPONSE_MAGIC = "TAKRIG_NDM_HERE"
DISCOVERY_ID_FILE = ".ndm-discovery-id"


def discovery_server_id(cfg: ManagerConfig) -> str:
    """Return a stable installation identity, persisted under the configured state root."""
    path = cfg.root / DISCOVERY_ID_FILE
    try:
        value = path.read_text(encoding="utf-8").strip()
        if value:
            return value[:160]
    except FileNotFoundError:
        pass
    value = str(uuid.uuid4())
    atomic_text(path, value + "\n")
    return value


def discovery_response(cfg: ManagerConfig, server_id: str | None = None) -> dict[str, Any]:
    name = str(cfg.data.get("discovery_name") or "").strip() or socket.gethostname() or "Navigation Data Manager"
    return {
        "magic": DISCOVERY_RESPONSE_MAGIC,
        "v": 1,
        "serverId": server_id or discovery_server_id(cfg),
        "name": name[:100],
        "port": int(cfg.data.get("web_port") or 8765),
        "version": VERSION,
        "capabilities": ["navigation", "elevation", "environment", "cellular"],
    }


def discovery_loop(cfg: ManagerConfig, stop_event: threading.Event | None = None) -> None:
    if not bool(cfg.data.get("discovery_enabled", True)):
        return
    port = int(cfg.data.get("discovery_port") or 47818)
    server_id = discovery_server_id(cfg)
    stop = stop_event or threading.Event()
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("0.0.0.0", port))
        sock.settimeout(1.0)
        log_line(cfg, f"NDM discovery listening on UDP/0.0.0.0:{port}")
        while not stop.is_set():
            try:
                payload, source = sock.recvfrom(2048)
            except socket.timeout:
                continue
            except OSError:
                if stop.is_set():
                    break
                continue
            if not payload or len(payload) > 1600:
                continue
            try:
                query = json.loads(payload.decode("utf-8"))
            except Exception:
                continue
            if not isinstance(query, dict) or query.get("magic") != DISCOVERY_QUERY_MAGIC:
                continue
            if int(query.get("v") or 0) != 1:
                continue
            response = json.dumps(discovery_response(cfg, server_id), separators=(",", ":")).encode("utf-8")
            with contextlib.suppress(OSError):
                sock.sendto(response, source)


def serve(cfg: ManagerConfig) -> None:
    cfg.ensure()
    host = str(cfg.data.get("web_host") or "0.0.0.0")
    port = int(cfg.data.get("web_port") or 8765)
    server = ThreadingHTTPServer((host, port), WebHandler)
    server.cfg = cfg  # type: ignore[attr-defined]
    if bool(cfg.data.get("discovery_enabled", True)):
        threading.Thread(target=discovery_loop, args=(cfg,), name="takrig-ndm-discovery", daemon=True).start()
    log_line(cfg, f"Navigation Data Manager web GUI listening on {host}:{port}")
    server.serve_forever()


def parse_args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="takrig-nav-manager")
    p.add_argument("--config", default=os.environ.get("TAKRIG_ROUTING_CONFIG", "/etc/takrig-routing/config.json"))
    p.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    sub = p.add_subparsers(dest="command", required=True)
    r = sub.add_parser("reconcile")
    r.add_argument("--state", action="append", default=[])
    r.add_argument("--force-refresh", action="store_true")
    r.add_argument("--force-rebuild", action="store_true")
    r.add_argument("--manual", action="store_true", help="Bypass maintenance timing for an explicit user action")
    sub.add_parser("status")
    sub.add_parser("catalog")
    sub.add_parser("serve")
    s = sub.add_parser("select")
    s.add_argument("states", nargs="*")
    s.add_argument("--preset", choices=sorted(PRESETS))
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    cfg = ManagerConfig(Path(args.config))
    cfg.ensure()
    try:
        if args.command == "reconcile":
            with manager_lock(cfg):
                print(json.dumps(reconcile(cfg, only=args.state or None,
                                           force_refresh=args.force_refresh, force_rebuild=args.force_rebuild,
                                           manual_override=args.manual), indent=2))
            return 0
        if args.command == "status":
            print(json.dumps(manager_status(cfg), indent=2)); return 0
        if args.command == "catalog":
            print(json.dumps(public_catalog(cfg), indent=2)); return 0
        if args.command == "serve":
            serve(cfg); return 0
        if args.command == "select":
            states = PRESETS[args.preset] if args.preset else args.states
            settings = cfg.save_settings(validate_states(states))
            spawn_reconcile(cfg, states=settings["selected_states"])
            print(json.dumps(settings, indent=2)); return 0
    except RuntimeError as exc:
        if "already running" in str(exc).lower():
            print(json.dumps({"ok": True, "busy": True, "message": str(exc)}, indent=2)); return 0
        raise
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
