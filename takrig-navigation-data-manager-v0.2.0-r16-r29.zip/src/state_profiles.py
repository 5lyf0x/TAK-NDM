#!/usr/bin/env python3
"""Declarative state-source profiles for TAK Rig NDM.

This module intentionally contains data only.  Runtime normalizers live in
``sources.py`` so CA/AZ/UT behavior remains unchanged while additional states
can be added without growing one-off registry code.

Only public, queryable, authoritative/state-sponsored line services are listed.
Recreation datasets are optional and are routed only after conservative
full-size-vehicle checks in sources.py.
"""
from __future__ import annotations

# States explicitly added/validated for the west-of-Mississippi expansion.
# CA/AZ/UT are intentionally excluded because their working r25 definitions are
# preserved verbatim in sources.py.
WEST_EXPANSION_STATES = (
    "AK", "AR", "CO", "HI", "ID", "IA", "KS", "LA", "MN", "MO", "MT",
    "NE", "NV", "NM", "ND", "OK", "OR", "SD", "TX", "WA", "WY",
)

# Each source supports the SupplementalSpec constructor in sources.py.
# ``profile_revision`` is deliberately per-source/per-state.  It participates
# in the state fingerprint so future mapping changes invalidate only the state
# whose adapter changed; the global r16 routing pipeline fingerprint is stable.
STATE_ROAD_PROFILES: dict[str, tuple[dict, ...]] = {
    "AK": (
        {
            "source_id": "ak_dotpf_road_centerlines",
            "name": "Alaska DOT&PF Road Centerlines",
            "layer_url": "https://services.arcgis.com/r4A0V7UzH9fcLVvv/ArcGIS/rest/services/AKDOTPF_Route_Data/FeatureServer/20",
            "file_name": "ak-dotpf-road-centerlines.geojsonl",
            "profile_revision": "ak-road-v1",
        },
    ),
    "AR": (
        {
            "source_id": "ar_gis_road_centerlines",
            "name": "Arkansas GIS Office Statewide Road Centerlines",
            "layer_url": "https://gis.arkansas.gov/arcgis/rest/services/FEATURESERVICES/Transportation/FeatureServer/18",
            "file_name": "ar-statewide-road-centerlines.geojsonl",
            "profile_revision": "ar-road-v1",
        },
    ),
    "CO": (
        {
            "source_id": "co_dot_highways",
            "name": "Colorado DOT Highways",
            "layer_url": "https://dtdapps.codot.gov/server/rest/services/Webapps/open_data_sde/FeatureServer/7",
            "file_name": "co-dot-highways.geojsonl",
            "profile_revision": "co-highways-v1",
        },
        {
            "source_id": "co_dot_local_roads",
            "name": "Colorado DOT Local Roads",
            "layer_url": "https://dtdapps.codot.gov/server/rest/services/Webapps/open_data_sde/FeatureServer/14",
            "file_name": "co-dot-local-roads.geojsonl",
            "profile_revision": "co-local-v1",
        },
        {
            "source_id": "co_cpw_state_park_public_roads",
            "name": "Colorado Parks & Wildlife State Park Public Roads",
            "layer_url": "https://services5.arcgis.com/ttNGmDvKQA7oeDQ3/arcgis/rest/services/CPWAdminData/FeatureServer/1",
            "file_name": "co-cpw-state-park-public-roads.geojsonl",
            "profile_revision": "co-cpw-roads-v1",
        },
    ),
    "HI": (
        {
            "source_id": "hi_oahu_roads", "name": "Hawaii GIS Oahu Roads",
            "layer_url": "https://geodata.hawaii.gov/arcgis/rest/services/Transportation/MapServer/3",
            "file_name": "hi-oahu-roads.geojsonl", "profile_revision": "hi-oahu-v1",
        },
        {
            "source_id": "hi_kauai_roads", "name": "Hawaii GIS Kauai Roads",
            "layer_url": "https://geodata.hawaii.gov/arcgis/rest/services/Transportation/MapServer/4",
            "file_name": "hi-kauai-roads.geojsonl", "profile_revision": "hi-kauai-v1",
        },
        {
            "source_id": "hi_maui_roads", "name": "Hawaii GIS Maui Roads",
            "layer_url": "https://geodata.hawaii.gov/arcgis/rest/services/Transportation/MapServer/5",
            "file_name": "hi-maui-roads.geojsonl", "profile_revision": "hi-maui-v1",
        },
        {
            "source_id": "hi_hawaii_county_roads", "name": "Hawaii GIS Hawaii County Roads",
            "layer_url": "https://geodata.hawaii.gov/arcgis/rest/services/Transportation/MapServer/6",
            "file_name": "hi-hawaii-county-roads.geojsonl", "profile_revision": "hi-big-island-v1",
        },
    ),
    "ID": (
        {
            "source_id": "id_itd_all_roads_jurisdiction",
            "name": "Idaho Transportation Department All Roads by Jurisdiction",
            "layer_url": "https://gis.itd.idaho.gov/arcgisprod/rest/services/ArcGISOnline/IdahoTransportationLayersForOpenData/MapServer/130",
            "file_name": "id-itd-all-roads.geojsonl",
            "profile_revision": "id-road-v1",
        },
    ),
    "IA": (
        {
            "source_id": "ia_dot_road_network",
            "name": "Iowa DOT Road Network",
            "layer_url": "https://services.arcgis.com/8lRhdTsQyJpO52F1/ArcGIS/rest/services/Road_Network_View/FeatureServer/0",
            "file_name": "ia-dot-road-network.geojsonl",
            "profile_revision": "ia-road-v1",
        },
    ),
    "KS": (
        {
            "source_id": "ks_ng911_road_centerlines",
            "name": "Kansas NG911 Statewide Road Centerlines",
            "layer_url": "https://services.kansasgis.org/arcgis4/rest/services/NG911/NG911/MapServer/1",
            "file_name": "ks-ng911-road-centerlines.geojsonl",
            "profile_revision": "ks-road-v1",
        },
    ),
    "LA": (
        {
            "source_id": "la_dotd_roadways",
            "name": "Louisiana DOTD Roadways",
            "layer_url": "https://gis.dotd.la.gov/road/rest/services/Roads_and_Highways_OpenData/FeatureServer/49",
            "file_name": "la-dotd-roadways.geojsonl",
            "profile_revision": "la-road-v1",
        },
    ),
    "MN": (
        {
            "source_id": "mn_dot_trunk_highways", "name": "Minnesota DOT Trunk Highway Route System",
            "layer_url": "https://dotapp9.dot.state.mn.us/egis12/rest/services/BASEMAP/mndot_commonlayers2/FeatureServer/0",
            "file_name": "mn-dot-trunk-highways.geojsonl", "profile_revision": "mn-trunk-v1",
        },
        {
            "source_id": "mn_dot_county_state_aid", "name": "Minnesota DOT County State Aid Highways",
            "layer_url": "https://dotapp9.dot.state.mn.us/egis12/rest/services/BASEMAP/mndot_commonlayers2/FeatureServer/1",
            "file_name": "mn-dot-county-state-aid.geojsonl", "profile_revision": "mn-csah-v1",
        },
        {
            "source_id": "mn_dot_other_county", "name": "Minnesota DOT Other County Routes",
            "layer_url": "https://dotapp9.dot.state.mn.us/egis12/rest/services/BASEMAP/mndot_commonlayers2/FeatureServer/2",
            "file_name": "mn-dot-other-county.geojsonl", "profile_revision": "mn-county-v1",
        },
        {
            "source_id": "mn_dot_municipal_state_aid", "name": "Minnesota DOT Municipal State Aid Streets",
            "layer_url": "https://dotapp9.dot.state.mn.us/egis12/rest/services/BASEMAP/mndot_commonlayers2/FeatureServer/3",
            "file_name": "mn-dot-municipal-state-aid.geojsonl", "profile_revision": "mn-msas-v1",
        },
        {
            "source_id": "mn_dot_municipal_streets", "name": "Minnesota DOT Municipal Streets",
            "layer_url": "https://dotapp9.dot.state.mn.us/egis12/rest/services/BASEMAP/mndot_commonlayers2/FeatureServer/4",
            "file_name": "mn-dot-municipal-streets.geojsonl", "profile_revision": "mn-municipal-v1",
        },
        {
            "source_id": "mn_dot_other_routes", "name": "Minnesota DOT Other Route System",
            "layer_url": "https://dotapp9.dot.state.mn.us/egis12/rest/services/BASEMAP/mndot_commonlayers2/FeatureServer/5",
            "file_name": "mn-dot-other-routes.geojsonl", "profile_revision": "mn-other-v1",
        },
    ),
    "MO": (
        {
            "source_id": "mo_dot_roads_routes",
            "name": "Missouri DOT Roads Routes",
            "layer_url": "https://services2.arcgis.com/kNS2ppBA4rwAQQZy/arcgis/rest/services/MO_MoDOT_Roads_Routes/FeatureServer/0",
            "file_name": "mo-dot-roads-routes.geojsonl",
            "profile_revision": "mo-road-v1",
        },
    ),
    "MT": (
        {
            "source_id": "mt_transportation_framework",
            "name": "Montana Transportation Framework Road Centerlines",
            "layer_url": "https://gisservice.mt.gov/ArcGIS/rest/services/msdi_transportation_map_v1/MapServer/0",
            "file_name": "mt-transportation-framework.geojsonl",
            "profile_revision": "mt-road-v1",
        },
    ),
    "NE": (
        {
            "source_id": "ne_dot_highways",
            "name": "Nebraska DOT Highways",
            "layer_url": "https://gis.ne.gov/Enterprise/rest/services/Highways/FeatureServer/0",
            "file_name": "ne-dot-highways.geojsonl",
            "profile_revision": "ne-road-v1",
        },
    ),
    # NV and NM retain the same endpoints as r25 but gain explicit adapter
    # revisions so future changes can invalidate those states independently.
    "NV": (
        {
            "source_id": "nv_dot_statewide_routes",
            "name": "Nevada DOT Statewide Routes",
            "layer_url": "https://gis.dot.nv.gov/arcgis/rest/services/ArcGISOnline/ALRS_Download/FeatureServer/1",
            "file_name": "state-dot-all-roads.geojson",
            "profile_revision": "nv-road-v1",
            "streaming": False,
        },
    ),
    "NM": (
        {
            "source_id": "nm_dot_911_roads",
            "name": "New Mexico DOT / NM911 Road Centerlines",
            "layer_url": "https://services.arcgis.com/hOpd7wfnKm16p9D9/ArcGIS/rest/services/NM911_Road_Centerlines/FeatureServer/0",
            "file_name": "state-dot-all-roads.geojson",
            "profile_revision": "nm-road-v1",
            "streaming": False,
        },
    ),
    "ND": (
        {
            "source_id": "nd_dot_state_federal_roads",
            "name": "North Dakota DOT State and Federal Roads",
            "layer_url": "https://services1.arcgis.com/GOcSXpzwBHyk2nog/arcgis/rest/services/NDGISHUB_State_and_Federal_Roads/FeatureServer/0",
            "file_name": "nd-dot-state-federal-roads.geojsonl",
            "profile_revision": "nd-state-v1",
        },
        {
            "source_id": "nd_dot_county_city_roads",
            "name": "North Dakota DOT County and City Roads",
            "layer_url": "https://services1.arcgis.com/GOcSXpzwBHyk2nog/arcgis/rest/services/NDGISHUB_County_Roads/FeatureServer/0",
            "file_name": "nd-dot-county-city-roads.geojsonl",
            "profile_revision": "nd-local-v1",
        },
    ),
    "OK": (
        {
            "source_id": "ok_dot_functional_roads",
            "name": "Oklahoma DOT Functionally Classified Roadways",
            "layer_url": "https://services6.arcgis.com/RBtoEUQ2lmN0K3GY/ArcGIS/rest/services/Roadways/FeatureServer/0",
            "file_name": "ok-dot-roadways.geojsonl",
            "profile_revision": "ok-road-v1",
        },
    ),
    "OR": (
        {
            "source_id": "or_dot_transportation_network",
            "name": "Oregon DOT Transportation Network",
            "layer_url": "https://services1.arcgis.com/CD5mKowwN6nIaqd8/arcgis/rest/services/Oregon_Transportation_Network/FeatureServer/0",
            "file_name": "or-dot-transportation-network.geojsonl",
            "profile_revision": "or-road-v1",
        },
    ),
    "SD": (
        {
            "source_id": "sd_dot_arnold_roads",
            "name": "South Dakota DOT ARNOLD All-Road Network",
            "layer_url": "https://dotgis.sd.gov/spearfishformation/rest/services/GFT/DOT_ARNOLD_viewer/FeatureServer/0",
            "file_name": "sd-dot-arnold-roads.geojsonl",
            "profile_revision": "sd-road-v1",
        },
    ),
    "TX": (
        {
            "source_id": "tx_dot_roadway_inventory",
            "name": "Texas DOT Roadway Inventory",
            "layer_url": "https://services.arcgis.com/KTcxiTD9dsQw4r7Z/arcgis/rest/services/TxDOT_Roadway_Inventory/FeatureServer/0",
            "file_name": "tx-dot-roadway-inventory.geojsonl",
            "profile_revision": "tx-road-v1",
        },
    ),
    "WA": (
        {
            "source_id": "wa_dot_state_routes", "name": "Washington State DOT State Routes",
            "layer_url": "https://data.wsdot.wa.gov/arcgis/rest/services/Shared/WSDOTPublicRoads/MapServer/1",
            "file_name": "wa-dot-state-routes.geojsonl", "profile_revision": "wa-state-v1",
        },
        {
            "source_id": "wa_dot_ramps", "name": "Washington State DOT Ramps",
            "layer_url": "https://data.wsdot.wa.gov/arcgis/rest/services/Shared/WSDOTPublicRoads/MapServer/3",
            "file_name": "wa-dot-ramps.geojsonl", "profile_revision": "wa-ramps-v1",
        },
        {
            "source_id": "wa_local_public_roads", "name": "Washington Local Agency Public Roads",
            "layer_url": "https://data.wsdot.wa.gov/arcgis/rest/services/Shared/WSDOTPublicRoads/MapServer/6",
            "file_name": "wa-local-public-roads.geojsonl", "profile_revision": "wa-local-v1",
        },
    ),
    "WY": (
        {
            "source_id": "wy_dot_highways",
            "name": "Wyoming DOT Highways Open Data",
            "layer_url": "https://services3.arcgis.com/HVjI8GKrRtjcQ4Ry/ArcGIS/rest/services/WyDOT_Highways_OpenData/FeatureServer/0",
            "file_name": "wy-dot-highways.geojsonl",
            "profile_revision": "wy-road-v1",
        },
    ),
}

# Optional vetted state recreation sources.  These are never enough by themselves
# to make a route truck/SUV-routable: sources.py applies explicit full-size-vehicle
# evidence checks to every trail feature.
STATE_RECREATION_PROFILES: dict[str, tuple[dict, ...]] = {
    "CO": (
        {
            "source_id": "co_cotrex_trails",
            "name": "Colorado Parks & Wildlife COTREX Trails",
            "layer_url": "https://services5.arcgis.com/ttNGmDvKQA7oeDQ3/arcgis/rest/services/CPWAdminData/FeatureServer/15",
            "file_name": "co-cotrex-trails.geojsonl",
            "profile_revision": "co-cotrex-v1",
        },
    ),
    "ID": (
        {
            "source_id": "id_recreation_routes",
            "name": "Idaho Recreation Trails - Routes",
            "layer_url": "https://services1.arcgis.com/CNPdEkvnGl65jCX8/arcgis/rest/services/Idaho_Recreation_Trails/FeatureServer/128",
            "file_name": "id-recreation-routes.geojsonl",
            "profile_revision": "id-recreation-v1",
        },
    ),
}
