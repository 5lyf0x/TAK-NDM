#!/usr/bin/env python3
from __future__ import annotations

import html
import json
import math
import re
import shutil
import sqlite3
import subprocess
import threading
from pathlib import Path
from typing import Any, Callable, Iterable, TextIO

GRAPH_APPLY_SOURCE_PREFIXES = (
    "usfs_", "blm_", "nps_public_roads",
    "ca_state_parks", "nm_state_highway_ohv_",
    "ca_dot_", "nv_dot_", "ut_dot_", "nm_dot_",
)


def log_default(msg: str) -> None:
    print(msg, flush=True)


def stage_default(stage: str, detail: str = "") -> None:
    return None


def run(cmd: list[str], log: Callable[[str], None]) -> None:
    log("RUN " + " ".join(cmd))
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if proc.stdout:
        for line in proc.stdout.splitlines():
            log(line)
    if proc.returncode != 0:
        raise RuntimeError(f"Command failed ({proc.returncode}): {' '.join(cmd)}")


def run_stream(cmd: list[str], consumer: Callable[[TextIO], Any], log: Callable[[str], None]) -> Any:
    """Feed an osmium stdout stream directly to a consumer without materializing it on disk."""
    log("RUN " + " ".join(cmd) + " [stream]")
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1024 * 1024,
    )
    assert proc.stdout is not None
    assert proc.stderr is not None
    stderr_lines: list[str] = []

    def drain_stderr() -> None:
        for line in proc.stderr:
            line = line.rstrip("\n")
            if line:
                stderr_lines.append(line)
                log(line)

    thread = threading.Thread(target=drain_stderr, daemon=True)
    thread.start()
    try:
        result = consumer(proc.stdout)
    except Exception:
        proc.terminate()
        proc.wait(timeout=10)
        thread.join(timeout=2)
        raise
    finally:
        proc.stdout.close()
    rc = proc.wait()
    thread.join(timeout=2)
    if rc != 0:
        suffix = f": {stderr_lines[-1]}" if stderr_lines else ""
        raise RuntimeError(f"Command failed ({rc}): {' '.join(cmd)}{suffix}")
    return result


def require_tools() -> None:
    if shutil.which("osmium") is None:
        raise RuntimeError("osmium-tool is required for supplemental route enrichment")
    try:
        import shapely  # noqa: F401
    except Exception as exc:
        raise RuntimeError("Python package shapely is required for supplemental route enrichment") from exc


def create_db(path: Path) -> sqlite3.Connection:
    path.unlink(missing_ok=True)
    db = sqlite3.connect(path)
    db.execute("PRAGMA journal_mode=OFF")
    db.execute("PRAGMA synchronous=OFF")
    db.execute("PRAGMA temp_store=MEMORY")
    db.execute("CREATE TABLE nodes (id INTEGER PRIMARY KEY, lon REAL NOT NULL, lat REAL NOT NULL)")
    db.execute("CREATE VIRTUAL TABLE node_idx USING rtree(id,minx,maxx,miny,maxy)")
    db.execute("CREATE TABLE ways (id INTEGER PRIMARY KEY, wkb BLOB NOT NULL)")
    db.execute("CREATE VIRTUAL TABLE way_idx USING rtree(id,minx,maxx,miny,maxy)")
    return db


_NODE_RE = re.compile(r"^n(-?\d+)(?:\s|$)")
_X_RE = re.compile(r"(?:^|\s)x(-?\d+(?:\.\d+)?)")
_Y_RE = re.compile(r"(?:^|\s)y(-?\d+(?:\.\d+)?)")


def index_road_nodes(lines: Iterable[str], db: sqlite3.Connection, log: Callable[[str], None]) -> int:
    count = 0
    batch_nodes: list[tuple[int, float, float]] = []
    batch_idx: list[tuple[int, float, float, float, float]] = []
    for line in lines:
        if not line.startswith("n"):
            continue
        mi = _NODE_RE.search(line); mx = _X_RE.search(line); my = _Y_RE.search(line)
        if not (mi and mx and my):
            continue
        node_id = int(mi.group(1)); lon = float(mx.group(1)); lat = float(my.group(1))
        batch_nodes.append((node_id, lon, lat))
        batch_idx.append((node_id, lon, lon, lat, lat))
        count += 1
        if len(batch_nodes) >= 20000:
            db.executemany("INSERT OR REPLACE INTO nodes VALUES (?,?,?)", batch_nodes)
            db.executemany("INSERT OR REPLACE INTO node_idx VALUES (?,?,?,?,?)", batch_idx)
            batch_nodes.clear(); batch_idx.clear()
    if batch_nodes:
        db.executemany("INSERT OR REPLACE INTO nodes VALUES (?,?,?)", batch_nodes)
        db.executemany("INSERT OR REPLACE INTO node_idx VALUES (?,?,?,?,?)", batch_idx)
    db.commit()
    log(f"Indexed {count:,} base road nodes")
    return count


def index_road_geometries(lines: Iterable[str], db: sqlite3.Connection, log: Callable[[str], None]) -> int:
    from shapely.geometry import shape
    from shapely import wkb

    count = 0
    batch_way: list[tuple[int, bytes]] = []
    batch_idx: list[tuple[int, float, float, float, float]] = []
    for line in lines:
        line = line.strip().lstrip("\x1e")
        if not line:
            continue
        try:
            obj = json.loads(line)
            geom = shape(obj.get("geometry"))
        except Exception:
            continue
        if geom.is_empty or geom.geom_type not in ("LineString", "MultiLineString"):
            continue
        count += 1
        ident = count
        minx, miny, maxx, maxy = geom.bounds
        batch_way.append((ident, wkb.dumps(geom)))
        batch_idx.append((ident, minx, maxx, miny, maxy))
        if len(batch_way) >= 5000:
            db.executemany("INSERT INTO ways VALUES (?,?)", batch_way)
            db.executemany("INSERT INTO way_idx VALUES (?,?,?,?,?)", batch_idx)
            batch_way.clear(); batch_idx.clear()
    if batch_way:
        db.executemany("INSERT INTO ways VALUES (?,?)", batch_way)
        db.executemany("INSERT INTO way_idx VALUES (?,?,?,?,?)", batch_idx)
    db.commit()
    log(f"Indexed {count:,} base road geometries")
    return count


def build_base_index(base_pbf: Path, work: Path, db: sqlite3.Connection,
                     log: Callable[[str], None], stage: Callable[[str, str], None]) -> None:
    """Build the conflation index while streaming OPL/GeoJSONSeq instead of saving multi-GB text files."""
    highway_pbf = work / "base-highways.osm.pbf"
    stage("indexing_osm", "Filtering OSM highway topology")
    run(["osmium", "tags-filter", str(base_pbf), "w/highway", "-o", str(highway_pbf), "--overwrite"], log)

    stage("indexing_osm", "Indexing OSM road nodes")
    run_stream(
        ["osmium", "cat", str(highway_pbf), "-f", "opl", "--no-progress"],
        lambda fh: index_road_nodes(fh, db, log),
        log,
    )

    stage("indexing_osm", "Indexing OSM road geometries")
    run_stream(
        ["osmium", "export", str(highway_pbf), "-f", "geojsonseq", "-x", "print_record_separator=false", "--no-progress"],
        lambda fh: index_road_geometries(fh, db, log),
        log,
    )
    highway_pbf.unlink(missing_ok=True)


def base_max_ids(base_pbf: Path, log: Callable[[str], None]) -> tuple[int, int]:
    """Read max node/way IDs in one pass so synthetic IDs can be safely allocated above them."""
    cmd = ["osmium", "fileinfo", "-e", "--no-crc", "-j", str(base_pbf)]
    log("RUN " + " ".join(cmd))
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if proc.returncode != 0:
        if proc.stderr.strip():
            log(proc.stderr.strip())
        raise RuntimeError(f"Command failed ({proc.returncode}): {' '.join(cmd)}")
    try:
        info = json.loads(proc.stdout)
        data = info.get("data") or {}
        maxid = data.get("maxid") or {}
        node_value = maxid.get("nodes") if isinstance(maxid, dict) else None
        way_value = maxid.get("ways") if isinstance(maxid, dict) else None
        if node_value is None:
            node_value = data.get("maxid.nodes", info.get("data.maxid.nodes", 0))
        if way_value is None:
            way_value = data.get("maxid.ways", info.get("data.maxid.ways", 0))
        node_max = int(node_value or 0)
        way_max = int(way_value or 0)
        ordered = data.get("objects_ordered", data.get("objects.ordered", info.get("data.objects_ordered")))
        if ordered is False or str(ordered).lower() == "no":
            raise RuntimeError("Base OSM PBF is not ordered by type and ID")
    except Exception as exc:
        raise RuntimeError("Could not read max OSM node/way IDs from osmium fileinfo JSON") from exc
    if node_max < 0 or way_max < 0:
        raise RuntimeError("Base OSM PBF reported invalid negative maximum object IDs")
    log(f"Base max IDs: node={node_max:,}, way={way_max:,}")
    return node_max, way_max


def meters_between(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    mean_lat = math.radians((lat1 + lat2) * 0.5)
    dx = (lon2 - lon1) * 111320.0 * max(0.2, math.cos(mean_lat))
    dy = (lat2 - lat1) * 110540.0
    return math.hypot(dx, dy)


def nearest_base_node(db: sqlite3.Connection, lon: float, lat: float, max_m: float) -> int | None:
    lat_tol = max_m / 110540.0
    lon_tol = max_m / (111320.0 * max(0.2, math.cos(math.radians(lat))))
    rows = db.execute(
        "SELECT n.id,n.lon,n.lat FROM node_idx r JOIN nodes n ON n.id=r.id "
        "WHERE r.minx<=? AND r.maxx>=? AND r.miny<=? AND r.maxy>=? LIMIT 80",
        (lon + lon_tol, lon - lon_tol, lat + lat_tol, lat - lat_tol),
    ).fetchall()
    best: tuple[float, int] | None = None
    for node_id, x, y in rows:
        d = meters_between(lon, lat, float(x), float(y))
        if d <= max_m and (best is None or d < best[0]):
            best = (d, int(node_id))
    return best[1] if best else None


def mostly_covered_by_base(db: sqlite3.Connection, geom: Any, tolerance_m: float = 18.0) -> bool:
    from shapely import wkb
    from shapely.ops import unary_union

    if geom.is_empty or geom.length <= 0:
        return True
    center_lat = geom.centroid.y
    lat_tol = tolerance_m / 110540.0
    lon_tol = tolerance_m / (111320.0 * max(0.2, math.cos(math.radians(center_lat))))
    minx, miny, maxx, maxy = geom.bounds
    ids = db.execute(
        "SELECT id FROM way_idx WHERE minx<=? AND maxx>=? AND miny<=? AND maxy>=? LIMIT 3000",
        (maxx + lon_tol, minx - lon_tol, maxy + lat_tol, miny - lat_tol),
    ).fetchall()
    if not ids:
        return False
    candidates = []
    for (ident,) in ids:
        row = db.execute("SELECT wkb FROM ways WHERE id=?", (ident,)).fetchone()
        if row:
            candidates.append(wkb.loads(row[0]))
    if not candidates:
        return False
    nearby = unary_union(candidates)
    tol_deg = max(lat_tol, lon_tol)
    remainder = geom.difference(nearby.buffer(tol_deg))
    ratio = remainder.length / geom.length if geom.length else 0.0
    return ratio <= 0.20


def missing_parts_against_base(db: sqlite3.Connection, geom: Any, tolerance_m: float = 18.0) -> list[Any]:
    """Return only portions of a supplemental line not represented by the Core OSM network.

    This is used for state public-road authority data.  It deliberately uses a
    proximity buffer rather than exact geometry equality because agency and OSM
    centerlines commonly differ by several metres.
    """
    from shapely import wkb
    from shapely.ops import unary_union

    if geom.is_empty or geom.length <= 0:
        return []
    center_lat = geom.centroid.y
    lat_tol = tolerance_m / 110540.0
    lon_tol = tolerance_m / (111320.0 * max(0.2, math.cos(math.radians(center_lat))))
    minx, miny, maxx, maxy = geom.bounds
    ids = db.execute(
        "SELECT id FROM way_idx WHERE minx<=? AND maxx>=? AND miny<=? AND maxy>=? LIMIT 5000",
        (maxx + lon_tol, minx - lon_tol, maxy + lat_tol, miny - lat_tol),
    ).fetchall()
    if not ids:
        return [geom]
    candidates = []
    for (ident,) in ids:
        row = db.execute("SELECT wkb FROM ways WHERE id=?", (ident,)).fetchone()
        if row:
            candidates.append(wkb.loads(row[0]))
    if not candidates:
        return [geom]
    nearby = unary_union(candidates)
    tol_deg = max(lat_tol, lon_tol)
    remainder = geom.difference(nearby.buffer(tol_deg))
    if remainder.is_empty:
        return []
    if remainder.geom_type == "LineString":
        return [remainder]
    if remainder.geom_type == "MultiLineString":
        return [g for g in remainder.geoms if not g.is_empty]
    if remainder.geom_type == "GeometryCollection":
        return [g for g in remainder.geoms if g.geom_type == "LineString" and not g.is_empty]
    return []


def iter_lines(geometry: dict[str, Any]) -> Iterable[list[list[float]]]:
    typ = geometry.get("type")
    coords = geometry.get("coordinates")
    if typ == "LineString" and isinstance(coords, list):
        yield coords
    elif typ == "MultiLineString" and isinstance(coords, list):
        for line in coords:
            if isinstance(line, list):
                yield line


def xml_tag(k: str, v: Any) -> str:
    return f'<tag k="{html.escape(str(k), quote=True)}" v="{html.escape(str(v), quote=True)}"/>'


def source_files(supplemental_dir: Path) -> list[Path]:
    manifest = supplemental_dir / "sources.json"
    if not manifest.is_file():
        return []
    data = json.loads(manifest.read_text(encoding="utf-8"))
    result: list[Path] = []
    for src in data.get("sources", []):
        sid = str(src.get("source_id", ""))
        if src.get("status") not in ("downloaded", "cached") or not src.get("routable_candidate"):
            continue
        if not sid.startswith(GRAPH_APPLY_SOURCE_PREFIXES):
            continue
        path = supplemental_dir / str(src.get("file", ""))
        if path.is_file():
            result.append(path)
    return result


def iter_source_features(path: Path):
    """Yield supplemental features without forcing large state inventories into RAM."""
    if path.suffix.lower() in {".geojsonl", ".jsonl", ".ndjson"}:
        with path.open("r", encoding="utf-8") as fh:
            for line_no, line in enumerate(fh, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    feature = json.loads(line)
                except Exception as exc:
                    raise RuntimeError(f"Invalid GeoJSONL feature in {path.name} line {line_no}") from exc
                if isinstance(feature, dict) and feature.get("type") == "Feature":
                    yield feature
        return
    data = json.loads(path.read_text(encoding="utf-8"))
    for feature in data.get("features", []):
        if isinstance(feature, dict):
            yield feature


def generate_supplement_osm(files: list[Path], db: sqlite3.Connection, output_xml: Path,
                            base_node_max: int, base_way_max: int,
                            log: Callable[[str], None]) -> dict[str, Any]:
    from shapely.geometry import LineString

    next_node_id = base_node_max + 1
    next_way_id = base_way_max + 1
    new_nodes: dict[tuple[int, int], tuple[int, float, float]] = {}
    ways: list[tuple[int, list[int], dict[str, str]]] = []
    by_source: dict[str, dict[str, int]] = {}

    def synthetic_node(lon: float, lat: float) -> int:
        nonlocal next_node_id
        key = (round(lon * 10_000_000), round(lat * 10_000_000))
        existing = new_nodes.get(key)
        if existing:
            return existing[0]
        ident = next_node_id
        next_node_id += 1
        new_nodes[key] = (ident, lon, lat)
        return ident

    for path in files:
        for feat in iter_source_features(path):
            p = feat.get("properties") or {}
            if not p.get("takrig_routable"):
                continue
            source = str(p.get("takrig_source") or "supplemental")
            stats = by_source.setdefault(source, {"seen": 0, "added": 0, "duplicate_skipped": 0})
            for coords in iter_lines(feat.get("geometry") or {}):
                stats["seen"] += 1
                clean: list[tuple[float, float]] = []
                for c in coords:
                    if not isinstance(c, (list, tuple)) or len(c) < 2:
                        continue
                    try:
                        lon = float(c[0]); lat = float(c[1])
                    except Exception:
                        continue
                    if not (-180 <= lon <= 180 and -90 <= lat <= 90):
                        continue
                    if not clean or abs(clean[-1][0]-lon) > 1e-10 or abs(clean[-1][1]-lat) > 1e-10:
                        clean.append((lon, lat))
                if len(clean) < 2:
                    continue
                geom = LineString(clean)
                role = str(p.get("takrig_routing_role") or "")
                # State DOT/public-road authority data is supplemental-only.  Clip
                # it against the Core OSM network and inject only genuinely missing
                # portions, preventing slightly-offset duplicate parallel roads.
                if role == "public_road_authority":
                    pieces = missing_parts_against_base(db, geom)
                    if not pieces:
                        stats["duplicate_skipped"] += 1
                        continue
                    stats.setdefault("partial_added", 0)
                else:
                    if mostly_covered_by_base(db, geom):
                        stats["duplicate_skipped"] += 1
                        continue
                    pieces = [geom]

                for piece in pieces:
                    piece_coords = [(float(x), float(y)) for x, y, *rest in piece.coords]
                    if len(piece_coords) < 2:
                        continue
                    # Ignore tiny geometry slivers produced only by the conflation buffer.
                    if meters_between(piece_coords[0][0], piece_coords[0][1], piece_coords[-1][0], piece_coords[-1][1]) < 8.0:
                        continue
                    refs: list[int] = []
                    for i, (lon, lat) in enumerate(piece_coords):
                        max_snap = 35.0 if i in (0, len(piece_coords)-1) else 8.0
                        ref = nearest_base_node(db, lon, lat, max_snap)
                        refs.append(ref if ref is not None else synthetic_node(lon, lat))
                    dedup = [refs[0]]
                    for ref in refs[1:]:
                        if ref != dedup[-1]:
                            dedup.append(ref)
                    if len(dedup) < 2:
                        continue
                    tags: dict[str, str] = {
                        "highway": str(p.get("takrig_highway") or "track"),
                        "motor_vehicle": "yes",
                        "source": str(p.get("takrig_source_name") or source),
                        "takrig:source": source,
                    }
                    if role == "public_road_authority":
                        tags["takrig:conflation"] = "core-missing-only"
                    name = str(p.get("takrig_name") or "").strip()
                    if name: tags["name"] = name
                    surface = str(p.get("takrig_surface") or "").strip()
                    if surface: tags["surface"] = surface
                    seasonal = str(p.get("takrig_seasonal") or "").strip()
                    if seasonal:
                        tags["seasonal"] = "yes"; tags["takrig:season"] = seasonal[:255]
                    if bool(p.get("takrig_high_clearance")): tags["4wd_only"] = "yes"
                    if bool(p.get("takrig_limited")): tags["access"] = "permissive"
                    ohv = str(p.get("takrig_ohv_designation") or "").strip()
                    if ohv: tags["takrig:ohv_designation"] = ohv[:255]
                    ways.append((next_way_id, dedup, tags))
                    next_way_id += 1
                    stats["added"] += 1
                    if role == "public_road_authority":
                        stats["partial_added"] += 1

    with output_xml.open("w", encoding="utf-8") as out:
        out.write('<?xml version="1.0" encoding="UTF-8"?>\n')
        out.write('<osm version="0.6" generator="takrig-navigation-data-manager-0.2.0-r16-r29">\n')
        for ident, lon, lat in sorted(new_nodes.values(), key=lambda r: r[0]):
            out.write(f'<node id="{ident}" lon="{lon:.8f}" lat="{lat:.8f}" version="1"/>\n')
        for ident, refs, tags in ways:
            out.write(f'<way id="{ident}" version="1">\n')
            for ref in refs:
                out.write(f'<nd ref="{ref}"/>\n')
            for k, v in tags.items():
                out.write(xml_tag(k, v) + "\n")
            out.write('</way>\n')
        out.write('</osm>\n')
    log(f"Generated supplemental OSM: {len(ways):,} ways, {len(new_nodes):,} new nodes")
    return {
        "ways_added": len(ways),
        "new_nodes": len(new_nodes),
        "synthetic_node_id_start": base_node_max + 1,
        "synthetic_way_id_start": base_way_max + 1,
        "sources": by_source,
    }


def apply_supplemental(base_pbf: Path, supplemental_dir: Path, output_pbf: Path,
                       work_dir: Path, log: Callable[[str], None] = log_default,
                       stage: Callable[[str, str], None] = stage_default) -> dict[str, Any]:
    # R4 could leave multi-gigabyte OPL/GeoJSON/SQLite intermediates behind after a
    # deterministic failure. R6 treats this directory as disposable scratch space.
    if work_dir.exists():
        shutil.rmtree(work_dir, ignore_errors=True)
    output_pbf.unlink(missing_ok=True)
    files = source_files(supplemental_dir)
    if not files:
        shutil.copy2(base_pbf, output_pbf)
        return {"applied": False, "reason": "no routable supplemental source files", "sources": {}}

    require_tools()
    work_dir.mkdir(parents=True, exist_ok=True)
    db: sqlite3.Connection | None = None
    succeeded = False
    try:
        db = create_db(work_dir / "base-index.sqlite")
        build_base_index(base_pbf, work_dir, db, log, stage)
        stage("enriching", "Allocating collision-free supplemental OSM IDs")
        max_node, max_way = base_max_ids(base_pbf, log)
        xml = work_dir / "supplement.osm"
        stage("enriching", "Conflating supplemental roads with OSM topology")
        result = generate_supplement_osm(files, db, xml, max_node, max_way, log)
        db.close(); db = None

        if result["ways_added"] <= 0:
            shutil.copy2(base_pbf, output_pbf)
            succeeded = True
            return {"applied": False, "reason": "all supplemental routes duplicated base topology", **result}

        pbf = work_dir / "supplement.osm.pbf"
        sorted_pbf = work_dir / "supplement-sorted.osm.pbf"
        stage("merging", "Encoding and sorting supplemental OSM")
        run(["osmium", "cat", str(xml), "-o", str(pbf), "--overwrite"], log)
        run(["osmium", "sort", str(pbf), "-o", str(sorted_pbf), "--overwrite"], log)
        stage("merging", "Merging supplemental routes into the state OSM graph input")
        run(["osmium", "merge", str(base_pbf), str(sorted_pbf), "-o", str(output_pbf), "--overwrite"], log)
        succeeded = True
        return {"applied": True, **result}
    finally:
        if db is not None:
            db.close()
        shutil.rmtree(work_dir, ignore_errors=True)
        log("Cleaned disposable enrichment workspace")
        if not succeeded:
            output_pbf.unlink(missing_ok=True)
