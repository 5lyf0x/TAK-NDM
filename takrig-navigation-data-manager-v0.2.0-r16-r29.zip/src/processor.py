#!/usr/bin/env python3
from __future__ import annotations

import argparse
import contextlib
import dataclasses
import datetime as dt
import fcntl
import hashlib
import io
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import tarfile
import tempfile
import time
import uuid
import zipfile
from pathlib import Path
from typing import Any, Iterable

import job_control
from coverage import COVERAGE_SCHEMA, COVERAGE_ZOOM, build_routing_coverage

VERSION = "0.2.0-r16-r29"
VALHALLA_VERSION = "3.6.3"
PACKAGE_FORMAT = "takrig.valhalla.region.v1"
CATALOG_SCHEMA = "takrig.routing.catalog.v1"
REQUIRED_PACKAGE_FILES = ("manifest.json", "valhalla.json", "valhalla_tiles.tar", "routing_coverage/index.json")

DEFAULT_CONFIG: dict[str, Any] = {
    "state_root": "/var/lib/takrig-routing",
    "log_root": "/var/log/takrig-routing",
    "venv_root": "/usr/local/lib/takrig-routing/venv",
    "valhalla_version": VALHALLA_VERSION,
    "package_format": PACKAGE_FORMAT,
    "settle_seconds": 20,
    "jobs_per_scan": 1,
    "keep_source_after_success": False,
    "required_free_multiplier": 6.0,
    "required_free_min_gib": 30.0,
}


def utcnow() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug or "region"


def human_bytes(value: int) -> str:
    n = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if n < 1024.0 or unit == "TiB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024.0
    return f"{value} B"


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp-{os.getpid()}-{uuid.uuid4().hex[:6]}")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def write_json(path: Path, data: dict[str, Any]) -> None:
    atomic_write_text(path, json.dumps(data, indent=2, sort_keys=False) + "\n")


def read_json(path: Path, default: Any = None) -> Any:
    if not path.is_file():
        return default
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def sha256_file(path: Path, chunk: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            data = f.read(chunk)
            if not data:
                break
            h.update(data)
    return h.hexdigest()


def directory_size(path: Path) -> int:
    total = 0
    if not path.exists():
        return 0
    for p in path.rglob("*"):
        if p.is_file():
            with contextlib.suppress(OSError):
                total += p.stat().st_size
    return total


@dataclasses.dataclass(frozen=True)
class Config:
    path: Path
    data: dict[str, Any]

    @classmethod
    def load(cls, path: Path) -> "Config":
        data = dict(DEFAULT_CONFIG)
        if path.is_file():
            loaded = read_json(path, {})
            if not isinstance(loaded, dict):
                raise ValueError(f"Configuration must be a JSON object: {path}")
            data.update(loaded)
        # R7 safety policy: graph compilation is intentionally serialized.
        data["jobs_per_scan"] = 1
        if float(data.get("required_free_min_gib", 30.0)) < 30.0:
            data["required_free_min_gib"] = 30.0
        if data.get("valhalla_version") != VALHALLA_VERSION:
            raise ValueError(
                f"This processor is pinned to Valhalla {VALHALLA_VERSION}; config requests {data.get('valhalla_version')}"
            )
        if data.get("package_format") != PACKAGE_FORMAT:
            raise ValueError(
                f"This processor emits {PACKAGE_FORMAT}; config requests {data.get('package_format')}"
            )
        return cls(path=path, data=data)

    def p(self, key: str) -> Path:
        return Path(str(self.data[key])).expanduser().resolve()

    @property
    def state_root(self) -> Path:
        return self.p("state_root")

    @property
    def log_root(self) -> Path:
        return self.p("log_root")

    @property
    def venv_root(self) -> Path:
        return self.p("venv_root")

    @property
    def incoming(self) -> Path:
        return self.state_root / "incoming"

    @property
    def processing(self) -> Path:
        return self.state_root / "processing"

    @property
    def ready(self) -> Path:
        return self.state_root / "ready"

    @property
    def failed(self) -> Path:
        return self.state_root / "failed"

    @property
    def history(self) -> Path:
        return self.state_root / "history"

    @property
    def archive(self) -> Path:
        return self.state_root / "archive"

    def ensure_dirs(self) -> None:
        for p in (
            self.state_root,
            self.log_root,
            self.incoming,
            self.processing,
            self.ready,
            self.failed,
            self.history,
            self.archive,
        ):
            p.mkdir(parents=True, exist_ok=True)


@dataclasses.dataclass(frozen=True)
class Toolchain:
    python: Path
    package_dir: Path
    build_tiles: Path
    build_config: Path

    @classmethod
    def from_config(cls, cfg: Config) -> "Toolchain":
        python = cfg.venv_root / "bin" / "python"
        if not python.is_file():
            raise RuntimeError(f"Valhalla toolchain is incomplete: {python}")
        package_override = cfg.data.get("valhalla_package_dir")
        if package_override:
            package_dir = Path(str(package_override)).expanduser().resolve()
        else:
            proc = subprocess.run(
                [str(python), "-c",
                 "import pathlib,valhalla; print(pathlib.Path(valhalla.__file__).resolve().parent)"],
                check=True, capture_output=True, text=True,
            )
            package_dir = Path(proc.stdout.strip())
        return cls(
            python=python,
            package_dir=package_dir,
            build_tiles=package_dir / "bin" / "valhalla_build_tiles",
            build_config=package_dir / "valhalla_build_config.py",
        )

    def validate(self) -> None:
        if not self.python.is_file():
            raise RuntimeError(f"Valhalla toolchain is incomplete: {self.python}")
        if not self.build_tiles.is_file() or not os.access(self.build_tiles, os.X_OK):
            raise RuntimeError(f"Valhalla tile builder is unavailable: {self.build_tiles}")
        if not self.build_config.is_file():
            raise RuntimeError(f"Valhalla config generator is unavailable: {self.build_config}")


class JobLogger:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = self.path.open("a", encoding="utf-8", buffering=1)

    def close(self) -> None:
        self._fh.close()

    def log(self, msg: str) -> None:
        line = f"[{utcnow()}] {msg}"
        print(line, flush=True)
        self._fh.write(line + "\n")

    def run(self, cmd: list[str], cwd: Path | None = None) -> None:
        self.log("RUN " + " ".join(cmd))
        proc = subprocess.Popen(
            cmd,
            cwd=str(cwd) if cwd else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            line = line.rstrip("\n")
            print(line, flush=True)
            self._fh.write(line + "\n")
        rc = proc.wait()
        if rc != 0:
            raise RuntimeError(f"Command failed with exit code {rc}: {' '.join(cmd)}")

    def capture(self, cmd: list[str], cwd: Path | None = None) -> str:
        self.log("RUN " + " ".join(cmd))
        proc = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        if proc.stderr:
            self._fh.write(proc.stderr)
            if not proc.stderr.endswith("\n"):
                self._fh.write("\n")
        if proc.returncode != 0:
            raise RuntimeError(
                f"Command failed with exit code {proc.returncode}: {' '.join(cmd)}\n{proc.stderr.strip()}"
            )
        return proc.stdout


@contextlib.contextmanager
def global_lock(cfg: Config):
    cfg.ensure_dirs()
    lock_path = cfg.state_root / "processor.lock"
    with lock_path.open("a+") as fh:
        try:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("Another TAK Rig routing build is already active")
        try:
            yield
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def normalize_metadata(meta: dict[str, Any], pbf_name: str) -> dict[str, Any]:
    base = pbf_name
    for suffix in (".osm.pbf", ".pbf"):
        if base.lower().endswith(suffix):
            base = base[: -len(suffix)]
            break
    inferred = re.sub(r"[-_]+", " ", base).strip().title() or "Routing Region"
    name = str(meta.get("name") or inferred).strip()
    region_id = slugify(str(meta.get("region_id") or name))
    source_url = str(meta.get("source_url") or "").strip()
    expected = str(meta.get("expected_sha256") or "").strip().lower()
    if expected and not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError("expected_sha256 must be a 64-character hexadecimal SHA-256")
    out = dict(meta)
    out.update({
        "name": name,
        "region_id": region_id,
        "source_url": source_url,
        "expected_sha256": expected,
    })
    return out


def load_sidecar(pbf: Path) -> dict[str, Any]:
    sidecar = Path(str(pbf) + ".json")
    data = read_json(sidecar, {})
    if data is None:
        data = {}
    if not isinstance(data, dict):
        raise ValueError(f"Sidecar must contain a JSON object: {sidecar}")
    return normalize_metadata(data, pbf.name)


def pbf_is_settled(pbf: Path, settle_seconds: int) -> bool:
    try:
        age = time.time() - pbf.stat().st_mtime
    except FileNotFoundError:
        return False
    return age >= settle_seconds and pbf.stat().st_size > 0


def new_job_id(region_id: str) -> str:
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{stamp}-{slugify(region_id)}-{uuid.uuid4().hex[:6]}"


def update_job(job_file: Path, **changes: Any) -> dict[str, Any]:
    data = read_json(job_file, {}) or {}
    previous_state = str(data.get("state") or "")
    now = utcnow()
    data.update(changes)
    data["updated_utc"] = now
    if "state" in changes and str(changes.get("state") or "") != previous_state:
        data["stage_started_utc"] = now
    write_json(job_file, data)
    return data


def claim_incoming(cfg: Config, pbf: Path) -> Path:
    meta = load_sidecar(pbf)
    job_id = new_job_id(meta["region_id"])
    job_dir = cfg.processing / job_id
    job_dir.mkdir(parents=True, exist_ok=False)
    dst = job_dir / "source.osm.pbf"
    sidecar = Path(str(pbf) + ".json")
    try:
        os.replace(pbf, dst)
        if sidecar.is_file():
            os.replace(sidecar, job_dir / "source.osm.pbf.json")
        job = {
            "job_id": job_id,
            "state": "claimed",
            "created_utc": utcnow(),
            "updated_utc": utcnow(),
            "original_filename": pbf.name,
            "source_path": str(dst),
            **meta,
        }
        write_json(job_dir / "job.json", job)
        return job_dir
    except Exception:
        if dst.exists() and not pbf.exists():
            os.replace(dst, pbf)
        if (job_dir / "source.osm.pbf.json").exists() and not sidecar.exists():
            os.replace(job_dir / "source.osm.pbf.json", sidecar)
        shutil.rmtree(job_dir, ignore_errors=True)
        raise


def resume_jobs(cfg: Config) -> list[Path]:
    jobs = []
    for d in sorted(cfg.processing.iterdir() if cfg.processing.exists() else []):
        if d.is_dir() and (d / "source.osm.pbf").is_file() and (d / "job.json").is_file():
            row = read_json(d / "job.json", {}) or {}
            code = str(row.get("state_code") or row.get("region_id") or "").upper()
            if len(code) == 2 and job_control.requested(cfg.path,"navigation",code):
                continue
            jobs.append(d)
    return jobs


def check_disk(cfg: Config, source_size: int) -> tuple[int, int]:
    usage = shutil.disk_usage(cfg.state_root)
    required = int(max(
        float(cfg.data.get("required_free_min_gib", 8.0)) * 1024**3,
        source_size * float(cfg.data.get("required_free_multiplier", 6.0)),
    ))
    if usage.free < required:
        raise RuntimeError(
            f"Insufficient free disk space: {human_bytes(usage.free)} free; "
            f"at least {human_bytes(required)} required for this {human_bytes(source_size)} PBF"
        )
    return usage.free, required


def _valhalla_config_363(tile_dir: Path, tile_extract: Path) -> dict[str, Any]:
    """Return Valhalla 3.6.3-compatible defaults with TAK Rig paths.

    Valhalla 3.6.3's pyvalhalla wheel ships the native C++ executables, but the
    Python build/config helpers were not packaged until Valhalla 3.7.0.  Keep
    the mobile-compatible 3.6.3 graph format and generate the 3.6.3 config
    directly from that release's valhalla_build_config defaults.

    Optional keys from the upstream generator are intentionally omitted, which
    is exactly how valhalla_build_config serializes them when no CLI override is
    supplied.
    """
    log = {"type": "std_out", "color": True, "file_name": "path_to_some_file.log"}
    return {
        "mjolnir": {
            "max_cache_size": 1000000000,
            "id_table_size": 1300000000,
            "use_lru_mem_cache": False,
            "lru_mem_cache_hard_control": False,
            "use_simple_mem_cache": False,
            "tile_dir": str(tile_dir),
            "tile_extract": str(tile_extract),
            "traffic_extract": str(tile_dir.parent / "traffic.tar"),
            "admin": str(tile_dir.parent / "admin.sqlite"),
            "landmarks": str(tile_dir.parent / "landmarks.sqlite"),
            "timezone": str(tile_dir.parent / "tz_world.sqlite"),
            "transit_dir": str(tile_dir.parent / "transit"),
            "transit_feeds_dir": str(tile_dir.parent / "transit_feeds"),
            "transit_pbf_limit": 20000,
            "hierarchy": True,
            "shortcuts": True,
            "keep_all_osm_node_ids": False,
            "keep_osm_node_ids": False,
            "include_platforms": False,
            "include_driveways": True,
            "include_construction": False,
            "include_bicycle": True,
            "include_pedestrian": True,
            "include_driving": True,
            "import_bike_share_stations": False,
            "global_synchronized_cache": False,
            "max_concurrent_reader_users": 1,
            "reclassify_links": True,
            "data_processing": {
                "infer_internal_intersections": True,
                "infer_turn_channels": True,
                "apply_country_overrides": True,
                "grid_divisions_within_tile": 32,
                "use_admin_db": True,
                "use_direction_on_ways": False,
                "allow_alt_name": False,
                "use_urban_tag": False,
                "use_rest_area": False,
                "scan_tar": False,
            },
            "logging": dict(log),
        },
        "additional_data": {"elevation": str(tile_dir.parent / "elevation") + "/"},
        "loki": {
            "actions": [
                "locate", "route", "height", "sources_to_targets", "optimized_route",
                "isochrone", "trace_route", "trace_attributes", "transit_available",
                "expansion", "centroid", "status", "tile",
            ],
            "use_connectivity": True,
            "service_defaults": {
                "radius": 0,
                "minimum_reachability": 50,
                "search_cutoff": 35000,
                "node_snap_tolerance": 5,
                "street_side_tolerance": 5,
                "street_side_max_distance": 1000,
                "heading_tolerance": 60,
                "mvt_min_zoom_road_class": [7, 7, 8, 11, 11, 12, 13, 14],
                "mvt_cache_min_zoom": 11,
            },
            "logging": {**log, "long_request": 100.0},
            "service": {"proxy": "ipc:///tmp/loki"},
        },
        "thor": {
            "logging": {**log, "long_request": 110.0},
            "source_to_target_algorithm": "select_optimal",
            "service": {"proxy": "ipc:///tmp/thor"},
            "max_reserved_labels_count_astar": 2000000,
            "max_reserved_labels_count_bidir_astar": 1000000,
            "max_reserved_labels_count_dijkstras": 4000000,
            "max_reserved_labels_count_bidir_dijkstras": 2000000,
            "clear_reserved_memory": False,
            "extended_search": False,
            "costmatrix": {
                "check_reverse_connection": True,
                "allow_second_pass": False,
                "max_reserved_locations": 25,
                "max_iterations": 2800,
                "min_iterations": 100,
                "hierarchy_limits": {
                    "max_up_transitions": {"1": 400, "2": 100},
                    "expand_within_distance": {"0": 1e8, "1": 20000, "2": 5000},
                },
            },
            "bidirectional_astar": {
                "threshold_delta": 420.0,
                "alternative_cost_extend": 1.2,
                "alternative_iterations_delta": 100000,
                "hierarchy_limits": {
                    "max_up_transitions": {"1": 400, "2": 100},
                    "expand_within_distance": {"0": 1e8, "1": 20000, "2": 5000},
                },
            },
            "unidirectional_astar": {
                "hierarchy_limits": {
                    "max_up_transitions": {"1": 400, "2": 100},
                    "expand_within_distance": {"0": 1e8, "1": 100000, "2": 5000},
                }
            },
        },
        "odin": {
            "logging": dict(log),
            "service": {"proxy": "ipc:///tmp/odin"},
            "markup_formatter": {
                "markup_enabled": False,
                "phoneme_format": "<TEXTUAL_STRING> (<span class=<QUOTES>phoneme<QUOTES>>/<VERBAL_STRING>/</span>)",
            },
        },
        "meili": {
            "mode": "auto",
            "customizable": [
                "mode", "search_radius", "turn_penalty_factor", "gps_accuracy",
                "interpolation_distance", "sigma_z", "beta", "max_route_distance_factor",
                "max_route_time_factor",
            ],
            "verbose": False,
            "default": {
                "sigma_z": 4.07, "gps_accuracy": 5.0, "beta": 3,
                "max_route_distance_factor": 5, "max_route_time_factor": 5,
                "max_search_radius": 100, "breakage_distance": 2000,
                "interpolation_distance": 10, "search_radius": 50,
                "geometry": False, "route": True, "turn_penalty_factor": 0,
            },
            "auto": {"turn_penalty_factor": 200, "search_radius": 50},
            "pedestrian": {"turn_penalty_factor": 100, "search_radius": 50},
            "bicycle": {"turn_penalty_factor": 140},
            "multimodal": {"turn_penalty_factor": 70},
            "logging": dict(log),
            "service": {"proxy": "ipc:///tmp/meili"},
            "grid": {"size": 500, "cache_size": 100240},
        },
        "httpd": {
            "service": {
                "listen": "tcp://*:8002",
                "loopback": "ipc:///tmp/loopback",
                "interrupt": "ipc:///tmp/interrupt",
                "drain_seconds": 28,
                "shutdown_seconds": 1,
                "timeout_seconds": -1,
            }
        },
        "service_limits": {
            "auto": {"max_distance": 5000000.0, "max_locations": 20, "max_matrix_distance": 400000.0, "max_matrix_location_pairs": 2500},
            "bus": {"max_distance": 5000000.0, "max_locations": 50, "max_matrix_distance": 400000.0, "max_matrix_location_pairs": 2500},
            "taxi": {"max_distance": 5000000.0, "max_locations": 20, "max_matrix_distance": 400000.0, "max_matrix_location_pairs": 2500},
            "pedestrian": {"max_distance": 250000.0, "max_locations": 50, "max_matrix_distance": 200000.0, "max_matrix_location_pairs": 2500, "min_transit_walking_distance": 1, "max_transit_walking_distance": 10000},
            "motor_scooter": {"max_distance": 500000.0, "max_locations": 50, "max_matrix_distance": 200000.0, "max_matrix_location_pairs": 2500},
            "motorcycle": {"max_distance": 500000.0, "max_locations": 50, "max_matrix_distance": 200000.0, "max_matrix_location_pairs": 2500},
            "bicycle": {"max_distance": 500000.0, "max_locations": 50, "max_matrix_distance": 200000.0, "max_matrix_location_pairs": 2500},
            "multimodal": {"max_distance": 500000.0, "max_locations": 50, "max_matrix_distance": 0.0, "max_matrix_location_pairs": 0},
            "status": {"allow_verbose": False},
            "transit": {"max_distance": 500000.0, "max_locations": 50, "max_matrix_distance": 200000.0, "max_matrix_location_pairs": 2500},
            "truck": {"max_distance": 5000000.0, "max_locations": 20, "max_matrix_distance": 400000.0, "max_matrix_location_pairs": 2500},
            "skadi": {"max_shape": 750000, "min_resample": 10.0},
            "isochrone": {"max_contours": 4, "max_time_contour": 120, "max_distance": 25000.0, "max_locations": 1, "max_distance_contour": 200},
            "trace": {"max_distance": 200000.0, "max_gps_accuracy": 100.0, "max_search_radius": 100.0, "max_shape": 16000, "max_alternates": 3, "max_alternates_shape": 100},
            "bikeshare": {"max_distance": 500000.0, "max_locations": 50, "max_matrix_distance": 200000.0, "max_matrix_location_pairs": 2500},
            "centroid": {"max_distance": 200000.0, "max_locations": 5},
            "max_exclude_locations": 50,
            "max_reachability": 100,
            "max_radius": 200,
            "max_timedep_distance": 500000,
            "max_timedep_distance_matrix": 0,
            "max_alternates": 2,
            "max_exclude_polygons_length": 10000,
            "min_linear_cost_factor": 1,
            "max_linear_cost_edges": 50000,
            "max_distance_disable_hierarchy_culling": 0,
            "hierarchy_limits": {
                "allow_modification": False,
                "costmatrix": {"max_allowed_up_transitions": {"1": 400, "2": 100}, "max_expand_within_distance": {"0": 1e8, "1": 100000, "2": 5000}},
                "unidirectional_astar": {"max_allowed_up_transitions": {"1": 400, "2": 100}, "max_expand_within_distance": {"0": 1e8, "1": 100000, "2": 5000}},
                "bidirectional_astar": {"max_allowed_up_transitions": {"1": 400, "2": 100}, "max_expand_within_distance": {"0": 1e8, "1": 20000, "2": 5000}},
            },
            "allow_hard_exclusions": False,
        },
        "statsd": {"port": 8125, "prefix": "valhalla"},
    }


def generate_config(tool: Toolchain, work: Path, logger: JobLogger) -> Path:
    """Generate valhalla.json with the config generator shipped by pyvalhalla 3.6.3."""
    tile_dir = work / "valhalla_tiles"
    tile_extract = work / "valhalla_tiles.tar"
    cfg_path = work / "valhalla.json"
    tile_dir.mkdir(parents=True, exist_ok=True)
    logger.run([
        str(tool.python), str(tool.build_config),
        "--mjolnir-tile-dir", str(tile_dir),
        "--mjolnir-tile-extract", str(tile_extract),
        "-o", str(cfg_path),
    ])
    if not cfg_path.is_file() or cfg_path.stat().st_size == 0:
        raise RuntimeError("Valhalla config generator did not create valhalla.json")
    parsed = json.loads(cfg_path.read_text(encoding="utf-8"))
    if parsed.get("mjolnir", {}).get("tile_dir") != str(tile_dir):
        raise RuntimeError("Generated Valhalla config has unexpected mjolnir.tile_dir")
    if parsed.get("mjolnir", {}).get("tile_extract") != str(tile_extract):
        raise RuntimeError("Generated Valhalla config has unexpected mjolnir.tile_extract")

    # R9 NAV COVERAGE uses Valhalla's graph-backed /tile action.  Verbose edge
    # attributes expose directional automobile access, use and surface.  Allow
    # every road class to appear at the fixed coverage zoom so forest/NPS tracks
    # and service roads are not hidden by the normal low-zoom MVT class filter.
    parsed.setdefault("service_limits", {}).setdefault("status", {})["allow_verbose"] = True
    parsed.setdefault("loki", {}).setdefault("service_defaults", {})["mvt_min_zoom_road_class"] = [
        7, 7, 8, COVERAGE_ZOOM, COVERAGE_ZOOM, COVERAGE_ZOOM, COVERAGE_ZOOM, COVERAGE_ZOOM
    ]
    write_json(cfg_path, parsed)
    logger.log(
        "Generated Valhalla 3.6.3 config with graph-MVT NAV coverage attributes enabled "
        f"at z{COVERAGE_ZOOM}"
    )
    return cfg_path

def _graph_tile_id(relative_name: str) -> int:
    """Return the packed Valhalla GraphId used by extract index.bin."""
    if not relative_name.endswith(".gph"):
        raise ValueError(f"Not a Valhalla graph tile: {relative_name}")
    stem = relative_name[:-4]
    level_text, sep, index_text = stem.partition("/")
    if not sep:
        raise ValueError(f"Unexpected Valhalla tile path: {relative_name}")
    level = int(level_text)
    tile_index = int(index_text.replace("/", ""))
    return level | (tile_index << 3)


def build_indexed_extract(tile_dir: Path, tile_extract: Path, logger: JobLogger) -> None:
    """Create the indexed tar layout Valhalla expects for tile_extract.

    The index uses Valhalla's stable <QLL record layout: data offset, packed
    GraphId, and tile byte size.  index.bin is the first tar member so its data
    begins at the first 512-byte tar data block.
    """
    tiles = sorted(
        (p for p in tile_dir.rglob("*.gph") if p.is_file()),
        key=lambda p: p.relative_to(tile_dir).as_posix(),
    )
    if not tiles:
        raise RuntimeError(f"Valhalla produced no .gph graph tiles in {tile_dir}")

    record_fmt = "<QLL"
    record_size = struct.calcsize(record_fmt)
    index_size = record_size * len(tiles)
    tmp = tile_extract.with_name(tile_extract.name + f".tmp-{os.getpid()}")
    if tmp.exists():
        tmp.unlink()
    tile_extract.parent.mkdir(parents=True, exist_ok=True)

    with tarfile.open(tmp, "w") as tar:
        info = tarfile.TarInfo("index.bin")
        info.size = index_size
        info.mtime = int(time.time())
        tar.addfile(info, io.BytesIO(b"\x00" * index_size))
        for tile in tiles:
            rel = tile.relative_to(tile_dir).as_posix()
            tar.add(tile, arcname=rel, recursive=False)

    index_rows: list[tuple[int, int, int]] = []
    with tarfile.open(tmp, "r") as tar:
        for member in tar.getmembers():
            if not member.isfile() or not member.name.endswith(".gph"):
                continue
            index_rows.append((member.offset_data, _graph_tile_id(member.name), member.size))

    if len(index_rows) != len(tiles):
        tmp.unlink(missing_ok=True)
        raise RuntimeError("Indexed tile extract did not contain every generated graph tile")

    with tmp.open("r+b") as fh:
        fh.seek(tarfile.BLOCKSIZE)
        for row in index_rows:
            fh.write(struct.pack(record_fmt, *row))

    os.replace(tmp, tile_extract)
    logger.log(f"Indexed {len(index_rows)} Valhalla graph tiles into {tile_extract.name}")


def source_bounds(path: Path) -> list[float]:
    """Read a PBF bounding box with osmium-tool for manual processor enqueue jobs."""
    proc = subprocess.run(
        ["osmium", "fileinfo", "-e", "-g", "data.bbox", str(path)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=120, check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            "NAV coverage requires geographic bounds and osmium-tool could not inspect the PBF: "
            + (proc.stderr.strip() or "fileinfo failed")
        )
    nums = [float(x) for x in re.findall(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", proc.stdout)]
    if len(nums) < 4:
        raise RuntimeError("NAV coverage could not determine a geographic bounding box for the PBF")
    bounds = nums[-4:]
    min_lon, min_lat, max_lon, max_lat = bounds
    if not (-180 <= min_lon <= max_lon <= 180 and -90 <= min_lat <= max_lat <= 90):
        raise RuntimeError(f"OSM PBF reported invalid geographic bounds: {bounds}")
    return bounds


def coverage_manifest_summary(index: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema": COVERAGE_SCHEMA,
        "index": "routing_coverage/index.json",
        "zoom": int(index.get("zoom") or COVERAGE_ZOOM),
        "tile_format": "geojson.gz",
        "classes": ["road", "offroad"],
        "nonempty_tile_count": int(index.get("nonempty_tile_count") or 0),
        "feature_count": int(index.get("feature_count") or 0),
        "road_feature_count": int(index.get("road_feature_count") or 0),
        "offroad_feature_count": int(index.get("offroad_feature_count") or 0),
        "vehicle_access": "Valhalla automobile-accessible graph edges; impassable and destination-only/private edges excluded",
    }


def package_manifest(
    job: dict[str, Any], source_hash: str, source_size: int, coverage_index: dict[str, Any]
) -> dict[str, Any]:
    source_pbf = job.get("source_url") or job.get("original_filename") or "source.osm.pbf"
    created = utcnow()
    manifest: dict[str, Any] = {
        "format": PACKAGE_FORMAT,
        "name": job["name"],
        "region_id": job["region_id"],
        "valhalla_version": VALHALLA_VERSION,
        "created_utc": created,
        "package_revision": created,
        "source_pbf": source_pbf,
        "source_pbf_size_bytes": source_size,
        "routing_coverage": coverage_manifest_summary(coverage_index),
        "notes": "TAK Rig local routing graph with graph-derived tiled NAV coverage. Installed separately from the raster map cache.",
    }
    if job.get("bounds") is not None:
        manifest["bounds"] = job["bounds"]
    if job.get("source_updated_utc"):
        manifest["source_updated_utc"] = job["source_updated_utc"]
    for key in ("state_code", "source_composition", "source_revisions", "source_fingerprint", "build_fingerprint", "manager_version"):
        if job.get(key) not in (None, "", []):
            manifest[key] = job[key]
    return manifest


def build_zip(
    package: Path, manifest_path: Path, config_path: Path, tile_extract: Path, coverage_dir: Path
) -> None:
    package.parent.mkdir(parents=True, exist_ok=True)
    tmp = package.with_name(package.name + f".tmp-{os.getpid()}")
    if tmp.exists():
        tmp.unlink()
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as zf:
        zf.write(manifest_path, "manifest.json")
        zf.write(config_path, "valhalla.json")
        zf.write(tile_extract, "valhalla_tiles.tar")
        for path in sorted(p for p in coverage_dir.rglob("*") if p.is_file()):
            rel = path.relative_to(coverage_dir).as_posix()
            zf.write(path, f"routing_coverage/{rel}")
    os.replace(tmp, package)


def verify_package(package: Path) -> dict[str, Any]:
    if not package.is_file():
        raise FileNotFoundError(package)
    with zipfile.ZipFile(package, "r", allowZip64=True) as zf:
        names = zf.namelist()
        name_set = set(names)
        for name in names:
            p = Path(name)
            if p.is_absolute() or ".." in p.parts:
                raise RuntimeError(f"Unsafe ZIP entry: {name}")
        missing = [name for name in REQUIRED_PACKAGE_FILES if name not in name_set]
        if missing:
            raise RuntimeError("Routing package is missing: " + ", ".join(missing))
        if zf.getinfo("valhalla_tiles.tar").file_size <= 0:
            raise RuntimeError("valhalla_tiles.tar is empty")
        manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
        config = json.loads(zf.read("valhalla.json").decode("utf-8"))
        coverage = json.loads(zf.read("routing_coverage/index.json").decode("utf-8"))
        if coverage.get("schema") != COVERAGE_SCHEMA:
            raise RuntimeError(f"NAV coverage schema is {coverage.get('schema')!r}, expected {COVERAGE_SCHEMA!r}")
        tiles = coverage.get("tiles")
        if not isinstance(tiles, list) or not tiles:
            raise RuntimeError("NAV coverage index contains no non-empty tiles")
        counted = 0
        import gzip
        for item in tiles:
            rel = Path(str(item.get("path") or ""))
            if rel.is_absolute() or ".." in rel.parts:
                raise RuntimeError(f"Unsafe NAV coverage path: {rel}")
            arc = f"routing_coverage/{rel.as_posix()}"
            if arc not in name_set:
                raise RuntimeError(f"Routing package is missing indexed NAV coverage tile: {arc}")
            try:
                data = json.loads(gzip.decompress(zf.read(arc)).decode("utf-8"))
            except Exception as exc:
                raise RuntimeError(f"NAV coverage tile is invalid: {arc}: {exc}") from exc
            features = data.get("features") or []
            if data.get("type") != "FeatureCollection" or not isinstance(features, list) or not features:
                raise RuntimeError(f"NAV coverage tile is malformed/empty: {arc}")
            counted += len(features)
        expected_features = int(coverage.get("feature_count") or 0)
        if counted != expected_features:
            raise RuntimeError(
                f"NAV coverage feature count mismatch: index={expected_features}, packaged={counted}"
            )
    if manifest.get("format") != PACKAGE_FORMAT:
        raise RuntimeError(f"Package format is {manifest.get('format')!r}, expected {PACKAGE_FORMAT!r}")
    version = str(manifest.get("valhalla_version", ""))
    if not version.startswith(VALHALLA_VERSION):
        raise RuntimeError(f"Valhalla version is {version!r}, expected {VALHALLA_VERSION}")
    if not isinstance(config, dict) or not isinstance(config.get("mjolnir"), dict):
        raise RuntimeError("valhalla.json is missing the mjolnir object")
    if (manifest.get("routing_coverage") or {}).get("schema") != COVERAGE_SCHEMA:
        raise RuntimeError("manifest.json does not advertise the packaged NAV coverage schema")
    return {
        "ok": True,
        "format": manifest["format"],
        "name": manifest.get("name", ""),
        "region_id": manifest.get("region_id", ""),
        "valhalla_version": version,
        "size_bytes": package.stat().st_size,
        "routing_coverage": coverage_manifest_summary(coverage),
    }


def package_descriptor(package: Path, verify: dict[str, Any], manifest: dict[str, Any], job: dict[str, Any]) -> dict[str, Any]:
    revision = str(manifest.get("package_revision") or manifest.get("created_utc") or utcnow())
    return {
        "schema": "takrig.routing.package.v1",
        "region_id": job["region_id"],
        "name": job["name"],
        "package": package.name,
        "revision": revision,
        "size_bytes": verify["size_bytes"],
        "valhalla_version": VALHALLA_VERSION,
        "format": PACKAGE_FORMAT,
        "created_utc": manifest["created_utc"],
        "source_pbf": manifest["source_pbf"],
        "source_pbf_size_bytes": manifest["source_pbf_size_bytes"],
        "routing_coverage": manifest["routing_coverage"],
        **({"bounds": manifest["bounds"]} if "bounds" in manifest else {}),
        **({"state_code": manifest["state_code"]} if "state_code" in manifest else {}),
        **({"source_composition": manifest["source_composition"]} if "source_composition" in manifest else {}),
        **({"source_revisions": manifest["source_revisions"]} if "source_revisions" in manifest else {}),
        **({"source_fingerprint": manifest["source_fingerprint"]} if "source_fingerprint" in manifest else {}),
        **({"build_fingerprint": manifest["build_fingerprint"]} if "build_fingerprint" in manifest else {}),
        **({"manager_version": manifest["manager_version"]} if "manager_version" in manifest else {}),
    }


def rebuild_catalog(cfg: Config) -> dict[str, Any]:
    cfg.ensure_dirs()
    packages: list[dict[str, Any]] = []
    for desc_path in sorted(cfg.ready.glob("*.zip.json")):
        try:
            desc = read_json(desc_path, {})
            package = cfg.ready / str(desc.get("package", ""))
            if not package.is_file():
                continue
            # R8 removes routing-package SHA-256 metadata. Migrate existing ready descriptors in
            # place without rebuilding the multi-gigabyte graph ZIP.
            changed = False
            for key in ("sha256", "sha256_file", "source_pbf_sha256"):
                if key in desc:
                    desc.pop(key, None); changed = True
            revision = str(desc.get("created_utc") or desc.get("revision") or "")
            if desc.get("revision") != revision:
                desc["revision"] = revision; changed = True
            if changed:
                write_json(desc_path, desc)
            packages.append(desc)
        except Exception:
            continue
    for legacy_hash in cfg.ready.glob("*.zip.sha256"):
        legacy_hash.unlink(missing_ok=True)
    packages.sort(key=lambda x: (str(x.get("name", "")).lower(), str(x.get("created_utc", ""))))
    catalog = {
        "schema": CATALOG_SCHEMA,
        "generated_utc": utcnow(),
        "package_format": PACKAGE_FORMAT,
        "valhalla_version": VALHALLA_VERSION,
        "packages": packages,
    }
    write_json(cfg.ready / "catalog.json", catalog)
    return catalog


def move_failed(cfg: Config, job_dir: Path, error: Exception, logger: JobLogger | None = None) -> Path:
    job_file = job_dir / "job.json"
    update_job(job_file, state="failed", failed_utc=utcnow(), error=str(error))
    target = cfg.failed / job_dir.name
    if target.exists():
        shutil.rmtree(target)
    if logger:
        logger.log(f"FAILED: {error}")
        logger.close()
    os.replace(job_dir, target)
    return target


def process_job(cfg: Config, job_dir: Path) -> dict[str, Any]:
    tool = Toolchain.from_config(cfg)
    tool.validate()
    job_file = job_dir / "job.json"
    source = job_dir / "source.osm.pbf"
    if not source.is_file():
        raise RuntimeError("Job source.osm.pbf is missing")
    job = read_json(job_file, {}) or {}
    job = normalize_metadata(job, job.get("original_filename") or source.name)
    code = str(job.get("state_code") or job.get("region_id") or "").upper()
    if len(code)==2 and code.isalpha():
        job_control.checkpoint(cfg.path,"navigation",code)
    write_json(job_file, job)

    log_path = job_dir / "build.log"
    logger = JobLogger(log_path)
    start = time.monotonic()
    try:
        logger.log(f"TAK Rig routing processor v{VERSION}")
        logger.log(f"Region: {job['name']} ({job['region_id']})")
        logger.log(f"Source: {source} ({human_bytes(source.stat().st_size)})")
        source_size = source.stat().st_size
        if source_size < 1024:
            raise RuntimeError("PBF source is unexpectedly small (< 1 KiB)")
        free, required = check_disk(cfg, source_size)
        logger.log(f"Disk preflight: {human_bytes(free)} free; {human_bytes(required)} required")

        if len(code)==2 and code.isalpha(): job_control.checkpoint(cfg.path,"navigation",code)
        update_job(job_file, state="hashing", started_utc=job.get("started_utc") or utcnow(),
                   detail="Verifying prepared OSM input", progress={"phase": "hashing"})
        source_hash = sha256_file(source)
        logger.log(f"Source SHA-256: {source_hash}")
        expected = str(job.get("expected_sha256") or "").lower()
        if expected and expected != source_hash:
            raise RuntimeError(f"Source SHA-256 mismatch: expected {expected}, got {source_hash}")

        work = job_dir / "build"
        if work.exists():
            shutil.rmtree(work)
        work.mkdir(parents=True)

        if len(code)==2 and code.isalpha(): job_control.checkpoint(cfg.path,"navigation",code)
        update_job(job_file, state="configuring", source_pbf_sha256=source_hash, source_pbf_size_bytes=source_size,
                   detail="Generating Valhalla build configuration", progress={"phase": "configuring"})
        config_path = generate_config(tool, work, logger)
        tile_extract = work / "valhalla_tiles.tar"

        if len(code)==2 and code.isalpha(): job_control.checkpoint(cfg.path,"navigation",code)
        update_job(job_file, state="building_tiles", detail="Building Valhalla graph tiles",
                   progress={"phase": "building_tiles", "source_bytes": source_size, "temporary_bytes": directory_size(work)})
        logger.log("Building Valhalla graph tiles. Large regions can take a substantial amount of time.")
        logger.run([
            str(tool.build_tiles),
            "-c", str(config_path), str(source),
        ])

        if len(code)==2 and code.isalpha(): job_control.checkpoint(cfg.path,"navigation",code)
        update_job(job_file, state="building_extract", detail="Building indexed mobile tile archive",
                   progress={"phase": "building_extract", "temporary_bytes": directory_size(work)})
        logger.log("Building indexed valhalla_tiles.tar for mobile loading.")
        build_indexed_extract(work / "valhalla_tiles", tile_extract, logger)
        if not tile_extract.is_file() or tile_extract.stat().st_size <= 0:
            raise RuntimeError("valhalla_tiles.tar was not created or is empty")
        logger.log(f"Tile extract: {human_bytes(tile_extract.stat().st_size)}")

        bounds = job.get("bounds")
        if not isinstance(bounds, list) or len(bounds) != 4:
            bounds = source_bounds(source)
            job["bounds"] = bounds
            write_json(job_file, job)
        if len(code)==2 and code.isalpha(): job_control.checkpoint(cfg.path,"navigation",code)
        coverage_dir = work / "routing_coverage"
        update_job(
            job_file, state="building_coverage",
            detail="Generating graph-derived road/off-road NAV coverage tiles",
            progress={"phase": "building_coverage", "coverage_zoom": COVERAGE_ZOOM},
        )
        coverage_index = build_routing_coverage(config_path, bounds, coverage_dir, logger, COVERAGE_ZOOM)

        if len(code)==2 and code.isalpha(): job_control.checkpoint(cfg.path,"navigation",code)
        manifest = package_manifest(job, source_hash, source_size, coverage_index)
        manifest_path = work / "manifest.json"
        write_json(manifest_path, manifest)

        slug = job["region_id"]
        filename = f"takrig-routing-{slug}-valhalla-{VALHALLA_VERSION}.zip"
        stage_package = work / filename
        if len(code)==2 and code.isalpha(): job_control.checkpoint(cfg.path,"navigation",code)
        update_job(job_file, state="packaging", detail="Packaging and verifying TAK Rig routing ZIP",
                   progress={"phase": "packaging", "temporary_bytes": directory_size(work), "tile_extract_bytes": tile_extract.stat().st_size})
        logger.log(f"Packaging {filename} with ZIP64/no recompression.")
        build_zip(stage_package, manifest_path, config_path, tile_extract, coverage_dir)
        verify = verify_package(stage_package)
        logger.log(f"Package size: {human_bytes(verify['size_bytes'])}")

        if len(code)==2 and code.isalpha(): job_control.checkpoint(cfg.path,"navigation",code)
        ready_package = cfg.ready / filename
        ready_desc = cfg.ready / (filename + ".json")
        os.replace(stage_package, ready_package)
        desc = package_descriptor(ready_package, verify, manifest, job)
        write_json(ready_desc, desc)
        rebuild_catalog(cfg)

        duration = round(time.monotonic() - start, 3)
        completed = update_job(
            job_file,
            state="ready",
            completed_utc=utcnow(),
            duration_seconds=duration,
            package=str(ready_package),
            package_size_bytes=verify["size_bytes"],
            tile_extract_size_bytes=tile_extract.stat().st_size,
            routing_coverage=coverage_manifest_summary(coverage_index),
        )
        logger.log(f"READY: {ready_package}")
        logger.log(f"Build duration: {duration:.1f} seconds")
        logger.close()

        history_path = cfg.history / f"{job_dir.name}.json"
        write_json(history_path, completed)
        log_history = cfg.history / f"{job_dir.name}.log"
        shutil.copy2(log_path, log_history)

        if bool(cfg.data.get("keep_source_after_success", False)):
            archive_name = f"{slug}-{source_hash[:12]}.osm.pbf"
            archive_pbf = cfg.archive / archive_name
            os.replace(source, archive_pbf)
            sidecar = job_dir / "source.osm.pbf.json"
            if sidecar.is_file():
                os.replace(sidecar, cfg.archive / (archive_name + ".json"))
        shutil.rmtree(job_dir, ignore_errors=True)
        return desc
    except job_control.JobPaused:
        update_job(job_file, state="paused", detail="Navigation build paused at a safe stage boundary")
        logger.log("PAUSED: source PBF and durable checkpoints retained")
        logger.close()
        raise
    except Exception as exc:
        # Keep the source PBF and logs under failed/ for diagnosis and retry.
        if not logger._fh.closed:
            move_failed(cfg, job_dir, exc, logger)
        raise


def scan(cfg: Config, process_all: bool = False) -> list[dict[str, Any]]:
    cfg.ensure_dirs()
    completed: list[dict[str, Any]] = []
    limit = 10**9 if process_all else max(1, int(cfg.data.get("jobs_per_scan", 1)))
    settle = max(0, int(cfg.data.get("settle_seconds", 20)))

    # Resume interrupted/claimed work before claiming a new download.
    jobs = resume_jobs(cfg)
    for job_dir in jobs[:limit]:
        completed.append(process_job(cfg, job_dir))
    remaining = limit - len(completed)
    if remaining <= 0:
        return completed

    candidates = sorted(
        [p for p in cfg.incoming.glob("*.osm.pbf") if p.is_file()],
        key=lambda p: (p.stat().st_mtime, p.name),
    )
    for pbf in candidates:
        if remaining <= 0:
            break
        if not pbf_is_settled(pbf, settle):
            continue
        code=pbf.name.split(".",1)[0].upper()
        if len(code)==2 and job_control.requested(cfg.path,"navigation",code):
            continue
        job_dir = claim_incoming(cfg, pbf)
        try:
            completed.append(process_job(cfg, job_dir))
        except Exception:
            # Failure is already persisted under failed/; continue only in --all mode.
            if not process_all:
                raise
        remaining -= 1
    return completed


def enqueue(cfg: Config, source: Path, meta: dict[str, Any], replace: bool = False) -> Path:
    cfg.ensure_dirs()
    source = source.resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    if source.stat().st_size <= 0:
        raise RuntimeError("Source PBF is empty")
    meta = normalize_metadata(meta, source.name)
    target = cfg.incoming / f"{meta['region_id']}.osm.pbf"
    sidecar = Path(str(target) + ".json")
    if (target.exists() or sidecar.exists()) and not replace:
        raise RuntimeError(f"Incoming region already exists: {target}; use --replace to replace it")
    part = cfg.incoming / (target.name + f".part-{os.getpid()}")
    if part.exists():
        part.unlink()
    shutil.copy2(source, part)
    write_json(Path(str(part) + ".json"), meta)
    if replace:
        with contextlib.suppress(FileNotFoundError):
            target.unlink()
        with contextlib.suppress(FileNotFoundError):
            sidecar.unlink()
    os.replace(Path(str(part) + ".json"), sidecar)
    os.replace(part, target)
    return target


def retry_failed(cfg: Config, job_id: str, replace: bool = False) -> Path:
    failed = cfg.failed / job_id
    source = failed / "source.osm.pbf"
    job_file = failed / "job.json"
    if not source.is_file() or not job_file.is_file():
        raise RuntimeError(f"Failed job is incomplete or does not exist: {job_id}")
    job = read_json(job_file, {}) or {}
    meta = normalize_metadata(job, job.get("original_filename") or source.name)
    target = cfg.incoming / f"{meta['region_id']}.osm.pbf"
    sidecar = Path(str(target) + ".json")
    if (target.exists() or sidecar.exists()) and not replace:
        raise RuntimeError(f"Incoming region already exists: {target}; use --replace")
    if replace:
        target.unlink(missing_ok=True)
        sidecar.unlink(missing_ok=True)
    write_json(sidecar, meta)
    os.replace(source, target)
    shutil.rmtree(failed, ignore_errors=True)
    return target


def status(cfg: Config) -> dict[str, Any]:
    cfg.ensure_dirs()
    def dirs(root: Path) -> list[str]:
        return sorted(p.name for p in root.iterdir() if p.is_dir())
    incoming = sorted(p.name for p in cfg.incoming.glob("*.osm.pbf"))
    ready = []
    for p in sorted(cfg.ready.glob("*.zip.json")):
        with contextlib.suppress(Exception):
            ready.append(read_json(p, {}))
    return {
        "processor_version": VERSION,
        "valhalla_version": VALHALLA_VERSION,
        "package_format": PACKAGE_FORMAT,
        "incoming": incoming,
        "processing": dirs(cfg.processing),
        "failed": dirs(cfg.failed),
        "ready": ready,
        "state_size_bytes": directory_size(cfg.state_root),
    }


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="takrig-routing",
        description="TAK Rig server-side Valhalla routing data processor",
    )
    parser.add_argument(
        "--config",
        default=os.environ.get("TAKRIG_ROUTING_CONFIG", "/etc/takrig-routing/config.json"),
        help="JSON configuration path",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    sub = parser.add_subparsers(dest="command", required=True)

    p_enqueue = sub.add_parser("enqueue", help="Copy a completed .osm.pbf into the processing inbox")
    p_enqueue.add_argument("pbf", type=Path)
    p_enqueue.add_argument("--name", required=True)
    p_enqueue.add_argument("--region-id", default="")
    p_enqueue.add_argument("--source-url", default="")
    p_enqueue.add_argument("--expected-sha256", default="")
    p_enqueue.add_argument("--source-updated-utc", default="")
    p_enqueue.add_argument("--bounds", default="", help="JSON array/object describing source bounds")
    p_enqueue.add_argument("--replace", action="store_true")

    p_scan = sub.add_parser("scan", help="Process settled completed downloads from the inbox")
    p_scan.add_argument("--all", action="store_true", help="Process all queued jobs sequentially")

    p_status = sub.add_parser("status", help="Show queue/build status")
    p_status.add_argument("--json", action="store_true")

    p_verify = sub.add_parser("verify", help="Validate a generated TAK Rig routing ZIP")
    p_verify.add_argument("package", type=Path)

    p_retry = sub.add_parser("retry", help="Move a failed job back to the incoming queue")
    p_retry.add_argument("job_id")
    p_retry.add_argument("--replace", action="store_true")

    sub.add_parser("catalog", help="Rebuild ready/catalog.json")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    cfg = Config.load(Path(args.config))
    cfg.ensure_dirs()
    try:
        if args.command == "enqueue":
            meta: dict[str, Any] = {
                "name": args.name,
                "region_id": args.region_id,
                "source_url": args.source_url,
                "expected_sha256": args.expected_sha256,
                "source_updated_utc": args.source_updated_utc,
            }
            if args.bounds:
                meta["bounds"] = json.loads(args.bounds)
            target = enqueue(cfg, args.pbf, meta, replace=args.replace)
            print(target)
            return 0

        if args.command == "scan":
            with global_lock(cfg):
                completed = scan(cfg, process_all=args.all)
            print(json.dumps({"processed": completed}, indent=2))
            return 0

        if args.command == "status":
            data = status(cfg)
            if args.json:
                print(json.dumps(data, indent=2))
            else:
                print(f"TAK Rig routing processor v{VERSION} · Valhalla {VALHALLA_VERSION}")
                print(f"Incoming:   {len(data['incoming'])}")
                print(f"Processing: {len(data['processing'])}")
                print(f"Ready:      {len(data['ready'])}")
                print(f"Failed:     {len(data['failed'])}")
                print(f"State size: {human_bytes(data['state_size_bytes'])}")
                if data["incoming"]:
                    print("\nIncoming:")
                    for x in data["incoming"]:
                        print(f"  {x}")
                if data["ready"]:
                    print("\nReady:")
                    for x in data["ready"]:
                        print(f"  {x.get('name')} · {x.get('package')} · {human_bytes(int(x.get('size_bytes', 0)))}")
                if data["failed"]:
                    print("\nFailed:")
                    for x in data["failed"]:
                        print(f"  {x}")
            return 0

        if args.command == "verify":
            print(json.dumps(verify_package(args.package.resolve()), indent=2))
            return 0

        if args.command == "retry":
            with global_lock(cfg):
                target = retry_failed(cfg, args.job_id, replace=args.replace)
            print(target)
            return 0

        if args.command == "catalog":
            with global_lock(cfg):
                print(json.dumps(rebuild_catalog(cfg), indent=2))
            return 0
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
