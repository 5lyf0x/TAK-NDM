#!/usr/bin/env python3
"""TAK Rig 3D environment/land-cover package builder.

r16-r16 adds an independent, optional environment package.  It preprocesses
ESA WorldCover 2021 v200 land-cover COGs into small, fast, normalized runtime
cells.  Dynamic snow is deliberately not stored here; TAK Rig applies current
weather-derived snow over this static land-cover baseline.
"""
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
import hashlib
import json
import math
import os
import shutil
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid
import zipfile
import zlib
from pathlib import Path
from typing import Any

HERE=Path(__file__).resolve().parent
if str(HERE) not in sys.path: sys.path.insert(0,str(HERE))
from state_catalog import STATES
from sources import fetch_geofabrik_boundary, geofabrik_urls, parse_geofabrik_poly
import environment_assets

VERSION="0.2.0-r16-r29"
PACKAGE_FORMAT="takrig.environment.region.v1"
DB_SCHEMA="takrig.environment.sqlite.v1"
SOURCE_NAME="ESA WorldCover 2021 v200"
SOURCE_BASE="https://esa-worldcover.s3.eu-central-1.amazonaws.com/v200/2021/map"
SOURCE_PRODUCT="ESA WorldCover 10 m 2021 v200"
TILE_SPAN_DEG=0.5
SOURCE_TILE_SPAN_DEG=3.0
RUNTIME_RESOLUTION_M=30
SOURCE_GRID=1801                  # 1800 intervals across 0.5 deg ~= 1 arc-sec
CELL_SPLIT=5                      # 0.1-degree runtime cells
SUBCELL_INTERVALS=(SOURCE_GRID-1)//CELL_SPLIT  # 360
SUBCELL_GRID=SUBCELL_INTERVALS+1  # 361
NODATA=0
DEFAULT_MIN_FREE_GIB=30.0
ACTIVE_STATES={"queued","preparing","building","packaging"}
TRANSIENT_HTTP={408,425,429,500,502,503,504}

# Stable TAK Rig classes. Values are intentionally tiny so the Android client can
# treat this schema as a compact contract independent of the upstream provider.
UNKNOWN=0; WATER=1; BUILT=2; TREE=3; SHRUB=4; GRASS=5; CROP=6; BARE=7; WETLAND=8; PERMANENT_SNOW_ICE=9
CLASS_NAMES={0:"unknown",1:"water",2:"built",3:"tree",4:"shrub",5:"grass",6:"crop",7:"bare_sparse",8:"wetland",9:"permanent_snow_ice"}
# ESA WorldCover class -> (normalized class, nominal vegetation density 0..255)
WORLDCOVER_MAP={
    10:(TREE,245), 20:(SHRUB,120), 30:(GRASS,90), 40:(CROP,110), 50:(BUILT,0),
    60:(BARE,5), 70:(PERMANENT_SNOW_ICE,0), 80:(WATER,0), 90:(WETLAND,90),
    95:(TREE,250), 100:(SHRUB,55),
}

class EnvironmentWaitingSpace(RuntimeError): pass
class WorldCoverTileAbsent(RuntimeError): pass

def utcnow()->str: return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00","Z")
def read_json(path:Path,default:Any=None)->Any:
    try:return json.loads(path.read_text(encoding="utf-8"))
    except Exception:return default

def atomic_json(path:Path,data:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+f".tmp-{os.getpid()}-{uuid.uuid4().hex[:8]}")
    tmp.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8"); os.replace(tmp,path)

def roots(config_path:Path)->dict[str,Path]:
    cfg=read_json(config_path,{}) if config_path.is_file() else {}
    root=Path(str((cfg if isinstance(cfg,dict) else {}).get("state_root") or "/var/lib/takrig-routing")).expanduser().resolve()
    env=root/"environment"
    return {"root":root,"environment":env,"ready":env/"ready","work":env/"work","status":env/"status",
            "cache":env/"cache"/"worldcover","asset_cache":env/"cache"/"cinematic-v1","boundary_cache":root/"manager"/"sources","settings":root/"manager"/"settings.json",
            "lock":env/"environment-build.lock"}

def ensure_roots(r:dict[str,Path])->None:
    for k in ("environment","ready","work","status","cache"):r[k].mkdir(parents=True,exist_ok=True)

def descriptor_path(config_path:Path,code:str)->Path:return roots(config_path)["ready"]/f"takrig-environment-{code.lower()}.zip.json"
def package_path(config_path:Path,code:str)->Path:return roots(config_path)["ready"]/f"takrig-environment-{code.lower()}.zip"
def status_path(config_path:Path,code:str)->Path:return roots(config_path)["status"]/f"{code.lower()}.json"

def ready_descriptor(config_path:Path,code:str)->dict[str,Any]|None:
    desc=read_json(descriptor_path(config_path,code.upper()),None)
    if not isinstance(desc,dict):return None
    package=roots(config_path)["ready"]/str(desc.get("package") or "")
    return desc if package.is_file() else None

def _update_status(config_path:Path,code:str,status:str,stage:str,detail:str="",**extra:Any)->None:
    prior=read_json(status_path(config_path,code),{})
    row=dict(prior) if isinstance(prior,dict) else {}
    row.update({"state_code":code,"state_name":STATES[code].name,"status":status,"stage":stage,"detail":detail,"updated_utc":utcnow(),**extra})
    atomic_json(status_path(config_path,code),row)

def status_summary(config_path:Path,code:str)->dict[str,Any]:
    code=code.upper(); ready=ready_descriptor(config_path,code); status=read_json(status_path(config_path,code),{})
    if not isinstance(status,dict):status={}
    state=str(status.get("status") or "")
    if state in ACTIVE_STATES or state in {"waiting_space","failed"}:out=dict(status)
    elif ready:out={"status":"ready","stage":"ready","detail":"3D environment package is available"}
    else:out={"status":"not_built","stage":"not_built","detail":"3D environment has not been built"}
    out["package"]=ready; return out

def remove(config_path:Path,code:str)->list[str]:
    code=code.upper(); removed=[]
    for p in (package_path(config_path,code),descriptor_path(config_path,code),status_path(config_path,code)):
        if p.exists(): p.unlink(missing_ok=True); removed.append(str(p))
    work=roots(config_path)["work"]/code.lower()
    if work.exists():shutil.rmtree(work,ignore_errors=True);removed.append(str(work))
    return removed

def _minimum_free_bytes(config_path:Path)->int:
    r=roots(config_path); settings=read_json(r["settings"],{}); cfg=read_json(config_path,{})
    raw=(settings if isinstance(settings,dict) else {}).get("minimum_free_disk_gib") or (cfg if isinstance(cfg,dict) else {}).get("minimum_free_disk_gib") or DEFAULT_MIN_FREE_GIB
    return int(float(raw)*1024**3)

def _disk_check(config_path:Path,code:str,remaining_cells:int)->None:
    r=roots(config_path); free=shutil.disk_usage(r["root"]).free; reserve=_minimum_free_bytes(config_path)
    # WorldCover source COGs can be sizable. Budget 24 MiB per unfinished 0.5-degree cell plus 256 MiB scratch.
    projected=max(256*1024**2,min(4*1024**3,remaining_cells*24*1024**2)); required=reserve+projected
    if free<required:
        info={"free_bytes":free,"minimum_free_bytes":reserve,"projected_additional_bytes":projected,"projected_required_free_bytes":required}
        _update_status(config_path,code,"waiting_space","waiting_space","3D environment build is waiting for disk space policy",disk_estimate=info)
        raise EnvironmentWaitingSpace(f"3D environment requires approximately {required} free bytes including reserve; {free} bytes are free")

def _run_checked(cmd:list[str],label:str)->subprocess.CompletedProcess[str]:
    r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if r.returncode!=0:raise RuntimeError(f"{label} failed (exit {r.returncode}): {(r.stderr or r.stdout or '').strip()[:1600]}")
    return r

def _tile_id(lat0:int,lon0:int)->str:
    return f"{'N' if lat0>=0 else 'S'}{abs(lat0):02d}{'E' if lon0>=0 else 'W'}{abs(lon0):03d}"

def _source_tile_for(west:float,south:float)->tuple[str,int,int]:
    lon0=int(math.floor(west/SOURCE_TILE_SPAN_DEG)*SOURCE_TILE_SPAN_DEG)
    lat0=int(math.floor(south/SOURCE_TILE_SPAN_DEG)*SOURCE_TILE_SPAN_DEG)
    return _tile_id(lat0,lon0),lat0,lon0

def _source_url(tile_id:str)->str:
    return f"{SOURCE_BASE}/ESA_WorldCover_10m_2021_v200_{tile_id}_Map.tif"

def _download_source(config_path:Path,tile_id:str,missing_tiles:set[str]|None=None)->Path|None:
    """Download one ESA WorldCover 3x3-degree source tile.

    The public WorldCover bucket contains only tiles with product coverage.  State/extract
    polygons can legitimately intersect neighboring ocean-only 0.5-degree work cells, whose
    corresponding 3-degree WorldCover object therefore returns HTTP 404.  A 404 is not a
    build failure: mark that source tile absent for this build and let the caller skip those
    work cells. Other HTTP errors still follow the normal transient/fatal policy.
    """
    if missing_tiles is not None and tile_id in missing_tiles:
        return None
    r=roots(config_path); ensure_roots(r); target=r["cache"]/f"ESA_WorldCover_10m_2021_v200_{tile_id}_Map.tif"
    if target.is_file() and target.stat().st_size>1024:return target
    part=target.with_suffix(target.suffix+".part"); url=_source_url(tile_id); last=None
    for attempt in range(1,5):
        part.unlink(missing_ok=True)
        try:
            req=urllib.request.Request(url,headers={"User-Agent":f"TAK-Rig-NDM/{VERSION}","Accept":"image/tiff,*/*"})
            with urllib.request.urlopen(req,timeout=180) as resp,part.open("wb") as out:
                shutil.copyfileobj(resp,out,length=2*1024*1024); out.flush(); os.fsync(out.fileno())
            if part.stat().st_size<=1024:raise RuntimeError("WorldCover response was unexpectedly small")
            os.replace(part,target); return target
        except urllib.error.HTTPError as exc:
            last=exc
            if exc.code==404:
                if missing_tiles is not None:missing_tiles.add(tile_id)
                part.unlink(missing_ok=True)
                return None
            if exc.code not in TRANSIENT_HTTP or attempt>=4:raise RuntimeError(f"WorldCover HTTP {exc.code} for {tile_id}") from exc
        except (urllib.error.URLError,TimeoutError,ConnectionError,OSError) as exc:
            last=exc
            if attempt>=4:raise RuntimeError(f"WorldCover download failed for {tile_id}: {exc}") from exc
        time.sleep(min(8.0,1.5*(2**(attempt-1))))
    raise RuntimeError(str(last or "WorldCover download failed"))

def _normalize_worldcover(raw:bytes)->bytes:
    out=bytearray(len(raw)*2); j=0
    for value in raw:
        cls,density=WORLDCOVER_MAP.get(value,(UNKNOWN,0)); out[j]=cls; out[j+1]=density; j+=2
    return bytes(out)

def _warp_half_degree(source:Path,west:float,south:float,east:float,north:float,outbase:Path)->bytes:
    gdalwarp=shutil.which("gdalwarp")
    if not gdalwarp:raise RuntimeError("gdalwarp is required; install NDM with gdal-bin")
    raw=outbase.with_suffix(".bin"); hdr=outbase.with_suffix(".hdr"); aux=Path(str(raw)+".aux.xml")
    for p in (raw,hdr,aux):p.unlink(missing_ok=True)
    cmd=[gdalwarp,"-overwrite","-of","ENVI","-ot","Byte","-r","near","-srcnodata","0","-dstnodata","0",
         "-te",f"{west:.10f}",f"{south:.10f}",f"{east:.10f}",f"{north:.10f}","-t_srs","EPSG:4326",
         "-ts",str(SOURCE_GRID),str(SOURCE_GRID),str(source),str(raw)]
    try:
        _run_checked(cmd,"WorldCover reprojection")
        data=raw.read_bytes(); expected=SOURCE_GRID*SOURCE_GRID
        if len(data)!=expected:raise RuntimeError(f"Unexpected WorldCover raster size {len(data)}, expected {expected}")
        return data
    finally:
        for p in (raw,hdr,aux):p.unlink(missing_ok=True)

def _subcell_payload(normalized:bytes,sr:int,sc:int)->bytes:
    # normalized is class,density interleaved for SOURCE_GRID square.  Subcells overlap one border node.
    start_r=sr*SUBCELL_INTERVALS; start_c=sc*SUBCELL_INTERVALS; row_bytes=SUBCELL_GRID*2
    out=bytearray(SUBCELL_GRID*SUBCELL_GRID*2); pos=0
    for r in range(start_r,start_r+SUBCELL_GRID):
        src=(r*SOURCE_GRID+start_c)*2
        out[pos:pos+row_bytes]=normalized[src:src+row_bytes]; pos+=row_bytes
    return bytes(out)

def _create_db(path:Path,code:str,state_name:str,created:str,reset:bool)->sqlite3.Connection:
    if reset:path.unlink(missing_ok=True)
    new=not path.exists(); db=sqlite3.connect(path); db.execute("PRAGMA journal_mode=WAL");db.execute("PRAGMA synchronous=FULL")
    if new:
        db.executescript("""
        CREATE TABLE metadata(name TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE cells(cell_id TEXT PRIMARY KEY,west REAL NOT NULL,south REAL NOT NULL,east REAL NOT NULL,north REAL NOT NULL,
          rows INTEGER NOT NULL,cols INTEGER NOT NULL,encoding TEXT NOT NULL,data BLOB NOT NULL);
        CREATE INDEX cells_bounds ON cells(west,south,east,north);
        """)
        environment_assets.ensure_tables(db)
        meta={"schema":DB_SCHEMA,"package_format":PACKAGE_FORMAT,"state_code":code,"state_name":state_name,"source_name":SOURCE_NAME,
              "source_year":"2021","runtime_resolution_m":str(RUNTIME_RESOLUTION_M),"cell_span_degrees":str(TILE_SPAN_DEG/CELL_SPLIT),
              "grid_rows":str(SUBCELL_GRID),"grid_cols":str(SUBCELL_GRID),"encoding":"u8class+density+zlib","created_utc":created,
              "class_names":json.dumps(CLASS_NAMES,sort_keys=True)}
        db.executemany("INSERT INTO metadata(name,value) VALUES(?,?)",meta.items());db.commit()
    return db

def _validate_db(path:Path)->dict[str,int]:
    db=sqlite3.connect(path)
    try:
        q=db.execute("PRAGMA quick_check").fetchone();
        if not q or q[0]!="ok":raise RuntimeError("Environment SQLite quick_check failed")
        meta=dict(db.execute("SELECT name,value FROM metadata"));
        if meta.get("schema")!=DB_SCHEMA:raise RuntimeError("Environment DB schema metadata is invalid")
        count=0
        for rows,cols,enc,blob in db.execute("SELECT rows,cols,encoding,data FROM cells"):
            if rows!=SUBCELL_GRID or cols!=SUBCELL_GRID or enc!="u8class+density+zlib":raise RuntimeError("Environment cell shape/encoding invalid")
            raw=zlib.decompress(blob)
            if len(raw)!=rows*cols*2:raise RuntimeError("Malformed environment cell")
            count+=1
        if count<=0:raise RuntimeError("Environment database contains no cells")
        return {"cell_count":count}
    finally:db.close()

def _coverage_boxes(cells:list[tuple[float,float,float,float]])->list[list[float]]:
    if not cells:return []
    return [[min(x[0] for x in cells),min(x[1] for x in cells),max(x[2] for x in cells),max(x[3] for x in cells)]]

def build(config_path:Path,code:str,force:bool=False)->dict[str,Any]:
    code=code.upper();
    if code not in STATES:raise ValueError(f"Unknown state: {code}")
    r=roots(config_path);ensure_roots(r);state=STATES[code];existing=ready_descriptor(config_path,code)
    if existing and not force:return existing
    import fcntl
    with r["lock"].open("a+") as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX)
        existing=ready_descriptor(config_path,code)
        if existing and not force:return existing
        _update_status(config_path,code,"preparing","boundary","Preparing 3D environment state boundary")
        boundary=r["boundary_cache"]/code.lower()/"state.poly";boundary.parent.mkdir(parents=True,exist_ok=True)
        fetch_geofabrik_boundary(state,boundary,force=False,urls=geofabrik_urls(state))
        geom=parse_geofabrik_poly(boundary.read_text(encoding="utf-8",errors="replace"));minx,miny,maxx,maxy=map(float,geom.bounds)
        from shapely.geometry import box
        cells=[];y=math.floor(miny/TILE_SPAN_DEG)*TILE_SPAN_DEG;ymax=math.ceil(maxy/TILE_SPAN_DEG)*TILE_SPAN_DEG
        while y<ymax-1e-9:
            x=math.floor(minx/TILE_SPAN_DEG)*TILE_SPAN_DEG;xmax=math.ceil(maxx/TILE_SPAN_DEG)*TILE_SPAN_DEG
            while x<xmax-1e-9:
                c=(round(x,10),round(y,10),round(x+TILE_SPAN_DEG,10),round(y+TILE_SPAN_DEG,10))
                if geom.intersects(box(*c)):cells.append(c)
                x+=TILE_SPAN_DEG
            y+=TILE_SPAN_DEG
        if not cells:raise RuntimeError("State boundary produced no environment cells")
        _disk_check(config_path,code,len(cells));work=r["work"]/code.lower();work.mkdir(parents=True,exist_ok=True)
        state_file=work/"build-state.json";fingerprint=hashlib.sha256(json.dumps(cells,separators=(",",":")).encode()).hexdigest()
        prior=read_json(state_file,{});reset=force or not isinstance(prior,dict) or prior.get("fingerprint")!=fingerprint
        if reset:
            shutil.rmtree(work,ignore_errors=True);work.mkdir(parents=True,exist_ok=True);prior={}
        created=str(prior.get("created_utc") or utcnow());db_path=work/"environment.sqlite";db=_create_db(db_path,code,state.name,created,reset)
        existing_half=set(row[0] for row in db.execute("SELECT DISTINCT substr(cell_id,1,instr(cell_id,'/')-1) FROM cells"))
        skipped_half=set(str(x) for x in (prior.get("skipped_half_cells") or []) if isinstance(x,str))
        completed_half=existing_half|skipped_half
        missing_source_tiles:set[str]=set()
        completed=len(completed_half);started=time.monotonic()
        try:
            for west,south,east,north in cells:
                half_id=f"{west:+07.1f}_{south:+06.1f}"
                if half_id in completed_half:continue
                _disk_check(config_path,code,max(1,len(cells)-completed));pct=int(completed*100/max(1,len(cells)))
                _update_status(config_path,code,"building","worldcover",f"3D environment cell {completed+1}/{len(cells)}",progress={"completed":completed,"total":len(cells),"percent":pct})
                src_id,_,_=_source_tile_for(west,south);source=_download_source(config_path,src_id,missing_source_tiles)
                if source is None:
                    skipped_half.add(half_id);completed_half.add(half_id);completed+=1
                    atomic_json(state_file,{"schema":"takrig.environment.build-state.v1","state_code":code,"created_utc":created,"fingerprint":fingerprint,"completed_half_cells":completed,"skipped_half_cells":sorted(skipped_half)})
                    _update_status(config_path,code,"building","worldcover",f"Skipping WorldCover no-coverage/ocean tile {src_id}",progress={"completed":completed,"total":len(cells),"percent":int(completed*100/max(1,len(cells)))})
                    continue
                wc=_warp_half_degree(source,west,south,east,north,work/f"{half_id}.worldcover")
                normalized=_normalize_worldcover(wc)
                if not any(normalized[0::2]):
                    skipped_half.add(half_id);completed_half.add(half_id);completed+=1
                    atomic_json(state_file,{"schema":"takrig.environment.build-state.v1","state_code":code,"created_utc":created,"fingerprint":fingerprint,"completed_half_cells":completed,"skipped_half_cells":sorted(skipped_half)})
                    continue
                for sr in range(CELL_SPLIT):
                    for sc in range(CELL_SPLIT):
                        payload=_subcell_payload(normalized,sr,sc)
                        span=TILE_SPAN_DEG/CELL_SPLIT
                        cw=west+sc*span;ce=cw+span
                        # GDAL/ENVI rows are north-to-south. sr=0 is therefore the northernmost
                        # runtime cell; label geographic bounds in the same orientation.
                        cn=north-sr*span;cs=cn-span
                        cell_id=f"{half_id}/{sr}{sc}"
                        db.execute("INSERT OR REPLACE INTO cells(cell_id,west,south,east,north,rows,cols,encoding,data) VALUES(?,?,?,?,?,?,?,?,?)",
                                   (cell_id,cw,cs,ce,cn,SUBCELL_GRID,SUBCELL_GRID,"u8class+density+zlib",zlib.compress(payload,6)))
                db.commit();completed+=1;existing_half.add(half_id);completed_half.add(half_id)
                atomic_json(state_file,{"schema":"takrig.environment.build-state.v1","state_code":code,"created_utc":created,"fingerprint":fingerprint,"completed_half_cells":completed,"skipped_half_cells":sorted(skipped_half)})
            cinematic={"available":False,"asset_set":environment_assets.ASSET_SET_REVISION,"material_count":0,"tree_source_count":0}
            try:
                _update_status(config_path,code,"building","cinematic_assets","Preparing photographic terrain and vegetation assets")
                detail=environment_assets.install_optional_cinematic_assets(db,r["asset_cache"],force=False)
                cinematic.update({"available":True,**detail})
            except Exception as exc:
                # Cinematic data is intentionally optional. Classification-only Environment packages
                # remain valid and let older/newer TAK Rig clients fall back without blocking 3D.
                cinematic["error"]=str(exc)[:500]
                environment_assets.ensure_tables(db);db.commit()
            db.execute("PRAGMA wal_checkpoint(TRUNCATE)");db.commit();db.close();db=None
            validation=_validate_db(db_path);coverage=_coverage_boxes(cells);legacy=coverage[0]
            manifest={"schema":PACKAGE_FORMAT,"format":PACKAGE_FORMAT,"state_code":code,"state_name":state.name,"revision":created,"built_utc":created,
                      "source":{"name":SOURCE_NAME,"product":SOURCE_PRODUCT,"url":SOURCE_BASE,"year":2021,"version":"v200"},
                      "runtime_resolution_m":RUNTIME_RESOLUTION_M,"cell_span_degrees":TILE_SPAN_DEG/CELL_SPLIT,"grid_size":[SUBCELL_GRID,SUBCELL_GRID],
                      "encoding":"u8class+density+zlib","classes":CLASS_NAMES,"bounds":legacy,"coverage_boxes":coverage,"cell_count":validation["cell_count"],
                      "database":"environment.sqlite","database_schema":DB_SCHEMA,"manager_version":VERSION,"dynamic_snow_included":False,
                      "cinematic_asset_set":environment_assets.ASSET_SET_REVISION,"cinematic_assets_included":bool(cinematic.get("available")),
                      "photographic_materials":int(cinematic.get("material_count") or 0),"tree_source_count":int(cinematic.get("tree_source_count") or 0),
                      "cinematic_assets":cinematic,
                      "skipped_no_coverage_cells":len(skipped_half),"missing_worldcover_tiles":sorted(missing_source_tiles)}
            atomic_json(work/"manifest.json",manifest);_update_status(config_path,code,"packaging","packaging","Packaging 3D environment")
            final=package_path(config_path,code);part=final.with_suffix(final.suffix+".part");part.unlink(missing_ok=True)
            with zipfile.ZipFile(part,"w",compression=zipfile.ZIP_STORED,allowZip64=True) as zf:
                zf.write(work/"manifest.json","manifest.json");zf.write(db_path,"environment.sqlite")
            with zipfile.ZipFile(part,"r") as zf:
                if set(zf.namelist())!={"manifest.json","environment.sqlite"}:raise RuntimeError("Environment package members invalid")
                bad=zf.testzip();
                if bad:raise RuntimeError(f"Environment package CRC failed: {bad}")
            os.replace(part,final);desc=dict(manifest);desc.update({"package":final.name,"size_bytes":final.stat().st_size,"created_utc":created,"duration_seconds":round(time.monotonic()-started,2)})
            atomic_json(descriptor_path(config_path,code),desc);_update_status(config_path,code,"ready","ready","3D environment package is ready",package=desc,progress={"completed":len(cells),"total":len(cells),"percent":100})
            shutil.rmtree(work,ignore_errors=True);return desc
        finally:
            if db is not None:
                with contextlib.suppress(Exception):db.commit();db.close()

def main()->int:
    ap=argparse.ArgumentParser(description="TAK Rig 3D environment package builder");ap.add_argument("--config",default=os.environ.get("TAKRIG_ROUTING_CONFIG","/etc/takrig-routing/config.json"))
    sub=ap.add_subparsers(dest="command",required=True);b=sub.add_parser("build");b.add_argument("state");b.add_argument("--force",action="store_true");s=sub.add_parser("status");s.add_argument("state");r=sub.add_parser("remove");r.add_argument("state")
    args=ap.parse_args();cfg=Path(args.config)
    try:
        result=build(cfg,args.state,force=args.force) if args.command=="build" else status_summary(cfg,args.state) if args.command=="status" else {"removed":remove(cfg,args.state)}
        print(json.dumps(result,indent=2));return 0
    except EnvironmentWaitingSpace as exc:print(f"WAITING: {exc}",file=sys.stderr);return 3
    except Exception as exc:
        if getattr(args,"state","").upper() in STATES:_update_status(cfg,args.state.upper(),"failed","failed",str(exc),error=str(exc))
        print(f"ERROR: {exc}",file=sys.stderr);return 2

if __name__=="__main__":raise SystemExit(main())
