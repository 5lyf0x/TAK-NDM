#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import hashlib
import concurrent.futures
import threading
import json
import os
import re
import shutil
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, asdict, replace
from pathlib import Path
from typing import Any, Callable, Iterable

from state_catalog import STATES, StateInfo
from state_profiles import STATE_ROAD_PROFILES, STATE_RECREATION_PROFILES, WEST_EXPANSION_STATES

USER_AGENT = "TAK-Rig-Navigation-Data-Manager/0.2.0-r16-r29 (+local TAK Gateway deployment)"


def utcnow() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".part-{os.getpid()}-{int(time.time() * 1000)}")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def atomic_json(path: Path, data: Any) -> None:
    atomic_write(path, (json.dumps(data, indent=2) + "\n").encode("utf-8"))


def sha256_file(path: Path, chunk: int = 4 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def http_request(url: str, method: str = "GET", timeout: int = 60, headers: dict[str, str] | None = None):
    req_headers = {"User-Agent": USER_AGENT, "Accept": "*/*"}
    if headers:
        req_headers.update(headers)
    req = urllib.request.Request(url, method=method, headers=req_headers)
    return urllib.request.urlopen(req, timeout=timeout)


def head_metadata(url: str, timeout: int = 30) -> dict[str, Any]:
    try:
        with http_request(url, method="HEAD", timeout=timeout) as resp:
            return {
                "url": resp.geturl(),
                "status": getattr(resp, "status", 200),
                "etag": resp.headers.get("ETag", "").strip(),
                "last_modified": resp.headers.get("Last-Modified", "").strip(),
                "content_length": int(resp.headers.get("Content-Length") or 0),
            }
    except urllib.error.HTTPError as exc:
        if exc.code not in (403, 405):
            raise
        # Some public GIS/CDN endpoints reject HEAD. A 1-byte range GET is sufficient
        # to discover validators without downloading the full source.
        with http_request(url, method="GET", timeout=timeout, headers={"Range": "bytes=0-0"}) as resp:
            total = 0
            content_range = resp.headers.get("Content-Range", "")
            m = re.search(r"/(\d+)$", content_range)
            if m:
                total = int(m.group(1))
            else:
                total = int(resp.headers.get("Content-Length") or 0)
            return {
                "url": resp.geturl(),
                "status": getattr(resp, "status", 200),
                "etag": resp.headers.get("ETag", "").strip(),
                "last_modified": resp.headers.get("Last-Modified", "").strip(),
                "content_length": total,
            }


def download_atomic(url: str, target: Path, timeout: int = 120, expected_md5: str = "",
                    progress: Callable[[dict[str, Any]], None] | None = None) -> dict[str, Any]:
    target.parent.mkdir(parents=True, exist_ok=True)
    part = target.with_name(target.name + ".part")
    part.unlink(missing_ok=True)
    h_sha = hashlib.sha256()
    h_md5 = hashlib.md5()  # upstream Geofabrik publishes MD5 sidecars
    total = 0
    started = time.monotonic()
    with http_request(url, method="GET", timeout=timeout) as resp, part.open("wb") as out:
        while True:
            block = resp.read(1024 * 1024)
            if not block:
                break
            out.write(block)
            h_sha.update(block)
            h_md5.update(block)
            total += len(block)
            if progress:
                elapsed = max(0.001, time.monotonic() - started)
                expected = int(resp.headers.get("Content-Length") or 0)
                progress({
                    "url": resp.geturl(),
                    "downloaded_bytes": total,
                    "total_bytes": expected,
                    "bytes_per_second": int(total / elapsed),
                    "elapsed_seconds": round(elapsed, 3),
                })
        meta = {
            "url": resp.geturl(),
            "etag": resp.headers.get("ETag", "").strip(),
            "last_modified": resp.headers.get("Last-Modified", "").strip(),
            "content_length": int(resp.headers.get("Content-Length") or total),
        }
    if total <= 0:
        part.unlink(missing_ok=True)
        raise RuntimeError(f"Downloaded source is empty: {url}")
    md5 = h_md5.hexdigest()
    if expected_md5 and md5.lower() != expected_md5.lower():
        part.unlink(missing_ok=True)
        raise RuntimeError(f"MD5 mismatch for {url}: expected {expected_md5}, got {md5}")
    os.replace(part, target)
    meta.update({
        "size_bytes": total,
        "sha256": h_sha.hexdigest(),
        "md5": md5,
        "duration_seconds": round(time.monotonic() - started, 3),
        "downloaded_utc": utcnow(),
    })
    return meta


def download_text(url: str, timeout: int = 30) -> str:
    with http_request(url, timeout=timeout) as resp:
        return resp.read().decode("utf-8", errors="replace")


def parse_geofabrik_md5(text: str) -> str:
    m = re.search(r"\b([0-9a-fA-F]{32})\b", text)
    return m.group(1).lower() if m else ""


def parse_geofabrik_poly(text: str):
    """Parse a Geofabrik .poly file into an exact Shapely state boundary."""
    from shapely.geometry import Polygon
    from shapely.ops import unary_union

    lines = [line.rstrip() for line in text.splitlines()]
    if not lines:
        raise RuntimeError("Geofabrik .poly file is empty")
    rings: list[tuple[bool, list[tuple[float, float]]]] = []
    current_name: str | None = None
    current: list[tuple[float, float]] = []
    for raw in lines[1:]:
        line = raw.strip()
        if not line:
            continue
        if line == "END":
            if current_name is None:
                break
            if len(current) >= 3:
                if current[0] != current[-1]:
                    current.append(current[0])
                rings.append((current_name.startswith("!"), current))
            current_name = None
            current = []
            continue
        if current_name is None:
            current_name = line
            continue
        parts = line.split()
        if len(parts) != 2:
            continue
        try:
            lon, lat = float(parts[0]), float(parts[1])
        except ValueError:
            continue
        if -180 <= lon <= 180 and -90 <= lat <= 90:
            current.append((lon, lat))

    outers = [Polygon(coords) for is_hole, coords in rings if not is_hole]
    holes = [Polygon(coords) for is_hole, coords in rings if is_hole]
    if not outers:
        raise RuntimeError("Geofabrik .poly file did not contain an exterior ring")
    geom = unary_union([g for g in outers if not g.is_empty and g.is_valid])
    if holes:
        hole_geom = unary_union([g for g in holes if not g.is_empty and g.is_valid])
        if not hole_geom.is_empty:
            geom = geom.difference(hole_geom)
    if geom.is_empty:
        raise RuntimeError("Geofabrik .poly boundary resolved to an empty geometry")
    if not geom.is_valid:
        geom = geom.buffer(0)
    return geom


def parse_poly_bounds(text: str) -> tuple[float, float, float, float]:
    geom = parse_geofabrik_poly(text)
    return tuple(float(x) for x in geom.bounds)


def geofabrik_urls(state: StateInfo) -> dict[str, str]:
    base = f"https://download.geofabrik.de/north-america/us/{state.geofabrik_slug}-latest.osm.pbf"
    return {
        "pbf": base,
        "md5": base + ".md5",
        "poly": f"https://download.geofabrik.de/north-america/us/{state.geofabrik_slug}.poly",
    }


def fetch_geofabrik_boundary(state: StateInfo, target: Path, *, force: bool = False,
                              urls: dict[str, str] | None = None) -> dict[str, Any]:
    """Cache the exact Geofabrik state polygon separately from the OSM PBF."""
    urls = dict(urls or geofabrik_urls(state))
    if force or not target.is_file() or target.stat().st_size <= 0:
        text = download_text(urls["poly"], timeout=30)
        geom = parse_geofabrik_poly(text)  # validate before replacing the cached copy
        atomic_write(target, text.encode("utf-8"))
    else:
        text = target.read_text(encoding="utf-8", errors="replace")
        geom = parse_geofabrik_poly(text)
    return {
        "poly_url": urls["poly"],
        "poly_file": target.name,
        "boundary_sha256": sha256_file(target),
        "bounds": [float(x) for x in geom.bounds],
    }


def load_geofabrik_boundary(path: Path):
    if not path.is_file() or path.stat().st_size <= 0:
        raise RuntimeError(f"State boundary file is missing: {path}")
    return parse_geofabrik_poly(path.read_text(encoding="utf-8", errors="replace"))


def fetch_geofabrik_state(state: StateInfo, target: Path, metadata_path: Path,
                           boundary_path: Path | None = None,
                           progress: Callable[[dict[str, Any]], None] | None = None,
                           urls: dict[str, str] | None = None) -> dict[str, Any]:
    urls = dict(urls or geofabrik_urls(state))
    expected_md5 = ""
    try:
        expected_md5 = parse_geofabrik_md5(download_text(urls["md5"]))
    except Exception:
        # The PBF itself is still SHA-256 verified after download even if the upstream
        # MD5 sidecar is temporarily unavailable.
        expected_md5 = ""
    meta = download_atomic(urls["pbf"], target, timeout=300, expected_md5=expected_md5, progress=progress)
    boundary_path = boundary_path or (metadata_path.parent / "state.poly")
    boundary_meta = fetch_geofabrik_boundary(state, boundary_path, force=True, urls=urls)
    meta.update({
        "source_id": "osm_geofabrik",
        "source_name": "OpenStreetMap / Geofabrik",
        "state": state.code,
        "state_name": state.name,
        **boundary_meta,
        "role": "base_network",
        "applied_to_graph": True,
    })
    atomic_json(metadata_path, meta)
    return meta

def query_params(**kwargs: Any) -> str:
    return urllib.parse.urlencode({k: str(v) for k, v in kwargs.items() if v is not None})


def arcgis_layer_info(layer_url: str) -> dict[str, Any]:
    url = layer_url.rstrip("/") + "?" + query_params(f="json")
    with http_request(url, timeout=60) as resp:
        data = json.loads(resp.read().decode("utf-8", errors="replace"))
    if not isinstance(data, dict) or data.get("error"):
        raise RuntimeError(f"ArcGIS layer metadata failed for {layer_url}: {data.get('error') if isinstance(data, dict) else 'invalid response'}")
    geometry = str(data.get("geometryType") or "")
    capabilities = str(data.get("capabilities") or "")
    if geometry and geometry != "esriGeometryPolyline":
        raise RuntimeError(f"ArcGIS schema changed for {layer_url}: expected polyline, got {geometry}")
    if capabilities and "Query" not in capabilities:
        raise RuntimeError(f"ArcGIS schema changed for {layer_url}: Query capability unavailable")
    advanced = data.get("advancedQueryCapabilities") or {}
    return {
        "geometry_type": geometry,
        "capabilities": capabilities,
        "max_record_count": max(1, int(data.get("maxRecordCount") or 2000)),
        "supports_pagination": bool(advanced.get("supportsPagination", True)),
        "object_id_field": str(data.get("objectIdField") or data.get("objectIdFieldName") or "OBJECTID"),
    }


def arcgis_query_ids(layer_url: str, where: str, bbox: tuple[float, float, float, float] | None) -> list[int | str]:
    params: dict[str, Any] = {"f": "json", "where": where, "returnIdsOnly": "true", "returnGeometry": "false"}
    if bbox is not None:
        params.update({
            "geometry": ",".join(str(v) for v in bbox),
            "geometryType": "esriGeometryEnvelope", "inSR": "4326",
            "spatialRel": "esriSpatialRelIntersects",
        })
    url = layer_url.rstrip("/") + "/query?" + query_params(**params)
    with http_request(url, timeout=120) as resp:
        data = json.loads(resp.read().decode("utf-8", errors="replace"))
    if not isinstance(data, dict) or data.get("error"):
        raise RuntimeError(f"ArcGIS object-id query failed for {layer_url}: {data.get('error') if isinstance(data, dict) else 'invalid response'}")
    ids = data.get("objectIds") or []
    return list(ids) if isinstance(ids, list) else []


def arcgis_query_object_ids(layer_url: str, object_ids: list[int | str], out_fields: str = "*") -> dict[str, Any]:
    params = {
        "f": "geojson", "objectIds": ",".join(str(x) for x in object_ids),
        "outFields": out_fields, "returnGeometry": "true", "outSR": "4326",
    }
    url = layer_url.rstrip("/") + "/query?" + query_params(**params)
    with http_request(url, timeout=120) as resp:
        raw = resp.read()
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise RuntimeError(f"ArcGIS endpoint did not return JSON: {layer_url}") from exc
    if isinstance(data, dict) and data.get("error"):
        raise RuntimeError(f"ArcGIS query failed for {layer_url}: {data['error']}")
    if not isinstance(data, dict) or data.get("type") != "FeatureCollection":
        raise RuntimeError(f"ArcGIS endpoint did not return GeoJSON FeatureCollection: {layer_url}")
    return data


def arcgis_query_page(layer_url: str, where: str, bbox: tuple[float, float, float, float] | None,
                      offset: int, count: int = 2000, out_fields: str = "*") -> dict[str, Any]:
    params: dict[str, Any] = {
        "f": "geojson",
        "where": where,
        "outFields": out_fields,
        "returnGeometry": "true",
        "outSR": "4326",
        "resultOffset": offset,
        "resultRecordCount": count,
    }
    if bbox is not None:
        params.update({
            "geometry": ",".join(str(v) for v in bbox),
            "geometryType": "esriGeometryEnvelope",
            "inSR": "4326",
            "spatialRel": "esriSpatialRelIntersects",
        })
    url = layer_url.rstrip("/") + "/query?" + query_params(**params)
    with http_request(url, timeout=120) as resp:
        raw = resp.read()
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise RuntimeError(f"ArcGIS endpoint did not return JSON: {layer_url}") from exc
    if isinstance(data, dict) and data.get("error"):
        raise RuntimeError(f"ArcGIS query failed for {layer_url}: {data['error']}")
    if not isinstance(data, dict) or data.get("type") != "FeatureCollection":
        raise RuntimeError(f"ArcGIS endpoint did not return GeoJSON FeatureCollection: {layer_url}")
    return data


def _clip_feature_to_boundary(feature: dict[str, Any], boundary: Any) -> dict[str, Any] | None:
    """Clip a normalized GeoJSON feature to the exact state polygon."""
    if boundary is None:
        return feature
    from shapely.geometry import LineString, MultiLineString, mapping, shape

    try:
        original = shape(feature.get("geometry") or {})
    except Exception:
        return None
    if original.is_empty:
        return None
    clipped = original.intersection(boundary)
    if clipped.is_empty:
        return None

    if original.geom_type in ("LineString", "MultiLineString"):
        lines = []
        def collect(g: Any) -> None:
            if g.is_empty:
                return
            if g.geom_type == "LineString":
                if len(g.coords) >= 2:
                    lines.append(g)
            elif g.geom_type in ("MultiLineString", "GeometryCollection"):
                for part in g.geoms:
                    collect(part)
        collect(clipped)
        if not lines:
            return None
        clipped = lines[0] if len(lines) == 1 else MultiLineString([list(g.coords) for g in lines])

    out = dict(feature)
    out["geometry"] = mapping(clipped)
    return out


def _feature_identity(feature: dict[str, Any]) -> str:
    """Stable identity used to deduplicate split-envelope ArcGIS queries."""
    p = feature.get("properties") or {}
    for key in ("OBJECTID", "ObjectID", "objectid", "FID", "GLOBALID", "GlobalID", "globalid", "NGUID"):
        if p.get(key) not in (None, ""):
            return f"{key}:{p.get(key)}"
    raw = json.dumps({"geometry": feature.get("geometry"), "properties": p}, sort_keys=True, separators=(",", ":"), default=str)
    return "sha256:" + hashlib.sha256(raw.encode("utf-8")).hexdigest()


def state_query_bboxes(boundary: Any, state_code: str) -> list[tuple[float, float, float, float]]:
    """Return safe ArcGIS query envelopes for a state boundary.

    Alaska crosses the antimeridian.  A single shapely bounding rectangle can
    therefore become nearly global.  Query two Alaska longitude ranges and let
    exact polygon clipping discard anything outside the Geofabrik boundary.
    """
    code = str(state_code or "").upper()
    if code == "AK":
        return [(-180.0, 48.0, -129.0, 72.5), (170.0, 48.0, 180.0, 72.5)]
    return [tuple(float(x) for x in boundary.bounds)]


def arcgis_download(layer_url: str, target: Path, *, where: str = "1=1",
                    bbox: tuple[float, float, float, float] | None = None,
                    bboxes: list[tuple[float, float, float, float]] | None = None,
                    normalize: Callable[[dict[str, Any]], dict[str, Any] | None] | None = None,
                    clip_boundary: Any = None,
                    page_size: int = 2000,
                    stream_ndjson: bool = False) -> dict[str, Any]:
    """Download/normalize a queryable ArcGIS line layer.

    Large state inventories are written incrementally as GeoJSON Lines when
    ``stream_ndjson`` is enabled so Texas-sized layers do not need to live in
    RAM as one giant FeatureCollection.  Existing GeoJSON callers retain the
    historical format for compatibility.
    """
    target.parent.mkdir(parents=True, exist_ok=True)
    query_boxes = list(bboxes or ([] if bbox is None else [bbox])) or [None]
    raw_count = 0
    clipped_out = 0
    feature_count = 0
    seen: set[str] = set()
    tmp = target.with_name(target.name + f".part-{os.getpid()}-{int(time.time()*1000)}")
    features: list[dict[str, Any]] = []
    out = tmp.open("w", encoding="utf-8") if stream_ndjson else None
    layer_info = arcgis_layer_info(layer_url)
    effective_page_size = max(1, min(int(page_size), int(layer_info.get("max_record_count") or page_size)))

    def consume(raw_features: list[dict[str, Any]]) -> None:
        nonlocal raw_count, clipped_out, feature_count
        raw_count += len(raw_features)
        for original in raw_features:
            key = _feature_identity(original)
            if key in seen:
                continue
            seen.add(key)
            f = original
            if normalize:
                f = normalize(f)
                if f is None:
                    continue
            before = f
            f = _clip_feature_to_boundary(f, clip_boundary)
            if f is None:
                if before is not None:
                    clipped_out += 1
                continue
            feature_count += 1
            if stream_ndjson:
                out.write(json.dumps(f, separators=(",", ":"), ensure_ascii=False) + "\n")
            else:
                features.append(f)

    try:
        for query_bbox in query_boxes:
            if layer_info.get("supports_pagination", True):
                offset = 0
                while True:
                    page = arcgis_query_page(layer_url, where, query_bbox, offset, effective_page_size)
                    raw_features = page.get("features") or []
                    consume(raw_features)
                    if len(raw_features) < effective_page_size:
                        break
                    offset += len(raw_features)
                    if offset > 2_000_000:
                        raise RuntimeError(f"ArcGIS pagination safety limit exceeded: {layer_url}")
            else:
                object_ids = arcgis_query_ids(layer_url, where, query_bbox)
                for start in range(0, len(object_ids), effective_page_size):
                    page = arcgis_query_object_ids(layer_url, object_ids[start:start + effective_page_size])
                    consume(page.get("features") or [])
        if stream_ndjson:
            out.flush(); os.fsync(out.fileno()); out.close(); out = None
            os.replace(tmp, target)
        else:
            atomic_json(target, {"type": "FeatureCollection", "features": features})
            if tmp.exists(): tmp.unlink()
    except Exception:
        if out is not None:
            out.close()
        try: tmp.unlink()
        except FileNotFoundError: pass
        raise
    return {
        "url": layer_url,
        "format": "geojsonl" if stream_ndjson else "geojson",
        "feature_count": feature_count,
        "queried_feature_count": raw_count,
        "outside_state_dropped": clipped_out,
        "query_envelopes": len(query_boxes),
        "pagination_mode": "offset" if layer_info.get("supports_pagination", True) else "object_ids",
        "size_bytes": target.stat().st_size,
        "sha256": sha256_file(target),
        "downloaded_utc": utcnow(),
    }

def _props(feature: dict[str, Any]) -> dict[str, Any]:
    p = feature.get("properties")
    return p if isinstance(p, dict) else {}


def _first(p: dict[str, Any], *keys: str) -> str:
    lower = {str(k).lower(): v for k, v in p.items()}
    for key in keys:
        v = lower.get(key.lower())
        if v is not None and str(v).strip():
            return str(v).strip()
    return ""


def _truthy(value: Any) -> bool:
    return str(value or "").strip().lower() in {"y", "yes", "true", "1", "open", "allowed"}


def _value_ci(properties: dict[str, Any], key: str) -> Any:
    wanted = key.lower()
    for k, value in properties.items():
        if str(k).lower() == wanted:
            return value
    return None


def _falsey(value: Any) -> bool:
    return str(value or "").strip().lower() in {"n", "no", "false", "0", "closed", "prohibited", "not allowed"}


def _text_blob(properties: dict[str, Any], *keys: str) -> str:
    values = []
    for key in keys:
        value = _value_ci(properties, key)
        if value is not None and str(value).strip():
            values.append(str(value).strip())
    return " ".join(values).lower()


def _fullsize_vehicle_evidence(properties: dict[str, Any], *extra_fields: str) -> bool:
    """Return True only for affirmative full-size/highway-vehicle evidence.

    Generic words such as ``motorized`` or ``OHV`` are intentionally insufficient
    because they may describe motorcycle-, ATV-, or UTV-only single-track.
    """
    explicit_flag_fields = (
        "passengervehicle", "highclearancevehicle", "truck", "bus", "motorhome",
        "fourwd_gt50inches", "twowd_gt50inches", "tracked_ohv_gt50inches",
        "other_ohv_gt50inches", "fullsizevehicle", "full_size_vehicle", "streetlegalvehicle",
        "automobile", "car",
    )
    if any(_truthy(_value_ci(properties, key)) for key in explicit_flag_fields):
        return True
    blob = _text_blob(
        properties,
        "allowed_use", "allowed_uses", "designateduses", "designated_uses",
        "vehicleclass", "vehicle_class", "vehicle_type", "vehicletype",
        "travel_mode", "mode", "motorizeduse", "routeclass", "route_class",
        "routetype", "route_type", "trluse", "trltype", "trlclass",
        "accessnotes", "notes", "comments", *extra_fields,
    )
    positive_tokens = (
        "4wd", "4-wheel drive", "four wheel drive", "4x4", "high clearance",
        "full size", "full-size", "passenger vehicle", "street legal", "street-legal",
        "automobile", "auto vehicle", "motor vehicle", "jeep", "truck", "suv",
        "2wd", "two wheel drive", "technical vehicle", "road vehicle",
    )
    return any(token in blob for token in positive_tokens)


def _narrow_only_evidence(properties: dict[str, Any], *extra_fields: str) -> bool:
    blob = _text_blob(
        properties, "allowed_use", "allowed_uses", "designateduses", "vehicleclass",
        "vehicle_type", "travel_mode", "motorizeduse", "trluse", "trltype",
        "routeclass", "routetype", "notes", "comments", *extra_fields,
    )
    narrow_tokens = (
        "motorcycle only", "motorcycles only", "motorbike only", "atv only",
        "utv only", "side-by-side only", "side by side only", "snowmobile only",
        "singletrack", "single-track", "motorcycle/atv", "atv/utv only",
    )
    return any(token in blob for token in narrow_tokens)


def _closed_or_private(properties: dict[str, Any], *extra_fields: str) -> bool:
    for key in ("opentopublic", "publicdisplay", "open_to_public", "public_access"):
        value = _value_ci(properties, key)
        if value is not None and _falsey(value):
            return True
    blob = _text_blob(
        properties, "status", "trlstatus", "access", "access_status", "accessnotes",
        "otherrestrictions", "restriction", "restrictions", "notes", *extra_fields,
    )
    blocked = (
        "closed", "prohibited", "no public access", "administrative only",
        "authorized users only", "permit only", "private", "decommissioned",
        "abandoned",
    )
    return any(token in blob for token in blocked)


def _wide_vehicle_evidence(properties: dict[str, Any]) -> bool:
    """Conservative fallback for state trail datasets that publish a width field."""
    raw = _first(properties, "trailwidth", "trail_width", "width", "routewidth")
    if not raw:
        return False
    text = raw.lower().strip()
    if any(token in text for token in ("road", "unlimited", "full size", "full-size")):
        return True
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:in|inch|inches|\")", text)
    if m:
        return float(m.group(1)) >= 80.0
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:ft|feet|foot|')", text)
    if m:
        return float(m.group(1)) >= 6.75
    return False


def normalize_usfs(feature: dict[str, Any], kind: str) -> dict[str, Any] | None:
    geom = feature.get("geometry") or {}
    if geom.get("type") not in ("LineString", "MultiLineString"):
        return None
    p = _props(feature)
    # TAK Rig's Valhalla profile is for a road-going/high-clearance vehicle, not
    # motorcycle/ATV-only single-track. Require at least one >50-inch/highway-legal
    # vehicle class when the MVUM vehicle flags are present.
    fullsize_fields = (
        "passengervehicle", "highclearancevehicle", "truck", "bus", "motorhome",
        "fourwd_gt50inches", "twowd_gt50inches", "tracked_ohv_gt50inches",
        "other_ohv_gt50inches",
    )
    present = {str(x).lower() for x in p}
    fullsize_allowed = any(_truthy(_value_ci(p, k)) for k in fullsize_fields) or _fullsize_vehicle_evidence(
        p, "alloweduses", "allowed_use", "vehicleclass", "travel_mode", "routeclass"
    )
    if any(k in present for k in fullsize_fields) and not fullsize_allowed:
        return None
    symbol = _first(p, "symbol")
    if kind == "road" and symbol and symbol not in {"1", "2", "3", "4", "11", "12"}:
        return None
    # The trail service is motorized-only, but if all full-size flags are missing
    # entirely we cannot safely assume a truck/SUV is allowed.
    if kind == "trail" and not fullsize_allowed:
        return None
    p.update({
        "takrig_source": "usfs_mvum",
        "takrig_source_name": "U.S. Forest Service MVUM",
        "takrig_routing_role": "authoritative_motorized",
        "takrig_routable": True,
        "takrig_highway": "track",
        "takrig_name": _first(p, "name", "rte_cn", "id"),
        "takrig_surface": _first(p, "surfacetype"),
        "takrig_seasonal": _first(p, "seasonal", "passengervehicle_datesopen", "highclearancevehicle_datesopen"),
        "takrig_high_clearance": _truthy(_value_ci(p, "highclearancevehicle")) or _truthy(_value_ci(p, "fourwd_gt50inches")),
    })
    feature["properties"] = p
    return feature


def normalize_blm(feature: dict[str, Any], layer_id: int) -> dict[str, Any] | None:
    geom = feature.get("geometry") or {}
    if geom.get("type") not in ("LineString", "MultiLineString"):
        return None
    p = _props(feature)
    allowed_mode = _first(p, "PLAN_ALLOW_MODE_TRNSPRT").upper()
    observed_use = _first(p, "OBSRVE_ROUTE_USE_CLASS").upper()
    ohv_designation = _first(p, "PLAN_OHV_ROUTE_DSGNTN").upper()
    access_restriction = _first(p, "PLAN_ACCESS_RSTRCT").upper()
    limitation = _first(p, "OHV_ROUTE_DSGNTN_LIM")
    limitation_explain = _first(p, "OHV_DSGNTN_LIM_EXPLAIN")

    fullsize_mode_codes = {
        "ALL_MOTO_VEH", "STRT_LGL_VEH", "TECH_VEH_SHARED", "TECH_VEH_ONLY",
    }
    narrow_only_prefixes = ("MTC_", "ATV_", "UTV_", "MTC_ONLY", "TECH_MTC")
    explicit_fullsize = allowed_mode in fullsize_mode_codes or any(
        token in observed_use for token in ("2WD", "4WD", "HIGH CLEARANCE", "TECHNICAL VEHICLE", "FULL SIZE", "STREET LEGAL")
    ) or _fullsize_vehicle_evidence(p, "PLAN_ALLOW_MODE_TRNSPRT", "OBSRVE_ROUTE_USE_CLASS", "PLAN_ASSET_CLASS")
    explicit_narrow_only = any(allowed_mode.startswith(prefix) for prefix in narrow_only_prefixes)
    closed = ohv_designation == "CLOSED"
    restricted_to_nonpublic = access_restriction in {"ADMIN ONLY", "AUTHORIZED/PERMITTED USER ONLY"}

    # Public/limited *road* layers are generally suitable for a road-going vehicle
    # unless the attributes explicitly narrow them to smaller vehicles. Trail
    # layers require affirmative full-size/4WD evidence to avoid routing a truck
    # down motorcycle/ATV single-track.
    if layer_id in (0, 1):
        routable = not (closed or restricted_to_nonpublic or explicit_narrow_only)
    else:
        routable = explicit_fullsize and not (closed or restricted_to_nonpublic)
    if not routable:
        return None

    seasonal_status = _first(p, "PLAN_SEASON_RSTRCT_CODE")
    seasonal = " / ".join(x for x in (seasonal_status, limitation, limitation_explain) if x)
    p.update({
        "takrig_source": "blm_gtlf",
        "takrig_source_name": "Bureau of Land Management GTLF",
        "takrig_routing_role": "authoritative_motorized",
        "takrig_routable": True,
        "takrig_highway": "track",
        "takrig_name": _first(p, "ROUTE_PRMRY_NM", "ROUTE_NAME", "NAME", "ROUTE_ID", "GTLF_NAME"),
        "takrig_limited": layer_id in (1, 3) or bool(limitation),
        "takrig_ohv_designation": ohv_designation,
        "takrig_asset_class": _first(p, "PLAN_ASSET_CLASS"),
        "takrig_surface": _first(p, "OBSRVE_SRFCE_TYPE"),
        "takrig_seasonal": seasonal,
        "takrig_high_clearance": "4WD" in observed_use or "HIGH CLEARANCE" in observed_use or "TECH" in observed_use,
    })
    feature["properties"] = p
    return feature


def normalize_nps_road(feature: dict[str, Any]) -> dict[str, Any] | None:
    geom = feature.get("geometry") or {}
    if geom.get("type") not in ("LineString", "MultiLineString"):
        return None
    p = _props(feature)
    p.update({
        "takrig_source": "nps_public_roads",
        "takrig_source_name": "National Park Service Public Roads",
        "takrig_routing_role": "public_road_supplement",
        "takrig_routable": True,
        "takrig_highway": "unclassified",
        "takrig_name": _first(p, "ROUTENAME", "ROAD_NAME", "NAME", "RDNAME"),
    })
    feature["properties"] = p
    return feature


def normalize_nps_trail(feature: dict[str, Any]) -> dict[str, Any] | None:
    geom = feature.get("geometry") or {}
    if geom.get("type") not in ("LineString", "MultiLineString"):
        return None
    p = _props(feature)
    fullsize = _fullsize_vehicle_evidence(p, "TRLUSE", "TRLTYPE", "TRLCLASS", "ACCESSNOTES")
    blocked = _closed_or_private(p, "TRLSTATUS", "OPENTOPUBLIC", "PUBLICDISPLAY")
    narrow_only = _narrow_only_evidence(p, "TRLUSE", "TRLTYPE", "TRLCLASS") and not fullsize
    routable = bool(fullsize and not blocked and not narrow_only)
    use_text = _text_blob(p, "TRLUSE", "TRLTYPE", "TRLCLASS", "ACCESSNOTES")
    p.update({
        "takrig_source": "nps_public_trails",
        "takrig_source_name": "National Park Service Public Trails",
        "takrig_routing_role": "authoritative_motorized" if routable else "reference_only",
        "takrig_routable": routable,
        "takrig_highway": "track",
        "takrig_name": _first(p, "TRLNAME", "MAPLABEL", "TRLALTNAME", "NAME"),
        "takrig_surface": _first(p, "TRLSURFACE"),
        "takrig_seasonal": " / ".join(x for x in (_first(p, "SEASONAL"), _first(p, "SEASDESC")) if x),
        "takrig_high_clearance": any(token in use_text for token in ("4wd", "4-wheel drive", "four wheel drive", "4x4", "high clearance")),
    })
    feature["properties"] = p
    return feature


def normalize_usgs_4wd(feature: dict[str, Any]) -> dict[str, Any] | None:
    geom = feature.get("geometry") or {}
    if geom.get("type") not in ("LineString", "MultiLineString"):
        return None
    p = _props(feature)
    p.update({
        "takrig_source": "usgs_4wd",
        "takrig_source_name": "USGS National Transportation 4WD Roads",
        "takrig_routing_role": "authoritative_motorized",
        "takrig_routable": True,
        "takrig_highway": "track",
        "takrig_name": _first(p, "name", "federal_lands_route", "state_route", "county_route"),
        "takrig_high_clearance": True,
    })
    feature["properties"] = p
    return feature


def normalize_state_motorized_trail(feature: dict[str, Any], source_id: str, source_name: str) -> dict[str, Any] | None:
    geom = feature.get("geometry") or {}
    if geom.get("type") not in ("LineString", "MultiLineString"):
        return None
    p = _props(feature)
    explicit_fullsize = _fullsize_vehicle_evidence(
        p, "motorizeduse", "DesignatedUses", "ROUTECLASS", "ROUTETYPE",
        "TRAIL_TYPE", "USE_TYPE", "VEHICLE_TYPE",
    )
    roadish = any(token in _text_blob(p, "Class", "CartoCode", "ROUTECLASS", "ROUTETYPE", "TRAIL_TYPE")
                  for token in ("4wd road", "4x4 road", "jeep road", "vehicle road", "forest road", "two-track", "two track", "road"))
    motorized_allowed = any(_truthy(_value_ci(p, key)) for key in (
        "MotorizedAllowed", "motor_vehicle", "motorvehicle", "streetlegalvehicle", "passengervehicle"
    ))
    generic_use = _text_blob(p, "motorizeduse", "DesignatedUses", "ROUTECLASS", "ROUTETYPE", "TRAIL_TYPE", "USE_TYPE")
    motorized_signal = motorized_allowed or any(token in generic_use for token in ("motorized", "motor vehicle", "ohv", "4wd", "4x4"))
    fullsize = explicit_fullsize or (_wide_vehicle_evidence(p) and motorized_signal)
    blocked = _closed_or_private(p, "status", "OtherRestrictions")
    narrow_only = _narrow_only_evidence(p, "motorizeduse", "DesignatedUses", "trailwidth") and not fullsize
    routable = bool(not blocked and not narrow_only and (fullsize or (roadish and motorized_allowed)))
    evidence = _text_blob(p, "motorizeduse", "DesignatedUses", "ROUTECLASS", "ROUTETYPE", "trailwidth", "Class")
    p.update({
        "takrig_source": source_id,
        "takrig_source_name": source_name,
        "takrig_routing_role": "state_recreation_authority" if routable else "reference_only",
        "takrig_routable": routable,
        "takrig_highway": "track",
        "takrig_name": _first(p, "trailname", "TRAIL_NAME", "PrimaryName", "ROUTENAME", "ROUTE_NAME", "NAME", "systemname"),
        "takrig_surface": _first(p, "trailsurface", "SurfaceType", "TRLSURFACE", "SURFACE", "ROUTESURFACE"),
        "takrig_seasonal": _first(p, "SEASONAL", "SEASON", "DATESOPEN", "OPEN_DATES", "OtherRestrictions"),
        "takrig_high_clearance": any(token in evidence for token in ("4wd", "4-wheel drive", "four wheel drive", "4x4", "high clearance", "jeep")),
    })
    feature["properties"] = p
    return feature


def normalize_reference(feature: dict[str, Any], source_id: str, source_name: str) -> dict[str, Any] | None:
    geom = feature.get("geometry") or {}
    if geom.get("type") not in ("LineString", "MultiLineString"):
        return None
    p = _props(feature)
    p.update({
        "takrig_source": source_id,
        "takrig_source_name": source_name,
        "takrig_routing_role": "reference_only",
        "takrig_routable": False,
        "takrig_name": _first(p, "NAME", "name", "ROUTENAME", "ROUTE_NAME"),
    })
    feature["properties"] = p
    return feature


def normalize_state_dot_legacy(feature: dict[str, Any], source_id: str, source_name: str) -> dict[str, Any] | None:
    """r25 state-road normalization retained for already validated CA/UT profiles."""
    geom = feature.get("geometry") or {}
    if geom.get("type") not in ("LineString", "MultiLineString"):
        return None
    p = _props(feature)
    p.update({
        "takrig_source": source_id,
        "takrig_source_name": source_name,
        "takrig_routing_role": "public_road_authority",
        "takrig_routable": True,
        "takrig_highway": "unclassified",
        "takrig_name": _first(p, "ROAD_NAME", "RouteId", "ROUTE_NAME", "FULLNAME", "STREETNAME", "ROAD_LABEL"),
    })
    feature["properties"] = p
    return feature


def normalize_state_dot(feature: dict[str, Any], source_id: str, source_name: str) -> dict[str, Any] | None:
    geom = feature.get("geometry") or {}
    if geom.get("type") not in ("LineString", "MultiLineString"):
        return None
    p = _props(feature)
    for public_key in ("PUBLIC", "PUBLIC_ROAD", "PUBLICROAD", "OPEN_TO_PUBLIC", "OPENTOPUBLIC"):
        value = _value_ci(p, public_key)
        if value is not None and _falsey(value):
            return None
    # State road layers are authoritative supplements, but some statewide GIS
    # inventories also contain planned, private, closed, abandoned or
    # non-public segments.  Explicit negative access evidence always wins.
    if _closed_or_private(
        p, "ROAD_STATUS", "ROADSTATUS", "STATUS_DESC", "STATUS_DESCRIPTION",
        "PUBLIC", "PUBLIC_ROAD", "PUBLICROAD", "ACCESS_CODE", "ACCESSCONTROL",
        "FACILITY_TYPE", "FACILITYTYPE", "CONSTRUCTED",
    ):
        return None
    constructed = _first(p, "CONSTRUCTED").strip().lower()
    if constructed in {"no", "n", "false", "0", "unconstructed"}:
        return None
    status_blob = _text_blob(p, "ROAD_STATUS", "ROADSTATUS", "STATUS_DESC", "STATUS_DESCRIPTION", "ROAD_CLASS", "ROADCLASS")
    if any(token in status_blob for token in ("proposed", "planned", "future", "vacated")):
        return None
    highway = "unclassified"
    class_blob = _text_blob(p, "FUNCTIONAL_CLASS", "FUNCTIONALCLASS", "FUNC_CLASS_NAME", "F_SYSTEM", "FSYSTEM", "ROAD_CLASS", "ROADCLASS", "ROUTE_SYSTEM", "ROUTE_TYPE")
    if "interstate" in class_blob or "freeway" in class_blob:
        highway = "motorway"
    elif "principal arterial" in class_blob or "expressway" in class_blob:
        highway = "trunk"
    elif "minor arterial" in class_blob:
        highway = "primary"
    elif "major collector" in class_blob:
        highway = "secondary"
    elif "minor collector" in class_blob:
        highway = "tertiary"
    elif "local" in class_blob or "street" in class_blob:
        highway = "unclassified"
    surface = _first(p, "SURFACE", "SURFACE_TYPE", "SURFACETYPE", "SURFACE_TY", "PAVEMENT", "PAVEMENT_TYPE")
    evidence = _text_blob(p, "ROAD_CLASS", "ROADCLASS", "ROUTE_TYPE", "ROUTE_SYSTEM", "SURFACE", "SURFACE_TYPE")
    p.update({
        "takrig_source": source_id,
        "takrig_source_name": source_name,
        "takrig_routing_role": "public_road_authority",
        "takrig_routable": True,
        "takrig_highway": highway,
        "takrig_name": _first(p, "ROAD_NAME", "RouteId", "ROUTE_ID", "ROUTE", "ROUTE_NAME", "FULLNAME", "FULL_NAME", "STREETNAME", "STREET_NAME", "ROAD_LABEL", "NAME"),
        "takrig_surface": surface,
        "takrig_high_clearance": any(token in evidence for token in ("4wd", "4x4", "high clearance", "jeep", "primitive road")),
    })
    feature["properties"] = p
    return feature


def normalize_state_ohv_route(feature: dict[str, Any], source_id: str, source_name: str) -> dict[str, Any] | None:
    geom = feature.get("geometry") or {}
    if geom.get("type") not in ("LineString", "MultiLineString"):
        return None
    p = _props(feature)
    p.update({
        "takrig_source": source_id,
        "takrig_source_name": source_name,
        "takrig_routing_role": "state_recreation_authority",
        "takrig_routable": True,
        "takrig_highway": "track",
        "takrig_name": _first(p, "NAME", "ROUTE_NAME", "ROUTENAME", "PrimaryName", "TRAIL_NAME"),
        "takrig_seasonal": _first(p, "SEASONAL", "SEASON", "DATESOPEN", "OPEN_DATES"),
    })
    feature["properties"] = p
    return feature


def normalize_ca_state_parks(feature: dict[str, Any]) -> dict[str, Any] | None:
    geom = feature.get("geometry") or {}
    if geom.get("type") not in ("LineString", "MultiLineString"):
        return None
    p = _props(feature)
    route_class = _first(p, "ROUTECLASS", "RouteClass").lower()
    route_type = _first(p, "ROUTETYPE", "RouteType").lower()
    # California State Parks public roads are high-trust; generic park trails stay
    # reference-only unless their attributes explicitly identify motorized/OHV use.
    fullsize = _fullsize_vehicle_evidence(p, "ROUTECLASS", "ROUTETYPE")
    is_road = any(token in route_class for token in ("local road", "state park road", "road"))
    blocked = _closed_or_private(p)
    routable = bool(not blocked and (is_road or fullsize))
    p.update({
        "takrig_source": "ca_state_parks",
        "takrig_source_name": "California State Parks / OHMVR",
        "takrig_routing_role": "state_recreation_authority" if routable else "reference_only",
        "takrig_routable": routable,
        "takrig_highway": "track" if fullsize and not is_road else "service",
        "takrig_name": _first(p, "ROUTENAME", "ROUTE_NAME", "NAME"),
        "takrig_high_clearance": any(token in (route_class + " " + route_type) for token in ("4wd", "4x4", "high clearance", "jeep")),
    })
    feature["properties"] = p
    return feature


@dataclass(frozen=True)
class SupplementalSpec:
    source_id: str
    name: str
    role: str
    layer_url: str
    file_name: str
    routable: bool
    where_factory: Callable[[StateInfo], str] | None = None
    bbox_filter: bool = True
    state_codes: tuple[str, ...] | None = None
    normalizer: Callable[[dict[str, Any]], dict[str, Any] | None] | None = None
    profile_revision: str = ""
    streaming: bool = False

    def supports(self, state: StateInfo) -> bool:
        return self.state_codes is None or state.code in self.state_codes


# National/federal sources with stable public REST services.
NATIONAL_SPECS: tuple[SupplementalSpec, ...] = (
    SupplementalSpec(
        "usfs_mvum_roads", "U.S. Forest Service MVUM Roads", "authoritative_motorized",
        "https://apps.fs.usda.gov/arcx/rest/services/EDW/EDW_MVUM_02/MapServer/1",
        "usfs-mvum-roads.geojson", True,
        normalizer=lambda f: normalize_usfs(f, "road"),
    ),
    SupplementalSpec(
        "usfs_mvum_trails", "U.S. Forest Service MVUM Trails", "authoritative_motorized",
        "https://apps.fs.usda.gov/arcx/rest/services/EDW/EDW_MVUM_02/MapServer/2",
        "usfs-mvum-trails.geojson", True,
        normalizer=lambda f: normalize_usfs(f, "trail"),
    ),
    SupplementalSpec(
        "blm_public_motorized_roads", "BLM Public Motorized Roads", "authoritative_motorized",
        "https://gis.blm.gov/arcgis/rest/services/transportation/BLM_Natl_GTLF_Public_Display/MapServer/0",
        "blm-public-motorized-roads.geojson", True,
        where_factory=lambda s: f"ADMIN_ST='{s.code}'", bbox_filter=False,
        normalizer=lambda f: normalize_blm(f, 0),
    ),
    SupplementalSpec(
        "blm_limited_motorized_roads", "BLM Limited Public Motorized Roads", "authoritative_motorized",
        "https://gis.blm.gov/arcgis/rest/services/transportation/BLM_Natl_GTLF_Public_Display/MapServer/1",
        "blm-limited-motorized-roads.geojson", True,
        where_factory=lambda s: f"ADMIN_ST='{s.code}'", bbox_filter=False,
        normalizer=lambda f: normalize_blm(f, 1),
    ),
    SupplementalSpec(
        "blm_public_motorized_trails", "BLM Public Motorized Trails", "authoritative_motorized",
        "https://gis.blm.gov/arcgis/rest/services/transportation/BLM_Natl_GTLF_Public_Display/MapServer/2",
        "blm-public-motorized-trails.geojson", True,
        where_factory=lambda s: f"ADMIN_ST='{s.code}'", bbox_filter=False,
        normalizer=lambda f: normalize_blm(f, 2),
    ),
    SupplementalSpec(
        "blm_limited_motorized_trails", "BLM Limited Public Motorized Trails", "authoritative_motorized",
        "https://gis.blm.gov/arcgis/rest/services/transportation/BLM_Natl_GTLF_Public_Display/MapServer/3",
        "blm-limited-motorized-trails.geojson", True,
        where_factory=lambda s: f"ADMIN_ST='{s.code}'", bbox_filter=False,
        normalizer=lambda f: normalize_blm(f, 3),
    ),
    SupplementalSpec(
        "nps_public_roads", "National Park Service Public Roads", "public_road_supplement",
        "https://mapservices.nps.gov/arcgis/rest/services/NationalDatasets/NPS_Public_Roads/FeatureServer/0",
        "nps-public-roads.geojson", True,
        normalizer=normalize_nps_road,
    ),
    SupplementalSpec(
        "nps_public_trails", "National Park Service Public Trails", "authoritative_motorized",
        "https://mapservices.nps.gov/arcgis/rest/services/NationalDatasets/NPS_Public_Trails/FeatureServer/0",
        "nps-public-trails.geojson", True,
        normalizer=normalize_nps_trail,
    ),
    SupplementalSpec(
        "usgs_4wd", "USGS National Transportation 4WD Roads", "authoritative_motorized",
        "https://carto.nationalmap.gov/arcgis/rest/services/transportation/MapServer/35",
        "usgs-4wd.geojson", True,
        normalizer=normalize_usgs_4wd,
    ),
    SupplementalSpec(
        "usgs_trails", "USGS National Transportation Trails", "reference_only",
        "https://carto.nationalmap.gov/arcgis/rest/services/transportation/MapServer/37",
        "usgs-trails-reference.geojson", False,
        normalizer=lambda f: normalize_reference(f, "usgs_trails", "USGS National Transportation Trails"),
    ),
)

# State public-road authorities. Coverage grows adapter-by-adapter without changing
# the user-facing source model. OSM remains the base if a state DOT adapter is absent.
STATE_DOT_SPECS: dict[str, SupplementalSpec] = {
    "CA": SupplementalSpec(
        "ca_dot_all_roads", "Caltrans All Roads", "public_road_authority",
        "https://caltrans-gis.dot.ca.gov/arcgis/rest/services/CHhighway/All_Roads/FeatureServer/0",
        "state-dot-all-roads.geojson", True, state_codes=("CA",),
        normalizer=lambda f: normalize_state_dot_legacy(f, "ca_dot_all_roads", "Caltrans All Roads"),
    ),
    "UT": SupplementalSpec(
        "ut_dot_roads", "Utah Roads / UDOT / UGRC", "public_road_authority",
        "https://services1.arcgis.com/99lidPhWCzftIe9K/ArcGIS/rest/services/UtahRoads/FeatureServer/0",
        "state-dot-all-roads.geojson", True, state_codes=("UT",),
        normalizer=lambda f: normalize_state_dot_legacy(f, "ut_dot_roads", "Utah Roads / UDOT / UGRC"),
    ),
}

STATE_RECREATION_SPECS: dict[str, tuple[SupplementalSpec, ...]] = {
    "AZ": (
        # Arizona State Parks trail geometry is evaluated per feature. Only explicit
        # full-size motor-vehicle evidence is promoted into the routing graph.
        SupplementalSpec(
            "az_state_parks_trails", "Arizona State Parks & Trails", "state_recreation_authority",
            "https://services1.arcgis.com/KbxwQRRfWyEYLgp4/ArcGIS/rest/services/Arizona_State_Parks_and_Trails_Freedom_250/FeatureServer/62",
            "az-state-parks-trails.geojson", True, state_codes=("AZ",),
            normalizer=lambda f: normalize_state_motorized_trail(f, "az_state_parks_trails", "Arizona State Parks & Trails"),
        ),
    ),
    "CA": (
        SupplementalSpec(
            "ca_state_parks_routes", "California State Parks Roads & Trails", "state_recreation_authority",
            "https://services2.arcgis.com/AhxrK3F6WM8ECvDi/arcgis/rest/services/RecreationalRoutes/FeatureServer/0",
            "ca-state-parks-routes.geojson", True, state_codes=("CA",),
            normalizer=normalize_ca_state_parks,
        ),
        # OHMVR/SVRA route geometry is evaluated per feature. Motorcycle/ATV/UTV-only
        # records remain reference-only; explicit full-size vehicle routes may route.
        SupplementalSpec(
            "ca_ohmvr_routes", "California State Parks OHMVR / SVRA Routes", "state_recreation_authority",
            "https://services2.arcgis.com/AhxrK3F6WM8ECvDi/arcgis/rest/services/RecreationalRoutes_OHV/FeatureServer/2",
            "ca-ohmvr-svra-routes.geojson", True, state_codes=("CA",),
            normalizer=lambda f: normalize_state_motorized_trail(f, "ca_ohmvr_routes", "California State Parks OHMVR / SVRA Routes"),
        ),
    ),
    "NV": (
        # Nevada Trail Finder's motorized layer blends authoritative and planning
        # sources and explicitly warns that some BLM trail data is provisional.
        SupplementalSpec(
            "nv_outdoor_recreation_motorized", "Nevada Division of Outdoor Recreation Motorized Trails", "state_recreation_authority",
            "https://arcgis.water.nv.gov/arcgis/rest/services/Hosted/SCORP_Moto/FeatureServer/0",
            "nv-motorized-trails.geojson", True, state_codes=("NV",),
            normalizer=lambda f: normalize_state_motorized_trail(f, "nv_outdoor_recreation_motorized", "Nevada Division of Outdoor Recreation Motorized Trails"),
        ),
    ),
    "NM": (
        # The official New Mexico OHV Recreation Atlas identifies designated
        # state-highway OHV routes. Those explicit route features may establish
        # motorized routability; broader authorization polygons are not injected.
        SupplementalSpec(
            "nm_state_highway_ohv_routes", "New Mexico OHV Recreation Atlas - State Highway OHV Routes", "state_recreation_authority",
            "https://services2.arcgis.com/CjbW1bVhK4dB3WOa/ArcGIS/rest/services/New_Mexico_OHV_Recreation_Atlas_Finder_v2_WFL1/FeatureServer/8",
            "nm-state-highway-ohv-routes.geojson", True, state_codes=("NM",),
            normalizer=lambda f: normalize_state_ohv_route(f, "nm_state_highway_ohv_routes", "New Mexico OHV Recreation Atlas - State Highway OHV Routes"),
        ),
    ),
    "UT": (
        # Utah Trails and Pathways includes MotorizedAllowed and DesignatedUses.
        # Because much of the statewide layer is non-motorized, only records with
        # additional full-size/road-class evidence are promoted into routing.
        SupplementalSpec(
            "ut_trails_pathways", "Utah Trails and Pathways", "state_recreation_authority",
            "https://services1.arcgis.com/99lidPhWCzftIe9K/ArcGIS/rest/services/TrailsAndPathways/FeatureServer/0",
            "ut-trails-pathways.geojson", True, state_codes=("UT",),
            normalizer=lambda f: normalize_state_motorized_trail(f, "ut_trails_pathways", "Utah Trails and Pathways"),
        ),
    ),
}


def _road_profile_specs(state_code: str) -> tuple[SupplementalSpec, ...]:
    specs: list[SupplementalSpec] = []
    for row in STATE_ROAD_PROFILES.get(state_code, ()):
        sid = str(row["source_id"]); name = str(row["name"])
        specs.append(SupplementalSpec(
            sid, name, "public_road_authority", str(row["layer_url"]), str(row["file_name"]), True,
            state_codes=(state_code,),
            normalizer=lambda f, sid=sid, name=name: normalize_state_dot(f, sid, name),
            profile_revision=str(row.get("profile_revision") or ""),
            streaming=bool(row.get("streaming", True)),
        ))
    return tuple(specs)


def _recreation_profile_specs(state_code: str) -> tuple[SupplementalSpec, ...]:
    specs: list[SupplementalSpec] = []
    for row in STATE_RECREATION_PROFILES.get(state_code, ()):
        sid = str(row["source_id"]); name = str(row["name"])
        specs.append(SupplementalSpec(
            sid, name, "state_recreation_authority", str(row["layer_url"]), str(row["file_name"]), True,
            state_codes=(state_code,),
            normalizer=lambda f, sid=sid, name=name: normalize_state_motorized_trail(f, sid, name),
            profile_revision=str(row.get("profile_revision") or ""),
            streaming=bool(row.get("streaming", True)),
        ))
    return tuple(specs)


def all_available_specs_for_state(state: StateInfo) -> list[SupplementalSpec]:
    """Return every built-in supplemental source known for *state*, regardless of enable state."""
    result = [spec for spec in NATIONAL_SPECS if spec.supports(state)]
    if state.code in STATE_DOT_SPECS:
        result.append(STATE_DOT_SPECS[state.code])
    result.extend(_road_profile_specs(state.code))
    result.extend(STATE_RECREATION_SPECS.get(state.code, ()))
    result.extend(_recreation_profile_specs(state.code))
    return result


def spec_group(spec: SupplementalSpec) -> str:
    if spec in NATIONAL_SPECS or spec.source_id.startswith(("usfs_", "blm_", "nps_", "usgs_")):
        return "Federal"
    return "State Sources"


def legacy_group_for_spec(spec: SupplementalSpec) -> str:
    if spec.source_id.startswith("usfs_"): return "usfs"
    if spec.source_id.startswith("blm_"): return "blm"
    if spec.source_id.startswith("nps_"): return "nps"
    if spec.source_id.startswith("usgs_"): return "usgs"
    if spec.role == "public_road_authority": return "state_dot"
    return "state_recreation"


def _state_source_entries(source_settings: dict[str, Any]) -> dict[str, Any] | None:
    if isinstance(source_settings.get("sources"), dict):
        # r10 per-state configuration: {preset, sources:{actual_source_id:{...}}}
        return source_settings.get("sources") or {}
    # Also accept a direct actual-source-id mapping for tests/callers.
    known = {s.source_id for st in STATES.values() for s in all_available_specs_for_state(st)}
    if any(k in known for k in source_settings):
        return source_settings
    return None


def all_specs_for_state(state: StateInfo, source_settings: dict[str, Any]) -> list[SupplementalSpec]:
    """Resolve enabled specs and user endpoint overrides for one state.

    Supports both the r10 state-scoped schema and the legacy r9 global group schema.
    """
    entries = _state_source_entries(source_settings)
    result: list[SupplementalSpec] = []
    for spec in all_available_specs_for_state(state):
        if entries is not None:
            entry = entries.get(spec.source_id) or {}
            enabled = bool(entry.get("enabled", False))
            override = str(entry.get("endpoint_override") or "").strip()
        else:
            group = legacy_group_for_spec(spec)
            enabled = bool((source_settings.get(group) or {}).get("enabled", True))
            override = ""
        if not enabled:
            continue
        result.append(replace(spec, layer_url=override or spec.layer_url))
    return result

def fetch_supplemental_sources(state: StateInfo, boundary_path: Path,
                               target_dir: Path, source_settings: dict[str, Any],
                               max_workers: int = 3, per_host_limit: int = 2,
                               progress: Callable[[dict[str, Any]], None] | None = None) -> list[dict[str, Any]]:
    target_dir.mkdir(parents=True, exist_ok=True)
    boundary = load_geofabrik_boundary(boundary_path)
    boundary_sha = sha256_file(boundary_path)
    bboxes = state_query_bboxes(boundary, state.code)
    prior_manifest = {}
    prior_path = target_dir / "sources.json"
    if prior_path.is_file():
        try:
            prior_manifest = json.loads(prior_path.read_text(encoding="utf-8"))
        except Exception:
            prior_manifest = {}
    prior_by_id = {str(x.get("source_id")): x for x in prior_manifest.get("sources", []) if isinstance(x, dict)}
    specs = all_specs_for_state(state, source_settings)
    host_locks: dict[str, threading.Semaphore] = {}
    host_guard = threading.Lock()

    def host_sem(url: str) -> threading.Semaphore:
        host = urllib.parse.urlparse(url).netloc.lower() or "unknown"
        with host_guard:
            return host_locks.setdefault(host, threading.Semaphore(max(1, int(per_host_limit))))

    def fetch_one(index_spec: tuple[int, SupplementalSpec]) -> tuple[int, dict[str, Any]]:
        index, spec = index_spec
        target = target_dir / spec.file_name
        where = spec.where_factory(state) if spec.where_factory else "1=1"
        started = time.monotonic()
        if progress:
            progress({"event": "source_started", "source_id": spec.source_id, "name": spec.name,
                      "url": spec.layer_url, "index": index, "total_sources": len(specs)})
        try:
            with host_sem(spec.layer_url):
                meta = arcgis_download(
                    spec.layer_url,
                    target,
                    where=where,
                    bboxes=bboxes if spec.bbox_filter else None,
                    normalize=spec.normalizer,
                    clip_boundary=boundary,
                    stream_ndjson=spec.streaming,
                )
            descriptor = {
                "source_id": spec.source_id,
                "name": spec.name,
                "role": spec.role,
                "routable_candidate": spec.routable,
                "state": state.code,
                "file": target.name,
                "status": "downloaded",
                "applied_to_graph": False,
                "boundary_sha256": boundary_sha,
                "endpoint": spec.layer_url,
                "profile_revision": spec.profile_revision,
                **meta,
            }
        except Exception as exc:
            prior = prior_by_id.get(spec.source_id) or {}
            cache_matches_boundary = str(prior.get("boundary_sha256") or "") == boundary_sha
            cache_matches_profile = str(prior.get("profile_revision") or "") == str(spec.profile_revision or "")
            if target.is_file() and target.stat().st_size > 0 and cache_matches_boundary and cache_matches_profile:
                descriptor = {
                    **prior,
                    "source_id": spec.source_id,
                    "name": spec.name,
                    "role": spec.role,
                    "routable_candidate": spec.routable,
                    "state": state.code,
                    "file": target.name,
                    "status": "cached",
                    "stale": True,
                    "applied_to_graph": False,
                    "boundary_sha256": boundary_sha,
                    "endpoint": spec.layer_url,
                    "profile_revision": spec.profile_revision,
                    "error": str(exc),
                    "checked_utc": utcnow(),
                }
            else:
                descriptor = {
                    "source_id": spec.source_id,
                    "name": spec.name,
                    "role": spec.role,
                    "routable_candidate": spec.routable,
                    "state": state.code,
                    "file": target.name,
                    "status": "error",
                    "applied_to_graph": False,
                    "boundary_sha256": boundary_sha,
                    "endpoint": spec.layer_url,
                    "profile_revision": spec.profile_revision,
                    "error": str(exc),
                    "checked_utc": utcnow(),
                }
        if progress:
            progress({"event": "source_finished", "source_id": spec.source_id, "name": spec.name,
                      "url": spec.layer_url, "status": descriptor.get("status"),
                      "feature_count": descriptor.get("feature_count", 0),
                      "duration_seconds": round(time.monotonic() - started, 3),
                      "index": index, "total_sources": len(specs)})
        return index, descriptor

    workers = max(1, min(6, int(max_workers or 1)))
    indexed: list[tuple[int, dict[str, Any]]] = []
    if len(specs) <= 1 or workers <= 1:
        indexed = [fetch_one(pair) for pair in enumerate(specs)]
    else:
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers, thread_name_prefix="takrig-source") as pool:
            futures = [pool.submit(fetch_one, pair) for pair in enumerate(specs)]
            for future in concurrent.futures.as_completed(futures):
                indexed.append(future.result())
    descriptors = [d for _, d in sorted(indexed, key=lambda item: item[0])]
    atomic_json(target_dir / "sources.json", {"state": state.code, "generated_utc": utcnow(), "sources": descriptors})
    return descriptors


def source_public_summary() -> list[dict[str, Any]]:
    return [
        {"id": "osm", "name": "OpenStreetMap / Geofabrik", "role": "Base Network", "default_enabled": True, "locked": True,
         "description": "Primary connected roads/highways topology for every state."},
        {"id": "state_dot", "name": "State DOT / statewide roads", "role": "Public Road Authority", "default_enabled": True,
         "description": "State public-road validation/enrichment where a vetted state adapter is available."},
        {"id": "usfs", "name": "U.S. Forest Service MVUM", "role": "Legal Off-Road", "default_enabled": True,
         "description": "Designated motorized Forest Service roads/trails and seasonal/vehicle restrictions."},
        {"id": "blm", "name": "Bureau of Land Management GTLF", "role": "Legal Off-Road", "default_enabled": True,
         "description": "Public and limited-public motorized BLM roads/trails."},
        {"id": "state_recreation", "name": "State Parks / OHV / SVRA", "role": "State Recreation Authority", "default_enabled": True,
         "description": "State-managed public roads and legal motorized recreation routes where vetted data is available."},
        {"id": "nps", "name": "National Park Service", "role": "Legal Off-Road / Supplemental", "default_enabled": True,
         "description": "Public park roads plus public trails when NPS attributes explicitly establish full-size motor-vehicle use."},
        {"id": "usgs", "name": "USGS National Transportation", "role": "4WD Gap Fill / Reference", "default_enabled": True,
         "description": "USGS 4WD Roads are routable high-clearance gap fill; generic USGS trails remain reference-only."},
    ]
