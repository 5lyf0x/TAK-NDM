#!/usr/bin/env python3
"""FCC BDC mobile coverage discovery/download helpers for TAK Rig NDM."""
from __future__ import annotations

import contextlib
import datetime as dt
import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Iterable, Sequence

VERSION = "0.2.0-r16-r29"
DEFAULT_API_BASES = (
    "https://broadbandmap.fcc.gov/api/public/map",
    "https://bdc.fcc.gov/api/public/map",
)

STATE_FIPS = {
    "AL":"01","AK":"02","AZ":"04","AR":"05","CA":"06","CO":"08","CT":"09","DE":"10","FL":"12","GA":"13",
    "HI":"15","ID":"16","IL":"17","IN":"18","IA":"19","KS":"20","KY":"21","LA":"22","ME":"23","MD":"24",
    "MA":"25","MI":"26","MN":"27","MS":"28","MO":"29","MT":"30","NE":"31","NV":"32","NH":"33","NJ":"34",
    "NM":"35","NY":"36","NC":"37","ND":"38","OH":"39","OK":"40","OR":"41","PA":"42","RI":"44","SC":"45",
    "SD":"46","TN":"47","TX":"48","UT":"49","VT":"50","VA":"51","WA":"53","WV":"54","WI":"55","WY":"56",
}

CARRIER_ALIASES = {
    "att": ("at&t", "att mobility", "at and t", "new cingular wireless", "cingular wireless"),
    "verizon": ("verizon", "cellco partnership", "verizon communications"),
    "tmobile": ("t-mobile", "t mobile", "tmobile", "t-mobile usa", "t mobile usa"),
}
# Current major-carrier BDC holding-company/provider IDs. Brand-name/provider metadata
# remain authoritative when present; these IDs make official provider-specific H3
# downloads self-classifying even when the reduced H3 table omits brandname.
KNOWN_MAJOR_PROVIDER_IDS = {
    "130077": "att",
    "130403": "tmobile",
    "131425": "verizon",
}

class CredentialsMissing(RuntimeError): pass
class FccApiError(RuntimeError): pass


def utcnow() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()


def load_env_file(path: Path) -> dict[str,str]:
    out: dict[str,str]={}
    if not path.is_file(): return out
    for raw in path.read_text(encoding="utf-8",errors="replace").splitlines():
        line=raw.strip()
        if not line or line.startswith("#") or "=" not in line: continue
        k,v=line.split("=",1); v=v.strip().strip('"').strip("'")
        out[k.strip()]=v
    return out


def _paths(value: Path | str | Iterable[Path | str]) -> list[Path]:
    if isinstance(value,(str,Path)): return [Path(value)]
    return [Path(x) for x in value]


def _placeholder_credentials(user:str,token:str)->bool:
    u=str(user or "").strip().lower(); t=str(token or "").strip().lower()
    if not u or not t:return True
    if u.startswith("your-fcc-") or t.startswith("your-fcc-"):return True
    if u in {"username","email","example@example.com","your-fcc-account-email"}:return True
    if t in {"token","api-token","api_token","hash-value","hash_value","your-fcc-api-token"}:return True
    return False


def credentials(paths: Path | str | Iterable[Path | str]) -> tuple[str,str,Path|None]:
    # Explicit process env has highest precedence, then configured paths in order.
    # Shipped/example values are never considered valid credentials.
    env_user=(os.environ.get("FCC_BDC_USERNAME") or "").strip()
    env_token=(os.environ.get("FCC_BDC_HASH_VALUE") or "").strip()
    if not _placeholder_credentials(env_user,env_token): return env_user,env_token,None
    for path in _paths(paths):
        env=load_env_file(path)
        user=(env.get("FCC_BDC_USERNAME") or "").strip(); token=(env.get("FCC_BDC_HASH_VALUE") or "").strip()
        if not _placeholder_credentials(user,token): return user,token,path
    joined=", ".join(str(p) for p in _paths(paths))
    raise CredentialsMissing(f"FCC BDC API credentials are not configured ({joined})")


def credentials_status(paths: Path | str | Iterable[Path | str]) -> dict[str,Any]:
    try:
        user,token,path=credentials(paths)
        return {"configured":True,"username":user,"credential_source":"environment" if path is None else str(path),"token_last4":token[-4:] if len(token)>=4 else ""}
    except CredentialsMissing:
        return {"configured":False,"username":"","credential_source":"","token_last4":""}


def _response_data(obj: Any) -> Any:
    if isinstance(obj,dict) and "data" in obj: return obj.get("data")
    return obj


class BdcClient:
    def __init__(self, credentials_files: Path | str | Iterable[Path | str] | None=None,
                 api_bases: Iterable[str] | None=None, timeout: int=30,
                 *, username: str="", hash_value: str=""):
        if username and hash_value:
            self.username,self.hash_value=str(username).strip(),str(hash_value).strip()
        else:
            if credentials_files is None: raise CredentialsMissing("FCC BDC API credentials were not supplied")
            self.username,self.hash_value,_=credentials(credentials_files)
        self.api_bases=tuple(str(x).rstrip("/") for x in (api_bases or DEFAULT_API_BASES))
        self.timeout=max(5,int(timeout)); self.active_base=""

    def _headers(self) -> dict[str,str]:
        return {"username":self.username,"hash_value":self.hash_value,
                "User-Agent":f"TAK-Rig-NDM-Cellular/{VERSION}","Accept":"application/json"}

    def _ordered_bases(self) -> tuple[str,...]:
        rows=[]
        if self.active_base: rows.append(self.active_base)
        rows.extend(self.api_bases); out=[]
        for row in rows:
            row=str(row or "").rstrip("/")
            if row and row not in out: out.append(row)
        return tuple(out)

    @staticmethod
    def _retry_delay(exc: Exception, attempt: int) -> float:
        if isinstance(exc, urllib.error.HTTPError):
            value=str(exc.headers.get("Retry-After") or "").strip()
            with contextlib.suppress(Exception): return max(0.5,min(60.0,float(value)))
        return min(8.0,0.75*(2**attempt))

    def request_json(self,path:str,params:dict[str,Any]|None=None) -> Any:
        errors=[]
        for base in self._ordered_bases():
            url=base+"/"+path.lstrip("/")
            if params: url += "?"+urllib.parse.urlencode({k:v for k,v in params.items() if v not in (None,"")})
            for attempt in range(3):
                try:
                    req=urllib.request.Request(url,headers=self._headers())
                    with urllib.request.urlopen(req,timeout=self.timeout) as resp: raw=resp.read(64*1024*1024)
                    obj=json.loads(raw.decode("utf-8"))
                    if isinstance(obj,dict) and int(obj.get("status_code") or 200)>=400:
                        raise FccApiError(str(obj.get("message") or obj.get("status") or "FCC API failure"))
                    self.active_base=base; return obj
                except Exception as exc:
                    errors.append(f"{base} attempt {attempt+1}: {exc}")
                    if attempt<2: time.sleep(self._retry_delay(exc,attempt))
            self.active_base=""
        raise FccApiError("FCC BDC API request failed: "+"; ".join(errors[-8:]))

    def list_as_of_dates(self) -> list[str]:
        obj=self.request_json("listAsOfDates"); data=_response_data(obj); dates=set()
        if isinstance(data,list):
            for row in data:
                if not isinstance(row,dict): continue
                kind=str(row.get("data_type") or row.get("type") or "availability").strip().lower()
                if kind and kind!="availability": continue
                value=str(row.get("as_of_date") or row.get("asOfDate") or row.get("date") or "")
                dates.update(re.findall(r"20\d{2}-\d{2}-\d{2}",value))
        if not dates: dates.update(re.findall(r"20\d{2}-\d{2}-\d{2}",json.dumps(data)))
        return sorted(dates)

    def list_availability(self,as_of:str) -> list[dict[str,Any]]:
        # FCC mobile coverage is provider-specific. Query the Provider catalog,
        # not the State aggregate catalog, so carrier identity is present.
        merged=[]; seen=set()
        for technology_type in ("Mobile Broadband","Mobile Voice"):
            obj=self.request_json(
                f"downloads/listAvailabilityData/{as_of}",
                params={"category":"Provider","technology_type":technology_type},
            )
            rows=_response_data(obj)
            if isinstance(rows,dict):
                rows=rows.get("results") or rows.get("items") or rows.get("files") or []
            if not isinstance(rows,list):
                raise FccApiError("FCC availability manifest did not contain a file list")
            for row in rows:
                if not isinstance(row,dict): continue
                key=str(_field(row,"file_id","fileid","id","download_id")
                        or json.dumps(row,sort_keys=True,default=str))
                if key in seen: continue
                seen.add(key); merged.append(row)
        return merged

    def download_file(self,file_id: Any,target: Path,file_type:int=2,progress=None) -> Path:
        # FCC Public Data API file_type 2 = GeoPackage. H3-vs-Raw is represented
        # by the selected manifest row/file ID, not by file_type.
        target.parent.mkdir(parents=True,exist_ok=True); part=target.with_suffix(target.suffix+".part"); errors=[]
        for base in self._ordered_bases():
            url=base+f"/downloads/downloadFile/availability/{urllib.parse.quote(str(file_id))}/{int(file_type)}"
            for attempt in range(3):
                try:
                    existing=part.stat().st_size if part.is_file() else 0
                    headers=self._headers(); headers["Accept"]="application/octet-stream"
                    if existing>0: headers["Range"]=f"bytes={existing}-"
                    req=urllib.request.Request(url,headers=headers)
                    with urllib.request.urlopen(req,timeout=max(self.timeout,300)) as resp:
                        status=int(getattr(resp,"status",200) or 200); append=existing>0 and status==206
                        if existing>0 and not append: existing=0
                        length=int(resp.headers.get("Content-Length") or 0); total=(existing+length) if length else 0
                        mode="ab" if append else "wb"; done=existing; started=time.time()
                        with part.open(mode) as out:
                            while True:
                                block=resp.read(2*1024*1024)
                                if not block: break
                                out.write(block); done+=len(block)
                                if progress: progress(done,total,max(0.001,time.time()-started))
                    if part.stat().st_size<=0: raise FccApiError("FCC download returned an empty file")
                    os.replace(part,target); self.active_base=base; return target
                except Exception as exc:
                    errors.append(f"{base} attempt {attempt+1}: {exc}")
                    if part.is_file() and part.stat().st_size==0: part.unlink(missing_ok=True)
                    if attempt<2: time.sleep(self._retry_delay(exc,attempt))
            self.active_base=""
        raise FccApiError("FCC file download failed: "+"; ".join(errors[-8:]))


def _norm_text(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+"," ",str(value or "").lower()).strip()

def _flat_text(row: dict[str,Any]) -> str:
    return " ".join(_norm_text(v) for v in row.values() if isinstance(v,(str,int,float)))

def _field(row:dict[str,Any],*names:str) -> Any:
    low={str(k).lower():v for k,v in row.items()}
    for name in names:
        if name.lower() in low: return low[name.lower()]
    return None

def _state_matches(row:dict[str,Any],code:str) -> bool:
    code=code.upper(); fips=STATE_FIPS.get(code,"")
    vals=[_field(row,"state","state_abbr","state_code","state_abbreviation","state_usps"),
          _field(row,"state_fips","statefips")]
    if any(str(v or "").upper()==code for v in vals): return True
    if any(str(v or "").zfill(2)==fips for v in vals if str(v or "").isdigit()): return True
    names={"AZ":"arizona","CA":"california","UT":"utah"}
    state_name=_norm_text(_field(row,"state_name","statename","geography_name","geography") or "")
    if state_name and state_name==names.get(code,""): return True
    text=_flat_text(row)
    return f" {code.lower()} " in f" {text} "

def carrier_from_text(value: Any) -> str|None:
    text=_norm_text(value)
    for carrier,aliases in CARRIER_ALIASES.items():
        if any(_norm_text(alias) in text for alias in aliases): return carrier
    return None

def carrier_from_provider_id(value: Any) -> str|None:
    return KNOWN_MAJOR_PROVIDER_IDS.get(str(value or "").strip())

def _carrier_matches(row:dict[str,Any],carrier:str) -> bool:
    pid=str(_field(row,"provider_id","providerid","provider") or "").strip()
    if carrier_from_provider_id(pid)==carrier: return True
    return carrier_from_text(_flat_text(row))==carrier

def _is_mobile(row:dict[str,Any]) -> bool:
    text=_flat_text(row)
    return "mobile" in text or any(t in text for t in ("5g","lte","3g","voice"))

def classify_row(row:dict[str,Any]) -> str|None:
    text=_flat_text(row); tech=str(_field(row,"technology","technology_code","tech_code","technologycode") or "").strip()
    if "voice" in text and "broadband" not in text: return "voice"
    if tech=="300" or " 3g " in f" {text} ": return "3g"
    if tech=="400" or " lte " in f" {text} " or "4g lte" in text: return "lte"
    if tech=="500" or "5g" in text: return "5g"
    if "mobile voice" in text or text.endswith(" voice") or " voice " in f" {text} ": return "voice"
    return None

def classify_variant(row:dict[str,Any],klass:str|None=None) -> str|None:
    klass=klass or classify_row(row)
    if klass in {"voice","3g","lte"}: return klass
    if klass!="5g": return None
    down=_field(row,"mindown","min_down","minimum_download_speed","download_speed","min_download","download_mbps")
    up=_field(row,"minup","min_up","minimum_upload_speed","upload_speed","min_upload","upload_mbps")
    speed_tier=_norm_text(_field(row,"speed_tier","speedtier","speed") or "")
    try:
        d=float(down);u=float(up)
        if abs(d-7.0)<1e-6 and abs(u-1.0)<1e-6:return "5g_7_1"
        if abs(d-35.0)<1e-6 and abs(u-3.0)<1e-6:return "5g_35_3"
    except (TypeError,ValueError):
        pass
    text=_norm_text(" ".join(str(v) for v in row.values()))
    tier_text=(text+" "+speed_tier).strip()
    if re.search(r"5g(?:\s*nr)?\s+7\s+1(?:\s|$)",tier_text) or re.search(r"(?:^|\s)7\s+1(?:\s|$)",speed_tier):return "5g_7_1"
    if re.search(r"5g(?:\s*nr)?\s+35\s+3(?:\s|$)",tier_text) or re.search(r"(?:^|\s)35\s+3(?:\s|$)",speed_tier):return "5g_35_3"
    return None

def _hex_score(row:dict[str,Any]) -> int:
    text=_flat_text(row); score=0
    if "h3" in text or "hexagon" in text or "hexagonal" in text: score+=40
    if "raw coverage" in text or " raw " in f" {text} ": score-=60
    if "geopackage" in text or "gpkg" in text: score+=4
    if "provider" in text: score+=1
    return score

def select_mobile_sources(rows:list[dict[str,Any]],state_code:str, carriers:Sequence[str]|None=None) -> dict[str,list[dict[str,Any]]]:
    """Return provider-specific FCC H3 rows for all applicable technologies, retaining both 5G tiers."""
    requested=tuple(c for c in (carriers or CARRIER_ALIASES.keys()) if c in CARRIER_ALIASES)
    variants=("voice","3g","lte","5g_7_1","5g_35_3")
    out={c:{k:[] for k in variants} for c in requested}
    for row in rows:
        if not _state_matches(row,state_code) or not _is_mobile(row): continue
        klass=classify_row(row);variant=classify_variant(row,klass)
        if klass not in {"voice","3g","lte","5g"} or variant not in variants: continue
        for carrier in requested:
            if _carrier_matches(row,carrier): out[carrier][variant].append(row)
    final: dict[str,list[dict[str,Any]]]={}
    for carrier,groups in out.items():
        chosen=[]
        for variant,items in groups.items():
            if not items: continue
            best=max(_hex_score(r) for r in items)
            if best<=0: continue
            for row in items:
                if _hex_score(row)==best:
                    copy=dict(row); copy["_takrig_variant"]=variant; copy["_takrig_class"]="5g" if variant.startswith("5g_") else variant; chosen.append(copy)
        final[carrier]=chosen
    return final

def row_file_id(row:dict[str,Any]) -> str:
    value=_field(row,"file_id","fileid","id","download_id")
    if value in (None,""): raise FccApiError(f"FCC manifest row is missing file_id: {row}")
    return str(value)

def row_provider_id(row:dict[str,Any]) -> str:
    return str(_field(row,"provider_id","providerid","provider") or "")

def row_provider_name(row:dict[str,Any]) -> str:
    return str(_field(row,"provider_name","provided_name","providername","brand_name","brandname","holding_company_name","holdingcompanyname") or "")

def row_file_name(row:dict[str,Any]) -> str:
    return str(_field(row,"file_name","filename","name") or f"fcc-{row_file_id(row)}.zip")
