#!/usr/bin/env python3
from __future__ import annotations

from dataclasses import dataclass

@dataclass(frozen=True)
class StateInfo:
    code: str
    name: str
    geofabrik_slug: str

# Geofabrik uses lowercase hyphenated state names for US state extracts.
_STATE_ROWS = [
    ("AL", "Alabama", "alabama"), ("AK", "Alaska", "alaska"),
    ("AZ", "Arizona", "arizona"), ("AR", "Arkansas", "arkansas"),
    ("CA", "California", "california"), ("CO", "Colorado", "colorado"),
    ("CT", "Connecticut", "connecticut"), ("DE", "Delaware", "delaware"),
    ("FL", "Florida", "florida"), ("GA", "Georgia", "georgia"),
    ("HI", "Hawaii", "hawaii"), ("ID", "Idaho", "idaho"),
    ("IL", "Illinois", "illinois"), ("IN", "Indiana", "indiana"),
    ("IA", "Iowa", "iowa"), ("KS", "Kansas", "kansas"),
    ("KY", "Kentucky", "kentucky"), ("LA", "Louisiana", "louisiana"),
    ("ME", "Maine", "maine"), ("MD", "Maryland", "maryland"),
    ("MA", "Massachusetts", "massachusetts"), ("MI", "Michigan", "michigan"),
    ("MN", "Minnesota", "minnesota"), ("MS", "Mississippi", "mississippi"),
    ("MO", "Missouri", "missouri"), ("MT", "Montana", "montana"),
    ("NE", "Nebraska", "nebraska"), ("NV", "Nevada", "nevada"),
    ("NH", "New Hampshire", "new-hampshire"), ("NJ", "New Jersey", "new-jersey"),
    ("NM", "New Mexico", "new-mexico"), ("NY", "New York", "new-york"),
    ("NC", "North Carolina", "north-carolina"), ("ND", "North Dakota", "north-dakota"),
    ("OH", "Ohio", "ohio"), ("OK", "Oklahoma", "oklahoma"),
    ("OR", "Oregon", "oregon"), ("PA", "Pennsylvania", "pennsylvania"),
    ("RI", "Rhode Island", "rhode-island"), ("SC", "South Carolina", "south-carolina"),
    ("SD", "South Dakota", "south-dakota"), ("TN", "Tennessee", "tennessee"),
    ("TX", "Texas", "texas"), ("UT", "Utah", "utah"),
    ("VT", "Vermont", "vermont"), ("VA", "Virginia", "virginia"),
    ("WA", "Washington", "washington"), ("WV", "West Virginia", "west-virginia"),
    ("WI", "Wisconsin", "wisconsin"), ("WY", "Wyoming", "wyoming"),
]

STATES = {code: StateInfo(code, name, slug) for code, name, slug in _STATE_ROWS}

PRESETS = {
    "southwest": ["AZ", "CA", "CO", "NV", "NM", "UT"],
    "west": ["AK", "AZ", "CA", "CO", "HI", "ID", "MT", "NV", "NM", "OR", "UT", "WA", "WY"],
    "all": list(STATES.keys()),
}

def validate_states(values: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        code = str(value).strip().upper()
        if code not in STATES:
            raise ValueError(f"Unknown US state code: {value}")
        if code not in seen:
            seen.add(code)
            out.append(code)
    return out
