# TAK Rig Navigation Data Manager v0.2.0-r16-r15

- Adds UDP/47818 TAK Rig auto-discovery with unicast replies.
- Advertises a stable NDM identity, display name, HTTP port, release version, and Navigation/Elevation/Cellular capabilities.
- Persists discovery identity under the configured state root so DHCP address changes retain the same logical NDM.
- Existing HTTP API, package formats, routing pipeline revision, and manual addressing remain unchanged.
