# TAK Rig Navigation Data Manager v0.2.0-r16-r4

## Scope

r16-r4 is a focused Outdoors Map Creator polygon-completion correction built on the validated r16-r3 manager-concurrency, red-coverage, and geometry-aware estimate baseline. It intentionally preserves `ROUTING_PIPELINE_REVISION = "0.2.0-r16"`.

## Polygon completion correction

- Polygon completion no longer depends on the browser successfully synthesizing a native `dblclick` while NDM redraws the provisional Leaflet layer between clicks.
- Once three committed vertices exist, the first vertex is highlighted with a red closure target. Clicking within the closure target finishes the polygon.
- `FINISH POLYGON` is displayed while Polygon mode is active and becomes enabled after three committed vertices. It provides an explicit guaranteed completion path.
- Double-click remains supported. NDM now recognizes it with its own time-and-screen-distance gesture detector before relying on Leaflet/browser `dblclick` behavior.
- The second click of a detected double-click finishes the polygon without adding a duplicate vertex.
- Native Leaflet `dblclick` remains as an additional fallback with map double-click zoom disabled.
- The creator instructions and incomplete-polygon warning now list all three completion methods.

## Preserved r16-r3 behavior

- Rectangle and Polygon outlines remain bright red with translucent red coverage shading.
- Mouse-position provisional Polygon/Rectangle shading and live size estimates remain enabled.
- Polygon estimates continue to use actual geometry rather than bounding-box area.
- Manager state read/modify/write locking, UUID atomic temp files, and serialized supplemental-source progress remain unchanged.
- Local Leaflet assets, preview tile proxy/cache, routing/terrain package formats, Valhalla 3.6.3, and Android package delivery contracts remain unchanged.

## Compatibility

- `ROUTING_PIPELINE_REVISION` remains `0.2.0-r16`; installing r16-r4 does not intentionally force current r16 routing packages to rebuild.
- Existing ready routing, terrain, and Outdoors packages are preserved by the installer.
- Existing operator configuration, including source-download concurrency, is preserved.
