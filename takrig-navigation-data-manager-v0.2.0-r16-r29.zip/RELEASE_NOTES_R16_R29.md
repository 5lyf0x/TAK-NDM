# TAK Rig Navigation Data Manager v0.2.0-r16-r29

## Changes from r28

1. Four-cell concurrent USGS 3DEP downloading; one SQLite writer; recoverable 502/503/504 errors via smaller raster exports and adaptive worker backoff.
2. 30 m unfinished terrain resumes independently of existing published 90 m terrain. Stale QUEUED state no longer permanently blocks normal Build.
3. Navigation, Elevation, and Cell Coverage each have a Pause/Resume control, persisted per state and per domain; pause is cooperative and may take an in-flight operation to finish.
4. Completed NAV/FCC input work and raster SQLite commits are preserved. NAV's Valhalla graph compilation is stage-granular rather than individually resumable.
5. No deletion or migration of user configuration, credentials, state databases, cached inputs, existing ZIP packages or local state imagery.

## Installation notes

- Install on Linux using `unzip` into a new versioned folder and `sudo ./install.sh`.
- If a legacy manual `/tmp/ndm-ca-resume30.py` process or another background NDM worker is still active, the installer refuses to overwrite source code. Wait for a safe stop before installing. Pausing via the new WebUI is available after installation.
- Pause/Resume is designed for long-running work, not an immediate OS-level SIGSTOP. An active raster or Valhalla stage may need to complete before PAUSED appears.
- Terrain and FCC API behavior has been validated with synthetic fixtures and regression tests; live USGS/FCC traffic and in-place upgrade on the user gateway have not been tested in this container.
