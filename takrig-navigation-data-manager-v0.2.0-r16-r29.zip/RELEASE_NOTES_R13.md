TAK Rig Navigation Data Manager v0.2.0-r14

3D Terrain Data release

- Adds optional per-state 3D Terrain packages alongside existing Valhalla Navigation Data.
- Uses the authoritative USGS 3DEP Bare Earth DEM Dynamic ImageServer as the elevation source.
- Targets a nominal 3 arc-second / ~90 m sample grid for the initial mobile terrain release.
- Stores terrain in a random-access SQLite tile database using zlib-compressed little-endian Int16 elevation grids.
- Publishes terrain status, version, size, resolution and download URL through the existing catalog API.
- Adds independent Build/Rebuild/Remove 3D Terrain controls in the NDM web UI.
- Adds HTTP Range/If-Range support for terrain package downloads.
- Terrain remains independent from routing packages and can be updated or removed without touching Valhalla data.
- Installer adds GDAL tooling required to decode USGS GeoTIFF exports and preserves existing NDM state/packages during upgrade.

Version: v0.2.0-r14
