# NDM v0.2.0-r16-r29 — Validation

## Scope and preservation

- Source base: intact r28 release source. Retained Executive Slate, the centered fixed-card layout, the 50 locally served WebP state hero images, routing pipeline revision `0.2.0-r16`, and existing package formats.
- Four concurrent USGS 3DEP cell requests; single SQLite writer. Aligned four-part subrequests on repeated HTTP 502/503/504 failures, bounded cell retries with worker reduction 4 → 2 → 1.
- Non-forced build can resume an unfinished 30 m SQLite work database even when a completed 90 m terrain package exists; publication occurs only after the new package validates. No install-time deletion of terrain work or cached state data.
- Navigation, Elevation, and Cellular cards have independent persistent pause markers and matching Pause/Resume APIs; running workers checkpoint cooperatively.
- Installer preflight rejects active legacy manual recovery workers; existing config, secrets, sources, downloaded ZIPs, source caches, and established state are preserved.

## Automated checks

- Full Python unit/regression suite: **140/140 PASS** from staged source (includes HTTP pause/resume, persisted state, stale queue, old-package preservation, 502/503/504 synthetic fallback tests).
- Python module compile, shell `bash -n`, and WebUI inline JavaScript `node --check`: PASS.
- ZIP CRC/structure, clean fresh extraction and byte-for-byte source equivalence: PASS.
- Fresh-extraction full Python unit/regression suite: **140/140 PASS**.
- All 50 state image WebP assets and two local data-card artwork files: preserved, without image updates in r29.

## Not validated by these tests

- Live USGS/FCC downloads, multi-gigabyte 30 m California completion, performance of concurrent upstream requests, native Valhalla stage-level checkpointing, or installation on the user's currently running gateway.
- Pausing is cooperative, not instant. Already-running USGS requests or a native Valhalla step may need to finish before the PAUSED state is reached.
- The older 90 m package is retained during the interrupted 30 m build, then replaced at successful publication of the 30 m package using the same legacy filename.
