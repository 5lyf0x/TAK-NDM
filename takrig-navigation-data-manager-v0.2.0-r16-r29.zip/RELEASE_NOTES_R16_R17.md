# TAK Rig Navigation Data Manager v0.2.0-r16-r17

## Cinematic Environment v1

This release extends the existing optional 30 m WorldCover Environment package without changing its strict outer archive contract. Each Environment ZIP still contains only `manifest.json` and `environment.sqlite`, and the database schema identifier remains `takrig.environment.sqlite.v1` for compatibility.

The Environment builder now prepares a versioned `cinematic-environment-v1` static asset set and stores it inside optional SQLite tables. The asset set contains the user-approved 35 photographic ground materials, 9 tree-source families rendered as lightweight front/side/top impostor views, material-pool metadata, and runtime physical-scale hints. Source assets are acquired from Poly Haven's public API/CDN and cached once under the Environment cache so successive state builds reuse them. The NDM web UI includes a visible `Powered by Poly Haven` credit. Poly Haven asset content is CC0.

The photographic assets are fail-soft: if the source service is unavailable, a state build still produces a valid classification-only Environment package and reports `cinematic_assets_included=false`. TAK Rig can then retain its procedural fallback instead of losing 3D functionality.

The routing pipeline revision remains `0.2.0-r16`; installing this release does not intentionally rebuild existing Navigation graphs.
